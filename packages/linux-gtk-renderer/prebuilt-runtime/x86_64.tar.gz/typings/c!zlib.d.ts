
declare const MAX_MEM_LEVEL: number;

declare const MAX_WBITS: number;

declare const ZLIB_VERNUM: number;

declare const ZLIB_VERSION: string;

declare const ZLIB_VER_MAJOR: number;

declare const ZLIB_VER_MINOR: number;

declare const ZLIB_VER_REVISION: number;

declare const ZLIB_VER_SUBREVISION: number;

declare const Z_ASCII: number;

declare const Z_BEST_COMPRESSION: number;

declare const Z_BEST_SPEED: number;

declare const Z_BINARY: number;

declare const Z_BLOCK: number;

declare const Z_BUF_ERROR: number;

declare const Z_DATA_ERROR: number;

declare const Z_DEFAULT_COMPRESSION: number;

declare const Z_DEFAULT_STRATEGY: number;

declare const Z_DEFLATED: number;

declare const Z_ERRNO: number;

declare const Z_FILTERED: number;

declare const Z_FINISH: number;

declare const Z_FIXED: number;

declare const Z_FULL_FLUSH: number;

declare const Z_HUFFMAN_ONLY: number;

declare const Z_MEM_ERROR: number;

declare const Z_NEED_DICT: number;

declare const Z_NO_COMPRESSION: number;

declare const Z_NO_FLUSH: number;

declare const Z_NULL: number;

declare const Z_OK: number;

declare const Z_PARTIAL_FLUSH: number;

declare const Z_RLE: number;

declare const Z_STREAM_END: number;

declare const Z_STREAM_ERROR: number;

declare const Z_SYNC_FLUSH: number;

declare const Z_TEXT: number;

declare const Z_TREES: number;

declare const Z_UNKNOWN: number;

declare const Z_VERSION_ERROR: number;

declare function adler32(adler: number, buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function adler32_combine(p1: number, p2: number, p3: number): number;

declare function adler32_z(adler: number, buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function compress(dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, destLen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, source: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sourceLen: number): number;

declare function compress2(dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, destLen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, source: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sourceLen: number, level: number): number;

declare function compressBound(sourceLen: number): number;

declare function crc32(crc: number, buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function crc32_combine(p1: number, p2: number, p3: number): number;

declare function crc32_combine_gen(p1: number): number;

declare function crc32_combine_op(crc1: number, crc2: number, op: number): number;

declare function crc32_z(crc: number, buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function deflate(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, flush: number): number;

declare function deflateBound(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, sourceLen: number): number;

declare function deflateCopy(dest: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, source: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null): number;

declare function deflateEnd(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null): number;

declare function deflateGetDictionary(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, dictionary: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, dictLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function deflateInit2_(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, level: number, method: number, windowBits: number, memLevel: number, strategy: number, version: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, stream_size: number): number;

declare function deflateInit_(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, level: number, version: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, stream_size: number): number;

declare function deflateParams(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, level: number, strategy: number): number;

declare function deflatePending(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, pending: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, bits: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function deflatePrime(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, bits: number, value: number): number;

declare function deflateReset(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null): number;

declare function deflateResetKeep(p1: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null): number;

declare function deflateSetDictionary(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, dictionary: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, dictLength: number): number;

declare function deflateSetHeader(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, head: interop.Pointer | interop.Reference<gz_header> | ArrayBufferLike | ArrayBufferView | null): number;

declare function deflateTune(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, good_length: number, max_lazy: number, nice_length: number, max_chain: number): number;

declare function get_crc_table(): interop.Pointer | interop.Reference<number> | null;

interface gzFile_s {
	have: number;
	next: interop.Pointer | interop.Reference<any> | null;
	pos: number;
}
declare var gzFile_s: interop.StructType<gzFile_s>;

interface gz_header {
	text: number;
	time: number;
	xflags: number;
	os: number;
	extra: interop.Pointer | interop.Reference<any> | null;
	extra_len: number;
	extra_max: number;
	name: interop.Pointer | interop.Reference<any> | null;
	name_max: number;
	comment: interop.Pointer | interop.Reference<any> | null;
	comm_max: number;
	hcrc: number;
	done: number;
}
declare var gz_header: interop.StructType<gz_header>;

declare function gzbuffer(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null, size: number): number;

declare function gzclearerr(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null): void;

declare function gzclose(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gzclose_r(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gzclose_w(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gzdirect(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gzdopen(fd: number, mode: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<gzFile_s> | null;

declare function gzeof(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gzerror(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null, errnum: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function gzflush(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null, flush: number): number;

declare function gzfread(buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, nitems: number, file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gzfwrite(buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, nitems: number, file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gzgetc(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gzgetc_(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gzgets(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null, buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): interop.Pointer | interop.Reference<any> | null;

declare function gzoffset(p1: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gzopen(p1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<gzFile_s> | null;

declare function gzprintf(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function gzputc(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null, c: number): number;

declare function gzputs(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null, s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gzread(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null, buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function gzrewind(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gzseek(p1: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function gzsetparams(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null, level: number, strategy: number): number;

declare function gztell(p1: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gzungetc(c: number, file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gzwrite(file: interop.Pointer | interop.Reference<gzFile_s> | ArrayBufferLike | ArrayBufferView | null, buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function inflate(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, flush: number): number;

declare function inflateBack(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, _in: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null) => number>, in_desc: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, out: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number) => number>, out_desc: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inflateBackEnd(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inflateBackInit_(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, windowBits: number, window: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, version: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, stream_size: number): number;

declare function inflateCodesUsed(p1: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inflateCopy(dest: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, source: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inflateEnd(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inflateGetDictionary(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, dictionary: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, dictLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inflateGetHeader(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, head: interop.Pointer | interop.Reference<gz_header> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inflateInit2_(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, windowBits: number, version: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, stream_size: number): number;

declare function inflateInit_(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, version: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, stream_size: number): number;

declare function inflateMark(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inflatePrime(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, bits: number, value: number): number;

declare function inflateReset(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inflateReset2(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, windowBits: number): number;

declare function inflateResetKeep(p1: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inflateSetDictionary(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, dictionary: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, dictLength: number): number;

declare function inflateSync(strm: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inflateSyncPoint(p1: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inflateUndermine(p1: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function inflateValidate(p1: interop.Pointer | interop.Reference<z_stream> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

interface internal_state {
}
declare var internal_state: interop.StructType<internal_state>;

declare function uncompress(dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, destLen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, source: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sourceLen: number): number;

declare function uncompress2(dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, destLen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, source: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sourceLen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function zError(p1: number): string | null;

interface z_stream {
	next_in: interop.Pointer | interop.Reference<any> | null;
	avail_in: number;
	total_in: number;
	next_out: interop.Pointer | interop.Reference<any> | null;
	avail_out: number;
	total_out: number;
	msg: interop.Pointer | interop.Reference<any> | null;
	state: interop.Pointer | interop.Reference<internal_state> | null;
	zalloc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: number, p3: number) => interop.Pointer | interop.Reference<any> | null>;
	zfree: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null) => void>;
	opaque: interop.Pointer | interop.Reference<any> | null;
	data_type: number;
	adler: number;
	reserved: number;
}
declare var z_stream: interop.StructType<z_stream>;

declare function zlibCompileFlags(): number;

declare function zlibVersion(): string | null;
