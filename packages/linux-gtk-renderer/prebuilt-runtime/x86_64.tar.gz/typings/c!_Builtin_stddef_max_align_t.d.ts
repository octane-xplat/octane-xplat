
interface max_align_t {
	__clang_max_align_nonce1: number;
	__clang_max_align_nonce2: number;
}
declare var max_align_t: interop.StructType<max_align_t>;
