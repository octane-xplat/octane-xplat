
declare const GL_3DC_XY_AMD: number;

declare const GL_3DC_X_AMD: number;

declare const GL_ACCUM_ADJACENT_PAIRS_NV: number;

declare const GL_ACTIVE_ATTRIBUTES: number;

declare const GL_ACTIVE_ATTRIBUTE_MAX_LENGTH: number;

declare const GL_ACTIVE_PROGRAM_EXT: number;

declare const GL_ACTIVE_TEXTURE: number;

declare const GL_ACTIVE_UNIFORMS: number;

declare const GL_ACTIVE_UNIFORM_BLOCKS: number;

declare const GL_ACTIVE_UNIFORM_BLOCK_MAX_NAME_LENGTH: number;

declare const GL_ACTIVE_UNIFORM_MAX_LENGTH: number;

declare const GL_ADJACENT_PAIRS_NV: number;

declare const GL_AFFINE_2D_NV: number;

declare const GL_AFFINE_3D_NV: number;

declare const GL_ALIASED_LINE_WIDTH_RANGE: number;

declare const GL_ALIASED_POINT_SIZE_RANGE: number;

declare const GL_ALL_COMPLETED_NV: number;

declare const GL_ALL_SHADER_BITS_EXT: number;

declare const GL_ALPHA: number;

declare const GL_ALPHA16F_EXT: number;

declare const GL_ALPHA32F_EXT: number;

declare const GL_ALPHA8_EXT: number;

declare const GL_ALPHA8_OES: number;

declare const GL_ALPHA_BITS: number;

declare const GL_ALPHA_TEST_FUNC_QCOM: number;

declare const GL_ALPHA_TEST_QCOM: number;

declare const GL_ALPHA_TEST_REF_QCOM: number;

declare const GL_ALREADY_SIGNALED: number;

declare const GL_ALREADY_SIGNALED_APPLE: number;

declare const GL_ALWAYS: number;

declare const GL_AMD_compressed_3DC_texture: number;

declare const GL_AMD_compressed_ATC_texture: number;

declare const GL_AMD_framebuffer_multisample_advanced: number;

declare const GL_AMD_performance_monitor: number;

declare const GL_AMD_program_binary_Z400: number;

declare const GL_ANDROID_extension_pack_es31a: number;

declare const GL_ANGLE_depth_texture: number;

declare const GL_ANGLE_framebuffer_blit: number;

declare const GL_ANGLE_framebuffer_multisample: number;

declare const GL_ANGLE_instanced_arrays: number;

declare const GL_ANGLE_pack_reverse_row_order: number;

declare const GL_ANGLE_program_binary: number;

declare const GL_ANGLE_texture_compression_dxt3: number;

declare const GL_ANGLE_texture_compression_dxt5: number;

declare const GL_ANGLE_texture_usage: number;

declare const GL_ANGLE_translated_shader_source: number;

declare const GL_ANY_SAMPLES_PASSED: number;

declare const GL_ANY_SAMPLES_PASSED_CONSERVATIVE: number;

declare const GL_ANY_SAMPLES_PASSED_CONSERVATIVE_EXT: number;

declare const GL_ANY_SAMPLES_PASSED_EXT: number;

declare const GL_APPLE_clip_distance: number;

declare const GL_APPLE_color_buffer_packed_float: number;

declare const GL_APPLE_copy_texture_levels: number;

declare const GL_APPLE_framebuffer_multisample: number;

declare const GL_APPLE_rgb_422: number;

declare const GL_APPLE_sync: number;

declare const GL_APPLE_texture_format_BGRA8888: number;

declare const GL_APPLE_texture_max_level: number;

declare const GL_APPLE_texture_packed_float: number;

declare const GL_ARC_TO_NV: number;

declare const GL_ARM_mali_program_binary: number;

declare const GL_ARM_mali_shader_binary: number;

declare const GL_ARM_rgba8: number;

declare const GL_ARM_shader_framebuffer_fetch: number;

declare const GL_ARM_shader_framebuffer_fetch_depth_stencil: number;

declare const GL_ARM_texture_unnormalized_coordinates: number;

declare const GL_ARRAY_BUFFER: number;

declare const GL_ARRAY_BUFFER_BINDING: number;

declare const GL_ATC_RGBA_EXPLICIT_ALPHA_AMD: number;

declare const GL_ATC_RGBA_INTERPOLATED_ALPHA_AMD: number;

declare const GL_ATC_RGB_AMD: number;

declare const GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_MESH_SHADER_NV: number;

declare const GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_TASK_SHADER_NV: number;

declare const GL_ATTACHED_MEMORY_OBJECT_NV: number;

declare const GL_ATTACHED_MEMORY_OFFSET_NV: number;

declare const GL_ATTACHED_SHADERS: number;

declare const GL_BACK: number;

declare const GL_BEVEL_NV: number;

declare const GL_BGRA8_EXT: number;

declare const GL_BGRA_EXT: number;

declare const GL_BGRA_IMG: number;

declare const GL_BGR_EXT: number;

declare const GL_BINNING_CONTROL_HINT_QCOM: number;

declare const GL_BLACKHOLE_RENDER_INTEL: number;

declare const GL_BLEND: number;

declare const GL_BLEND_ADVANCED_COHERENT_KHR: number;

declare const GL_BLEND_ADVANCED_COHERENT_NV: number;

declare const GL_BLEND_COLOR: number;

declare const GL_BLEND_DST_ALPHA: number;

declare const GL_BLEND_DST_RGB: number;

declare const GL_BLEND_EQUATION: number;

declare const GL_BLEND_EQUATION_ALPHA: number;

declare const GL_BLEND_EQUATION_RGB: number;

declare const GL_BLEND_OVERLAP_NV: number;

declare const GL_BLEND_PREMULTIPLIED_SRC_NV: number;

declare const GL_BLEND_SRC_ALPHA: number;

declare const GL_BLEND_SRC_RGB: number;

declare const GL_BLUE: number;

declare const GL_BLUE_BITS: number;

declare const GL_BLUE_NV: number;

declare const GL_BOLD_BIT_NV: number;

declare const GL_BOOL: number;

declare const GL_BOOL_VEC2: number;

declare const GL_BOOL_VEC3: number;

declare const GL_BOOL_VEC4: number;

declare const GL_BOUNDING_BOX_NV: number;

declare const GL_BOUNDING_BOX_OF_BOUNDING_BOXES_NV: number;

declare const GL_BUFFER_ACCESS_FLAGS: number;

declare const GL_BUFFER_ACCESS_OES: number;

declare const GL_BUFFER_IMMUTABLE_STORAGE_EXT: number;

declare const GL_BUFFER_KHR: number;

declare const GL_BUFFER_MAPPED: number;

declare const GL_BUFFER_MAPPED_OES: number;

declare const GL_BUFFER_MAP_LENGTH: number;

declare const GL_BUFFER_MAP_OFFSET: number;

declare const GL_BUFFER_MAP_POINTER: number;

declare const GL_BUFFER_MAP_POINTER_OES: number;

declare const GL_BUFFER_OBJECT_EXT: number;

declare const GL_BUFFER_SIZE: number;

declare const GL_BUFFER_STORAGE_FLAGS_EXT: number;

declare const GL_BUFFER_USAGE: number;

declare const GL_BYTE: number;

declare const GL_CCW: number;

declare const GL_CIRCULAR_CCW_ARC_TO_NV: number;

declare const GL_CIRCULAR_CW_ARC_TO_NV: number;

declare const GL_CIRCULAR_TANGENT_ARC_TO_NV: number;

declare const GL_CLAMP_TO_BORDER_EXT: number;

declare const GL_CLAMP_TO_BORDER_NV: number;

declare const GL_CLAMP_TO_BORDER_OES: number;

declare const GL_CLAMP_TO_EDGE: number;

declare const GL_CLIENT_MAPPED_BUFFER_BARRIER_BIT_EXT: number;

declare const GL_CLIENT_STORAGE_BIT_EXT: number;

declare const GL_CLIP_DEPTH_MODE_EXT: number;

declare const GL_CLIP_DISTANCE0_APPLE: number;

declare const GL_CLIP_DISTANCE0_EXT: number;

declare const GL_CLIP_DISTANCE1_APPLE: number;

declare const GL_CLIP_DISTANCE1_EXT: number;

declare const GL_CLIP_DISTANCE2_APPLE: number;

declare const GL_CLIP_DISTANCE2_EXT: number;

declare const GL_CLIP_DISTANCE3_APPLE: number;

declare const GL_CLIP_DISTANCE3_EXT: number;

declare const GL_CLIP_DISTANCE4_APPLE: number;

declare const GL_CLIP_DISTANCE4_EXT: number;

declare const GL_CLIP_DISTANCE5_APPLE: number;

declare const GL_CLIP_DISTANCE5_EXT: number;

declare const GL_CLIP_DISTANCE6_APPLE: number;

declare const GL_CLIP_DISTANCE6_EXT: number;

declare const GL_CLIP_DISTANCE7_APPLE: number;

declare const GL_CLIP_DISTANCE7_EXT: number;

declare const GL_CLIP_ORIGIN_EXT: number;

declare const GL_CLOSE_PATH_NV: number;

declare const GL_COLOR: number;

declare const GL_COLORBURN_KHR: number;

declare const GL_COLORBURN_NV: number;

declare const GL_COLORDODGE_KHR: number;

declare const GL_COLORDODGE_NV: number;

declare const GL_COLOR_ATTACHMENT0: number;

declare const GL_COLOR_ATTACHMENT0_EXT: number;

declare const GL_COLOR_ATTACHMENT0_NV: number;

declare const GL_COLOR_ATTACHMENT1: number;

declare const GL_COLOR_ATTACHMENT10: number;

declare const GL_COLOR_ATTACHMENT10_EXT: number;

declare const GL_COLOR_ATTACHMENT10_NV: number;

declare const GL_COLOR_ATTACHMENT11: number;

declare const GL_COLOR_ATTACHMENT11_EXT: number;

declare const GL_COLOR_ATTACHMENT11_NV: number;

declare const GL_COLOR_ATTACHMENT12: number;

declare const GL_COLOR_ATTACHMENT12_EXT: number;

declare const GL_COLOR_ATTACHMENT12_NV: number;

declare const GL_COLOR_ATTACHMENT13: number;

declare const GL_COLOR_ATTACHMENT13_EXT: number;

declare const GL_COLOR_ATTACHMENT13_NV: number;

declare const GL_COLOR_ATTACHMENT14: number;

declare const GL_COLOR_ATTACHMENT14_EXT: number;

declare const GL_COLOR_ATTACHMENT14_NV: number;

declare const GL_COLOR_ATTACHMENT15: number;

declare const GL_COLOR_ATTACHMENT15_EXT: number;

declare const GL_COLOR_ATTACHMENT15_NV: number;

declare const GL_COLOR_ATTACHMENT16: number;

declare const GL_COLOR_ATTACHMENT17: number;

declare const GL_COLOR_ATTACHMENT18: number;

declare const GL_COLOR_ATTACHMENT19: number;

declare const GL_COLOR_ATTACHMENT1_EXT: number;

declare const GL_COLOR_ATTACHMENT1_NV: number;

declare const GL_COLOR_ATTACHMENT2: number;

declare const GL_COLOR_ATTACHMENT20: number;

declare const GL_COLOR_ATTACHMENT21: number;

declare const GL_COLOR_ATTACHMENT22: number;

declare const GL_COLOR_ATTACHMENT23: number;

declare const GL_COLOR_ATTACHMENT24: number;

declare const GL_COLOR_ATTACHMENT25: number;

declare const GL_COLOR_ATTACHMENT26: number;

declare const GL_COLOR_ATTACHMENT27: number;

declare const GL_COLOR_ATTACHMENT28: number;

declare const GL_COLOR_ATTACHMENT29: number;

declare const GL_COLOR_ATTACHMENT2_EXT: number;

declare const GL_COLOR_ATTACHMENT2_NV: number;

declare const GL_COLOR_ATTACHMENT3: number;

declare const GL_COLOR_ATTACHMENT30: number;

declare const GL_COLOR_ATTACHMENT31: number;

declare const GL_COLOR_ATTACHMENT3_EXT: number;

declare const GL_COLOR_ATTACHMENT3_NV: number;

declare const GL_COLOR_ATTACHMENT4: number;

declare const GL_COLOR_ATTACHMENT4_EXT: number;

declare const GL_COLOR_ATTACHMENT4_NV: number;

declare const GL_COLOR_ATTACHMENT5: number;

declare const GL_COLOR_ATTACHMENT5_EXT: number;

declare const GL_COLOR_ATTACHMENT5_NV: number;

declare const GL_COLOR_ATTACHMENT6: number;

declare const GL_COLOR_ATTACHMENT6_EXT: number;

declare const GL_COLOR_ATTACHMENT6_NV: number;

declare const GL_COLOR_ATTACHMENT7: number;

declare const GL_COLOR_ATTACHMENT7_EXT: number;

declare const GL_COLOR_ATTACHMENT7_NV: number;

declare const GL_COLOR_ATTACHMENT8: number;

declare const GL_COLOR_ATTACHMENT8_EXT: number;

declare const GL_COLOR_ATTACHMENT8_NV: number;

declare const GL_COLOR_ATTACHMENT9: number;

declare const GL_COLOR_ATTACHMENT9_EXT: number;

declare const GL_COLOR_ATTACHMENT9_NV: number;

declare const GL_COLOR_ATTACHMENT_EXT: number;

declare const GL_COLOR_BUFFER_BIT: number;

declare const GL_COLOR_BUFFER_BIT0_QCOM: number;

declare const GL_COLOR_BUFFER_BIT1_QCOM: number;

declare const GL_COLOR_BUFFER_BIT2_QCOM: number;

declare const GL_COLOR_BUFFER_BIT3_QCOM: number;

declare const GL_COLOR_BUFFER_BIT4_QCOM: number;

declare const GL_COLOR_BUFFER_BIT5_QCOM: number;

declare const GL_COLOR_BUFFER_BIT6_QCOM: number;

declare const GL_COLOR_BUFFER_BIT7_QCOM: number;

declare const GL_COLOR_CLEAR_VALUE: number;

declare const GL_COLOR_EXT: number;

declare const GL_COLOR_SAMPLES_NV: number;

declare const GL_COLOR_WRITEMASK: number;

declare const GL_COMPARE_REF_TO_TEXTURE: number;

declare const GL_COMPARE_REF_TO_TEXTURE_EXT: number;

declare const GL_COMPILE_STATUS: number;

declare const GL_COMPLETION_STATUS_KHR: number;

declare const GL_COMPRESSED_R11_EAC: number;

declare const GL_COMPRESSED_RED_GREEN_RGTC2_EXT: number;

declare const GL_COMPRESSED_RED_RGTC1_EXT: number;

declare const GL_COMPRESSED_RG11_EAC: number;

declare const GL_COMPRESSED_RGB8_ETC2: number;

declare const GL_COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2: number;

declare const GL_COMPRESSED_RGBA8_ETC2_EAC: number;

declare const GL_COMPRESSED_RGBA_ASTC_10x10_KHR: number;

declare const GL_COMPRESSED_RGBA_ASTC_10x5_KHR: number;

declare const GL_COMPRESSED_RGBA_ASTC_10x6_KHR: number;

declare const GL_COMPRESSED_RGBA_ASTC_10x8_KHR: number;

declare const GL_COMPRESSED_RGBA_ASTC_12x10_KHR: number;

declare const GL_COMPRESSED_RGBA_ASTC_12x12_KHR: number;

declare const GL_COMPRESSED_RGBA_ASTC_3x3x3_OES: number;

declare const GL_COMPRESSED_RGBA_ASTC_4x3x3_OES: number;

declare const GL_COMPRESSED_RGBA_ASTC_4x4_KHR: number;

declare const GL_COMPRESSED_RGBA_ASTC_4x4x3_OES: number;

declare const GL_COMPRESSED_RGBA_ASTC_4x4x4_OES: number;

declare const GL_COMPRESSED_RGBA_ASTC_5x4_KHR: number;

declare const GL_COMPRESSED_RGBA_ASTC_5x4x4_OES: number;

declare const GL_COMPRESSED_RGBA_ASTC_5x5_KHR: number;

declare const GL_COMPRESSED_RGBA_ASTC_5x5x4_OES: number;

declare const GL_COMPRESSED_RGBA_ASTC_5x5x5_OES: number;

declare const GL_COMPRESSED_RGBA_ASTC_6x5_KHR: number;

declare const GL_COMPRESSED_RGBA_ASTC_6x5x5_OES: number;

declare const GL_COMPRESSED_RGBA_ASTC_6x6_KHR: number;

declare const GL_COMPRESSED_RGBA_ASTC_6x6x5_OES: number;

declare const GL_COMPRESSED_RGBA_ASTC_6x6x6_OES: number;

declare const GL_COMPRESSED_RGBA_ASTC_8x5_KHR: number;

declare const GL_COMPRESSED_RGBA_ASTC_8x6_KHR: number;

declare const GL_COMPRESSED_RGBA_ASTC_8x8_KHR: number;

declare const GL_COMPRESSED_RGBA_BPTC_UNORM_EXT: number;

declare const GL_COMPRESSED_RGBA_PVRTC_2BPPV1_IMG: number;

declare const GL_COMPRESSED_RGBA_PVRTC_2BPPV2_IMG: number;

declare const GL_COMPRESSED_RGBA_PVRTC_4BPPV1_IMG: number;

declare const GL_COMPRESSED_RGBA_PVRTC_4BPPV2_IMG: number;

declare const GL_COMPRESSED_RGBA_S3TC_DXT1_EXT: number;

declare const GL_COMPRESSED_RGBA_S3TC_DXT3_ANGLE: number;

declare const GL_COMPRESSED_RGBA_S3TC_DXT3_EXT: number;

declare const GL_COMPRESSED_RGBA_S3TC_DXT5_ANGLE: number;

declare const GL_COMPRESSED_RGBA_S3TC_DXT5_EXT: number;

declare const GL_COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT: number;

declare const GL_COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT: number;

declare const GL_COMPRESSED_RGB_PVRTC_2BPPV1_IMG: number;

declare const GL_COMPRESSED_RGB_PVRTC_4BPPV1_IMG: number;

declare const GL_COMPRESSED_RGB_S3TC_DXT1_EXT: number;

declare const GL_COMPRESSED_SIGNED_R11_EAC: number;

declare const GL_COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT: number;

declare const GL_COMPRESSED_SIGNED_RED_RGTC1_EXT: number;

declare const GL_COMPRESSED_SIGNED_RG11_EAC: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_3x3x3_OES: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_4x3x3_OES: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_4x4x3_OES: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_4x4x4_OES: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_5x4x4_OES: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_5x5x4_OES: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_5x5x5_OES: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_6x5x5_OES: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_6x6x5_OES: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_6x6x6_OES: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR: number;

declare const GL_COMPRESSED_SRGB8_ALPHA8_ETC2_EAC: number;

declare const GL_COMPRESSED_SRGB8_ETC2: number;

declare const GL_COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2: number;

declare const GL_COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT: number;

declare const GL_COMPRESSED_SRGB_ALPHA_PVRTC_2BPPV1_EXT: number;

declare const GL_COMPRESSED_SRGB_ALPHA_PVRTC_2BPPV2_IMG: number;

declare const GL_COMPRESSED_SRGB_ALPHA_PVRTC_4BPPV1_EXT: number;

declare const GL_COMPRESSED_SRGB_ALPHA_PVRTC_4BPPV2_IMG: number;

declare const GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT: number;

declare const GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT1_NV: number;

declare const GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT: number;

declare const GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT3_NV: number;

declare const GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT: number;

declare const GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT5_NV: number;

declare const GL_COMPRESSED_SRGB_PVRTC_2BPPV1_EXT: number;

declare const GL_COMPRESSED_SRGB_PVRTC_4BPPV1_EXT: number;

declare const GL_COMPRESSED_SRGB_S3TC_DXT1_EXT: number;

declare const GL_COMPRESSED_SRGB_S3TC_DXT1_NV: number;

declare const GL_COMPRESSED_TEXTURE_FORMATS: number;

declare const GL_CONDITION_SATISFIED: number;

declare const GL_CONDITION_SATISFIED_APPLE: number;

declare const GL_CONFORMANT_NV: number;

declare const GL_CONIC_CURVE_TO_NV: number;

declare const GL_CONJOINT_NV: number;

declare const GL_CONSERVATIVE_RASTERIZATION_INTEL: number;

declare const GL_CONSERVATIVE_RASTERIZATION_NV: number;

declare const GL_CONSERVATIVE_RASTER_MODE_NV: number;

declare const GL_CONSERVATIVE_RASTER_MODE_POST_SNAP_NV: number;

declare const GL_CONSERVATIVE_RASTER_MODE_PRE_SNAP_NV: number;

declare const GL_CONSERVATIVE_RASTER_MODE_PRE_SNAP_TRIANGLES_NV: number;

declare const GL_CONSTANT_ALPHA: number;

declare const GL_CONSTANT_COLOR: number;

declare const GL_CONTEXT_FLAG_DEBUG_BIT_KHR: number;

declare const GL_CONTEXT_FLAG_NO_ERROR_BIT_KHR: number;

declare const GL_CONTEXT_FLAG_PROTECTED_CONTENT_BIT_EXT: number;

declare const GL_CONTEXT_LOST_KHR: number;

declare const GL_CONTEXT_RELEASE_BEHAVIOR_FLUSH_KHR: number;

declare const GL_CONTEXT_RELEASE_BEHAVIOR_KHR: number;

declare const GL_CONTEXT_ROBUST_ACCESS_EXT: number;

declare const GL_CONTEXT_ROBUST_ACCESS_KHR: number;

declare const GL_CONTRAST_NV: number;

declare const GL_CONVEX_HULL_NV: number;

declare const GL_COPY_READ_BUFFER: number;

declare const GL_COPY_READ_BUFFER_BINDING: number;

declare const GL_COPY_READ_BUFFER_NV: number;

declare const GL_COPY_WRITE_BUFFER: number;

declare const GL_COPY_WRITE_BUFFER_BINDING: number;

declare const GL_COPY_WRITE_BUFFER_NV: number;

declare const GL_COUNTER_RANGE_AMD: number;

declare const GL_COUNTER_TYPE_AMD: number;

declare const GL_COUNT_DOWN_NV: number;

declare const GL_COUNT_UP_NV: number;

declare const GL_COVERAGE_ALL_FRAGMENTS_NV: number;

declare const GL_COVERAGE_ATTACHMENT_NV: number;

declare const GL_COVERAGE_AUTOMATIC_NV: number;

declare const GL_COVERAGE_BUFFERS_NV: number;

declare const GL_COVERAGE_BUFFER_BIT_NV: number;

declare const GL_COVERAGE_COMPONENT4_NV: number;

declare const GL_COVERAGE_COMPONENT_NV: number;

declare const GL_COVERAGE_EDGE_FRAGMENTS_NV: number;

declare const GL_COVERAGE_MODULATION_NV: number;

declare const GL_COVERAGE_MODULATION_TABLE_NV: number;

declare const GL_COVERAGE_MODULATION_TABLE_SIZE_NV: number;

declare const GL_COVERAGE_SAMPLES_NV: number;

declare const GL_CPU_OPTIMIZED_QCOM: number;

declare const GL_CUBIC_CURVE_TO_NV: number;

declare const GL_CUBIC_IMG: number;

declare const GL_CUBIC_MIPMAP_LINEAR_IMG: number;

declare const GL_CUBIC_MIPMAP_NEAREST_IMG: number;

declare const GL_CULL_FACE: number;

declare const GL_CULL_FACE_MODE: number;

declare const GL_CURRENT_PROGRAM: number;

declare const GL_CURRENT_QUERY: number;

declare const GL_CURRENT_QUERY_EXT: number;

declare const GL_CURRENT_VERTEX_ATTRIB: number;

declare const GL_CW: number;

declare const GL_D3D12_FENCE_VALUE_EXT: number;

declare const GL_DARKEN_KHR: number;

declare const GL_DARKEN_NV: number;

declare const GL_DEBUG_CALLBACK_FUNCTION_KHR: number;

declare const GL_DEBUG_CALLBACK_USER_PARAM_KHR: number;

declare const GL_DEBUG_GROUP_STACK_DEPTH_KHR: number;

declare const GL_DEBUG_LOGGED_MESSAGES_KHR: number;

declare const GL_DEBUG_NEXT_LOGGED_MESSAGE_LENGTH_KHR: number;

declare const GL_DEBUG_OUTPUT_KHR: number;

declare const GL_DEBUG_OUTPUT_SYNCHRONOUS_KHR: number;

declare const GL_DEBUG_SEVERITY_HIGH_KHR: number;

declare const GL_DEBUG_SEVERITY_LOW_KHR: number;

declare const GL_DEBUG_SEVERITY_MEDIUM_KHR: number;

declare const GL_DEBUG_SEVERITY_NOTIFICATION_KHR: number;

declare const GL_DEBUG_SOURCE_API_KHR: number;

declare const GL_DEBUG_SOURCE_APPLICATION_KHR: number;

declare const GL_DEBUG_SOURCE_OTHER_KHR: number;

declare const GL_DEBUG_SOURCE_SHADER_COMPILER_KHR: number;

declare const GL_DEBUG_SOURCE_THIRD_PARTY_KHR: number;

declare const GL_DEBUG_SOURCE_WINDOW_SYSTEM_KHR: number;

declare const GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR_KHR: number;

declare const GL_DEBUG_TYPE_ERROR_KHR: number;

declare const GL_DEBUG_TYPE_MARKER_KHR: number;

declare const GL_DEBUG_TYPE_OTHER_KHR: number;

declare const GL_DEBUG_TYPE_PERFORMANCE_KHR: number;

declare const GL_DEBUG_TYPE_POP_GROUP_KHR: number;

declare const GL_DEBUG_TYPE_PORTABILITY_KHR: number;

declare const GL_DEBUG_TYPE_PUSH_GROUP_KHR: number;

declare const GL_DEBUG_TYPE_UNDEFINED_BEHAVIOR_KHR: number;

declare const GL_DECODE_EXT: number;

declare const GL_DECR: number;

declare const GL_DECR_WRAP: number;

declare const GL_DEDICATED_MEMORY_OBJECT_EXT: number;

declare const GL_DELETE_STATUS: number;

declare const GL_DEPTH: number;

declare const GL_DEPTH24_STENCIL8: number;

declare const GL_DEPTH24_STENCIL8_OES: number;

declare const GL_DEPTH32F_STENCIL8: number;

declare const GL_DEPTH_ATTACHMENT: number;

declare const GL_DEPTH_BITS: number;

declare const GL_DEPTH_BUFFER_BIT: number;

declare const GL_DEPTH_BUFFER_BIT0_QCOM: number;

declare const GL_DEPTH_BUFFER_BIT1_QCOM: number;

declare const GL_DEPTH_BUFFER_BIT2_QCOM: number;

declare const GL_DEPTH_BUFFER_BIT3_QCOM: number;

declare const GL_DEPTH_BUFFER_BIT4_QCOM: number;

declare const GL_DEPTH_BUFFER_BIT5_QCOM: number;

declare const GL_DEPTH_BUFFER_BIT6_QCOM: number;

declare const GL_DEPTH_BUFFER_BIT7_QCOM: number;

declare const GL_DEPTH_CLAMP_EXT: number;

declare const GL_DEPTH_CLEAR_VALUE: number;

declare const GL_DEPTH_COMPONENT: number;

declare const GL_DEPTH_COMPONENT16: number;

declare const GL_DEPTH_COMPONENT16_NONLINEAR_NV: number;

declare const GL_DEPTH_COMPONENT16_OES: number;

declare const GL_DEPTH_COMPONENT24: number;

declare const GL_DEPTH_COMPONENT24_OES: number;

declare const GL_DEPTH_COMPONENT32F: number;

declare const GL_DEPTH_COMPONENT32_OES: number;

declare const GL_DEPTH_EXT: number;

declare const GL_DEPTH_FUNC: number;

declare const GL_DEPTH_RANGE: number;

declare const GL_DEPTH_SAMPLES_NV: number;

declare const GL_DEPTH_STENCIL: number;

declare const GL_DEPTH_STENCIL_ATTACHMENT: number;

declare const GL_DEPTH_STENCIL_OES: number;

declare const GL_DEPTH_TEST: number;

declare const GL_DEPTH_WRITEMASK: number;

declare const GL_DETACHED_BUFFERS_NV: number;

declare const GL_DETACHED_MEMORY_INCARNATION_NV: number;

declare const GL_DETACHED_TEXTURES_NV: number;

declare const GL_DEVICE_LUID_EXT: number;

declare const GL_DEVICE_NODE_MASK_EXT: number;

declare const GL_DEVICE_UUID_EXT: number;

declare const GL_DIFFERENCE_KHR: number;

declare const GL_DIFFERENCE_NV: number;

declare const GL_DISJOINT_NV: number;

declare const GL_DITHER: number;

declare const GL_DMP_PROGRAM_BINARY_DMP: number;

declare const GL_DMP_program_binary: number;

declare const GL_DMP_shader_binary: number;

declare const GL_DONT_CARE: number;

declare const GL_DOWNSAMPLE_SCALES_IMG: number;

declare const GL_DRAW_BUFFER0: number;

declare const GL_DRAW_BUFFER0_EXT: number;

declare const GL_DRAW_BUFFER0_NV: number;

declare const GL_DRAW_BUFFER1: number;

declare const GL_DRAW_BUFFER10: number;

declare const GL_DRAW_BUFFER10_EXT: number;

declare const GL_DRAW_BUFFER10_NV: number;

declare const GL_DRAW_BUFFER11: number;

declare const GL_DRAW_BUFFER11_EXT: number;

declare const GL_DRAW_BUFFER11_NV: number;

declare const GL_DRAW_BUFFER12: number;

declare const GL_DRAW_BUFFER12_EXT: number;

declare const GL_DRAW_BUFFER12_NV: number;

declare const GL_DRAW_BUFFER13: number;

declare const GL_DRAW_BUFFER13_EXT: number;

declare const GL_DRAW_BUFFER13_NV: number;

declare const GL_DRAW_BUFFER14: number;

declare const GL_DRAW_BUFFER14_EXT: number;

declare const GL_DRAW_BUFFER14_NV: number;

declare const GL_DRAW_BUFFER15: number;

declare const GL_DRAW_BUFFER15_EXT: number;

declare const GL_DRAW_BUFFER15_NV: number;

declare const GL_DRAW_BUFFER1_EXT: number;

declare const GL_DRAW_BUFFER1_NV: number;

declare const GL_DRAW_BUFFER2: number;

declare const GL_DRAW_BUFFER2_EXT: number;

declare const GL_DRAW_BUFFER2_NV: number;

declare const GL_DRAW_BUFFER3: number;

declare const GL_DRAW_BUFFER3_EXT: number;

declare const GL_DRAW_BUFFER3_NV: number;

declare const GL_DRAW_BUFFER4: number;

declare const GL_DRAW_BUFFER4_EXT: number;

declare const GL_DRAW_BUFFER4_NV: number;

declare const GL_DRAW_BUFFER5: number;

declare const GL_DRAW_BUFFER5_EXT: number;

declare const GL_DRAW_BUFFER5_NV: number;

declare const GL_DRAW_BUFFER6: number;

declare const GL_DRAW_BUFFER6_EXT: number;

declare const GL_DRAW_BUFFER6_NV: number;

declare const GL_DRAW_BUFFER7: number;

declare const GL_DRAW_BUFFER7_EXT: number;

declare const GL_DRAW_BUFFER7_NV: number;

declare const GL_DRAW_BUFFER8: number;

declare const GL_DRAW_BUFFER8_EXT: number;

declare const GL_DRAW_BUFFER8_NV: number;

declare const GL_DRAW_BUFFER9: number;

declare const GL_DRAW_BUFFER9_EXT: number;

declare const GL_DRAW_BUFFER9_NV: number;

declare const GL_DRAW_BUFFER_EXT: number;

declare const GL_DRAW_FRAMEBUFFER: number;

declare const GL_DRAW_FRAMEBUFFER_ANGLE: number;

declare const GL_DRAW_FRAMEBUFFER_APPLE: number;

declare const GL_DRAW_FRAMEBUFFER_BINDING: number;

declare const GL_DRAW_FRAMEBUFFER_BINDING_ANGLE: number;

declare const GL_DRAW_FRAMEBUFFER_BINDING_APPLE: number;

declare const GL_DRAW_FRAMEBUFFER_BINDING_NV: number;

declare const GL_DRAW_FRAMEBUFFER_NV: number;

declare const GL_DRIVER_UUID_EXT: number;

declare const GL_DST_ALPHA: number;

declare const GL_DST_ATOP_NV: number;

declare const GL_DST_COLOR: number;

declare const GL_DST_IN_NV: number;

declare const GL_DST_NV: number;

declare const GL_DST_OUT_NV: number;

declare const GL_DST_OVER_NV: number;

declare const GL_DUP_FIRST_CUBIC_CURVE_TO_NV: number;

declare const GL_DUP_LAST_CUBIC_CURVE_TO_NV: number;

declare const GL_DYNAMIC_COPY: number;

declare const GL_DYNAMIC_DRAW: number;

declare const GL_DYNAMIC_READ: number;

declare const GL_DYNAMIC_STORAGE_BIT_EXT: number;

declare const GL_EFFECTIVE_RASTER_SAMPLES_EXT: number;

declare const GL_ELEMENT_ARRAY_BUFFER: number;

declare const GL_ELEMENT_ARRAY_BUFFER_BINDING: number;

declare const GL_EQUAL: number;

declare const GL_ES_VERSION_2_0: number;

declare const GL_ES_VERSION_3_0: number;

declare const GL_ETC1_RGB8_OES: number;

declare const GL_ETC1_SRGB8_NV: number;

declare const GL_EXCLUSION_KHR: number;

declare const GL_EXCLUSION_NV: number;

declare const GL_EXCLUSIVE_EXT: number;

declare const GL_EXTENSIONS: number;

declare const GL_EXT_EGL_image_array: number;

declare const GL_EXT_EGL_image_storage: number;

declare const GL_EXT_EGL_image_storage_compression: number;

declare const GL_EXT_YUV_target: number;

declare const GL_EXT_base_instance: number;

declare const GL_EXT_blend_func_extended: number;

declare const GL_EXT_blend_minmax: number;

declare const GL_EXT_buffer_storage: number;

declare const GL_EXT_clear_texture: number;

declare const GL_EXT_clip_control: number;

declare const GL_EXT_clip_cull_distance: number;

declare const GL_EXT_color_buffer_float: number;

declare const GL_EXT_color_buffer_half_float: number;

declare const GL_EXT_conservative_depth: number;

declare const GL_EXT_copy_image: number;

declare const GL_EXT_debug_label: number;

declare const GL_EXT_debug_marker: number;

declare const GL_EXT_depth_clamp: number;

declare const GL_EXT_discard_framebuffer: number;

declare const GL_EXT_disjoint_timer_query: number;

declare const GL_EXT_draw_buffers: number;

declare const GL_EXT_draw_buffers_indexed: number;

declare const GL_EXT_draw_elements_base_vertex: number;

declare const GL_EXT_draw_instanced: number;

declare const GL_EXT_draw_transform_feedback: number;

declare const GL_EXT_external_buffer: number;

declare const GL_EXT_float_blend: number;

declare const GL_EXT_fragment_shading_rate: number;

declare const GL_EXT_geometry_point_size: number;

declare const GL_EXT_geometry_shader: number;

declare const GL_EXT_gpu_shader5: number;

declare const GL_EXT_instanced_arrays: number;

declare const GL_EXT_map_buffer_range: number;

declare const GL_EXT_memory_object: number;

declare const GL_EXT_memory_object_fd: number;

declare const GL_EXT_memory_object_win32: number;

declare const GL_EXT_multi_draw_arrays: number;

declare const GL_EXT_multi_draw_indirect: number;

declare const GL_EXT_multisampled_compatibility: number;

declare const GL_EXT_multisampled_render_to_texture: number;

declare const GL_EXT_multisampled_render_to_texture2: number;

declare const GL_EXT_multiview_draw_buffers: number;

declare const GL_EXT_multiview_tessellation_geometry_shader: number;

declare const GL_EXT_multiview_texture_multisample: number;

declare const GL_EXT_multiview_timer_query: number;

declare const GL_EXT_occlusion_query_boolean: number;

declare const GL_EXT_polygon_offset_clamp: number;

declare const GL_EXT_post_depth_coverage: number;

declare const GL_EXT_primitive_bounding_box: number;

declare const GL_EXT_protected_textures: number;

declare const GL_EXT_pvrtc_sRGB: number;

declare const GL_EXT_raster_multisample: number;

declare const GL_EXT_read_format_bgra: number;

declare const GL_EXT_render_snorm: number;

declare const GL_EXT_robustness: number;

declare const GL_EXT_sRGB: number;

declare const GL_EXT_sRGB_write_control: number;

declare const GL_EXT_semaphore: number;

declare const GL_EXT_semaphore_fd: number;

declare const GL_EXT_semaphore_win32: number;

declare const GL_EXT_separate_depth_stencil: number;

declare const GL_EXT_separate_shader_objects: number;

declare const GL_EXT_shader_framebuffer_fetch: number;

declare const GL_EXT_shader_framebuffer_fetch_non_coherent: number;

declare const GL_EXT_shader_group_vote: number;

declare const GL_EXT_shader_implicit_conversions: number;

declare const GL_EXT_shader_integer_mix: number;

declare const GL_EXT_shader_io_blocks: number;

declare const GL_EXT_shader_non_constant_global_initializers: number;

declare const GL_EXT_shader_pixel_local_storage: number;

declare const GL_EXT_shader_pixel_local_storage2: number;

declare const GL_EXT_shader_samples_identical: number;

declare const GL_EXT_shader_texture_lod: number;

declare const GL_EXT_shadow_samplers: number;

declare const GL_EXT_sparse_texture: number;

declare const GL_EXT_sparse_texture2: number;

declare const GL_EXT_tessellation_point_size: number;

declare const GL_EXT_tessellation_shader: number;

declare const GL_EXT_texture_border_clamp: number;

declare const GL_EXT_texture_buffer: number;

declare const GL_EXT_texture_compression_astc_decode_mode: number;

declare const GL_EXT_texture_compression_bptc: number;

declare const GL_EXT_texture_compression_dxt1: number;

declare const GL_EXT_texture_compression_rgtc: number;

declare const GL_EXT_texture_compression_s3tc: number;

declare const GL_EXT_texture_compression_s3tc_srgb: number;

declare const GL_EXT_texture_cube_map_array: number;

declare const GL_EXT_texture_filter_anisotropic: number;

declare const GL_EXT_texture_filter_minmax: number;

declare const GL_EXT_texture_format_BGRA8888: number;

declare const GL_EXT_texture_format_sRGB_override: number;

declare const GL_EXT_texture_mirror_clamp_to_edge: number;

declare const GL_EXT_texture_norm16: number;

declare const GL_EXT_texture_query_lod: number;

declare const GL_EXT_texture_rg: number;

declare const GL_EXT_texture_sRGB_R8: number;

declare const GL_EXT_texture_sRGB_RG8: number;

declare const GL_EXT_texture_sRGB_decode: number;

declare const GL_EXT_texture_shadow_lod: number;

declare const GL_EXT_texture_storage: number;

declare const GL_EXT_texture_storage_compression: number;

declare const GL_EXT_texture_type_2_10_10_10_REV: number;

declare const GL_EXT_texture_view: number;

declare const GL_EXT_unpack_subimage: number;

declare const GL_EXT_win32_keyed_mutex: number;

declare const GL_EXT_window_rectangles: number;

declare const GL_FACTOR_MAX_AMD: number;

declare const GL_FACTOR_MIN_AMD: number;

declare const GL_FALSE: number;

declare const GL_FASTEST: number;

declare const GL_FENCE_CONDITION_NV: number;

declare const GL_FENCE_STATUS_NV: number;

declare const GL_FETCH_PER_SAMPLE_ARM: number;

declare const GL_FILE_NAME_NV: number;

declare const GL_FILL_NV: number;

declare const GL_FILL_RECTANGLE_NV: number;

declare const GL_FIRST_TO_REST_NV: number;

declare const GL_FIRST_VERTEX_CONVENTION_EXT: number;

declare const GL_FIRST_VERTEX_CONVENTION_OES: number;

declare const GL_FIXED: number;

declare const GL_FJ_shader_binary_GCCSO: number;

declare const GL_FLOAT: number;

declare const GL_FLOAT16_NV: number;

declare const GL_FLOAT16_VEC2_NV: number;

declare const GL_FLOAT16_VEC3_NV: number;

declare const GL_FLOAT16_VEC4_NV: number;

declare const GL_FLOAT_32_UNSIGNED_INT_24_8_REV: number;

declare const GL_FLOAT_MAT2: number;

declare const GL_FLOAT_MAT2x3: number;

declare const GL_FLOAT_MAT2x3_NV: number;

declare const GL_FLOAT_MAT2x4: number;

declare const GL_FLOAT_MAT2x4_NV: number;

declare const GL_FLOAT_MAT3: number;

declare const GL_FLOAT_MAT3x2: number;

declare const GL_FLOAT_MAT3x2_NV: number;

declare const GL_FLOAT_MAT3x4: number;

declare const GL_FLOAT_MAT3x4_NV: number;

declare const GL_FLOAT_MAT4: number;

declare const GL_FLOAT_MAT4x2: number;

declare const GL_FLOAT_MAT4x2_NV: number;

declare const GL_FLOAT_MAT4x3: number;

declare const GL_FLOAT_MAT4x3_NV: number;

declare const GL_FLOAT_VEC2: number;

declare const GL_FLOAT_VEC3: number;

declare const GL_FLOAT_VEC4: number;

declare const GL_FONT_ASCENDER_BIT_NV: number;

declare const GL_FONT_DESCENDER_BIT_NV: number;

declare const GL_FONT_GLYPHS_AVAILABLE_NV: number;

declare const GL_FONT_HAS_KERNING_BIT_NV: number;

declare const GL_FONT_HEIGHT_BIT_NV: number;

declare const GL_FONT_MAX_ADVANCE_HEIGHT_BIT_NV: number;

declare const GL_FONT_MAX_ADVANCE_WIDTH_BIT_NV: number;

declare const GL_FONT_NUM_GLYPH_INDICES_BIT_NV: number;

declare const GL_FONT_TARGET_UNAVAILABLE_NV: number;

declare const GL_FONT_UNAVAILABLE_NV: number;

declare const GL_FONT_UNDERLINE_POSITION_BIT_NV: number;

declare const GL_FONT_UNDERLINE_THICKNESS_BIT_NV: number;

declare const GL_FONT_UNINTELLIGIBLE_NV: number;

declare const GL_FONT_UNITS_PER_EM_BIT_NV: number;

declare const GL_FONT_X_MAX_BOUNDS_BIT_NV: number;

declare const GL_FONT_X_MIN_BOUNDS_BIT_NV: number;

declare const GL_FONT_Y_MAX_BOUNDS_BIT_NV: number;

declare const GL_FONT_Y_MIN_BOUNDS_BIT_NV: number;

declare const GL_FOVEATION_ENABLE_BIT_QCOM: number;

declare const GL_FOVEATION_SCALED_BIN_METHOD_BIT_QCOM: number;

declare const GL_FOVEATION_SUBSAMPLED_LAYOUT_METHOD_BIT_QCOM: number;

declare const GL_FRACTIONAL_EVEN_EXT: number;

declare const GL_FRACTIONAL_EVEN_OES: number;

declare const GL_FRACTIONAL_ODD_EXT: number;

declare const GL_FRACTIONAL_ODD_OES: number;

declare const GL_FRAGMENT_COVERAGE_COLOR_NV: number;

declare const GL_FRAGMENT_COVERAGE_TO_COLOR_NV: number;

declare const GL_FRAGMENT_INPUT_NV: number;

declare const GL_FRAGMENT_INTERPOLATION_OFFSET_BITS_OES: number;

declare const GL_FRAGMENT_SHADER: number;

declare const GL_FRAGMENT_SHADER_BIT_EXT: number;

declare const GL_FRAGMENT_SHADER_DERIVATIVE_HINT: number;

declare const GL_FRAGMENT_SHADER_DERIVATIVE_HINT_OES: number;

declare const GL_FRAGMENT_SHADER_DISCARDS_SAMPLES_EXT: number;

declare const GL_FRAGMENT_SHADER_FRAMEBUFFER_FETCH_MRT_ARM: number;

declare const GL_FRAGMENT_SHADING_RATE_ATTACHMENT_WITH_DEFAULT_FRAMEBUFFER_SUPPORTED_EXT: number;

declare const GL_FRAGMENT_SHADING_RATE_COMBINER_OP_KEEP_EXT: number;

declare const GL_FRAGMENT_SHADING_RATE_COMBINER_OP_MAX_EXT: number;

declare const GL_FRAGMENT_SHADING_RATE_COMBINER_OP_MIN_EXT: number;

declare const GL_FRAGMENT_SHADING_RATE_COMBINER_OP_MUL_EXT: number;

declare const GL_FRAGMENT_SHADING_RATE_COMBINER_OP_REPLACE_EXT: number;

declare const GL_FRAGMENT_SHADING_RATE_NON_TRIVIAL_COMBINERS_SUPPORTED_EXT: number;

declare const GL_FRAGMENT_SHADING_RATE_WITH_SAMPLE_MASK_SUPPORTED_EXT: number;

declare const GL_FRAGMENT_SHADING_RATE_WITH_SHADER_DEPTH_STENCIL_WRITES_SUPPORTED_EXT: number;

declare const GL_FRAMEBUFFER: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_ANGLE: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_BLUE_SIZE: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING_EXT: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE_EXT: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_GREEN_SIZE: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_LAYERED_EXT: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_LAYERED_OES: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_RED_SIZE: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_3D_ZOFFSET_OES: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_BASE_VIEW_INDEX_OVR: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_NUM_VIEWS_OVR: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_SAMPLES_EXT: number;

declare const GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_SCALE_IMG: number;

declare const GL_FRAMEBUFFER_BINDING: number;

declare const GL_FRAMEBUFFER_COMPLETE: number;

declare const GL_FRAMEBUFFER_DEFAULT: number;

declare const GL_FRAMEBUFFER_DEFAULT_LAYERS_EXT: number;

declare const GL_FRAMEBUFFER_DEFAULT_LAYERS_OES: number;

declare const GL_FRAMEBUFFER_FETCH_NONCOHERENT_QCOM: number;

declare const GL_FRAMEBUFFER_FLIP_X_MESA: number;

declare const GL_FRAMEBUFFER_FLIP_Y_MESA: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_FOVEATION_QCOM: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_INSUFFICIENT_SHADER_COMBINED_LOCAL_STORAGE_EXT: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS_EXT: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS_OES: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE_AND_DOWNSAMPLE_IMG: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE_ANGLE: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE_APPLE: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE_EXT: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE_IMG: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE_NV: number;

declare const GL_FRAMEBUFFER_INCOMPLETE_VIEW_TARGETS_OVR: number;

declare const GL_FRAMEBUFFER_PROGRAMMABLE_SAMPLE_LOCATIONS_NV: number;

declare const GL_FRAMEBUFFER_SAMPLE_LOCATION_PIXEL_GRID_NV: number;

declare const GL_FRAMEBUFFER_SRGB_EXT: number;

declare const GL_FRAMEBUFFER_SWAP_XY_MESA: number;

declare const GL_FRAMEBUFFER_UNDEFINED: number;

declare const GL_FRAMEBUFFER_UNDEFINED_OES: number;

declare const GL_FRAMEBUFFER_UNSUPPORTED: number;

declare const GL_FRONT: number;

declare const GL_FRONT_AND_BACK: number;

declare const GL_FRONT_FACE: number;

declare const GL_FUNC_ADD: number;

declare const GL_FUNC_REVERSE_SUBTRACT: number;

declare const GL_FUNC_SUBTRACT: number;

declare const GL_GCCSO_SHADER_BINARY_FJ: number;

declare const GL_GENERATE_MIPMAP_HINT: number;

declare const GL_GEOMETRY_LINKED_INPUT_TYPE_EXT: number;

declare const GL_GEOMETRY_LINKED_INPUT_TYPE_OES: number;

declare const GL_GEOMETRY_LINKED_OUTPUT_TYPE_EXT: number;

declare const GL_GEOMETRY_LINKED_OUTPUT_TYPE_OES: number;

declare const GL_GEOMETRY_LINKED_VERTICES_OUT_EXT: number;

declare const GL_GEOMETRY_LINKED_VERTICES_OUT_OES: number;

declare const GL_GEOMETRY_SHADER_BIT_EXT: number;

declare const GL_GEOMETRY_SHADER_BIT_OES: number;

declare const GL_GEOMETRY_SHADER_EXT: number;

declare const GL_GEOMETRY_SHADER_INVOCATIONS_EXT: number;

declare const GL_GEOMETRY_SHADER_INVOCATIONS_OES: number;

declare const GL_GEOMETRY_SHADER_OES: number;

declare const GL_GEQUAL: number;

declare const GL_GLES_PROTOTYPES: number;

declare const GL_GLYPH_HAS_KERNING_BIT_NV: number;

declare const GL_GLYPH_HEIGHT_BIT_NV: number;

declare const GL_GLYPH_HORIZONTAL_BEARING_ADVANCE_BIT_NV: number;

declare const GL_GLYPH_HORIZONTAL_BEARING_X_BIT_NV: number;

declare const GL_GLYPH_HORIZONTAL_BEARING_Y_BIT_NV: number;

declare const GL_GLYPH_VERTICAL_BEARING_ADVANCE_BIT_NV: number;

declare const GL_GLYPH_VERTICAL_BEARING_X_BIT_NV: number;

declare const GL_GLYPH_VERTICAL_BEARING_Y_BIT_NV: number;

declare const GL_GLYPH_WIDTH_BIT_NV: number;

declare const GL_GPU_DISJOINT_EXT: number;

declare const GL_GPU_OPTIMIZED_QCOM: number;

declare const GL_GREATER: number;

declare const GL_GREEN: number;

declare const GL_GREEN_BITS: number;

declare const GL_GREEN_NV: number;

declare const GL_GUILTY_CONTEXT_RESET_EXT: number;

declare const GL_GUILTY_CONTEXT_RESET_KHR: number;

declare const GL_HALF_FLOAT: number;

declare const GL_HALF_FLOAT_OES: number;

declare const GL_HANDLE_TYPE_D3D11_IMAGE_EXT: number;

declare const GL_HANDLE_TYPE_D3D11_IMAGE_KMT_EXT: number;

declare const GL_HANDLE_TYPE_D3D12_FENCE_EXT: number;

declare const GL_HANDLE_TYPE_D3D12_RESOURCE_EXT: number;

declare const GL_HANDLE_TYPE_D3D12_TILEPOOL_EXT: number;

declare const GL_HANDLE_TYPE_OPAQUE_FD_EXT: number;

declare const GL_HANDLE_TYPE_OPAQUE_WIN32_EXT: number;

declare const GL_HANDLE_TYPE_OPAQUE_WIN32_KMT_EXT: number;

declare const GL_HARDLIGHT_KHR: number;

declare const GL_HARDLIGHT_NV: number;

declare const GL_HARDMIX_NV: number;

declare const GL_HIGH_FLOAT: number;

declare const GL_HIGH_INT: number;

declare const GL_HORIZONTAL_LINE_TO_NV: number;

declare const GL_HSL_COLOR_KHR: number;

declare const GL_HSL_COLOR_NV: number;

declare const GL_HSL_HUE_KHR: number;

declare const GL_HSL_HUE_NV: number;

declare const GL_HSL_LUMINOSITY_KHR: number;

declare const GL_HSL_LUMINOSITY_NV: number;

declare const GL_HSL_SATURATION_KHR: number;

declare const GL_HSL_SATURATION_NV: number;

declare const GL_IMAGE_BUFFER_EXT: number;

declare const GL_IMAGE_BUFFER_OES: number;

declare const GL_IMAGE_CUBE_MAP_ARRAY_EXT: number;

declare const GL_IMAGE_CUBE_MAP_ARRAY_OES: number;

declare const GL_IMG_bindless_texture: number;

declare const GL_IMG_framebuffer_downsample: number;

declare const GL_IMG_multisampled_render_to_texture: number;

declare const GL_IMG_program_binary: number;

declare const GL_IMG_read_format: number;

declare const GL_IMG_shader_binary: number;

declare const GL_IMG_texture_compression_pvrtc: number;

declare const GL_IMG_texture_compression_pvrtc2: number;

declare const GL_IMG_texture_filter_cubic: number;

declare const GL_IMPLEMENTATION_COLOR_READ_FORMAT: number;

declare const GL_IMPLEMENTATION_COLOR_READ_TYPE: number;

declare const GL_INCLUSIVE_EXT: number;

declare const GL_INCR: number;

declare const GL_INCR_WRAP: number;

declare const GL_INFO_LOG_LENGTH: number;

declare const GL_INNOCENT_CONTEXT_RESET_EXT: number;

declare const GL_INNOCENT_CONTEXT_RESET_KHR: number;

declare const GL_INT: number;

declare const GL_INT16_NV: number;

declare const GL_INT16_VEC2_NV: number;

declare const GL_INT16_VEC3_NV: number;

declare const GL_INT16_VEC4_NV: number;

declare const GL_INT64_NV: number;

declare const GL_INT64_VEC2_NV: number;

declare const GL_INT64_VEC3_NV: number;

declare const GL_INT64_VEC4_NV: number;

declare const GL_INT8_NV: number;

declare const GL_INT8_VEC2_NV: number;

declare const GL_INT8_VEC3_NV: number;

declare const GL_INT8_VEC4_NV: number;

declare const GL_INTEL_blackhole_render: number;

declare const GL_INTEL_conservative_rasterization: number;

declare const GL_INTEL_framebuffer_CMAA: number;

declare const GL_INTEL_performance_query: number;

declare const GL_INTERLEAVED_ATTRIBS: number;

declare const GL_INT_10_10_10_2_OES: number;

declare const GL_INT_2_10_10_10_REV: number;

declare const GL_INT_IMAGE_BUFFER_EXT: number;

declare const GL_INT_IMAGE_BUFFER_OES: number;

declare const GL_INT_IMAGE_CUBE_MAP_ARRAY_EXT: number;

declare const GL_INT_IMAGE_CUBE_MAP_ARRAY_OES: number;

declare const GL_INT_SAMPLER_2D: number;

declare const GL_INT_SAMPLER_2D_ARRAY: number;

declare const GL_INT_SAMPLER_2D_MULTISAMPLE_ARRAY_OES: number;

declare const GL_INT_SAMPLER_3D: number;

declare const GL_INT_SAMPLER_BUFFER_EXT: number;

declare const GL_INT_SAMPLER_BUFFER_OES: number;

declare const GL_INT_SAMPLER_CUBE: number;

declare const GL_INT_SAMPLER_CUBE_MAP_ARRAY_EXT: number;

declare const GL_INT_SAMPLER_CUBE_MAP_ARRAY_OES: number;

declare const GL_INT_VEC2: number;

declare const GL_INT_VEC3: number;

declare const GL_INT_VEC4: number;

declare const GL_INVALID_ENUM: number;

declare const GL_INVALID_FRAMEBUFFER_OPERATION: number;

declare const GL_INVALID_INDEX: number;

declare const GL_INVALID_OPERATION: number;

declare const GL_INVALID_VALUE: number;

declare const GL_INVERT: number;

declare const GL_INVERT_OVG_NV: number;

declare const GL_INVERT_RGB_NV: number;

declare const GL_ISOLINES_EXT: number;

declare const GL_ISOLINES_OES: number;

declare const GL_IS_PER_PATCH_EXT: number;

declare const GL_IS_PER_PATCH_OES: number;

declare const GL_ITALIC_BIT_NV: number;

declare const GL_KEEP: number;

declare const GL_KHR_blend_equation_advanced: number;

declare const GL_KHR_blend_equation_advanced_coherent: number;

declare const GL_KHR_context_flush_control: number;

declare const GL_KHR_debug: number;

declare const GL_KHR_no_error: number;

declare const GL_KHR_parallel_shader_compile: number;

declare const GL_KHR_robust_buffer_access_behavior: number;

declare const GL_KHR_robustness: number;

declare const GL_KHR_shader_subgroup: number;

declare const GL_KHR_texture_compression_astc_hdr: number;

declare const GL_KHR_texture_compression_astc_ldr: number;

declare const GL_KHR_texture_compression_astc_sliced_3d: number;

declare const GL_LARGE_CCW_ARC_TO_NV: number;

declare const GL_LARGE_CW_ARC_TO_NV: number;

declare const GL_LAST_VERTEX_CONVENTION_EXT: number;

declare const GL_LAST_VERTEX_CONVENTION_OES: number;

declare const GL_LAYER_PROVOKING_VERTEX_EXT: number;

declare const GL_LAYER_PROVOKING_VERTEX_OES: number;

declare const GL_LAYOUT_COLOR_ATTACHMENT_EXT: number;

declare const GL_LAYOUT_DEPTH_ATTACHMENT_STENCIL_READ_ONLY_EXT: number;

declare const GL_LAYOUT_DEPTH_READ_ONLY_STENCIL_ATTACHMENT_EXT: number;

declare const GL_LAYOUT_DEPTH_STENCIL_ATTACHMENT_EXT: number;

declare const GL_LAYOUT_DEPTH_STENCIL_READ_ONLY_EXT: number;

declare const GL_LAYOUT_GENERAL_EXT: number;

declare const GL_LAYOUT_SHADER_READ_ONLY_EXT: number;

declare const GL_LAYOUT_TRANSFER_DST_EXT: number;

declare const GL_LAYOUT_TRANSFER_SRC_EXT: number;

declare const GL_LEQUAL: number;

declare const GL_LESS: number;

declare const GL_LIGHTEN_KHR: number;

declare const GL_LIGHTEN_NV: number;

declare const GL_LINEAR: number;

declare const GL_LINEARBURN_NV: number;

declare const GL_LINEARDODGE_NV: number;

declare const GL_LINEARLIGHT_NV: number;

declare const GL_LINEAR_MIPMAP_LINEAR: number;

declare const GL_LINEAR_MIPMAP_NEAREST: number;

declare const GL_LINEAR_TILING_EXT: number;

declare const GL_LINES: number;

declare const GL_LINES_ADJACENCY_EXT: number;

declare const GL_LINES_ADJACENCY_OES: number;

declare const GL_LINE_LOOP: number;

declare const GL_LINE_NV: number;

declare const GL_LINE_STRIP: number;

declare const GL_LINE_STRIP_ADJACENCY_EXT: number;

declare const GL_LINE_STRIP_ADJACENCY_OES: number;

declare const GL_LINE_TO_NV: number;

declare const GL_LINE_WIDTH: number;

declare const GL_LINK_STATUS: number;

declare const GL_LOCATION_INDEX_EXT: number;

declare const GL_LOSE_CONTEXT_ON_RESET_EXT: number;

declare const GL_LOSE_CONTEXT_ON_RESET_KHR: number;

declare const GL_LOWER_LEFT_EXT: number;

declare const GL_LOW_FLOAT: number;

declare const GL_LOW_INT: number;

declare const GL_LUID_SIZE_EXT: number;

declare const GL_LUMINANCE: number;

declare const GL_LUMINANCE16F_EXT: number;

declare const GL_LUMINANCE32F_EXT: number;

declare const GL_LUMINANCE4_ALPHA4_OES: number;

declare const GL_LUMINANCE8_ALPHA8_EXT: number;

declare const GL_LUMINANCE8_ALPHA8_OES: number;

declare const GL_LUMINANCE8_EXT: number;

declare const GL_LUMINANCE8_OES: number;

declare const GL_LUMINANCE_ALPHA: number;

declare const GL_LUMINANCE_ALPHA16F_EXT: number;

declare const GL_LUMINANCE_ALPHA32F_EXT: number;

declare const GL_MAJOR_VERSION: number;

declare const GL_MALI_PROGRAM_BINARY_ARM: number;

declare const GL_MALI_SHADER_BINARY_ARM: number;

declare const GL_MAP_COHERENT_BIT_EXT: number;

declare const GL_MAP_FLUSH_EXPLICIT_BIT: number;

declare const GL_MAP_FLUSH_EXPLICIT_BIT_EXT: number;

declare const GL_MAP_INVALIDATE_BUFFER_BIT: number;

declare const GL_MAP_INVALIDATE_BUFFER_BIT_EXT: number;

declare const GL_MAP_INVALIDATE_RANGE_BIT: number;

declare const GL_MAP_INVALIDATE_RANGE_BIT_EXT: number;

declare const GL_MAP_PERSISTENT_BIT_EXT: number;

declare const GL_MAP_READ_BIT: number;

declare const GL_MAP_READ_BIT_EXT: number;

declare const GL_MAP_UNSYNCHRONIZED_BIT: number;

declare const GL_MAP_UNSYNCHRONIZED_BIT_EXT: number;

declare const GL_MAP_WRITE_BIT: number;

declare const GL_MAP_WRITE_BIT_EXT: number;

declare const GL_MAX: number;

declare const GL_MAX_3D_TEXTURE_SIZE: number;

declare const GL_MAX_3D_TEXTURE_SIZE_OES: number;

declare const GL_MAX_ARRAY_TEXTURE_LAYERS: number;

declare const GL_MAX_CLIP_DISTANCES_APPLE: number;

declare const GL_MAX_CLIP_DISTANCES_EXT: number;

declare const GL_MAX_COARSE_FRAGMENT_SAMPLES_NV: number;

declare const GL_MAX_COLOR_ATTACHMENTS: number;

declare const GL_MAX_COLOR_ATTACHMENTS_EXT: number;

declare const GL_MAX_COLOR_ATTACHMENTS_NV: number;

declare const GL_MAX_COLOR_FRAMEBUFFER_SAMPLES_AMD: number;

declare const GL_MAX_COLOR_FRAMEBUFFER_STORAGE_SAMPLES_AMD: number;

declare const GL_MAX_COMBINED_CLIP_AND_CULL_DISTANCES_EXT: number;

declare const GL_MAX_COMBINED_FRAGMENT_UNIFORM_COMPONENTS: number;

declare const GL_MAX_COMBINED_GEOMETRY_UNIFORM_COMPONENTS_EXT: number;

declare const GL_MAX_COMBINED_GEOMETRY_UNIFORM_COMPONENTS_OES: number;

declare const GL_MAX_COMBINED_MESH_UNIFORM_COMPONENTS_NV: number;

declare const GL_MAX_COMBINED_TASK_UNIFORM_COMPONENTS_NV: number;

declare const GL_MAX_COMBINED_TESS_CONTROL_UNIFORM_COMPONENTS_EXT: number;

declare const GL_MAX_COMBINED_TESS_CONTROL_UNIFORM_COMPONENTS_OES: number;

declare const GL_MAX_COMBINED_TESS_EVALUATION_UNIFORM_COMPONENTS_EXT: number;

declare const GL_MAX_COMBINED_TESS_EVALUATION_UNIFORM_COMPONENTS_OES: number;

declare const GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS: number;

declare const GL_MAX_COMBINED_UNIFORM_BLOCKS: number;

declare const GL_MAX_COMBINED_VERTEX_UNIFORM_COMPONENTS: number;

declare const GL_MAX_CUBE_MAP_TEXTURE_SIZE: number;

declare const GL_MAX_CULL_DISTANCES_EXT: number;

declare const GL_MAX_DEBUG_GROUP_STACK_DEPTH_KHR: number;

declare const GL_MAX_DEBUG_LOGGED_MESSAGES_KHR: number;

declare const GL_MAX_DEBUG_MESSAGE_LENGTH_KHR: number;

declare const GL_MAX_DEPTH_STENCIL_FRAMEBUFFER_SAMPLES_AMD: number;

declare const GL_MAX_DETACHED_BUFFERS_NV: number;

declare const GL_MAX_DETACHED_TEXTURES_NV: number;

declare const GL_MAX_DRAW_BUFFERS: number;

declare const GL_MAX_DRAW_BUFFERS_EXT: number;

declare const GL_MAX_DRAW_BUFFERS_NV: number;

declare const GL_MAX_DRAW_MESH_TASKS_COUNT_NV: number;

declare const GL_MAX_DUAL_SOURCE_DRAW_BUFFERS_EXT: number;

declare const GL_MAX_ELEMENTS_INDICES: number;

declare const GL_MAX_ELEMENTS_VERTICES: number;

declare const GL_MAX_ELEMENT_INDEX: number;

declare const GL_MAX_EXT: number;

declare const GL_MAX_FRAGMENT_INPUT_COMPONENTS: number;

declare const GL_MAX_FRAGMENT_INTERPOLATION_OFFSET_OES: number;

declare const GL_MAX_FRAGMENT_SHADING_RATE_ATTACHMENT_LAYERS_EXT: number;

declare const GL_MAX_FRAGMENT_SHADING_RATE_ATTACHMENT_TEXEL_ASPECT_RATIO_EXT: number;

declare const GL_MAX_FRAGMENT_SHADING_RATE_ATTACHMENT_TEXEL_HEIGHT_EXT: number;

declare const GL_MAX_FRAGMENT_SHADING_RATE_ATTACHMENT_TEXEL_WIDTH_EXT: number;

declare const GL_MAX_FRAGMENT_UNIFORM_BLOCKS: number;

declare const GL_MAX_FRAGMENT_UNIFORM_COMPONENTS: number;

declare const GL_MAX_FRAGMENT_UNIFORM_VECTORS: number;

declare const GL_MAX_FRAMEBUFFER_LAYERS_EXT: number;

declare const GL_MAX_FRAMEBUFFER_LAYERS_OES: number;

declare const GL_MAX_GEOMETRY_ATOMIC_COUNTERS_EXT: number;

declare const GL_MAX_GEOMETRY_ATOMIC_COUNTERS_OES: number;

declare const GL_MAX_GEOMETRY_ATOMIC_COUNTER_BUFFERS_EXT: number;

declare const GL_MAX_GEOMETRY_ATOMIC_COUNTER_BUFFERS_OES: number;

declare const GL_MAX_GEOMETRY_IMAGE_UNIFORMS_EXT: number;

declare const GL_MAX_GEOMETRY_IMAGE_UNIFORMS_OES: number;

declare const GL_MAX_GEOMETRY_INPUT_COMPONENTS_EXT: number;

declare const GL_MAX_GEOMETRY_INPUT_COMPONENTS_OES: number;

declare const GL_MAX_GEOMETRY_OUTPUT_COMPONENTS_EXT: number;

declare const GL_MAX_GEOMETRY_OUTPUT_COMPONENTS_OES: number;

declare const GL_MAX_GEOMETRY_OUTPUT_VERTICES_EXT: number;

declare const GL_MAX_GEOMETRY_OUTPUT_VERTICES_OES: number;

declare const GL_MAX_GEOMETRY_SHADER_INVOCATIONS_EXT: number;

declare const GL_MAX_GEOMETRY_SHADER_INVOCATIONS_OES: number;

declare const GL_MAX_GEOMETRY_SHADER_STORAGE_BLOCKS_EXT: number;

declare const GL_MAX_GEOMETRY_SHADER_STORAGE_BLOCKS_OES: number;

declare const GL_MAX_GEOMETRY_TEXTURE_IMAGE_UNITS_EXT: number;

declare const GL_MAX_GEOMETRY_TEXTURE_IMAGE_UNITS_OES: number;

declare const GL_MAX_GEOMETRY_TOTAL_OUTPUT_COMPONENTS_EXT: number;

declare const GL_MAX_GEOMETRY_TOTAL_OUTPUT_COMPONENTS_OES: number;

declare const GL_MAX_GEOMETRY_UNIFORM_BLOCKS_EXT: number;

declare const GL_MAX_GEOMETRY_UNIFORM_BLOCKS_OES: number;

declare const GL_MAX_GEOMETRY_UNIFORM_COMPONENTS_EXT: number;

declare const GL_MAX_GEOMETRY_UNIFORM_COMPONENTS_OES: number;

declare const GL_MAX_LABEL_LENGTH_KHR: number;

declare const GL_MAX_MESH_ATOMIC_COUNTERS_NV: number;

declare const GL_MAX_MESH_ATOMIC_COUNTER_BUFFERS_NV: number;

declare const GL_MAX_MESH_IMAGE_UNIFORMS_NV: number;

declare const GL_MAX_MESH_OUTPUT_PRIMITIVES_NV: number;

declare const GL_MAX_MESH_OUTPUT_VERTICES_NV: number;

declare const GL_MAX_MESH_SHADER_STORAGE_BLOCKS_NV: number;

declare const GL_MAX_MESH_TEXTURE_IMAGE_UNITS_NV: number;

declare const GL_MAX_MESH_TOTAL_MEMORY_SIZE_NV: number;

declare const GL_MAX_MESH_UNIFORM_BLOCKS_NV: number;

declare const GL_MAX_MESH_UNIFORM_COMPONENTS_NV: number;

declare const GL_MAX_MESH_VIEWS_NV: number;

declare const GL_MAX_MESH_WORK_GROUP_INVOCATIONS_NV: number;

declare const GL_MAX_MESH_WORK_GROUP_SIZE_NV: number;

declare const GL_MAX_MULTIVIEW_BUFFERS_EXT: number;

declare const GL_MAX_PATCH_VERTICES_EXT: number;

declare const GL_MAX_PATCH_VERTICES_OES: number;

declare const GL_MAX_PROGRAM_TEXEL_OFFSET: number;

declare const GL_MAX_RASTER_SAMPLES_EXT: number;

declare const GL_MAX_RENDERBUFFER_SIZE: number;

declare const GL_MAX_SAMPLES: number;

declare const GL_MAX_SAMPLES_ANGLE: number;

declare const GL_MAX_SAMPLES_APPLE: number;

declare const GL_MAX_SAMPLES_EXT: number;

declare const GL_MAX_SAMPLES_IMG: number;

declare const GL_MAX_SAMPLES_NV: number;

declare const GL_MAX_SERVER_WAIT_TIMEOUT: number;

declare const GL_MAX_SERVER_WAIT_TIMEOUT_APPLE: number;

declare const GL_MAX_SHADER_COMBINED_LOCAL_STORAGE_FAST_SIZE_EXT: number;

declare const GL_MAX_SHADER_COMBINED_LOCAL_STORAGE_SIZE_EXT: number;

declare const GL_MAX_SHADER_COMPILER_THREADS_KHR: number;

declare const GL_MAX_SHADER_PIXEL_LOCAL_STORAGE_FAST_SIZE_EXT: number;

declare const GL_MAX_SHADER_PIXEL_LOCAL_STORAGE_SIZE_EXT: number;

declare const GL_MAX_SHADER_SUBSAMPLED_IMAGE_UNITS_QCOM: number;

declare const GL_MAX_SPARSE_3D_TEXTURE_SIZE_EXT: number;

declare const GL_MAX_SPARSE_ARRAY_TEXTURE_LAYERS_EXT: number;

declare const GL_MAX_SPARSE_TEXTURE_SIZE_EXT: number;

declare const GL_MAX_SUBPIXEL_PRECISION_BIAS_BITS_NV: number;

declare const GL_MAX_TASK_ATOMIC_COUNTERS_NV: number;

declare const GL_MAX_TASK_ATOMIC_COUNTER_BUFFERS_NV: number;

declare const GL_MAX_TASK_IMAGE_UNIFORMS_NV: number;

declare const GL_MAX_TASK_OUTPUT_COUNT_NV: number;

declare const GL_MAX_TASK_SHADER_STORAGE_BLOCKS_NV: number;

declare const GL_MAX_TASK_TEXTURE_IMAGE_UNITS_NV: number;

declare const GL_MAX_TASK_TOTAL_MEMORY_SIZE_NV: number;

declare const GL_MAX_TASK_UNIFORM_BLOCKS_NV: number;

declare const GL_MAX_TASK_UNIFORM_COMPONENTS_NV: number;

declare const GL_MAX_TASK_WORK_GROUP_INVOCATIONS_NV: number;

declare const GL_MAX_TASK_WORK_GROUP_SIZE_NV: number;

declare const GL_MAX_TESS_CONTROL_ATOMIC_COUNTERS_EXT: number;

declare const GL_MAX_TESS_CONTROL_ATOMIC_COUNTERS_OES: number;

declare const GL_MAX_TESS_CONTROL_ATOMIC_COUNTER_BUFFERS_EXT: number;

declare const GL_MAX_TESS_CONTROL_ATOMIC_COUNTER_BUFFERS_OES: number;

declare const GL_MAX_TESS_CONTROL_IMAGE_UNIFORMS_EXT: number;

declare const GL_MAX_TESS_CONTROL_IMAGE_UNIFORMS_OES: number;

declare const GL_MAX_TESS_CONTROL_INPUT_COMPONENTS_EXT: number;

declare const GL_MAX_TESS_CONTROL_INPUT_COMPONENTS_OES: number;

declare const GL_MAX_TESS_CONTROL_OUTPUT_COMPONENTS_EXT: number;

declare const GL_MAX_TESS_CONTROL_OUTPUT_COMPONENTS_OES: number;

declare const GL_MAX_TESS_CONTROL_SHADER_STORAGE_BLOCKS_EXT: number;

declare const GL_MAX_TESS_CONTROL_SHADER_STORAGE_BLOCKS_OES: number;

declare const GL_MAX_TESS_CONTROL_TEXTURE_IMAGE_UNITS_EXT: number;

declare const GL_MAX_TESS_CONTROL_TEXTURE_IMAGE_UNITS_OES: number;

declare const GL_MAX_TESS_CONTROL_TOTAL_OUTPUT_COMPONENTS_EXT: number;

declare const GL_MAX_TESS_CONTROL_TOTAL_OUTPUT_COMPONENTS_OES: number;

declare const GL_MAX_TESS_CONTROL_UNIFORM_BLOCKS_EXT: number;

declare const GL_MAX_TESS_CONTROL_UNIFORM_BLOCKS_OES: number;

declare const GL_MAX_TESS_CONTROL_UNIFORM_COMPONENTS_EXT: number;

declare const GL_MAX_TESS_CONTROL_UNIFORM_COMPONENTS_OES: number;

declare const GL_MAX_TESS_EVALUATION_ATOMIC_COUNTERS_EXT: number;

declare const GL_MAX_TESS_EVALUATION_ATOMIC_COUNTERS_OES: number;

declare const GL_MAX_TESS_EVALUATION_ATOMIC_COUNTER_BUFFERS_EXT: number;

declare const GL_MAX_TESS_EVALUATION_ATOMIC_COUNTER_BUFFERS_OES: number;

declare const GL_MAX_TESS_EVALUATION_IMAGE_UNIFORMS_EXT: number;

declare const GL_MAX_TESS_EVALUATION_IMAGE_UNIFORMS_OES: number;

declare const GL_MAX_TESS_EVALUATION_INPUT_COMPONENTS_EXT: number;

declare const GL_MAX_TESS_EVALUATION_INPUT_COMPONENTS_OES: number;

declare const GL_MAX_TESS_EVALUATION_OUTPUT_COMPONENTS_EXT: number;

declare const GL_MAX_TESS_EVALUATION_OUTPUT_COMPONENTS_OES: number;

declare const GL_MAX_TESS_EVALUATION_SHADER_STORAGE_BLOCKS_EXT: number;

declare const GL_MAX_TESS_EVALUATION_SHADER_STORAGE_BLOCKS_OES: number;

declare const GL_MAX_TESS_EVALUATION_TEXTURE_IMAGE_UNITS_EXT: number;

declare const GL_MAX_TESS_EVALUATION_TEXTURE_IMAGE_UNITS_OES: number;

declare const GL_MAX_TESS_EVALUATION_UNIFORM_BLOCKS_EXT: number;

declare const GL_MAX_TESS_EVALUATION_UNIFORM_BLOCKS_OES: number;

declare const GL_MAX_TESS_EVALUATION_UNIFORM_COMPONENTS_EXT: number;

declare const GL_MAX_TESS_EVALUATION_UNIFORM_COMPONENTS_OES: number;

declare const GL_MAX_TESS_GEN_LEVEL_EXT: number;

declare const GL_MAX_TESS_GEN_LEVEL_OES: number;

declare const GL_MAX_TESS_PATCH_COMPONENTS_EXT: number;

declare const GL_MAX_TESS_PATCH_COMPONENTS_OES: number;

declare const GL_MAX_TEXTURE_BUFFER_SIZE_EXT: number;

declare const GL_MAX_TEXTURE_BUFFER_SIZE_OES: number;

declare const GL_MAX_TEXTURE_IMAGE_UNITS: number;

declare const GL_MAX_TEXTURE_LOD_BIAS: number;

declare const GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT: number;

declare const GL_MAX_TEXTURE_SIZE: number;

declare const GL_MAX_TIMELINE_SEMAPHORE_VALUE_DIFFERENCE_NV: number;

declare const GL_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS: number;

declare const GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS: number;

declare const GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS: number;

declare const GL_MAX_UNIFORM_BLOCK_SIZE: number;

declare const GL_MAX_UNIFORM_BUFFER_BINDINGS: number;

declare const GL_MAX_VARYING_COMPONENTS: number;

declare const GL_MAX_VARYING_VECTORS: number;

declare const GL_MAX_VERTEX_ATTRIBS: number;

declare const GL_MAX_VERTEX_OUTPUT_COMPONENTS: number;

declare const GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS: number;

declare const GL_MAX_VERTEX_UNIFORM_BLOCKS: number;

declare const GL_MAX_VERTEX_UNIFORM_COMPONENTS: number;

declare const GL_MAX_VERTEX_UNIFORM_VECTORS: number;

declare const GL_MAX_VIEWPORTS_NV: number;

declare const GL_MAX_VIEWPORTS_OES: number;

declare const GL_MAX_VIEWPORT_DIMS: number;

declare const GL_MAX_VIEWS_OVR: number;

declare const GL_MAX_WINDOW_RECTANGLES_EXT: number;

declare const GL_MEDIUM_FLOAT: number;

declare const GL_MEDIUM_INT: number;

declare const GL_MEMORY_ATTACHABLE_ALIGNMENT_NV: number;

declare const GL_MEMORY_ATTACHABLE_NV: number;

declare const GL_MEMORY_ATTACHABLE_SIZE_NV: number;

declare const GL_MESA_bgra: number;

declare const GL_MESA_framebuffer_flip_x: number;

declare const GL_MESA_framebuffer_flip_y: number;

declare const GL_MESA_framebuffer_swap_xy: number;

declare const GL_MESA_program_binary_formats: number;

declare const GL_MESA_shader_integer_functions: number;

declare const GL_MESH_OUTPUT_PER_PRIMITIVE_GRANULARITY_NV: number;

declare const GL_MESH_OUTPUT_PER_VERTEX_GRANULARITY_NV: number;

declare const GL_MESH_OUTPUT_TYPE_NV: number;

declare const GL_MESH_PRIMITIVES_OUT_NV: number;

declare const GL_MESH_SHADER_BIT_NV: number;

declare const GL_MESH_SHADER_NV: number;

declare const GL_MESH_SUBROUTINE_NV: number;

declare const GL_MESH_SUBROUTINE_UNIFORM_NV: number;

declare const GL_MESH_VERTICES_OUT_NV: number;

declare const GL_MESH_WORK_GROUP_SIZE_NV: number;

declare const GL_MIN: number;

declare const GL_MINOR_VERSION: number;

declare const GL_MINUS_CLAMPED_NV: number;

declare const GL_MINUS_NV: number;

declare const GL_MIN_EXT: number;

declare const GL_MIN_FRAGMENT_INTERPOLATION_OFFSET_OES: number;

declare const GL_MIN_FRAGMENT_SHADING_RATE_ATTACHMENT_TEXEL_HEIGHT_EXT: number;

declare const GL_MIN_FRAGMENT_SHADING_RATE_ATTACHMENT_TEXEL_WIDTH_EXT: number;

declare const GL_MIN_PROGRAM_TEXEL_OFFSET: number;

declare const GL_MIN_SAMPLE_SHADING_VALUE_OES: number;

declare const GL_MIRRORED_REPEAT: number;

declare const GL_MIRROR_CLAMP_TO_EDGE_EXT: number;

declare const GL_MITER_REVERT_NV: number;

declare const GL_MITER_TRUNCATE_NV: number;

declare const GL_MIXED_DEPTH_SAMPLES_SUPPORTED_NV: number;

declare const GL_MIXED_STENCIL_SAMPLES_SUPPORTED_NV: number;

declare const GL_MOTION_ESTIMATION_SEARCH_BLOCK_X_QCOM: number;

declare const GL_MOTION_ESTIMATION_SEARCH_BLOCK_Y_QCOM: number;

declare const GL_MOVE_TO_CONTINUES_NV: number;

declare const GL_MOVE_TO_NV: number;

declare const GL_MOVE_TO_RESETS_NV: number;

declare const GL_MULTIPLY_KHR: number;

declare const GL_MULTIPLY_NV: number;

declare const GL_MULTISAMPLES_NV: number;

declare const GL_MULTISAMPLE_BUFFER_BIT0_QCOM: number;

declare const GL_MULTISAMPLE_BUFFER_BIT1_QCOM: number;

declare const GL_MULTISAMPLE_BUFFER_BIT2_QCOM: number;

declare const GL_MULTISAMPLE_BUFFER_BIT3_QCOM: number;

declare const GL_MULTISAMPLE_BUFFER_BIT4_QCOM: number;

declare const GL_MULTISAMPLE_BUFFER_BIT5_QCOM: number;

declare const GL_MULTISAMPLE_BUFFER_BIT6_QCOM: number;

declare const GL_MULTISAMPLE_BUFFER_BIT7_QCOM: number;

declare const GL_MULTISAMPLE_EXT: number;

declare const GL_MULTISAMPLE_RASTERIZATION_ALLOWED_EXT: number;

declare const GL_MULTIVIEW_EXT: number;

declare const GL_NEAREST: number;

declare const GL_NEAREST_MIPMAP_LINEAR: number;

declare const GL_NEAREST_MIPMAP_NEAREST: number;

declare const GL_NEGATIVE_ONE_TO_ONE_EXT: number;

declare const GL_NEVER: number;

declare const GL_NICEST: number;

declare const GL_NONE: number;

declare const GL_NOTEQUAL: number;

declare const GL_NO_ERROR: number;

declare const GL_NO_RESET_NOTIFICATION_EXT: number;

declare const GL_NO_RESET_NOTIFICATION_KHR: number;

declare const GL_NUM_COMPRESSED_TEXTURE_FORMATS: number;

declare const GL_NUM_DEVICE_UUIDS_EXT: number;

declare const GL_NUM_DOWNSAMPLE_SCALES_IMG: number;

declare const GL_NUM_EXTENSIONS: number;

declare const GL_NUM_PROGRAM_BINARY_FORMATS: number;

declare const GL_NUM_PROGRAM_BINARY_FORMATS_OES: number;

declare const GL_NUM_SAMPLE_COUNTS: number;

declare const GL_NUM_SHADER_BINARY_FORMATS: number;

declare const GL_NUM_SPARSE_LEVELS_EXT: number;

declare const GL_NUM_SUPPORTED_MULTISAMPLE_MODES_AMD: number;

declare const GL_NUM_SURFACE_COMPRESSION_FIXED_RATES_EXT: number;

declare const GL_NUM_TILING_TYPES_EXT: number;

declare const GL_NUM_VIRTUAL_PAGE_SIZES_EXT: number;

declare const GL_NUM_WINDOW_RECTANGLES_EXT: number;

declare const GL_NVX_blend_equation_advanced_multi_draw_buffers: number;

declare const GL_NV_bindless_texture: number;

declare const GL_NV_blend_equation_advanced: number;

declare const GL_NV_blend_equation_advanced_coherent: number;

declare const GL_NV_blend_minmax_factor: number;

declare const GL_NV_clip_space_w_scaling: number;

declare const GL_NV_compute_shader_derivatives: number;

declare const GL_NV_conditional_render: number;

declare const GL_NV_conservative_raster: number;

declare const GL_NV_conservative_raster_pre_snap: number;

declare const GL_NV_conservative_raster_pre_snap_triangles: number;

declare const GL_NV_copy_buffer: number;

declare const GL_NV_coverage_sample: number;

declare const GL_NV_depth_nonlinear: number;

declare const GL_NV_draw_buffers: number;

declare const GL_NV_draw_instanced: number;

declare const GL_NV_draw_vulkan_image: number;

declare const GL_NV_explicit_attrib_location: number;

declare const GL_NV_fbo_color_attachments: number;

declare const GL_NV_fence: number;

declare const GL_NV_fill_rectangle: number;

declare const GL_NV_fragment_coverage_to_color: number;

declare const GL_NV_fragment_shader_barycentric: number;

declare const GL_NV_fragment_shader_interlock: number;

declare const GL_NV_framebuffer_blit: number;

declare const GL_NV_framebuffer_mixed_samples: number;

declare const GL_NV_framebuffer_multisample: number;

declare const GL_NV_generate_mipmap_sRGB: number;

declare const GL_NV_geometry_shader_passthrough: number;

declare const GL_NV_gpu_shader5: number;

declare const GL_NV_image_formats: number;

declare const GL_NV_instanced_arrays: number;

declare const GL_NV_internalformat_sample_query: number;

declare const GL_NV_memory_attachment: number;

declare const GL_NV_memory_object_sparse: number;

declare const GL_NV_mesh_shader: number;

declare const GL_NV_non_square_matrices: number;

declare const GL_NV_path_rendering: number;

declare const GL_NV_path_rendering_shared_edge: number;

declare const GL_NV_pixel_buffer_object: number;

declare const GL_NV_polygon_mode: number;

declare const GL_NV_primitive_shading_rate: number;

declare const GL_NV_read_buffer: number;

declare const GL_NV_read_buffer_front: number;

declare const GL_NV_read_depth: number;

declare const GL_NV_read_depth_stencil: number;

declare const GL_NV_read_stencil: number;

declare const GL_NV_representative_fragment_test: number;

declare const GL_NV_sRGB_formats: number;

declare const GL_NV_sample_locations: number;

declare const GL_NV_sample_mask_override_coverage: number;

declare const GL_NV_scissor_exclusive: number;

declare const GL_NV_shader_atomic_fp16_vector: number;

declare const GL_NV_shader_noperspective_interpolation: number;

declare const GL_NV_shader_subgroup_partitioned: number;

declare const GL_NV_shader_texture_footprint: number;

declare const GL_NV_shading_rate_image: number;

declare const GL_NV_shadow_samplers_array: number;

declare const GL_NV_shadow_samplers_cube: number;

declare const GL_NV_stereo_view_rendering: number;

declare const GL_NV_texture_border_clamp: number;

declare const GL_NV_texture_compression_s3tc_update: number;

declare const GL_NV_texture_npot_2D_mipmap: number;

declare const GL_NV_timeline_semaphore: number;

declare const GL_NV_viewport_array: number;

declare const GL_NV_viewport_array2: number;

declare const GL_NV_viewport_swizzle: number;

declare const GL_OBJECT_TYPE: number;

declare const GL_OBJECT_TYPE_APPLE: number;

declare const GL_OES_EGL_image: number;

declare const GL_OES_EGL_image_external: number;

declare const GL_OES_EGL_image_external_essl3: number;

declare const GL_OES_compressed_ETC1_RGB8_sub_texture: number;

declare const GL_OES_compressed_ETC1_RGB8_texture: number;

declare const GL_OES_compressed_paletted_texture: number;

declare const GL_OES_copy_image: number;

declare const GL_OES_depth24: number;

declare const GL_OES_depth32: number;

declare const GL_OES_depth_texture: number;

declare const GL_OES_draw_buffers_indexed: number;

declare const GL_OES_draw_elements_base_vertex: number;

declare const GL_OES_element_index_uint: number;

declare const GL_OES_fbo_render_mipmap: number;

declare const GL_OES_fragment_precision_high: number;

declare const GL_OES_geometry_point_size: number;

declare const GL_OES_geometry_shader: number;

declare const GL_OES_get_program_binary: number;

declare const GL_OES_gpu_shader5: number;

declare const GL_OES_mapbuffer: number;

declare const GL_OES_packed_depth_stencil: number;

declare const GL_OES_primitive_bounding_box: number;

declare const GL_OES_required_internalformat: number;

declare const GL_OES_rgb8_rgba8: number;

declare const GL_OES_sample_shading: number;

declare const GL_OES_sample_variables: number;

declare const GL_OES_shader_image_atomic: number;

declare const GL_OES_shader_io_blocks: number;

declare const GL_OES_shader_multisample_interpolation: number;

declare const GL_OES_standard_derivatives: number;

declare const GL_OES_stencil1: number;

declare const GL_OES_stencil4: number;

declare const GL_OES_surfaceless_context: number;

declare const GL_OES_tessellation_point_size: number;

declare const GL_OES_tessellation_shader: number;

declare const GL_OES_texture_3D: number;

declare const GL_OES_texture_border_clamp: number;

declare const GL_OES_texture_buffer: number;

declare const GL_OES_texture_compression_astc: number;

declare const GL_OES_texture_cube_map_array: number;

declare const GL_OES_texture_float: number;

declare const GL_OES_texture_float_linear: number;

declare const GL_OES_texture_half_float: number;

declare const GL_OES_texture_half_float_linear: number;

declare const GL_OES_texture_npot: number;

declare const GL_OES_texture_stencil8: number;

declare const GL_OES_texture_storage_multisample_2d_array: number;

declare const GL_OES_texture_view: number;

declare const GL_OES_vertex_array_object: number;

declare const GL_OES_vertex_half_float: number;

declare const GL_OES_vertex_type_10_10_10_2: number;

declare const GL_OES_viewport_array: number;

declare const GL_ONE: number;

declare const GL_ONE_MINUS_CONSTANT_ALPHA: number;

declare const GL_ONE_MINUS_CONSTANT_COLOR: number;

declare const GL_ONE_MINUS_DST_ALPHA: number;

declare const GL_ONE_MINUS_DST_COLOR: number;

declare const GL_ONE_MINUS_SRC1_ALPHA_EXT: number;

declare const GL_ONE_MINUS_SRC1_COLOR_EXT: number;

declare const GL_ONE_MINUS_SRC_ALPHA: number;

declare const GL_ONE_MINUS_SRC_COLOR: number;

declare const GL_OPTIMAL_TILING_EXT: number;

declare const GL_OUT_OF_MEMORY: number;

declare const GL_OVERLAY_KHR: number;

declare const GL_OVERLAY_NV: number;

declare const GL_OVR_multiview: number;

declare const GL_OVR_multiview2: number;

declare const GL_OVR_multiview_multisampled_render_to_texture: number;

declare const GL_PACK_ALIGNMENT: number;

declare const GL_PACK_REVERSE_ROW_ORDER_ANGLE: number;

declare const GL_PACK_ROW_LENGTH: number;

declare const GL_PACK_SKIP_PIXELS: number;

declare const GL_PACK_SKIP_ROWS: number;

declare const GL_PALETTE4_R5_G6_B5_OES: number;

declare const GL_PALETTE4_RGB5_A1_OES: number;

declare const GL_PALETTE4_RGB8_OES: number;

declare const GL_PALETTE4_RGBA4_OES: number;

declare const GL_PALETTE4_RGBA8_OES: number;

declare const GL_PALETTE8_R5_G6_B5_OES: number;

declare const GL_PALETTE8_RGB5_A1_OES: number;

declare const GL_PALETTE8_RGB8_OES: number;

declare const GL_PALETTE8_RGBA4_OES: number;

declare const GL_PALETTE8_RGBA8_OES: number;

declare const GL_PATCHES: number;

declare const GL_PATCHES_EXT: number;

declare const GL_PATCHES_OES: number;

declare const GL_PATCH_VERTICES_EXT: number;

declare const GL_PATCH_VERTICES_OES: number;

declare const GL_PATH_CLIENT_LENGTH_NV: number;

declare const GL_PATH_COMMAND_COUNT_NV: number;

declare const GL_PATH_COMPUTED_LENGTH_NV: number;

declare const GL_PATH_COORD_COUNT_NV: number;

declare const GL_PATH_COVER_DEPTH_FUNC_NV: number;

declare const GL_PATH_DASH_ARRAY_COUNT_NV: number;

declare const GL_PATH_DASH_CAPS_NV: number;

declare const GL_PATH_DASH_OFFSET_NV: number;

declare const GL_PATH_DASH_OFFSET_RESET_NV: number;

declare const GL_PATH_END_CAPS_NV: number;

declare const GL_PATH_ERROR_POSITION_NV: number;

declare const GL_PATH_FILL_BOUNDING_BOX_NV: number;

declare const GL_PATH_FILL_COVER_MODE_NV: number;

declare const GL_PATH_FILL_MASK_NV: number;

declare const GL_PATH_FILL_MODE_NV: number;

declare const GL_PATH_FORMAT_PS_NV: number;

declare const GL_PATH_FORMAT_SVG_NV: number;

declare const GL_PATH_GEN_COEFF_NV: number;

declare const GL_PATH_GEN_COMPONENTS_NV: number;

declare const GL_PATH_GEN_MODE_NV: number;

declare const GL_PATH_INITIAL_DASH_CAP_NV: number;

declare const GL_PATH_INITIAL_END_CAP_NV: number;

declare const GL_PATH_JOIN_STYLE_NV: number;

declare const GL_PATH_MAX_MODELVIEW_STACK_DEPTH_NV: number;

declare const GL_PATH_MAX_PROJECTION_STACK_DEPTH_NV: number;

declare const GL_PATH_MITER_LIMIT_NV: number;

declare const GL_PATH_MODELVIEW_MATRIX_NV: number;

declare const GL_PATH_MODELVIEW_NV: number;

declare const GL_PATH_MODELVIEW_STACK_DEPTH_NV: number;

declare const GL_PATH_OBJECT_BOUNDING_BOX_NV: number;

declare const GL_PATH_PROJECTION_MATRIX_NV: number;

declare const GL_PATH_PROJECTION_NV: number;

declare const GL_PATH_PROJECTION_STACK_DEPTH_NV: number;

declare const GL_PATH_STENCIL_DEPTH_OFFSET_FACTOR_NV: number;

declare const GL_PATH_STENCIL_DEPTH_OFFSET_UNITS_NV: number;

declare const GL_PATH_STENCIL_FUNC_NV: number;

declare const GL_PATH_STENCIL_REF_NV: number;

declare const GL_PATH_STENCIL_VALUE_MASK_NV: number;

declare const GL_PATH_STROKE_BOUNDING_BOX_NV: number;

declare const GL_PATH_STROKE_COVER_MODE_NV: number;

declare const GL_PATH_STROKE_MASK_NV: number;

declare const GL_PATH_STROKE_WIDTH_NV: number;

declare const GL_PATH_TERMINAL_DASH_CAP_NV: number;

declare const GL_PATH_TERMINAL_END_CAP_NV: number;

declare const GL_PATH_TRANSPOSE_MODELVIEW_MATRIX_NV: number;

declare const GL_PATH_TRANSPOSE_PROJECTION_MATRIX_NV: number;

declare const GL_PERCENTAGE_AMD: number;

declare const GL_PERFMON_GLOBAL_MODE_QCOM: number;

declare const GL_PERFMON_RESULT_AMD: number;

declare const GL_PERFMON_RESULT_AVAILABLE_AMD: number;

declare const GL_PERFMON_RESULT_SIZE_AMD: number;

declare const GL_PERFQUERY_COUNTER_DATA_BOOL32_INTEL: number;

declare const GL_PERFQUERY_COUNTER_DATA_DOUBLE_INTEL: number;

declare const GL_PERFQUERY_COUNTER_DATA_FLOAT_INTEL: number;

declare const GL_PERFQUERY_COUNTER_DATA_UINT32_INTEL: number;

declare const GL_PERFQUERY_COUNTER_DATA_UINT64_INTEL: number;

declare const GL_PERFQUERY_COUNTER_DESC_LENGTH_MAX_INTEL: number;

declare const GL_PERFQUERY_COUNTER_DURATION_NORM_INTEL: number;

declare const GL_PERFQUERY_COUNTER_DURATION_RAW_INTEL: number;

declare const GL_PERFQUERY_COUNTER_EVENT_INTEL: number;

declare const GL_PERFQUERY_COUNTER_NAME_LENGTH_MAX_INTEL: number;

declare const GL_PERFQUERY_COUNTER_RAW_INTEL: number;

declare const GL_PERFQUERY_COUNTER_THROUGHPUT_INTEL: number;

declare const GL_PERFQUERY_COUNTER_TIMESTAMP_INTEL: number;

declare const GL_PERFQUERY_DONOT_FLUSH_INTEL: number;

declare const GL_PERFQUERY_FLUSH_INTEL: number;

declare const GL_PERFQUERY_GLOBAL_CONTEXT_INTEL: number;

declare const GL_PERFQUERY_GPA_EXTENDED_COUNTERS_INTEL: number;

declare const GL_PERFQUERY_QUERY_NAME_LENGTH_MAX_INTEL: number;

declare const GL_PERFQUERY_SINGLE_CONTEXT_INTEL: number;

declare const GL_PERFQUERY_WAIT_INTEL: number;

declare const GL_PINLIGHT_NV: number;

declare const GL_PIXEL_PACK_BUFFER: number;

declare const GL_PIXEL_PACK_BUFFER_BINDING: number;

declare const GL_PIXEL_PACK_BUFFER_BINDING_NV: number;

declare const GL_PIXEL_PACK_BUFFER_NV: number;

declare const GL_PIXEL_UNPACK_BUFFER: number;

declare const GL_PIXEL_UNPACK_BUFFER_BINDING: number;

declare const GL_PIXEL_UNPACK_BUFFER_BINDING_NV: number;

declare const GL_PIXEL_UNPACK_BUFFER_NV: number;

declare const GL_PLUS_CLAMPED_ALPHA_NV: number;

declare const GL_PLUS_CLAMPED_NV: number;

declare const GL_PLUS_DARKER_NV: number;

declare const GL_PLUS_NV: number;

declare const GL_POINTS: number;

declare const GL_POINT_NV: number;

declare const GL_POLYGON_MODE_NV: number;

declare const GL_POLYGON_OFFSET_CLAMP_EXT: number;

declare const GL_POLYGON_OFFSET_FACTOR: number;

declare const GL_POLYGON_OFFSET_FILL: number;

declare const GL_POLYGON_OFFSET_LINE_NV: number;

declare const GL_POLYGON_OFFSET_POINT_NV: number;

declare const GL_POLYGON_OFFSET_UNITS: number;

declare const GL_PRIMITIVES_GENERATED_EXT: number;

declare const GL_PRIMITIVES_GENERATED_OES: number;

declare const GL_PRIMITIVE_BOUNDING_BOX_EXT: number;

declare const GL_PRIMITIVE_BOUNDING_BOX_OES: number;

declare const GL_PRIMITIVE_RESTART_FIXED_INDEX: number;

declare const GL_PRIMITIVE_RESTART_FOR_PATCHES_SUPPORTED: number;

declare const GL_PRIMITIVE_RESTART_FOR_PATCHES_SUPPORTED_OES: number;

declare const GL_PROGRAMMABLE_SAMPLE_LOCATION_NV: number;

declare const GL_PROGRAMMABLE_SAMPLE_LOCATION_TABLE_SIZE_NV: number;

declare const GL_PROGRAM_BINARY_ANGLE: number;

declare const GL_PROGRAM_BINARY_FORMATS: number;

declare const GL_PROGRAM_BINARY_FORMATS_OES: number;

declare const GL_PROGRAM_BINARY_FORMAT_MESA: number;

declare const GL_PROGRAM_BINARY_LENGTH: number;

declare const GL_PROGRAM_BINARY_LENGTH_OES: number;

declare const GL_PROGRAM_BINARY_RETRIEVABLE_HINT: number;

declare const GL_PROGRAM_KHR: number;

declare const GL_PROGRAM_OBJECT_EXT: number;

declare const GL_PROGRAM_PIPELINE_BINDING_EXT: number;

declare const GL_PROGRAM_PIPELINE_KHR: number;

declare const GL_PROGRAM_PIPELINE_OBJECT_EXT: number;

declare const GL_PROGRAM_SEPARABLE_EXT: number;

declare const GL_PROTECTED_MEMORY_OBJECT_EXT: number;

declare const GL_QCOM_YUV_texture_gather: number;

declare const GL_QCOM_alpha_test: number;

declare const GL_QCOM_binning_control: number;

declare const GL_QCOM_driver_control: number;

declare const GL_QCOM_extended_get: number;

declare const GL_QCOM_extended_get2: number;

declare const GL_QCOM_frame_extrapolation: number;

declare const GL_QCOM_framebuffer_foveated: number;

declare const GL_QCOM_motion_estimation: number;

declare const GL_QCOM_perfmon_global_mode: number;

declare const GL_QCOM_render_shared_exponent: number;

declare const GL_QCOM_shader_framebuffer_fetch_noncoherent: number;

declare const GL_QCOM_shader_framebuffer_fetch_rate: number;

declare const GL_QCOM_shading_rate: number;

declare const GL_QCOM_texture_foveated: number;

declare const GL_QCOM_texture_foveated2: number;

declare const GL_QCOM_texture_foveated_subsampled_layout: number;

declare const GL_QCOM_tiled_rendering: number;

declare const GL_QCOM_writeonly_rendering: number;

declare const GL_QUADRATIC_CURVE_TO_NV: number;

declare const GL_QUADS_EXT: number;

declare const GL_QUADS_OES: number;

declare const GL_QUERY_BY_REGION_NO_WAIT_NV: number;

declare const GL_QUERY_BY_REGION_WAIT_NV: number;

declare const GL_QUERY_COUNTER_BITS_EXT: number;

declare const GL_QUERY_KHR: number;

declare const GL_QUERY_NO_WAIT_NV: number;

declare const GL_QUERY_OBJECT_EXT: number;

declare const GL_QUERY_RESULT: number;

declare const GL_QUERY_RESULT_AVAILABLE: number;

declare const GL_QUERY_RESULT_AVAILABLE_EXT: number;

declare const GL_QUERY_RESULT_EXT: number;

declare const GL_QUERY_WAIT_NV: number;

declare const GL_R11F_G11F_B10F: number;

declare const GL_R11F_G11F_B10F_APPLE: number;

declare const GL_R16F: number;

declare const GL_R16F_EXT: number;

declare const GL_R16I: number;

declare const GL_R16UI: number;

declare const GL_R16_EXT: number;

declare const GL_R16_SNORM_EXT: number;

declare const GL_R32F: number;

declare const GL_R32F_EXT: number;

declare const GL_R32I: number;

declare const GL_R32UI: number;

declare const GL_R8: number;

declare const GL_R8I: number;

declare const GL_R8UI: number;

declare const GL_R8_EXT: number;

declare const GL_R8_SNORM: number;

declare const GL_RASTERIZER_DISCARD: number;

declare const GL_RASTER_FIXED_SAMPLE_LOCATIONS_EXT: number;

declare const GL_RASTER_MULTISAMPLE_EXT: number;

declare const GL_RASTER_SAMPLES_EXT: number;

declare const GL_READ_BUFFER: number;

declare const GL_READ_BUFFER_EXT: number;

declare const GL_READ_BUFFER_NV: number;

declare const GL_READ_FRAMEBUFFER: number;

declare const GL_READ_FRAMEBUFFER_ANGLE: number;

declare const GL_READ_FRAMEBUFFER_APPLE: number;

declare const GL_READ_FRAMEBUFFER_BINDING: number;

declare const GL_READ_FRAMEBUFFER_BINDING_ANGLE: number;

declare const GL_READ_FRAMEBUFFER_BINDING_APPLE: number;

declare const GL_READ_FRAMEBUFFER_BINDING_NV: number;

declare const GL_READ_FRAMEBUFFER_NV: number;

declare const GL_RECT_NV: number;

declare const GL_RED: number;

declare const GL_RED_BITS: number;

declare const GL_RED_EXT: number;

declare const GL_RED_INTEGER: number;

declare const GL_RED_NV: number;

declare const GL_REFERENCED_BY_GEOMETRY_SHADER_EXT: number;

declare const GL_REFERENCED_BY_GEOMETRY_SHADER_OES: number;

declare const GL_REFERENCED_BY_MESH_SHADER_NV: number;

declare const GL_REFERENCED_BY_TASK_SHADER_NV: number;

declare const GL_REFERENCED_BY_TESS_CONTROL_SHADER_EXT: number;

declare const GL_REFERENCED_BY_TESS_CONTROL_SHADER_OES: number;

declare const GL_REFERENCED_BY_TESS_EVALUATION_SHADER_EXT: number;

declare const GL_REFERENCED_BY_TESS_EVALUATION_SHADER_OES: number;

declare const GL_RELATIVE_ARC_TO_NV: number;

declare const GL_RELATIVE_CONIC_CURVE_TO_NV: number;

declare const GL_RELATIVE_CUBIC_CURVE_TO_NV: number;

declare const GL_RELATIVE_HORIZONTAL_LINE_TO_NV: number;

declare const GL_RELATIVE_LARGE_CCW_ARC_TO_NV: number;

declare const GL_RELATIVE_LARGE_CW_ARC_TO_NV: number;

declare const GL_RELATIVE_LINE_TO_NV: number;

declare const GL_RELATIVE_MOVE_TO_NV: number;

declare const GL_RELATIVE_QUADRATIC_CURVE_TO_NV: number;

declare const GL_RELATIVE_RECT_NV: number;

declare const GL_RELATIVE_ROUNDED_RECT2_NV: number;

declare const GL_RELATIVE_ROUNDED_RECT4_NV: number;

declare const GL_RELATIVE_ROUNDED_RECT8_NV: number;

declare const GL_RELATIVE_ROUNDED_RECT_NV: number;

declare const GL_RELATIVE_SMALL_CCW_ARC_TO_NV: number;

declare const GL_RELATIVE_SMALL_CW_ARC_TO_NV: number;

declare const GL_RELATIVE_SMOOTH_CUBIC_CURVE_TO_NV: number;

declare const GL_RELATIVE_SMOOTH_QUADRATIC_CURVE_TO_NV: number;

declare const GL_RELATIVE_VERTICAL_LINE_TO_NV: number;

declare const GL_RENDERBUFFER: number;

declare const GL_RENDERBUFFER_ALPHA_SIZE: number;

declare const GL_RENDERBUFFER_BINDING: number;

declare const GL_RENDERBUFFER_BLUE_SIZE: number;

declare const GL_RENDERBUFFER_DEPTH_SIZE: number;

declare const GL_RENDERBUFFER_GREEN_SIZE: number;

declare const GL_RENDERBUFFER_HEIGHT: number;

declare const GL_RENDERBUFFER_INTERNAL_FORMAT: number;

declare const GL_RENDERBUFFER_RED_SIZE: number;

declare const GL_RENDERBUFFER_SAMPLES: number;

declare const GL_RENDERBUFFER_SAMPLES_ANGLE: number;

declare const GL_RENDERBUFFER_SAMPLES_APPLE: number;

declare const GL_RENDERBUFFER_SAMPLES_EXT: number;

declare const GL_RENDERBUFFER_SAMPLES_IMG: number;

declare const GL_RENDERBUFFER_SAMPLES_NV: number;

declare const GL_RENDERBUFFER_STENCIL_SIZE: number;

declare const GL_RENDERBUFFER_STORAGE_SAMPLES_AMD: number;

declare const GL_RENDERBUFFER_WIDTH: number;

declare const GL_RENDERER: number;

declare const GL_RENDER_DIRECT_TO_FRAMEBUFFER_QCOM: number;

declare const GL_REPEAT: number;

declare const GL_REPLACE: number;

declare const GL_REPRESENTATIVE_FRAGMENT_TEST_NV: number;

declare const GL_REQUIRED_TEXTURE_IMAGE_UNITS_OES: number;

declare const GL_RESET_NOTIFICATION_STRATEGY_EXT: number;

declare const GL_RESET_NOTIFICATION_STRATEGY_KHR: number;

declare const GL_RESTART_PATH_NV: number;

declare const GL_RG: number;

declare const GL_RG16F: number;

declare const GL_RG16F_EXT: number;

declare const GL_RG16I: number;

declare const GL_RG16UI: number;

declare const GL_RG16_EXT: number;

declare const GL_RG16_SNORM_EXT: number;

declare const GL_RG32F: number;

declare const GL_RG32F_EXT: number;

declare const GL_RG32I: number;

declare const GL_RG32UI: number;

declare const GL_RG8: number;

declare const GL_RG8I: number;

declare const GL_RG8UI: number;

declare const GL_RG8_EXT: number;

declare const GL_RG8_SNORM: number;

declare const GL_RGB: number;

declare const GL_RGB10_A2: number;

declare const GL_RGB10_A2UI: number;

declare const GL_RGB10_A2_EXT: number;

declare const GL_RGB10_EXT: number;

declare const GL_RGB16F: number;

declare const GL_RGB16F_EXT: number;

declare const GL_RGB16I: number;

declare const GL_RGB16UI: number;

declare const GL_RGB16_EXT: number;

declare const GL_RGB16_SNORM_EXT: number;

declare const GL_RGB32F: number;

declare const GL_RGB32F_EXT: number;

declare const GL_RGB32I: number;

declare const GL_RGB32UI: number;

declare const GL_RGB565: number;

declare const GL_RGB565_OES: number;

declare const GL_RGB5_A1: number;

declare const GL_RGB5_A1_OES: number;

declare const GL_RGB8: number;

declare const GL_RGB8I: number;

declare const GL_RGB8UI: number;

declare const GL_RGB8_OES: number;

declare const GL_RGB8_SNORM: number;

declare const GL_RGB9_E5: number;

declare const GL_RGB9_E5_APPLE: number;

declare const GL_RGBA: number;

declare const GL_RGBA16F: number;

declare const GL_RGBA16F_EXT: number;

declare const GL_RGBA16I: number;

declare const GL_RGBA16UI: number;

declare const GL_RGBA16_EXT: number;

declare const GL_RGBA16_SNORM_EXT: number;

declare const GL_RGBA32F: number;

declare const GL_RGBA32F_EXT: number;

declare const GL_RGBA32I: number;

declare const GL_RGBA32UI: number;

declare const GL_RGBA4: number;

declare const GL_RGBA4_OES: number;

declare const GL_RGBA8: number;

declare const GL_RGBA8I: number;

declare const GL_RGBA8UI: number;

declare const GL_RGBA8_OES: number;

declare const GL_RGBA8_SNORM: number;

declare const GL_RGBA_INTEGER: number;

declare const GL_RGB_422_APPLE: number;

declare const GL_RGB_INTEGER: number;

declare const GL_RGB_RAW_422_APPLE: number;

declare const GL_RG_EXT: number;

declare const GL_RG_INTEGER: number;

declare const GL_ROUNDED_RECT2_NV: number;

declare const GL_ROUNDED_RECT4_NV: number;

declare const GL_ROUNDED_RECT8_NV: number;

declare const GL_ROUNDED_RECT_NV: number;

declare const GL_ROUND_NV: number;

declare const GL_SAMPLER: number;

declare const GL_SAMPLER_2D: number;

declare const GL_SAMPLER_2D_ARRAY: number;

declare const GL_SAMPLER_2D_ARRAY_SHADOW: number;

declare const GL_SAMPLER_2D_ARRAY_SHADOW_NV: number;

declare const GL_SAMPLER_2D_MULTISAMPLE_ARRAY_OES: number;

declare const GL_SAMPLER_2D_SHADOW: number;

declare const GL_SAMPLER_2D_SHADOW_EXT: number;

declare const GL_SAMPLER_3D: number;

declare const GL_SAMPLER_3D_OES: number;

declare const GL_SAMPLER_BINDING: number;

declare const GL_SAMPLER_BUFFER_EXT: number;

declare const GL_SAMPLER_BUFFER_OES: number;

declare const GL_SAMPLER_CUBE: number;

declare const GL_SAMPLER_CUBE_MAP_ARRAY_EXT: number;

declare const GL_SAMPLER_CUBE_MAP_ARRAY_OES: number;

declare const GL_SAMPLER_CUBE_MAP_ARRAY_SHADOW_EXT: number;

declare const GL_SAMPLER_CUBE_MAP_ARRAY_SHADOW_OES: number;

declare const GL_SAMPLER_CUBE_SHADOW: number;

declare const GL_SAMPLER_CUBE_SHADOW_NV: number;

declare const GL_SAMPLER_EXTERNAL_2D_Y2Y_EXT: number;

declare const GL_SAMPLER_EXTERNAL_OES: number;

declare const GL_SAMPLER_KHR: number;

declare const GL_SAMPLES: number;

declare const GL_SAMPLE_ALPHA_TO_COVERAGE: number;

declare const GL_SAMPLE_ALPHA_TO_ONE_EXT: number;

declare const GL_SAMPLE_BUFFERS: number;

declare const GL_SAMPLE_COVERAGE: number;

declare const GL_SAMPLE_COVERAGE_INVERT: number;

declare const GL_SAMPLE_COVERAGE_VALUE: number;

declare const GL_SAMPLE_LOCATION_NV: number;

declare const GL_SAMPLE_LOCATION_PIXEL_GRID_HEIGHT_NV: number;

declare const GL_SAMPLE_LOCATION_PIXEL_GRID_WIDTH_NV: number;

declare const GL_SAMPLE_LOCATION_SUBPIXEL_BITS_NV: number;

declare const GL_SAMPLE_SHADING_OES: number;

declare const GL_SCISSOR_BOX: number;

declare const GL_SCISSOR_BOX_EXCLUSIVE_NV: number;

declare const GL_SCISSOR_TEST: number;

declare const GL_SCISSOR_TEST_EXCLUSIVE_NV: number;

declare const GL_SCREEN_KHR: number;

declare const GL_SCREEN_NV: number;

declare const GL_SEMAPHORE_TYPE_BINARY_NV: number;

declare const GL_SEMAPHORE_TYPE_NV: number;

declare const GL_SEMAPHORE_TYPE_TIMELINE_NV: number;

declare const GL_SEPARATE_ATTRIBS: number;

declare const GL_SGX_BINARY_IMG: number;

declare const GL_SGX_PROGRAM_BINARY_IMG: number;

declare const GL_SHADER_BINARY_DMP: number;

declare const GL_SHADER_BINARY_FORMATS: number;

declare const GL_SHADER_BINARY_VIV: number;

declare const GL_SHADER_COMPILER: number;

declare const GL_SHADER_KHR: number;

declare const GL_SHADER_OBJECT_EXT: number;

declare const GL_SHADER_PIXEL_LOCAL_STORAGE_EXT: number;

declare const GL_SHADER_SOURCE_LENGTH: number;

declare const GL_SHADER_TYPE: number;

declare const GL_SHADING_LANGUAGE_VERSION: number;

declare const GL_SHADING_RATE_16_INVOCATIONS_PER_PIXEL_NV: number;

declare const GL_SHADING_RATE_1X1_PIXELS_EXT: number;

declare const GL_SHADING_RATE_1X1_PIXELS_QCOM: number;

declare const GL_SHADING_RATE_1X2_PIXELS_EXT: number;

declare const GL_SHADING_RATE_1X2_PIXELS_QCOM: number;

declare const GL_SHADING_RATE_1X4_PIXELS_EXT: number;

declare const GL_SHADING_RATE_1_INVOCATION_PER_1X2_PIXELS_NV: number;

declare const GL_SHADING_RATE_1_INVOCATION_PER_2X1_PIXELS_NV: number;

declare const GL_SHADING_RATE_1_INVOCATION_PER_2X2_PIXELS_NV: number;

declare const GL_SHADING_RATE_1_INVOCATION_PER_2X4_PIXELS_NV: number;

declare const GL_SHADING_RATE_1_INVOCATION_PER_4X2_PIXELS_NV: number;

declare const GL_SHADING_RATE_1_INVOCATION_PER_4X4_PIXELS_NV: number;

declare const GL_SHADING_RATE_1_INVOCATION_PER_PIXEL_NV: number;

declare const GL_SHADING_RATE_2X1_PIXELS_EXT: number;

declare const GL_SHADING_RATE_2X1_PIXELS_QCOM: number;

declare const GL_SHADING_RATE_2X2_PIXELS_EXT: number;

declare const GL_SHADING_RATE_2X2_PIXELS_QCOM: number;

declare const GL_SHADING_RATE_2X4_PIXELS_EXT: number;

declare const GL_SHADING_RATE_2_INVOCATIONS_PER_PIXEL_NV: number;

declare const GL_SHADING_RATE_4X1_PIXELS_EXT: number;

declare const GL_SHADING_RATE_4X2_PIXELS_EXT: number;

declare const GL_SHADING_RATE_4X2_PIXELS_QCOM: number;

declare const GL_SHADING_RATE_4X4_PIXELS_EXT: number;

declare const GL_SHADING_RATE_4X4_PIXELS_QCOM: number;

declare const GL_SHADING_RATE_4_INVOCATIONS_PER_PIXEL_NV: number;

declare const GL_SHADING_RATE_8_INVOCATIONS_PER_PIXEL_NV: number;

declare const GL_SHADING_RATE_ATTACHMENT_EXT: number;

declare const GL_SHADING_RATE_EXT: number;

declare const GL_SHADING_RATE_IMAGE_BINDING_NV: number;

declare const GL_SHADING_RATE_IMAGE_NV: number;

declare const GL_SHADING_RATE_IMAGE_PALETTE_COUNT_NV: number;

declare const GL_SHADING_RATE_IMAGE_PALETTE_SIZE_NV: number;

declare const GL_SHADING_RATE_IMAGE_PER_PRIMITIVE_NV: number;

declare const GL_SHADING_RATE_IMAGE_TEXEL_HEIGHT_NV: number;

declare const GL_SHADING_RATE_IMAGE_TEXEL_WIDTH_NV: number;

declare const GL_SHADING_RATE_NO_INVOCATIONS_NV: number;

declare const GL_SHADING_RATE_PRESERVE_ASPECT_RATIO_QCOM: number;

declare const GL_SHADING_RATE_QCOM: number;

declare const GL_SHADING_RATE_SAMPLE_ORDER_DEFAULT_NV: number;

declare const GL_SHADING_RATE_SAMPLE_ORDER_PIXEL_MAJOR_NV: number;

declare const GL_SHADING_RATE_SAMPLE_ORDER_SAMPLE_MAJOR_NV: number;

declare const GL_SHARED_EDGE_NV: number;

declare const GL_SHORT: number;

declare const GL_SIGNALED: number;

declare const GL_SIGNALED_APPLE: number;

declare const GL_SIGNED_NORMALIZED: number;

declare const GL_SKIP_DECODE_EXT: number;

declare const GL_SKIP_MISSING_GLYPH_NV: number;

declare const GL_SLUMINANCE8_ALPHA8_NV: number;

declare const GL_SLUMINANCE8_NV: number;

declare const GL_SLUMINANCE_ALPHA_NV: number;

declare const GL_SLUMINANCE_NV: number;

declare const GL_SMALL_CCW_ARC_TO_NV: number;

declare const GL_SMALL_CW_ARC_TO_NV: number;

declare const GL_SMAPHS30_PROGRAM_BINARY_DMP: number;

declare const GL_SMAPHS_PROGRAM_BINARY_DMP: number;

declare const GL_SMOOTH_CUBIC_CURVE_TO_NV: number;

declare const GL_SMOOTH_QUADRATIC_CURVE_TO_NV: number;

declare const GL_SOFTLIGHT_KHR: number;

declare const GL_SOFTLIGHT_NV: number;

declare const GL_SPARSE_TEXTURE_FULL_ARRAY_CUBE_MIPMAPS_EXT: number;

declare const GL_SQUARE_NV: number;

declare const GL_SR8_EXT: number;

declare const GL_SRC1_ALPHA_EXT: number;

declare const GL_SRC1_COLOR_EXT: number;

declare const GL_SRC_ALPHA: number;

declare const GL_SRC_ALPHA_SATURATE: number;

declare const GL_SRC_ALPHA_SATURATE_EXT: number;

declare const GL_SRC_ATOP_NV: number;

declare const GL_SRC_COLOR: number;

declare const GL_SRC_IN_NV: number;

declare const GL_SRC_NV: number;

declare const GL_SRC_OUT_NV: number;

declare const GL_SRC_OVER_NV: number;

declare const GL_SRG8_EXT: number;

declare const GL_SRGB: number;

declare const GL_SRGB8: number;

declare const GL_SRGB8_ALPHA8: number;

declare const GL_SRGB8_ALPHA8_EXT: number;

declare const GL_SRGB8_NV: number;

declare const GL_SRGB_ALPHA_EXT: number;

declare const GL_SRGB_EXT: number;

declare const GL_STACK_OVERFLOW_KHR: number;

declare const GL_STACK_UNDERFLOW_KHR: number;

declare const GL_STANDARD_FONT_FORMAT_NV: number;

declare const GL_STANDARD_FONT_NAME_NV: number;

declare const GL_STATE_RESTORE: number;

declare const GL_STATIC_COPY: number;

declare const GL_STATIC_DRAW: number;

declare const GL_STATIC_READ: number;

declare const GL_STENCIL: number;

declare const GL_STENCIL_ATTACHMENT: number;

declare const GL_STENCIL_BACK_FAIL: number;

declare const GL_STENCIL_BACK_FUNC: number;

declare const GL_STENCIL_BACK_PASS_DEPTH_FAIL: number;

declare const GL_STENCIL_BACK_PASS_DEPTH_PASS: number;

declare const GL_STENCIL_BACK_REF: number;

declare const GL_STENCIL_BACK_VALUE_MASK: number;

declare const GL_STENCIL_BACK_WRITEMASK: number;

declare const GL_STENCIL_BITS: number;

declare const GL_STENCIL_BUFFER_BIT: number;

declare const GL_STENCIL_BUFFER_BIT0_QCOM: number;

declare const GL_STENCIL_BUFFER_BIT1_QCOM: number;

declare const GL_STENCIL_BUFFER_BIT2_QCOM: number;

declare const GL_STENCIL_BUFFER_BIT3_QCOM: number;

declare const GL_STENCIL_BUFFER_BIT4_QCOM: number;

declare const GL_STENCIL_BUFFER_BIT5_QCOM: number;

declare const GL_STENCIL_BUFFER_BIT6_QCOM: number;

declare const GL_STENCIL_BUFFER_BIT7_QCOM: number;

declare const GL_STENCIL_CLEAR_VALUE: number;

declare const GL_STENCIL_EXT: number;

declare const GL_STENCIL_FAIL: number;

declare const GL_STENCIL_FUNC: number;

declare const GL_STENCIL_INDEX1_OES: number;

declare const GL_STENCIL_INDEX4_OES: number;

declare const GL_STENCIL_INDEX8: number;

declare const GL_STENCIL_INDEX8_OES: number;

declare const GL_STENCIL_INDEX_OES: number;

declare const GL_STENCIL_PASS_DEPTH_FAIL: number;

declare const GL_STENCIL_PASS_DEPTH_PASS: number;

declare const GL_STENCIL_REF: number;

declare const GL_STENCIL_SAMPLES_NV: number;

declare const GL_STENCIL_TEST: number;

declare const GL_STENCIL_VALUE_MASK: number;

declare const GL_STENCIL_WRITEMASK: number;

declare const GL_STREAM_COPY: number;

declare const GL_STREAM_DRAW: number;

declare const GL_STREAM_READ: number;

declare const GL_SUBGROUP_FEATURE_ARITHMETIC_BIT_KHR: number;

declare const GL_SUBGROUP_FEATURE_BALLOT_BIT_KHR: number;

declare const GL_SUBGROUP_FEATURE_BASIC_BIT_KHR: number;

declare const GL_SUBGROUP_FEATURE_CLUSTERED_BIT_KHR: number;

declare const GL_SUBGROUP_FEATURE_PARTITIONED_BIT_NV: number;

declare const GL_SUBGROUP_FEATURE_QUAD_BIT_KHR: number;

declare const GL_SUBGROUP_FEATURE_SHUFFLE_BIT_KHR: number;

declare const GL_SUBGROUP_FEATURE_SHUFFLE_RELATIVE_BIT_KHR: number;

declare const GL_SUBGROUP_FEATURE_VOTE_BIT_KHR: number;

declare const GL_SUBGROUP_QUAD_ALL_STAGES_KHR: number;

declare const GL_SUBGROUP_SIZE_KHR: number;

declare const GL_SUBGROUP_SUPPORTED_FEATURES_KHR: number;

declare const GL_SUBGROUP_SUPPORTED_STAGES_KHR: number;

declare const GL_SUBPIXEL_BITS: number;

declare const GL_SUBPIXEL_PRECISION_BIAS_X_BITS_NV: number;

declare const GL_SUBPIXEL_PRECISION_BIAS_Y_BITS_NV: number;

declare const GL_SUPERSAMPLE_SCALE_X_NV: number;

declare const GL_SUPERSAMPLE_SCALE_Y_NV: number;

declare const GL_SUPPORTED_MULTISAMPLE_MODES_AMD: number;

declare const GL_SURFACE_COMPRESSION_EXT: number;

declare const GL_SURFACE_COMPRESSION_FIXED_RATE_10BPC_EXT: number;

declare const GL_SURFACE_COMPRESSION_FIXED_RATE_11BPC_EXT: number;

declare const GL_SURFACE_COMPRESSION_FIXED_RATE_12BPC_EXT: number;

declare const GL_SURFACE_COMPRESSION_FIXED_RATE_1BPC_EXT: number;

declare const GL_SURFACE_COMPRESSION_FIXED_RATE_2BPC_EXT: number;

declare const GL_SURFACE_COMPRESSION_FIXED_RATE_3BPC_EXT: number;

declare const GL_SURFACE_COMPRESSION_FIXED_RATE_4BPC_EXT: number;

declare const GL_SURFACE_COMPRESSION_FIXED_RATE_5BPC_EXT: number;

declare const GL_SURFACE_COMPRESSION_FIXED_RATE_6BPC_EXT: number;

declare const GL_SURFACE_COMPRESSION_FIXED_RATE_7BPC_EXT: number;

declare const GL_SURFACE_COMPRESSION_FIXED_RATE_8BPC_EXT: number;

declare const GL_SURFACE_COMPRESSION_FIXED_RATE_9BPC_EXT: number;

declare const GL_SURFACE_COMPRESSION_FIXED_RATE_DEFAULT_EXT: number;

declare const GL_SURFACE_COMPRESSION_FIXED_RATE_NONE_EXT: number;

declare const GL_SYNC_CONDITION: number;

declare const GL_SYNC_CONDITION_APPLE: number;

declare const GL_SYNC_FENCE: number;

declare const GL_SYNC_FENCE_APPLE: number;

declare const GL_SYNC_FLAGS: number;

declare const GL_SYNC_FLAGS_APPLE: number;

declare const GL_SYNC_FLUSH_COMMANDS_BIT: number;

declare const GL_SYNC_FLUSH_COMMANDS_BIT_APPLE: number;

declare const GL_SYNC_GPU_COMMANDS_COMPLETE: number;

declare const GL_SYNC_GPU_COMMANDS_COMPLETE_APPLE: number;

declare const GL_SYNC_OBJECT_APPLE: number;

declare const GL_SYNC_STATUS: number;

declare const GL_SYNC_STATUS_APPLE: number;

declare const GL_SYSTEM_FONT_NAME_NV: number;

declare const GL_TASK_SHADER_BIT_NV: number;

declare const GL_TASK_SHADER_NV: number;

declare const GL_TASK_SUBROUTINE_NV: number;

declare const GL_TASK_SUBROUTINE_UNIFORM_NV: number;

declare const GL_TASK_WORK_GROUP_SIZE_NV: number;

declare const GL_TESS_CONTROL_OUTPUT_VERTICES_EXT: number;

declare const GL_TESS_CONTROL_OUTPUT_VERTICES_OES: number;

declare const GL_TESS_CONTROL_SHADER_BIT_EXT: number;

declare const GL_TESS_CONTROL_SHADER_BIT_OES: number;

declare const GL_TESS_CONTROL_SHADER_EXT: number;

declare const GL_TESS_CONTROL_SHADER_OES: number;

declare const GL_TESS_EVALUATION_SHADER_BIT_EXT: number;

declare const GL_TESS_EVALUATION_SHADER_BIT_OES: number;

declare const GL_TESS_EVALUATION_SHADER_EXT: number;

declare const GL_TESS_EVALUATION_SHADER_OES: number;

declare const GL_TESS_GEN_MODE_EXT: number;

declare const GL_TESS_GEN_MODE_OES: number;

declare const GL_TESS_GEN_POINT_MODE_EXT: number;

declare const GL_TESS_GEN_POINT_MODE_OES: number;

declare const GL_TESS_GEN_SPACING_EXT: number;

declare const GL_TESS_GEN_SPACING_OES: number;

declare const GL_TESS_GEN_VERTEX_ORDER_EXT: number;

declare const GL_TESS_GEN_VERTEX_ORDER_OES: number;

declare const GL_TEXTURE: number;

declare const GL_TEXTURE0: number;

declare const GL_TEXTURE1: number;

declare const GL_TEXTURE10: number;

declare const GL_TEXTURE11: number;

declare const GL_TEXTURE12: number;

declare const GL_TEXTURE13: number;

declare const GL_TEXTURE14: number;

declare const GL_TEXTURE15: number;

declare const GL_TEXTURE16: number;

declare const GL_TEXTURE17: number;

declare const GL_TEXTURE18: number;

declare const GL_TEXTURE19: number;

declare const GL_TEXTURE2: number;

declare const GL_TEXTURE20: number;

declare const GL_TEXTURE21: number;

declare const GL_TEXTURE22: number;

declare const GL_TEXTURE23: number;

declare const GL_TEXTURE24: number;

declare const GL_TEXTURE25: number;

declare const GL_TEXTURE26: number;

declare const GL_TEXTURE27: number;

declare const GL_TEXTURE28: number;

declare const GL_TEXTURE29: number;

declare const GL_TEXTURE3: number;

declare const GL_TEXTURE30: number;

declare const GL_TEXTURE31: number;

declare const GL_TEXTURE4: number;

declare const GL_TEXTURE5: number;

declare const GL_TEXTURE6: number;

declare const GL_TEXTURE7: number;

declare const GL_TEXTURE8: number;

declare const GL_TEXTURE9: number;

declare const GL_TEXTURE_2D: number;

declare const GL_TEXTURE_2D_ARRAY: number;

declare const GL_TEXTURE_2D_MULTISAMPLE: number;

declare const GL_TEXTURE_2D_MULTISAMPLE_ARRAY: number;

declare const GL_TEXTURE_2D_MULTISAMPLE_ARRAY_OES: number;

declare const GL_TEXTURE_3D: number;

declare const GL_TEXTURE_3D_OES: number;

declare const GL_TEXTURE_ASTC_DECODE_PRECISION_EXT: number;

declare const GL_TEXTURE_BASE_LEVEL: number;

declare const GL_TEXTURE_BINDING_2D: number;

declare const GL_TEXTURE_BINDING_2D_ARRAY: number;

declare const GL_TEXTURE_BINDING_2D_MULTISAMPLE_ARRAY_OES: number;

declare const GL_TEXTURE_BINDING_3D: number;

declare const GL_TEXTURE_BINDING_3D_OES: number;

declare const GL_TEXTURE_BINDING_BUFFER_EXT: number;

declare const GL_TEXTURE_BINDING_BUFFER_OES: number;

declare const GL_TEXTURE_BINDING_CUBE_MAP: number;

declare const GL_TEXTURE_BINDING_CUBE_MAP_ARRAY_EXT: number;

declare const GL_TEXTURE_BINDING_CUBE_MAP_ARRAY_OES: number;

declare const GL_TEXTURE_BINDING_EXTERNAL_OES: number;

declare const GL_TEXTURE_BORDER_COLOR_EXT: number;

declare const GL_TEXTURE_BORDER_COLOR_NV: number;

declare const GL_TEXTURE_BORDER_COLOR_OES: number;

declare const GL_TEXTURE_BUFFER_BINDING_EXT: number;

declare const GL_TEXTURE_BUFFER_BINDING_OES: number;

declare const GL_TEXTURE_BUFFER_DATA_STORE_BINDING_EXT: number;

declare const GL_TEXTURE_BUFFER_DATA_STORE_BINDING_OES: number;

declare const GL_TEXTURE_BUFFER_EXT: number;

declare const GL_TEXTURE_BUFFER_OES: number;

declare const GL_TEXTURE_BUFFER_OFFSET_ALIGNMENT_EXT: number;

declare const GL_TEXTURE_BUFFER_OFFSET_ALIGNMENT_OES: number;

declare const GL_TEXTURE_BUFFER_OFFSET_EXT: number;

declare const GL_TEXTURE_BUFFER_OFFSET_OES: number;

declare const GL_TEXTURE_BUFFER_SIZE_EXT: number;

declare const GL_TEXTURE_BUFFER_SIZE_OES: number;

declare const GL_TEXTURE_COMPARE_FUNC: number;

declare const GL_TEXTURE_COMPARE_FUNC_EXT: number;

declare const GL_TEXTURE_COMPARE_MODE: number;

declare const GL_TEXTURE_COMPARE_MODE_EXT: number;

declare const GL_TEXTURE_CUBE_MAP: number;

declare const GL_TEXTURE_CUBE_MAP_ARRAY_EXT: number;

declare const GL_TEXTURE_CUBE_MAP_ARRAY_OES: number;

declare const GL_TEXTURE_CUBE_MAP_NEGATIVE_X: number;

declare const GL_TEXTURE_CUBE_MAP_NEGATIVE_Y: number;

declare const GL_TEXTURE_CUBE_MAP_NEGATIVE_Z: number;

declare const GL_TEXTURE_CUBE_MAP_POSITIVE_X: number;

declare const GL_TEXTURE_CUBE_MAP_POSITIVE_Y: number;

declare const GL_TEXTURE_CUBE_MAP_POSITIVE_Z: number;

declare const GL_TEXTURE_DEPTH_QCOM: number;

declare const GL_TEXTURE_EXTERNAL_OES: number;

declare const GL_TEXTURE_FORMAT_QCOM: number;

declare const GL_TEXTURE_FORMAT_SRGB_OVERRIDE_EXT: number;

declare const GL_TEXTURE_FOVEATED_CUTOFF_DENSITY_QCOM: number;

declare const GL_TEXTURE_FOVEATED_FEATURE_BITS_QCOM: number;

declare const GL_TEXTURE_FOVEATED_FEATURE_QUERY_QCOM: number;

declare const GL_TEXTURE_FOVEATED_MIN_PIXEL_DENSITY_QCOM: number;

declare const GL_TEXTURE_FOVEATED_NUM_FOCAL_POINTS_QUERY_QCOM: number;

declare const GL_TEXTURE_HEIGHT_QCOM: number;

declare const GL_TEXTURE_IMAGE_VALID_QCOM: number;

declare const GL_TEXTURE_IMMUTABLE_FORMAT: number;

declare const GL_TEXTURE_IMMUTABLE_FORMAT_EXT: number;

declare const GL_TEXTURE_IMMUTABLE_LEVELS: number;

declare const GL_TEXTURE_INTERNAL_FORMAT_QCOM: number;

declare const GL_TEXTURE_MAG_FILTER: number;

declare const GL_TEXTURE_MAX_ANISOTROPY_EXT: number;

declare const GL_TEXTURE_MAX_LEVEL: number;

declare const GL_TEXTURE_MAX_LEVEL_APPLE: number;

declare const GL_TEXTURE_MAX_LOD: number;

declare const GL_TEXTURE_MIN_FILTER: number;

declare const GL_TEXTURE_MIN_LOD: number;

declare const GL_TEXTURE_NUM_LEVELS_QCOM: number;

declare const GL_TEXTURE_OBJECT_VALID_QCOM: number;

declare const GL_TEXTURE_PROTECTED_EXT: number;

declare const GL_TEXTURE_REDUCTION_MODE_EXT: number;

declare const GL_TEXTURE_SAMPLES_IMG: number;

declare const GL_TEXTURE_SPARSE_EXT: number;

declare const GL_TEXTURE_SRGB_DECODE_EXT: number;

declare const GL_TEXTURE_SWIZZLE_A: number;

declare const GL_TEXTURE_SWIZZLE_B: number;

declare const GL_TEXTURE_SWIZZLE_G: number;

declare const GL_TEXTURE_SWIZZLE_R: number;

declare const GL_TEXTURE_TARGET_QCOM: number;

declare const GL_TEXTURE_TILING_EXT: number;

declare const GL_TEXTURE_TYPE_QCOM: number;

declare const GL_TEXTURE_UNNORMALIZED_COORDINATES_ARM: number;

declare const GL_TEXTURE_USAGE_ANGLE: number;

declare const GL_TEXTURE_VIEW_MIN_LAYER_EXT: number;

declare const GL_TEXTURE_VIEW_MIN_LAYER_OES: number;

declare const GL_TEXTURE_VIEW_MIN_LEVEL_EXT: number;

declare const GL_TEXTURE_VIEW_MIN_LEVEL_OES: number;

declare const GL_TEXTURE_VIEW_NUM_LAYERS_EXT: number;

declare const GL_TEXTURE_VIEW_NUM_LAYERS_OES: number;

declare const GL_TEXTURE_VIEW_NUM_LEVELS_EXT: number;

declare const GL_TEXTURE_VIEW_NUM_LEVELS_OES: number;

declare const GL_TEXTURE_WIDTH_QCOM: number;

declare const GL_TEXTURE_WRAP_R: number;

declare const GL_TEXTURE_WRAP_R_OES: number;

declare const GL_TEXTURE_WRAP_S: number;

declare const GL_TEXTURE_WRAP_T: number;

declare const GL_TILING_TYPES_EXT: number;

declare const GL_TIMELINE_SEMAPHORE_VALUE_NV: number;

declare const GL_TIMEOUT_EXPIRED: number;

declare const GL_TIMEOUT_EXPIRED_APPLE: number;

declare const GL_TIMEOUT_IGNORED: bigint;

declare const GL_TIMEOUT_IGNORED_APPLE: bigint;

declare const GL_TIMESTAMP_EXT: number;

declare const GL_TIME_ELAPSED_EXT: number;

declare const GL_TRANSFORM_FEEDBACK: number;

declare const GL_TRANSFORM_FEEDBACK_ACTIVE: number;

declare const GL_TRANSFORM_FEEDBACK_BINDING: number;

declare const GL_TRANSFORM_FEEDBACK_BUFFER: number;

declare const GL_TRANSFORM_FEEDBACK_BUFFER_BINDING: number;

declare const GL_TRANSFORM_FEEDBACK_BUFFER_MODE: number;

declare const GL_TRANSFORM_FEEDBACK_BUFFER_SIZE: number;

declare const GL_TRANSFORM_FEEDBACK_BUFFER_START: number;

declare const GL_TRANSFORM_FEEDBACK_PAUSED: number;

declare const GL_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN: number;

declare const GL_TRANSFORM_FEEDBACK_VARYINGS: number;

declare const GL_TRANSFORM_FEEDBACK_VARYING_MAX_LENGTH: number;

declare const GL_TRANSLATED_SHADER_SOURCE_LENGTH_ANGLE: number;

declare const GL_TRANSLATE_2D_NV: number;

declare const GL_TRANSLATE_3D_NV: number;

declare const GL_TRANSLATE_X_NV: number;

declare const GL_TRANSLATE_Y_NV: number;

declare const GL_TRANSPOSE_AFFINE_2D_NV: number;

declare const GL_TRANSPOSE_AFFINE_3D_NV: number;

declare const GL_TRIANGLES: number;

declare const GL_TRIANGLES_ADJACENCY_EXT: number;

declare const GL_TRIANGLES_ADJACENCY_OES: number;

declare const GL_TRIANGLE_FAN: number;

declare const GL_TRIANGLE_STRIP: number;

declare const GL_TRIANGLE_STRIP_ADJACENCY_EXT: number;

declare const GL_TRIANGLE_STRIP_ADJACENCY_OES: number;

declare const GL_TRIANGULAR_NV: number;

declare const GL_TRUE: number;

declare const GL_UNCORRELATED_NV: number;

declare const GL_UNDEFINED_VERTEX_EXT: number;

declare const GL_UNDEFINED_VERTEX_OES: number;

declare const GL_UNIFORM_ARRAY_STRIDE: number;

declare const GL_UNIFORM_BLOCK_ACTIVE_UNIFORMS: number;

declare const GL_UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES: number;

declare const GL_UNIFORM_BLOCK_BINDING: number;

declare const GL_UNIFORM_BLOCK_DATA_SIZE: number;

declare const GL_UNIFORM_BLOCK_INDEX: number;

declare const GL_UNIFORM_BLOCK_NAME_LENGTH: number;

declare const GL_UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER: number;

declare const GL_UNIFORM_BLOCK_REFERENCED_BY_MESH_SHADER_NV: number;

declare const GL_UNIFORM_BLOCK_REFERENCED_BY_TASK_SHADER_NV: number;

declare const GL_UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER: number;

declare const GL_UNIFORM_BUFFER: number;

declare const GL_UNIFORM_BUFFER_BINDING: number;

declare const GL_UNIFORM_BUFFER_OFFSET_ALIGNMENT: number;

declare const GL_UNIFORM_BUFFER_SIZE: number;

declare const GL_UNIFORM_BUFFER_START: number;

declare const GL_UNIFORM_IS_ROW_MAJOR: number;

declare const GL_UNIFORM_MATRIX_STRIDE: number;

declare const GL_UNIFORM_NAME_LENGTH: number;

declare const GL_UNIFORM_OFFSET: number;

declare const GL_UNIFORM_SIZE: number;

declare const GL_UNIFORM_TYPE: number;

declare const GL_UNKNOWN_CONTEXT_RESET_EXT: number;

declare const GL_UNKNOWN_CONTEXT_RESET_KHR: number;

declare const GL_UNPACK_ALIGNMENT: number;

declare const GL_UNPACK_IMAGE_HEIGHT: number;

declare const GL_UNPACK_ROW_LENGTH: number;

declare const GL_UNPACK_ROW_LENGTH_EXT: number;

declare const GL_UNPACK_SKIP_IMAGES: number;

declare const GL_UNPACK_SKIP_PIXELS: number;

declare const GL_UNPACK_SKIP_PIXELS_EXT: number;

declare const GL_UNPACK_SKIP_ROWS: number;

declare const GL_UNPACK_SKIP_ROWS_EXT: number;

declare const GL_UNSIGNALED: number;

declare const GL_UNSIGNALED_APPLE: number;

declare const GL_UNSIGNED_BYTE: number;

declare const GL_UNSIGNED_INT: number;

declare const GL_UNSIGNED_INT16_NV: number;

declare const GL_UNSIGNED_INT16_VEC2_NV: number;

declare const GL_UNSIGNED_INT16_VEC3_NV: number;

declare const GL_UNSIGNED_INT16_VEC4_NV: number;

declare const GL_UNSIGNED_INT64_AMD: number;

declare const GL_UNSIGNED_INT64_NV: number;

declare const GL_UNSIGNED_INT64_VEC2_NV: number;

declare const GL_UNSIGNED_INT64_VEC3_NV: number;

declare const GL_UNSIGNED_INT64_VEC4_NV: number;

declare const GL_UNSIGNED_INT8_NV: number;

declare const GL_UNSIGNED_INT8_VEC2_NV: number;

declare const GL_UNSIGNED_INT8_VEC3_NV: number;

declare const GL_UNSIGNED_INT8_VEC4_NV: number;

declare const GL_UNSIGNED_INT_10F_11F_11F_REV: number;

declare const GL_UNSIGNED_INT_10F_11F_11F_REV_APPLE: number;

declare const GL_UNSIGNED_INT_10_10_10_2_OES: number;

declare const GL_UNSIGNED_INT_24_8: number;

declare const GL_UNSIGNED_INT_24_8_OES: number;

declare const GL_UNSIGNED_INT_2_10_10_10_REV: number;

declare const GL_UNSIGNED_INT_2_10_10_10_REV_EXT: number;

declare const GL_UNSIGNED_INT_5_9_9_9_REV: number;

declare const GL_UNSIGNED_INT_5_9_9_9_REV_APPLE: number;

declare const GL_UNSIGNED_INT_IMAGE_BUFFER_EXT: number;

declare const GL_UNSIGNED_INT_IMAGE_BUFFER_OES: number;

declare const GL_UNSIGNED_INT_IMAGE_CUBE_MAP_ARRAY_EXT: number;

declare const GL_UNSIGNED_INT_IMAGE_CUBE_MAP_ARRAY_OES: number;

declare const GL_UNSIGNED_INT_SAMPLER_2D: number;

declare const GL_UNSIGNED_INT_SAMPLER_2D_ARRAY: number;

declare const GL_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE_ARRAY_OES: number;

declare const GL_UNSIGNED_INT_SAMPLER_3D: number;

declare const GL_UNSIGNED_INT_SAMPLER_BUFFER_EXT: number;

declare const GL_UNSIGNED_INT_SAMPLER_BUFFER_OES: number;

declare const GL_UNSIGNED_INT_SAMPLER_CUBE: number;

declare const GL_UNSIGNED_INT_SAMPLER_CUBE_MAP_ARRAY_EXT: number;

declare const GL_UNSIGNED_INT_SAMPLER_CUBE_MAP_ARRAY_OES: number;

declare const GL_UNSIGNED_INT_VEC2: number;

declare const GL_UNSIGNED_INT_VEC3: number;

declare const GL_UNSIGNED_INT_VEC4: number;

declare const GL_UNSIGNED_NORMALIZED: number;

declare const GL_UNSIGNED_NORMALIZED_EXT: number;

declare const GL_UNSIGNED_SHORT: number;

declare const GL_UNSIGNED_SHORT_1_5_5_5_REV_EXT: number;

declare const GL_UNSIGNED_SHORT_4_4_4_4: number;

declare const GL_UNSIGNED_SHORT_4_4_4_4_REV_EXT: number;

declare const GL_UNSIGNED_SHORT_4_4_4_4_REV_IMG: number;

declare const GL_UNSIGNED_SHORT_5_5_5_1: number;

declare const GL_UNSIGNED_SHORT_5_6_5: number;

declare const GL_UNSIGNED_SHORT_8_8_APPLE: number;

declare const GL_UNSIGNED_SHORT_8_8_REV_APPLE: number;

declare const GL_UPPER_LEFT_EXT: number;

declare const GL_USE_MISSING_GLYPH_NV: number;

declare const GL_UTF16_NV: number;

declare const GL_UTF8_NV: number;

declare const GL_UUID_SIZE_EXT: number;

declare const GL_VALIDATE_STATUS: number;

declare const GL_VENDOR: number;

declare const GL_VERSION: number;

declare const GL_VERTEX_ARRAY_BINDING: number;

declare const GL_VERTEX_ARRAY_BINDING_OES: number;

declare const GL_VERTEX_ARRAY_KHR: number;

declare const GL_VERTEX_ARRAY_OBJECT_EXT: number;

declare const GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING: number;

declare const GL_VERTEX_ATTRIB_ARRAY_DIVISOR: number;

declare const GL_VERTEX_ATTRIB_ARRAY_DIVISOR_ANGLE: number;

declare const GL_VERTEX_ATTRIB_ARRAY_DIVISOR_EXT: number;

declare const GL_VERTEX_ATTRIB_ARRAY_DIVISOR_NV: number;

declare const GL_VERTEX_ATTRIB_ARRAY_ENABLED: number;

declare const GL_VERTEX_ATTRIB_ARRAY_INTEGER: number;

declare const GL_VERTEX_ATTRIB_ARRAY_NORMALIZED: number;

declare const GL_VERTEX_ATTRIB_ARRAY_POINTER: number;

declare const GL_VERTEX_ATTRIB_ARRAY_SIZE: number;

declare const GL_VERTEX_ATTRIB_ARRAY_STRIDE: number;

declare const GL_VERTEX_ATTRIB_ARRAY_TYPE: number;

declare const GL_VERTEX_SHADER: number;

declare const GL_VERTEX_SHADER_BIT_EXT: number;

declare const GL_VERTICAL_LINE_TO_NV: number;

declare const GL_VIEWPORT: number;

declare const GL_VIEWPORT_BOUNDS_RANGE_NV: number;

declare const GL_VIEWPORT_BOUNDS_RANGE_OES: number;

declare const GL_VIEWPORT_INDEX_PROVOKING_VERTEX_NV: number;

declare const GL_VIEWPORT_INDEX_PROVOKING_VERTEX_OES: number;

declare const GL_VIEWPORT_POSITION_W_SCALE_NV: number;

declare const GL_VIEWPORT_POSITION_W_SCALE_X_COEFF_NV: number;

declare const GL_VIEWPORT_POSITION_W_SCALE_Y_COEFF_NV: number;

declare const GL_VIEWPORT_SUBPIXEL_BITS_NV: number;

declare const GL_VIEWPORT_SUBPIXEL_BITS_OES: number;

declare const GL_VIEWPORT_SWIZZLE_NEGATIVE_W_NV: number;

declare const GL_VIEWPORT_SWIZZLE_NEGATIVE_X_NV: number;

declare const GL_VIEWPORT_SWIZZLE_NEGATIVE_Y_NV: number;

declare const GL_VIEWPORT_SWIZZLE_NEGATIVE_Z_NV: number;

declare const GL_VIEWPORT_SWIZZLE_POSITIVE_W_NV: number;

declare const GL_VIEWPORT_SWIZZLE_POSITIVE_X_NV: number;

declare const GL_VIEWPORT_SWIZZLE_POSITIVE_Y_NV: number;

declare const GL_VIEWPORT_SWIZZLE_POSITIVE_Z_NV: number;

declare const GL_VIEWPORT_SWIZZLE_W_NV: number;

declare const GL_VIEWPORT_SWIZZLE_X_NV: number;

declare const GL_VIEWPORT_SWIZZLE_Y_NV: number;

declare const GL_VIEWPORT_SWIZZLE_Z_NV: number;

declare const GL_VIRTUAL_PAGE_SIZE_INDEX_EXT: number;

declare const GL_VIRTUAL_PAGE_SIZE_X_EXT: number;

declare const GL_VIRTUAL_PAGE_SIZE_Y_EXT: number;

declare const GL_VIRTUAL_PAGE_SIZE_Z_EXT: number;

declare const GL_VIVIDLIGHT_NV: number;

declare const GL_VIV_shader_binary: number;

declare const GL_WAIT_FAILED: number;

declare const GL_WAIT_FAILED_APPLE: number;

declare const GL_WEIGHTED_AVERAGE_EXT: number;

declare const GL_WINDOW_RECTANGLE_EXT: number;

declare const GL_WINDOW_RECTANGLE_MODE_EXT: number;

declare const GL_WRITEONLY_RENDERING_QCOM: number;

declare const GL_WRITE_ONLY_OES: number;

declare const GL_XOR_NV: number;

declare const GL_Z400_BINARY_AMD: number;

declare const GL_ZERO: number;

declare const GL_ZERO_TO_ONE_EXT: number;

interface __GLsync {
}
declare var __GLsync: interop.StructType<__GLsync>;

declare function glActiveTexture(texture: number): void;

declare function glAttachShader(program: number, shader: number): void;

declare function glBeginQuery(target: number, id: number): void;

declare function glBeginTransformFeedback(primitiveMode: number): void;

declare function glBindAttribLocation(program: number, index: number, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glBindBuffer(target: number, buffer: number): void;

declare function glBindBufferBase(target: number, index: number, buffer: number): void;

declare function glBindBufferRange(target: number, index: number, buffer: number, offset: number, size: number): void;

declare function glBindFramebuffer(target: number, framebuffer: number): void;

declare function glBindRenderbuffer(target: number, renderbuffer: number): void;

declare function glBindSampler(unit: number, sampler: number): void;

declare function glBindTexture(target: number, texture: number): void;

declare function glBindTransformFeedback(target: number, id: number): void;

declare function glBindVertexArray(array: number): void;

declare function glBlendColor(red: number, green: number, blue: number, alpha: number): void;

declare function glBlendEquation(mode: number): void;

declare function glBlendEquationSeparate(modeRGB: number, modeAlpha: number): void;

declare function glBlendFunc(sfactor: number, dfactor: number): void;

declare function glBlendFuncSeparate(sfactorRGB: number, dfactorRGB: number, sfactorAlpha: number, dfactorAlpha: number): void;

declare function glBlitFramebuffer(srcX0: number, srcY0: number, srcX1: number, srcY1: number, dstX0: number, dstY0: number, dstX1: number, dstY1: number, mask: number, filter: number): void;

declare function glBufferData(target: number, size: number, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, usage: number): void;

declare function glBufferSubData(target: number, offset: number, size: number, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glCheckFramebufferStatus(target: number): number;

declare function glClear(mask: number): void;

declare function glClearBufferfi(buffer: number, drawbuffer: number, depth: number, stencil: number): void;

declare function glClearBufferfv(buffer: number, drawbuffer: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glClearBufferiv(buffer: number, drawbuffer: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glClearBufferuiv(buffer: number, drawbuffer: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glClearColor(red: number, green: number, blue: number, alpha: number): void;

declare function glClearDepthf(d: number): void;

declare function glClearStencil(s: number): void;

declare function glClientWaitSync(sync: interop.Pointer | interop.Reference<__GLsync> | ArrayBufferLike | ArrayBufferView | null, flags: number, timeout: number): number;

declare function glColorMask(red: number, green: number, blue: number, alpha: number): void;

declare function glCompileShader(shader: number): void;

declare function glCompressedTexImage2D(target: number, level: number, internalformat: number, width: number, height: number, border: number, imageSize: number, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glCompressedTexImage3D(target: number, level: number, internalformat: number, width: number, height: number, depth: number, border: number, imageSize: number, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glCompressedTexSubImage2D(target: number, level: number, xoffset: number, yoffset: number, width: number, height: number, format: number, imageSize: number, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glCompressedTexSubImage3D(target: number, level: number, xoffset: number, yoffset: number, zoffset: number, width: number, height: number, depth: number, format: number, imageSize: number, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glCopyBufferSubData(readTarget: number, writeTarget: number, readOffset: number, writeOffset: number, size: number): void;

declare function glCopyTexImage2D(target: number, level: number, internalformat: number, x: number, y: number, width: number, height: number, border: number): void;

declare function glCopyTexSubImage2D(target: number, level: number, xoffset: number, yoffset: number, x: number, y: number, width: number, height: number): void;

declare function glCopyTexSubImage3D(target: number, level: number, xoffset: number, yoffset: number, zoffset: number, x: number, y: number, width: number, height: number): void;

declare function glCreateProgram(): number;

declare function glCreateShader(type: number): number;

declare function glCullFace(mode: number): void;

declare function glDeleteBuffers(n: number, buffers: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glDeleteFramebuffers(n: number, framebuffers: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glDeleteProgram(program: number): void;

declare function glDeleteQueries(n: number, ids: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glDeleteRenderbuffers(n: number, renderbuffers: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glDeleteSamplers(count: number, samplers: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glDeleteShader(shader: number): void;

declare function glDeleteSync(sync: interop.Pointer | interop.Reference<__GLsync> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glDeleteTextures(n: number, textures: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glDeleteTransformFeedbacks(n: number, ids: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glDeleteVertexArrays(n: number, arrays: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glDepthFunc(func: number): void;

declare function glDepthMask(flag: number): void;

declare function glDepthRangef(n: number, f: number): void;

declare function glDetachShader(program: number, shader: number): void;

declare function glDisable(cap: number): void;

declare function glDisableVertexAttribArray(index: number): void;

declare function glDrawArrays(mode: number, first: number, count: number): void;

declare function glDrawArraysInstanced(mode: number, first: number, count: number, instancecount: number): void;

declare function glDrawBuffers(n: number, bufs: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glDrawElements(mode: number, count: number, type: number, indices: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glDrawElementsInstanced(mode: number, count: number, type: number, indices: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, instancecount: number): void;

declare function glDrawRangeElements(mode: number, start: number, end: number, count: number, type: number, indices: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glEnable(cap: number): void;

declare function glEnableVertexAttribArray(index: number): void;

declare function glEndQuery(target: number): void;

declare function glEndTransformFeedback(): void;

declare function glFenceSync(condition: number, flags: number): interop.Pointer | interop.Reference<__GLsync> | null;

declare function glFinish(): void;

declare function glFlush(): void;

declare function glFlushMappedBufferRange(target: number, offset: number, length: number): void;

declare function glFramebufferRenderbuffer(target: number, attachment: number, renderbuffertarget: number, renderbuffer: number): void;

declare function glFramebufferTexture2D(target: number, attachment: number, textarget: number, texture: number, level: number): void;

declare function glFramebufferTextureLayer(target: number, attachment: number, texture: number, level: number, layer: number): void;

declare function glFrontFace(mode: number): void;

declare function glGenBuffers(n: number, buffers: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGenFramebuffers(n: number, framebuffers: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGenQueries(n: number, ids: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGenRenderbuffers(n: number, renderbuffers: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGenSamplers(count: number, samplers: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGenTextures(n: number, textures: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGenTransformFeedbacks(n: number, ids: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGenVertexArrays(n: number, arrays: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGenerateMipmap(target: number): void;

declare function glGetActiveAttrib(program: number, index: number, bufSize: number, length: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, size: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, type: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetActiveUniform(program: number, index: number, bufSize: number, length: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, size: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, type: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetActiveUniformBlockName(program: number, uniformBlockIndex: number, bufSize: number, length: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, uniformBlockName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetActiveUniformBlockiv(program: number, uniformBlockIndex: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetActiveUniformsiv(program: number, uniformCount: number, uniformIndices: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetAttachedShaders(program: number, maxCount: number, count: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, shaders: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetAttribLocation(program: number, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function glGetBooleanv(pname: number, data: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetBufferParameteri64v(target: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetBufferParameteriv(target: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetBufferPointerv(target: number, pname: number, params: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetError(): number;

declare function glGetFloatv(pname: number, data: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetFragDataLocation(program: number, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function glGetFramebufferAttachmentParameteriv(target: number, attachment: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetInteger64i_v(target: number, index: number, data: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetInteger64v(pname: number, data: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetIntegeri_v(target: number, index: number, data: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetIntegerv(pname: number, data: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetInternalformativ(target: number, internalformat: number, pname: number, count: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetProgramBinary(program: number, bufSize: number, length: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, binaryFormat: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, binary: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetProgramInfoLog(program: number, bufSize: number, length: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, infoLog: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetProgramiv(program: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetQueryObjectuiv(id: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetQueryiv(target: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetRenderbufferParameteriv(target: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetSamplerParameterfv(sampler: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetSamplerParameteriv(sampler: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetShaderInfoLog(shader: number, bufSize: number, length: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, infoLog: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetShaderPrecisionFormat(shadertype: number, precisiontype: number, range: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, precision: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetShaderSource(shader: number, bufSize: number, length: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, source: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetShaderiv(shader: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetString(name: number): string | null;

declare function glGetStringi(name: number, index: number): string | null;

declare function glGetSynciv(sync: interop.Pointer | interop.Reference<__GLsync> | ArrayBufferLike | ArrayBufferView | null, pname: number, count: number, length: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, values: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetTexParameterfv(target: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetTexParameteriv(target: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetTransformFeedbackVarying(program: number, index: number, bufSize: number, length: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, size: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, type: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetUniformBlockIndex(program: number, uniformBlockName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function glGetUniformIndices(program: number, uniformCount: number, uniformNames: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null, uniformIndices: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetUniformLocation(program: number, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function glGetUniformfv(program: number, location: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetUniformiv(program: number, location: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetUniformuiv(program: number, location: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetVertexAttribIiv(index: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetVertexAttribIuiv(index: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetVertexAttribPointerv(index: number, pname: number, pointer: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetVertexAttribfv(index: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glGetVertexAttribiv(index: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glHint(target: number, mode: number): void;

declare function glInvalidateFramebuffer(target: number, numAttachments: number, attachments: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glInvalidateSubFramebuffer(target: number, numAttachments: number, attachments: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, x: number, y: number, width: number, height: number): void;

declare function glIsBuffer(buffer: number): number;

declare function glIsEnabled(cap: number): number;

declare function glIsFramebuffer(framebuffer: number): number;

declare function glIsProgram(program: number): number;

declare function glIsQuery(id: number): number;

declare function glIsRenderbuffer(renderbuffer: number): number;

declare function glIsSampler(sampler: number): number;

declare function glIsShader(shader: number): number;

declare function glIsSync(sync: interop.Pointer | interop.Reference<__GLsync> | ArrayBufferLike | ArrayBufferView | null): number;

declare function glIsTexture(texture: number): number;

declare function glIsTransformFeedback(id: number): number;

declare function glIsVertexArray(array: number): number;

declare function glLineWidth(width: number): void;

declare function glLinkProgram(program: number): void;

declare function glMapBufferRange(target: number, offset: number, length: number, access: number): interop.Pointer | interop.Reference<any> | null;

declare function glPauseTransformFeedback(): void;

declare function glPixelStorei(pname: number, param: number): void;

declare function glPolygonOffset(factor: number, units: number): void;

declare function glProgramBinary(program: number, binaryFormat: number, binary: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, length: number): void;

declare function glProgramParameteri(program: number, pname: number, value: number): void;

declare function glReadBuffer(src: number): void;

declare function glReadPixels(x: number, y: number, width: number, height: number, format: number, type: number, pixels: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glReleaseShaderCompiler(): void;

declare function glRenderbufferStorage(target: number, internalformat: number, width: number, height: number): void;

declare function glRenderbufferStorageMultisample(target: number, samples: number, internalformat: number, width: number, height: number): void;

declare function glResumeTransformFeedback(): void;

declare function glSampleCoverage(value: number, invert: number): void;

declare function glSamplerParameterf(sampler: number, pname: number, param: number): void;

declare function glSamplerParameterfv(sampler: number, pname: number, param: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glSamplerParameteri(sampler: number, pname: number, param: number): void;

declare function glSamplerParameteriv(sampler: number, pname: number, param: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glScissor(x: number, y: number, width: number, height: number): void;

declare function glShaderBinary(count: number, shaders: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, binaryFormat: number, binary: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, length: number): void;

declare function glShaderSource(shader: number, count: number, string: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null, length: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glStencilFunc(func: number, ref: number, mask: number): void;

declare function glStencilFuncSeparate(face: number, func: number, ref: number, mask: number): void;

declare function glStencilMask(mask: number): void;

declare function glStencilMaskSeparate(face: number, mask: number): void;

declare function glStencilOp(fail: number, zfail: number, zpass: number): void;

declare function glStencilOpSeparate(face: number, sfail: number, dpfail: number, dppass: number): void;

declare function glTexImage2D(target: number, level: number, internalformat: number, width: number, height: number, border: number, format: number, type: number, pixels: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glTexImage3D(target: number, level: number, internalformat: number, width: number, height: number, depth: number, border: number, format: number, type: number, pixels: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glTexParameterf(target: number, pname: number, param: number): void;

declare function glTexParameterfv(target: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glTexParameteri(target: number, pname: number, param: number): void;

declare function glTexParameteriv(target: number, pname: number, params: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glTexStorage2D(target: number, levels: number, internalformat: number, width: number, height: number): void;

declare function glTexStorage3D(target: number, levels: number, internalformat: number, width: number, height: number, depth: number): void;

declare function glTexSubImage2D(target: number, level: number, xoffset: number, yoffset: number, width: number, height: number, format: number, type: number, pixels: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glTexSubImage3D(target: number, level: number, xoffset: number, yoffset: number, zoffset: number, width: number, height: number, depth: number, format: number, type: number, pixels: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glTransformFeedbackVaryings(program: number, count: number, varyings: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null, bufferMode: number): void;

declare function glUniform1f(location: number, v0: number): void;

declare function glUniform1fv(location: number, count: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniform1i(location: number, v0: number): void;

declare function glUniform1iv(location: number, count: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniform1ui(location: number, v0: number): void;

declare function glUniform1uiv(location: number, count: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniform2f(location: number, v0: number, v1: number): void;

declare function glUniform2fv(location: number, count: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniform2i(location: number, v0: number, v1: number): void;

declare function glUniform2iv(location: number, count: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniform2ui(location: number, v0: number, v1: number): void;

declare function glUniform2uiv(location: number, count: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniform3f(location: number, v0: number, v1: number, v2: number): void;

declare function glUniform3fv(location: number, count: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniform3i(location: number, v0: number, v1: number, v2: number): void;

declare function glUniform3iv(location: number, count: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniform3ui(location: number, v0: number, v1: number, v2: number): void;

declare function glUniform3uiv(location: number, count: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniform4f(location: number, v0: number, v1: number, v2: number, v3: number): void;

declare function glUniform4fv(location: number, count: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniform4i(location: number, v0: number, v1: number, v2: number, v3: number): void;

declare function glUniform4iv(location: number, count: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniform4ui(location: number, v0: number, v1: number, v2: number, v3: number): void;

declare function glUniform4uiv(location: number, count: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniformBlockBinding(program: number, uniformBlockIndex: number, uniformBlockBinding: number): void;

declare function glUniformMatrix2fv(location: number, count: number, transpose: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniformMatrix2x3fv(location: number, count: number, transpose: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniformMatrix2x4fv(location: number, count: number, transpose: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniformMatrix3fv(location: number, count: number, transpose: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniformMatrix3x2fv(location: number, count: number, transpose: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniformMatrix3x4fv(location: number, count: number, transpose: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniformMatrix4fv(location: number, count: number, transpose: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniformMatrix4x2fv(location: number, count: number, transpose: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUniformMatrix4x3fv(location: number, count: number, transpose: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glUnmapBuffer(target: number): number;

declare function glUseProgram(program: number): void;

declare function glValidateProgram(program: number): void;

declare function glVertexAttrib1f(index: number, x: number): void;

declare function glVertexAttrib1fv(index: number, v: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glVertexAttrib2f(index: number, x: number, y: number): void;

declare function glVertexAttrib2fv(index: number, v: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glVertexAttrib3f(index: number, x: number, y: number, z: number): void;

declare function glVertexAttrib3fv(index: number, v: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glVertexAttrib4f(index: number, x: number, y: number, z: number, w: number): void;

declare function glVertexAttrib4fv(index: number, v: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glVertexAttribDivisor(index: number, divisor: number): void;

declare function glVertexAttribI4i(index: number, x: number, y: number, z: number, w: number): void;

declare function glVertexAttribI4iv(index: number, v: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glVertexAttribI4ui(index: number, x: number, y: number, z: number, w: number): void;

declare function glVertexAttribI4uiv(index: number, v: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glVertexAttribIPointer(index: number, size: number, type: number, stride: number, pointer: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glVertexAttribPointer(index: number, size: number, type: number, normalized: number, stride: number, pointer: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function glViewport(x: number, y: number, width: number, height: number): void;

declare function glWaitSync(sync: interop.Pointer | interop.Reference<__GLsync> | ArrayBufferLike | ArrayBufferView | null, flags: number, timeout: number): void;
