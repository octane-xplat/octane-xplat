
declare const EGL_ALPHA_FORMAT: number;

declare const EGL_ALPHA_FORMAT_NONPRE: number;

declare const EGL_ALPHA_FORMAT_PRE: number;

declare const EGL_ALPHA_MASK_SIZE: number;

declare const EGL_ALPHA_SIZE: number;

declare const EGL_BACK_BUFFER: number;

declare const EGL_BAD_ACCESS: number;

declare const EGL_BAD_ALLOC: number;

declare const EGL_BAD_ATTRIBUTE: number;

declare const EGL_BAD_CONFIG: number;

declare const EGL_BAD_CONTEXT: number;

declare const EGL_BAD_CURRENT_SURFACE: number;

declare const EGL_BAD_DISPLAY: number;

declare const EGL_BAD_MATCH: number;

declare const EGL_BAD_NATIVE_PIXMAP: number;

declare const EGL_BAD_NATIVE_WINDOW: number;

declare const EGL_BAD_PARAMETER: number;

declare const EGL_BAD_SURFACE: number;

declare const EGL_BIND_TO_TEXTURE_RGB: number;

declare const EGL_BIND_TO_TEXTURE_RGBA: number;

declare const EGL_BLUE_SIZE: number;

declare const EGL_BUFFER_DESTROYED: number;

declare const EGL_BUFFER_PRESERVED: number;

declare const EGL_BUFFER_SIZE: number;

declare const EGL_CLIENT_APIS: number;

declare const EGL_CL_EVENT_HANDLE: number;

declare const EGL_COLORSPACE: number;

declare const EGL_COLORSPACE_LINEAR: number;

declare const EGL_COLORSPACE_sRGB: number;

declare const EGL_COLOR_BUFFER_TYPE: number;

declare const EGL_CONDITION_SATISFIED: number;

declare const EGL_CONFIG_CAVEAT: number;

declare const EGL_CONFIG_ID: number;

declare const EGL_CONFORMANT: number;

declare const EGL_CONTEXT_CLIENT_TYPE: number;

declare const EGL_CONTEXT_CLIENT_VERSION: number;

declare const EGL_CONTEXT_LOST: number;

declare const EGL_CONTEXT_MAJOR_VERSION: number;

declare const EGL_CONTEXT_MINOR_VERSION: number;

declare const EGL_CONTEXT_OPENGL_COMPATIBILITY_PROFILE_BIT: number;

declare const EGL_CONTEXT_OPENGL_CORE_PROFILE_BIT: number;

declare const EGL_CONTEXT_OPENGL_DEBUG: number;

declare const EGL_CONTEXT_OPENGL_FORWARD_COMPATIBLE: number;

declare const EGL_CONTEXT_OPENGL_PROFILE_MASK: number;

declare const EGL_CONTEXT_OPENGL_RESET_NOTIFICATION_STRATEGY: number;

declare const EGL_CONTEXT_OPENGL_ROBUST_ACCESS: number;

declare const EGL_CORE_NATIVE_ENGINE: number;

declare const EGL_DEPTH_SIZE: number;

declare const EGL_DISPLAY_SCALING: number;

declare const EGL_DRAW: number;

declare const EGL_EGL_PROTOTYPES: number;

declare const EGL_EXTENSIONS: number;

declare const EGL_FALSE: number;

declare const EGL_FOREVER: bigint;

declare const EGL_GL_COLORSPACE: number;

declare const EGL_GL_COLORSPACE_LINEAR: number;

declare const EGL_GL_COLORSPACE_SRGB: number;

declare const EGL_GL_RENDERBUFFER: number;

declare const EGL_GL_TEXTURE_2D: number;

declare const EGL_GL_TEXTURE_3D: number;

declare const EGL_GL_TEXTURE_CUBE_MAP_NEGATIVE_X: number;

declare const EGL_GL_TEXTURE_CUBE_MAP_NEGATIVE_Y: number;

declare const EGL_GL_TEXTURE_CUBE_MAP_NEGATIVE_Z: number;

declare const EGL_GL_TEXTURE_CUBE_MAP_POSITIVE_X: number;

declare const EGL_GL_TEXTURE_CUBE_MAP_POSITIVE_Y: number;

declare const EGL_GL_TEXTURE_CUBE_MAP_POSITIVE_Z: number;

declare const EGL_GL_TEXTURE_LEVEL: number;

declare const EGL_GL_TEXTURE_ZOFFSET: number;

declare const EGL_GREEN_SIZE: number;

declare const EGL_HEIGHT: number;

declare const EGL_HORIZONTAL_RESOLUTION: number;

declare const EGL_IMAGE_PRESERVED: number;

declare const EGL_LARGEST_PBUFFER: number;

declare const EGL_LEVEL: number;

declare const EGL_LOSE_CONTEXT_ON_RESET: number;

declare const EGL_LUMINANCE_BUFFER: number;

declare const EGL_LUMINANCE_SIZE: number;

declare const EGL_MATCH_NATIVE_PIXMAP: number;

declare const EGL_MAX_PBUFFER_HEIGHT: number;

declare const EGL_MAX_PBUFFER_PIXELS: number;

declare const EGL_MAX_PBUFFER_WIDTH: number;

declare const EGL_MAX_SWAP_INTERVAL: number;

declare const EGL_MIN_SWAP_INTERVAL: number;

declare const EGL_MIPMAP_LEVEL: number;

declare const EGL_MIPMAP_TEXTURE: number;

declare const EGL_MULTISAMPLE_RESOLVE: number;

declare const EGL_MULTISAMPLE_RESOLVE_BOX: number;

declare const EGL_MULTISAMPLE_RESOLVE_BOX_BIT: number;

declare const EGL_MULTISAMPLE_RESOLVE_DEFAULT: number;

declare const EGL_NATIVE_RENDERABLE: number;

declare const EGL_NATIVE_VISUAL_ID: number;

declare const EGL_NATIVE_VISUAL_TYPE: number;

declare const EGL_NONE: number;

declare const EGL_NON_CONFORMANT_CONFIG: number;

declare const EGL_NOT_INITIALIZED: number;

declare const EGL_NO_RESET_NOTIFICATION: number;

declare const EGL_NO_TEXTURE: number;

declare const EGL_OPENGL_API: number;

declare const EGL_OPENGL_BIT: number;

declare const EGL_OPENGL_ES2_BIT: number;

declare const EGL_OPENGL_ES3_BIT: number;

declare const EGL_OPENGL_ES_API: number;

declare const EGL_OPENGL_ES_BIT: number;

declare const EGL_OPENVG_API: number;

declare const EGL_OPENVG_BIT: number;

declare const EGL_OPENVG_IMAGE: number;

declare const EGL_PBUFFER_BIT: number;

declare const EGL_PIXEL_ASPECT_RATIO: number;

declare const EGL_PIXMAP_BIT: number;

declare const EGL_READ: number;

declare const EGL_RED_SIZE: number;

declare const EGL_RENDERABLE_TYPE: number;

declare const EGL_RENDER_BUFFER: number;

declare const EGL_RGB_BUFFER: number;

declare const EGL_SAMPLES: number;

declare const EGL_SAMPLE_BUFFERS: number;

declare const EGL_SIGNALED: number;

declare const EGL_SINGLE_BUFFER: number;

declare const EGL_SLOW_CONFIG: number;

declare const EGL_STENCIL_SIZE: number;

declare const EGL_SUCCESS: number;

declare const EGL_SURFACE_TYPE: number;

declare const EGL_SWAP_BEHAVIOR: number;

declare const EGL_SWAP_BEHAVIOR_PRESERVED_BIT: number;

declare const EGL_SYNC_CL_EVENT: number;

declare const EGL_SYNC_CL_EVENT_COMPLETE: number;

declare const EGL_SYNC_CONDITION: number;

declare const EGL_SYNC_FENCE: number;

declare const EGL_SYNC_FLUSH_COMMANDS_BIT: number;

declare const EGL_SYNC_PRIOR_COMMANDS_COMPLETE: number;

declare const EGL_SYNC_STATUS: number;

declare const EGL_SYNC_TYPE: number;

declare const EGL_TEXTURE_2D: number;

declare const EGL_TEXTURE_FORMAT: number;

declare const EGL_TEXTURE_RGB: number;

declare const EGL_TEXTURE_RGBA: number;

declare const EGL_TEXTURE_TARGET: number;

declare const EGL_TIMEOUT_EXPIRED: number;

declare const EGL_TRANSPARENT_BLUE_VALUE: number;

declare const EGL_TRANSPARENT_GREEN_VALUE: number;

declare const EGL_TRANSPARENT_RED_VALUE: number;

declare const EGL_TRANSPARENT_RGB: number;

declare const EGL_TRANSPARENT_TYPE: number;

declare const EGL_TRUE: number;

declare const EGL_UNSIGNALED: number;

declare const EGL_VENDOR: number;

declare const EGL_VERSION: number;

declare const EGL_VERSION_1_0: number;

declare const EGL_VERSION_1_1: number;

declare const EGL_VERSION_1_2: number;

declare const EGL_VERSION_1_3: number;

declare const EGL_VERSION_1_4: number;

declare const EGL_VERSION_1_5: number;

declare const EGL_VERTICAL_RESOLUTION: number;

declare const EGL_VG_ALPHA_FORMAT: number;

declare const EGL_VG_ALPHA_FORMAT_NONPRE: number;

declare const EGL_VG_ALPHA_FORMAT_PRE: number;

declare const EGL_VG_ALPHA_FORMAT_PRE_BIT: number;

declare const EGL_VG_COLORSPACE: number;

declare const EGL_VG_COLORSPACE_LINEAR: number;

declare const EGL_VG_COLORSPACE_LINEAR_BIT: number;

declare const EGL_VG_COLORSPACE_sRGB: number;

declare const EGL_WIDTH: number;

declare const EGL_WINDOW_BIT: number;

declare const KHRONOS_MAX_ENUM: number;

declare const KHRONOS_SUPPORT_FLOAT: number;

declare const KHRONOS_SUPPORT_INT64: number;

declare function eglBindAPI(api: number): number;

declare function eglBindTexImage(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, surface: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, buffer: number): number;

declare function eglChooseConfig(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attrib_list: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, configs: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, config_size: number, num_config: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function eglClientWaitSync(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sync: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, flags: number, timeout: number): number;

declare function eglCopyBuffers(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, surface: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, target: number): number;

declare function eglCreateContext(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, config: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, share_context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attrib_list: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function eglCreateImage(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, target: number, buffer: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attrib_list: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function eglCreatePbufferFromClientBuffer(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, buftype: number, buffer: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, config: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attrib_list: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function eglCreatePbufferSurface(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, config: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attrib_list: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function eglCreatePixmapSurface(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, config: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pixmap: number, attrib_list: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function eglCreatePlatformPixmapSurface(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, config: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, native_pixmap: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attrib_list: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function eglCreatePlatformWindowSurface(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, config: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, native_window: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attrib_list: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function eglCreateSync(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: number, attrib_list: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function eglCreateWindowSurface(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, config: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, win: number, attrib_list: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function eglDestroyContext(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function eglDestroyImage(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, image: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function eglDestroySurface(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, surface: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function eglDestroySync(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sync: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function eglGetConfigAttrib(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, config: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attribute: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function eglGetConfigs(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, configs: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, config_size: number, num_config: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function eglGetCurrentContext(): interop.Pointer | interop.Reference<any> | null;

declare function eglGetCurrentDisplay(): interop.Pointer | interop.Reference<any> | null;

declare function eglGetCurrentSurface(readdraw: number): interop.Pointer | interop.Reference<any> | null;

declare function eglGetDisplay(display_id: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function eglGetError(): number;

declare function eglGetPlatformDisplay(platform: number, native_display: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attrib_list: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function eglGetProcAddress(procname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.FunctionReference<() => void>;

declare function eglGetSyncAttrib(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sync: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attribute: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function eglInitialize(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, major: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, minor: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function eglMakeCurrent(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, draw: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, read: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function eglQueryAPI(): number;

declare function eglQueryContext(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attribute: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function eglQueryString(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: number): string | null;

declare function eglQuerySurface(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, surface: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attribute: number, value: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function eglReleaseTexImage(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, surface: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, buffer: number): number;

declare function eglReleaseThread(): number;

declare function eglSurfaceAttrib(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, surface: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attribute: number, value: number): number;

declare function eglSwapBuffers(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, surface: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function eglSwapInterval(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, interval: number): number;

declare function eglTerminate(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function eglWaitClient(): number;

declare function eglWaitGL(): number;

declare function eglWaitNative(engine: number): number;

declare function eglWaitSync(dpy: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sync: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, flags: number): number;

declare const enum khronos_boolean_enum_t {

	FALSE = 0,

	TRUE = 1,

	BOOLEAN_ENUM_FORCE_SIZE = 2147483647
}
