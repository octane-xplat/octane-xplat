
declare const CFF_CONFIG_OPTION_DARKENING_PARAMETER_X1: number;

declare const CFF_CONFIG_OPTION_DARKENING_PARAMETER_X2: number;

declare const CFF_CONFIG_OPTION_DARKENING_PARAMETER_X3: number;

declare const CFF_CONFIG_OPTION_DARKENING_PARAMETER_X4: number;

declare const CFF_CONFIG_OPTION_DARKENING_PARAMETER_Y1: number;

declare const CFF_CONFIG_OPTION_DARKENING_PARAMETER_Y2: number;

declare const CFF_CONFIG_OPTION_DARKENING_PARAMETER_Y3: number;

declare const CFF_CONFIG_OPTION_DARKENING_PARAMETER_Y4: number;

declare const FREETYPE_MAJOR: number;

declare const FREETYPE_MINOR: number;

declare const FREETYPE_PATCH: number;

declare function FT_Attach_File(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, filepathname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_Attach_Stream(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, parameters: interop.Pointer | interop.Reference<FT_Open_Args> | ArrayBufferLike | ArrayBufferView | null): number;

interface FT_BBox {
	xMin: number;
	yMin: number;
	xMax: number;
	yMax: number;
}
declare var FT_BBox: interop.StructType<FT_BBox>;

interface FT_Bitmap {
	rows: number;
	width: number;
	pitch: number;
	buffer: interop.Pointer | interop.Reference<any> | null;
	num_grays: number;
	pixel_mode: number;
	palette_mode: number;
	palette: interop.Pointer | interop.Reference<any> | null;
}
declare var FT_Bitmap: interop.StructType<FT_Bitmap>;

interface FT_Bitmap_Size {
	height: number;
	width: number;
	size: number;
	x_ppem: number;
	y_ppem: number;
}
declare var FT_Bitmap_Size: interop.StructType<FT_Bitmap_Size>;

declare const FT_CHAR_BIT: number;

declare const FT_CURVE_TAG_CONIC: number;

declare const FT_CURVE_TAG_CUBIC: number;

declare const FT_CURVE_TAG_HAS_SCANMODE: number;

declare const FT_CURVE_TAG_ON: number;

declare const FT_CURVE_TAG_TOUCH_BOTH: number;

declare const FT_CURVE_TAG_TOUCH_X: number;

declare const FT_CURVE_TAG_TOUCH_Y: number;

declare function FT_CeilFix(a: number): number;

interface FT_CharMapRec {
	face: interop.Pointer | interop.Reference<FT_FaceRec> | null;
	encoding: FT_Encoding;
	platform_id: number;
	encoding_id: number;
}
declare var FT_CharMapRec: interop.StructType<FT_CharMapRec>;

declare const FT_Curve_Tag_Conic: number;

declare const FT_Curve_Tag_Cubic: number;

declare const FT_Curve_Tag_On: number;

declare const FT_Curve_Tag_Touch_X: number;

declare const FT_Curve_Tag_Touch_Y: number;

interface FT_Data {
	pointer: string | null;
	length: number;
}
declare var FT_Data: interop.StructType<FT_Data>;

declare function FT_DivFix(a: number, b: number): number;

declare function FT_Done_Face(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_Done_FreeType(library: interop.Pointer | interop.Reference<FT_LibraryRec_> | ArrayBufferLike | ArrayBufferView | null): number;

interface FT_DriverRec_ {
}
declare var FT_DriverRec_: interop.StructType<FT_DriverRec_>;

declare const enum FT_Encoding {

	NONE = 0,

	MS_SYMBOL = 1937337698,

	UNICODE = 1970170211,

	SJIS = 1936353651,

	PRC = 1734484000,

	BIG5 = 1651074869,

	WANSUNG = 2002873971,

	JOHAB = 1785686113,

	GB2312 = 1734484000,

	MS_SJIS = 1936353651,

	MS_GB2312 = 1734484000,

	MS_BIG5 = 1651074869,

	MS_WANSUNG = 2002873971,

	MS_JOHAB = 1785686113,

	ADOBE_STANDARD = 1094995778,

	ADOBE_EXPERT = 1094992453,

	ADOBE_CUSTOM = 1094992451,

	ADOBE_LATIN_1 = 1818326065,

	OLD_LATIN_2 = 1818326066,

	APPLE_ROMAN = 1634889070
}

declare var FT_Err_Array_Too_Large: number;

declare var FT_Err_Bad_Argument: number;

declare var FT_Err_Bbx_Too_Big: number;

declare var FT_Err_CMap_Table_Missing: number;

declare var FT_Err_Cannot_Open_Resource: number;

declare var FT_Err_Cannot_Open_Stream: number;

declare var FT_Err_Cannot_Render_Glyph: number;

declare var FT_Err_Code_Overflow: number;

declare var FT_Err_Corrupted_Font_Glyphs: number;

declare var FT_Err_Corrupted_Font_Header: number;

declare var FT_Err_Could_Not_Find_Context: number;

declare var FT_Err_DEF_In_Glyf_Bytecode: number;

declare var FT_Err_Debug_OpCode: number;

declare var FT_Err_Divide_By_Zero: number;

declare var FT_Err_ENDF_In_Exec_Stream: number;

declare var FT_Err_Execution_Too_Long: number;

declare var FT_Err_Glyph_Too_Big: number;

declare var FT_Err_Hmtx_Table_Missing: number;

declare var FT_Err_Horiz_Header_Missing: number;

declare var FT_Err_Ignore: number;

declare var FT_Err_Invalid_Argument: number;

declare var FT_Err_Invalid_Cache_Handle: number;

declare var FT_Err_Invalid_CharMap_Format: number;

declare var FT_Err_Invalid_CharMap_Handle: number;

declare var FT_Err_Invalid_Character_Code: number;

declare var FT_Err_Invalid_CodeRange: number;

declare var FT_Err_Invalid_Composite: number;

declare var FT_Err_Invalid_Driver_Handle: number;

declare var FT_Err_Invalid_Face_Handle: number;

declare var FT_Err_Invalid_File_Format: number;

declare var FT_Err_Invalid_Frame_Operation: number;

declare var FT_Err_Invalid_Frame_Read: number;

declare var FT_Err_Invalid_Glyph_Format: number;

declare var FT_Err_Invalid_Glyph_Index: number;

declare var FT_Err_Invalid_Handle: number;

declare var FT_Err_Invalid_Horiz_Metrics: number;

declare var FT_Err_Invalid_Library_Handle: number;

declare var FT_Err_Invalid_Offset: number;

declare var FT_Err_Invalid_Opcode: number;

declare var FT_Err_Invalid_Outline: number;

declare var FT_Err_Invalid_PPem: number;

declare var FT_Err_Invalid_Pixel_Size: number;

declare var FT_Err_Invalid_Post_Table: number;

declare var FT_Err_Invalid_Post_Table_Format: number;

declare var FT_Err_Invalid_Reference: number;

declare var FT_Err_Invalid_SVG_Document: number;

declare var FT_Err_Invalid_Size_Handle: number;

declare var FT_Err_Invalid_Slot_Handle: number;

declare var FT_Err_Invalid_Stream_Handle: number;

declare var FT_Err_Invalid_Stream_Operation: number;

declare var FT_Err_Invalid_Stream_Read: number;

declare var FT_Err_Invalid_Stream_Seek: number;

declare var FT_Err_Invalid_Stream_Skip: number;

declare var FT_Err_Invalid_Table: number;

declare var FT_Err_Invalid_Version: number;

declare var FT_Err_Invalid_Vert_Metrics: number;

declare var FT_Err_Locations_Missing: number;

declare var FT_Err_Lower_Module_Version: number;

declare var FT_Err_Missing_Bbx_Field: number;

declare var FT_Err_Missing_Bitmap: number;

declare var FT_Err_Missing_Chars_Field: number;

declare var FT_Err_Missing_Encoding_Field: number;

declare var FT_Err_Missing_Font_Field: number;

declare var FT_Err_Missing_Fontboundingbox_Field: number;

declare var FT_Err_Missing_Module: number;

declare var FT_Err_Missing_Property: number;

declare var FT_Err_Missing_SVG_Hooks: number;

declare var FT_Err_Missing_Size_Field: number;

declare var FT_Err_Missing_Startchar_Field: number;

declare var FT_Err_Missing_Startfont_Field: number;

declare var FT_Err_Name_Table_Missing: number;

declare var FT_Err_Nested_DEFS: number;

declare var FT_Err_Nested_Frame_Access: number;

declare var FT_Err_No_Unicode_Glyph_Name: number;

declare var FT_Err_Ok: number;

declare var FT_Err_Out_Of_Memory: number;

declare var FT_Err_Post_Table_Missing: number;

declare var FT_Err_Raster_Corrupted: number;

declare var FT_Err_Raster_Negative_Height: number;

declare var FT_Err_Raster_Overflow: number;

declare var FT_Err_Raster_Uninitialized: number;

declare var FT_Err_Stack_Overflow: number;

declare var FT_Err_Stack_Underflow: number;

declare var FT_Err_Syntax_Error: number;

declare var FT_Err_Table_Missing: number;

declare var FT_Err_Too_Few_Arguments: number;

declare var FT_Err_Too_Many_Caches: number;

declare var FT_Err_Too_Many_Drivers: number;

declare var FT_Err_Too_Many_Extensions: number;

declare var FT_Err_Too_Many_Function_Defs: number;

declare var FT_Err_Too_Many_Hints: number;

declare var FT_Err_Too_Many_Instruction_Defs: number;

declare var FT_Err_Unimplemented_Feature: number;

declare var FT_Err_Unknown_File_Format: number;

declare var FT_Err_Unlisted_Object: number;

declare function FT_Error_String(error_code: number): string | null;

declare const FT_FACE_FLAG_CID_KEYED: number;

declare const FT_FACE_FLAG_COLOR: number;

declare const FT_FACE_FLAG_EXTERNAL_STREAM: number;

declare const FT_FACE_FLAG_FAST_GLYPHS: number;

declare const FT_FACE_FLAG_FIXED_SIZES: number;

declare const FT_FACE_FLAG_FIXED_WIDTH: number;

declare const FT_FACE_FLAG_GLYPH_NAMES: number;

declare const FT_FACE_FLAG_HINTER: number;

declare const FT_FACE_FLAG_HORIZONTAL: number;

declare const FT_FACE_FLAG_KERNING: number;

declare const FT_FACE_FLAG_MULTIPLE_MASTERS: number;

declare const FT_FACE_FLAG_SBIX: number;

declare const FT_FACE_FLAG_SBIX_OVERLAY: number;

declare const FT_FACE_FLAG_SCALABLE: number;

declare const FT_FACE_FLAG_SFNT: number;

declare const FT_FACE_FLAG_SVG: number;

declare const FT_FACE_FLAG_TRICKY: number;

declare const FT_FACE_FLAG_VARIATION: number;

declare const FT_FACE_FLAG_VERTICAL: number;

declare const FT_FSTYPE_BITMAP_EMBEDDING_ONLY: number;

declare const FT_FSTYPE_EDITABLE_EMBEDDING: number;

declare const FT_FSTYPE_INSTALLABLE_EMBEDDING: number;

declare const FT_FSTYPE_NO_SUBSETTING: number;

declare const FT_FSTYPE_PREVIEW_AND_PRINT_EMBEDDING: number;

declare const FT_FSTYPE_RESTRICTED_LICENSE_EMBEDDING: number;

interface FT_FaceRec {
	num_faces: number;
	face_index: number;
	face_flags: number;
	style_flags: number;
	num_glyphs: number;
	family_name: interop.Pointer | interop.Reference<any> | null;
	style_name: interop.Pointer | interop.Reference<any> | null;
	num_fixed_sizes: number;
	available_sizes: interop.Pointer | interop.Reference<FT_Bitmap_Size> | null;
	num_charmaps: number;
	charmaps: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FT_CharMapRec> | null> | null;
	generic: FT_Generic;
	bbox: FT_BBox;
	units_per_EM: number;
	ascender: number;
	descender: number;
	height: number;
	max_advance_width: number;
	max_advance_height: number;
	underline_position: number;
	underline_thickness: number;
	glyph: interop.Pointer | interop.Reference<FT_GlyphSlotRec> | null;
	size: interop.Pointer | interop.Reference<FT_SizeRec> | null;
	charmap: interop.Pointer | interop.Reference<FT_CharMapRec> | null;
	driver: interop.Pointer | interop.Reference<FT_DriverRec_> | null;
	memory: interop.Pointer | interop.Reference<FT_MemoryRec_> | null;
	stream: interop.Pointer | interop.Reference<FT_StreamRec> | null;
	sizes_list: FT_ListRec;
	autohint: FT_Generic;
	extensions: interop.Pointer | interop.Reference<any> | null;
	internal: interop.Pointer | interop.Reference<FT_Face_InternalRec_> | null;
}
declare var FT_FaceRec: interop.StructType<FT_FaceRec>;

declare function FT_Face_CheckTrueTypePatents(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_Face_GetCharVariantIndex(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, charcode: number, variantSelector: number): number;

declare function FT_Face_GetCharVariantIsDefault(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, charcode: number, variantSelector: number): number;

declare function FT_Face_GetCharsOfVariant(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, variantSelector: number): interop.Pointer | interop.Reference<number> | null;

declare function FT_Face_GetVariantSelectors(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function FT_Face_GetVariantsOfChar(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, charcode: number): interop.Pointer | interop.Reference<number> | null;

interface FT_Face_InternalRec_ {
}
declare var FT_Face_InternalRec_: interop.StructType<FT_Face_InternalRec_>;

declare function FT_Face_Properties(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, num_properties: number, properties: interop.Pointer | interop.Reference<FT_Parameter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_Face_SetUnpatentedHinting(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, value: number): number;

declare function FT_FloorFix(a: number): number;

interface FT_Generic {
	data: interop.Pointer | interop.Reference<any> | null;
	finalizer: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>;
}
declare var FT_Generic: interop.StructType<FT_Generic>;

declare function FT_Get_Char_Index(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, charcode: number): number;

declare function FT_Get_Charmap_Index(charmap: interop.Pointer | interop.Reference<FT_CharMapRec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_Get_FSType_Flags(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_Get_First_Char(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, agindex: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_Get_Glyph_Name(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, glyph_index: number, buffer: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, buffer_max: number): number;

declare function FT_Get_Kerning(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, left_glyph: number, right_glyph: number, kern_mode: number, akerning: interop.Pointer | interop.Reference<FT_Vector> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_Get_Name_Index(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, glyph_name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_Get_Next_Char(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, char_code: number, agindex: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_Get_Postscript_Name(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function FT_Get_SubGlyph_Info(glyph: interop.Pointer | interop.Reference<FT_GlyphSlotRec> | ArrayBufferLike | ArrayBufferView | null, sub_index: number, p_index: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p_flags: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p_arg1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p_arg2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p_transform: interop.Pointer | interop.Reference<FT_Matrix> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_Get_Track_Kerning(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, point_size: number, degree: number, akerning: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_Get_Transform(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, matrix: interop.Pointer | interop.Reference<FT_Matrix> | ArrayBufferLike | ArrayBufferView | null, delta: interop.Pointer | interop.Reference<FT_Vector> | ArrayBufferLike | ArrayBufferView | null): void;

interface FT_GlyphSlotRec {
	library: interop.Pointer | interop.Reference<FT_LibraryRec_> | null;
	face: interop.Pointer | interop.Reference<FT_FaceRec> | null;
	next: interop.Pointer | interop.Reference<FT_GlyphSlotRec> | null;
	glyph_index: number;
	generic: FT_Generic;
	metrics: FT_Glyph_Metrics;
	linearHoriAdvance: number;
	linearVertAdvance: number;
	advance: FT_Vector;
	format: FT_Glyph_Format;
	bitmap: FT_Bitmap;
	bitmap_left: number;
	bitmap_top: number;
	outline: FT_Outline;
	num_subglyphs: number;
	subglyphs: interop.Pointer | interop.Reference<FT_SubGlyphRec_> | null;
	control_data: interop.Pointer | interop.Reference<any> | null;
	control_len: number;
	lsb_delta: number;
	rsb_delta: number;
	other: interop.Pointer | interop.Reference<any> | null;
	internal: interop.Pointer | interop.Reference<FT_Slot_InternalRec_> | null;
}
declare var FT_GlyphSlotRec: interop.StructType<FT_GlyphSlotRec>;

declare const enum FT_Glyph_Format {

	NONE = 0,

	COMPOSITE = 1668246896,

	BITMAP = 1651078259,

	OUTLINE = 1869968492,

	PLOTTER = 1886154612,

	SVG = 1398163232
}

interface FT_Glyph_Metrics {
	width: number;
	height: number;
	horiBearingX: number;
	horiBearingY: number;
	horiAdvance: number;
	vertBearingX: number;
	vertBearingY: number;
	vertAdvance: number;
}
declare var FT_Glyph_Metrics: interop.StructType<FT_Glyph_Metrics>;

declare const FT_INT_MAX: number;

declare const FT_INT_MIN: number;

declare function FT_Init_FreeType(alibrary: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FT_LibraryRec_> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare const enum FT_Kerning_Mode {

	DEFAULT = 0,

	UNFITTED = 1,

	UNSCALED = 2
}

declare const FT_LLONG_MAX: bigint;

declare const FT_LLONG_MIN: bigint;

declare const FT_LOAD_ADVANCE_ONLY: number;

declare const FT_LOAD_BITMAP_METRICS_ONLY: number;

declare const FT_LOAD_COLOR: number;

declare const FT_LOAD_COMPUTE_METRICS: number;

declare const FT_LOAD_CROP_BITMAP: number;

declare const FT_LOAD_DEFAULT: number;

declare const FT_LOAD_FORCE_AUTOHINT: number;

declare const FT_LOAD_IGNORE_GLOBAL_ADVANCE_WIDTH: number;

declare const FT_LOAD_IGNORE_TRANSFORM: number;

declare const FT_LOAD_LINEAR_DESIGN: number;

declare const FT_LOAD_MONOCHROME: number;

declare const FT_LOAD_NO_AUTOHINT: number;

declare const FT_LOAD_NO_BITMAP: number;

declare const FT_LOAD_NO_HINTING: number;

declare const FT_LOAD_NO_RECURSE: number;

declare const FT_LOAD_NO_SCALE: number;

declare const FT_LOAD_NO_SVG: number;

declare const FT_LOAD_PEDANTIC: number;

declare const FT_LOAD_RENDER: number;

declare const FT_LOAD_SBITS_ONLY: number;

declare const FT_LOAD_SVG_ONLY: number;

declare const FT_LOAD_TARGET_LCD: number;

declare const FT_LOAD_TARGET_LCD_V: number;

declare const FT_LOAD_TARGET_LIGHT: number;

declare const FT_LOAD_TARGET_MONO: number;

declare const FT_LOAD_TARGET_NORMAL: number;

declare const FT_LOAD_VERTICAL_LAYOUT: number;

declare const FT_LONG_MAX: bigint;

declare const FT_LONG_MIN: bigint;

interface FT_LibraryRec_ {
}
declare var FT_LibraryRec_: interop.StructType<FT_LibraryRec_>;

declare function FT_Library_Version(library: interop.Pointer | interop.Reference<FT_LibraryRec_> | ArrayBufferLike | ArrayBufferView | null, amajor: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, aminor: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, apatch: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

interface FT_ListNodeRec {
	prev: interop.Pointer | interop.Reference<FT_ListNodeRec> | null;
	next: interop.Pointer | interop.Reference<FT_ListNodeRec> | null;
	data: interop.Pointer | interop.Reference<any> | null;
}
declare var FT_ListNodeRec: interop.StructType<FT_ListNodeRec>;

interface FT_ListRec {
	head: interop.Pointer | interop.Reference<FT_ListNodeRec> | null;
	tail: interop.Pointer | interop.Reference<FT_ListNodeRec> | null;
}
declare var FT_ListRec: interop.StructType<FT_ListRec>;

declare function FT_Load_Char(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, char_code: number, load_flags: number): number;

declare function FT_Load_Glyph(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, glyph_index: number, load_flags: number): number;

declare const FT_MAX_MODULES: number;

interface FT_Matrix {
	xx: number;
	xy: number;
	yx: number;
	yy: number;
}
declare var FT_Matrix: interop.StructType<FT_Matrix>;

interface FT_MemoryRec_ {
	user: interop.Pointer | interop.Reference<any> | null;
	alloc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<FT_MemoryRec_> | null, p2: number) => interop.Pointer | interop.Reference<any> | null>;
	free: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<FT_MemoryRec_> | null, p2: interop.Pointer | interop.Reference<any> | null) => void>;
	realloc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<FT_MemoryRec_> | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<any> | null) => interop.Pointer | interop.Reference<any> | null>;
}
declare var FT_MemoryRec_: interop.StructType<FT_MemoryRec_>;

declare const FT_Mod_Err_Autofit: number;

declare const FT_Mod_Err_BDF: number;

declare const FT_Mod_Err_Base: number;

declare const FT_Mod_Err_Bzip2: number;

declare const FT_Mod_Err_CFF: number;

declare const FT_Mod_Err_CID: number;

declare const FT_Mod_Err_Cache: number;

declare const FT_Mod_Err_GXvalid: number;

declare const FT_Mod_Err_Gzip: number;

declare const FT_Mod_Err_LZW: number;

declare const FT_Mod_Err_Max: number;

declare const FT_Mod_Err_OTvalid: number;

declare const FT_Mod_Err_PCF: number;

declare const FT_Mod_Err_PFR: number;

declare const FT_Mod_Err_PSaux: number;

declare const FT_Mod_Err_PShinter: number;

declare const FT_Mod_Err_PSnames: number;

declare const FT_Mod_Err_Raster: number;

declare const FT_Mod_Err_SFNT: number;

declare const FT_Mod_Err_Sdf: number;

declare const FT_Mod_Err_Smooth: number;

declare const FT_Mod_Err_TrueType: number;

declare const FT_Mod_Err_Type1: number;

declare const FT_Mod_Err_Type42: number;

declare const FT_Mod_Err_Winfonts: number;

interface FT_ModuleRec_ {
}
declare var FT_ModuleRec_: interop.StructType<FT_ModuleRec_>;

declare function FT_MulDiv(a: number, b: number, c: number): number;

declare function FT_MulFix(a: number, b: number): number;

declare function FT_New_Face(library: interop.Pointer | interop.Reference<FT_LibraryRec_> | ArrayBufferLike | ArrayBufferView | null, filepathname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, face_index: number, aface: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FT_FaceRec> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_New_Memory_Face(library: interop.Pointer | interop.Reference<FT_LibraryRec_> | ArrayBufferLike | ArrayBufferView | null, file_base: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, file_size: number, face_index: number, aface: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FT_FaceRec> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare const FT_OPEN_DRIVER: number;

declare const FT_OPEN_MEMORY: number;

declare const FT_OPEN_PARAMS: number;

declare const FT_OPEN_PATHNAME: number;

declare const FT_OPEN_STREAM: number;

declare const FT_OUTLINE_CONTOURS_MAX: number;

declare const FT_OUTLINE_EVEN_ODD_FILL: number;

declare const FT_OUTLINE_HIGH_PRECISION: number;

declare const FT_OUTLINE_IGNORE_DROPOUTS: number;

declare const FT_OUTLINE_INCLUDE_STUBS: number;

declare const FT_OUTLINE_NONE: number;

declare const FT_OUTLINE_OVERLAP: number;

declare const FT_OUTLINE_OWNER: number;

declare const FT_OUTLINE_POINTS_MAX: number;

declare const FT_OUTLINE_REVERSE_FILL: number;

declare const FT_OUTLINE_SINGLE_PASS: number;

declare const FT_OUTLINE_SMART_DROPOUTS: number;

interface FT_Open_Args {
	flags: number;
	memory_base: string | null;
	memory_size: number;
	pathname: interop.Pointer | interop.Reference<any> | null;
	stream: interop.Pointer | interop.Reference<FT_StreamRec> | null;
	driver: interop.Pointer | interop.Reference<FT_ModuleRec_> | null;
	num_params: number;
	params: interop.Pointer | interop.Reference<FT_Parameter> | null;
}
declare var FT_Open_Args: interop.StructType<FT_Open_Args>;

declare function FT_Open_Face(library: interop.Pointer | interop.Reference<FT_LibraryRec_> | ArrayBufferLike | ArrayBufferView | null, args: interop.Pointer | interop.Reference<FT_Open_Args> | ArrayBufferLike | ArrayBufferView | null, face_index: number, aface: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FT_FaceRec> | null> | ArrayBufferLike | ArrayBufferView | null): number;

interface FT_Outline {
	n_contours: number;
	n_points: number;
	points: interop.Pointer | interop.Reference<FT_Vector> | null;
	tags: interop.Pointer | interop.Reference<any> | null;
	contours: interop.Pointer | interop.Reference<number> | null;
	flags: number;
}
declare var FT_Outline: interop.StructType<FT_Outline>;

interface FT_Outline_Funcs {
	move_to: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<FT_Vector> | null, p2: interop.Pointer | interop.Reference<any> | null) => number>;
	line_to: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<FT_Vector> | null, p2: interop.Pointer | interop.Reference<any> | null) => number>;
	conic_to: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<FT_Vector> | null, p2: interop.Pointer | interop.Reference<FT_Vector> | null, p3: interop.Pointer | interop.Reference<any> | null) => number>;
	cubic_to: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<FT_Vector> | null, p2: interop.Pointer | interop.Reference<FT_Vector> | null, p3: interop.Pointer | interop.Reference<FT_Vector> | null, p4: interop.Pointer | interop.Reference<any> | null) => number>;
	shift: number;
	delta: number;
}
declare var FT_Outline_Funcs: interop.StructType<FT_Outline_Funcs>;

interface FT_Parameter {
	tag: number;
	data: interop.Pointer | interop.Reference<any> | null;
}
declare var FT_Parameter: interop.StructType<FT_Parameter>;

declare const enum FT_Pixel_Mode {

	NONE = 0,

	MONO = 1,

	GRAY = 2,

	GRAY2 = 3,

	GRAY4 = 4,

	LCD = 5,

	LCD_V = 6,

	BGRA = 7,

	MAX = 8
}

declare const FT_RASTER_FLAG_AA: number;

declare const FT_RASTER_FLAG_CLIP: number;

declare const FT_RASTER_FLAG_DEFAULT: number;

declare const FT_RASTER_FLAG_DIRECT: number;

declare const FT_RASTER_FLAG_SDF: number;

declare const FT_RENDER_POOL_SIZE: number;

interface FT_RasterRec_ {
}
declare var FT_RasterRec_: interop.StructType<FT_RasterRec_>;

interface FT_Raster_Funcs {
	glyph_format: FT_Glyph_Format;
	raster_new: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FT_RasterRec_> | null> | null) => number>;
	raster_reset: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<FT_RasterRec_> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number) => void>;
	raster_set_mode: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<FT_RasterRec_> | null, p2: number, p3: interop.Pointer | interop.Reference<any> | null) => number>;
	raster_render: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<FT_RasterRec_> | null, p2: interop.Pointer | interop.Reference<FT_Raster_Params> | null) => number>;
	raster_done: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<FT_RasterRec_> | null) => void>;
}
declare var FT_Raster_Funcs: interop.StructType<FT_Raster_Funcs>;

interface FT_Raster_Params {
	target: interop.Pointer | interop.Reference<FT_Bitmap> | null;
	source: interop.Pointer | interop.Reference<any> | null;
	flags: number;
	gray_spans: interop.FunctionReference<(p1: number, p2: number, p3: interop.Pointer | interop.Reference<FT_Span> | null, p4: interop.Pointer | interop.Reference<any> | null) => void>;
	black_spans: interop.FunctionReference<(p1: number, p2: number, p3: interop.Pointer | interop.Reference<FT_Span> | null, p4: interop.Pointer | interop.Reference<any> | null) => void>;
	bit_test: interop.FunctionReference<(p1: number, p2: number, p3: interop.Pointer | interop.Reference<any> | null) => number>;
	bit_set: interop.FunctionReference<(p1: number, p2: number, p3: interop.Pointer | interop.Reference<any> | null) => void>;
	user: interop.Pointer | interop.Reference<any> | null;
	clip_box: FT_BBox;
}
declare var FT_Raster_Params: interop.StructType<FT_Raster_Params>;

declare function FT_Reference_Face(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_Render_Glyph(slot: interop.Pointer | interop.Reference<FT_GlyphSlotRec> | ArrayBufferLike | ArrayBufferView | null, render_mode: FT_Render_Mode): number;

declare const enum FT_Render_Mode {

	NORMAL = 0,

	LIGHT = 1,

	MONO = 2,

	LCD = 3,

	LCD_V = 4,

	SDF = 5,

	MAX = 6
}

interface FT_RendererRec_ {
}
declare var FT_RendererRec_: interop.StructType<FT_RendererRec_>;

declare function FT_Request_Size(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, req: interop.Pointer | interop.Reference<FT_Size_RequestRec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_RoundFix(a: number): number;

declare const FT_SIZEOF_INT: number;

declare const FT_SIZEOF_LONG: number;

declare const FT_SIZEOF_LONG_LONG: number;

declare const FT_STYLE_FLAG_BOLD: number;

declare const FT_STYLE_FLAG_ITALIC: number;

declare const FT_SUBGLYPH_FLAG_2X2: number;

declare const FT_SUBGLYPH_FLAG_ARGS_ARE_WORDS: number;

declare const FT_SUBGLYPH_FLAG_ARGS_ARE_XY_VALUES: number;

declare const FT_SUBGLYPH_FLAG_ROUND_XY_TO_GRID: number;

declare const FT_SUBGLYPH_FLAG_SCALE: number;

declare const FT_SUBGLYPH_FLAG_USE_MY_METRICS: number;

declare const FT_SUBGLYPH_FLAG_XY_SCALE: number;

declare function FT_Select_Charmap(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, encoding: FT_Encoding): number;

declare function FT_Select_Size(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, strike_index: number): number;

declare function FT_Set_Char_Size(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, char_width: number, char_height: number, horz_resolution: number, vert_resolution: number): number;

declare function FT_Set_Charmap(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, charmap: interop.Pointer | interop.Reference<FT_CharMapRec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FT_Set_Pixel_Sizes(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, pixel_width: number, pixel_height: number): number;

declare function FT_Set_Transform(face: interop.Pointer | interop.Reference<FT_FaceRec> | ArrayBufferLike | ArrayBufferView | null, matrix: interop.Pointer | interop.Reference<FT_Matrix> | ArrayBufferLike | ArrayBufferView | null, delta: interop.Pointer | interop.Reference<FT_Vector> | ArrayBufferLike | ArrayBufferView | null): void;

interface FT_SizeRec {
	face: interop.Pointer | interop.Reference<FT_FaceRec> | null;
	generic: FT_Generic;
	metrics: FT_Size_Metrics;
	internal: interop.Pointer | interop.Reference<FT_Size_InternalRec_> | null;
}
declare var FT_SizeRec: interop.StructType<FT_SizeRec>;

interface FT_Size_InternalRec_ {
}
declare var FT_Size_InternalRec_: interop.StructType<FT_Size_InternalRec_>;

interface FT_Size_Metrics {
	x_ppem: number;
	y_ppem: number;
	x_scale: number;
	y_scale: number;
	ascender: number;
	descender: number;
	height: number;
	max_advance: number;
}
declare var FT_Size_Metrics: interop.StructType<FT_Size_Metrics>;

interface FT_Size_RequestRec {
	type: FT_Size_Request_Type;
	width: number;
	height: number;
	horiResolution: number;
	vertResolution: number;
}
declare var FT_Size_RequestRec: interop.StructType<FT_Size_RequestRec>;

declare const enum FT_Size_Request_Type {

	NOMINAL = 0,

	REAL_DIM = 1,

	BBOX = 2,

	CELL = 3,

	SCALES = 4,

	MAX = 5
}

interface FT_Slot_InternalRec_ {
}
declare var FT_Slot_InternalRec_: interop.StructType<FT_Slot_InternalRec_>;

interface FT_Span {
	x: number;
	len: number;
	coverage: number;
}
declare var FT_Span: interop.StructType<FT_Span>;

interface FT_StreamDesc {
	value: number;
	pointer: interop.Pointer | interop.Reference<any> | null;
}


interface FT_StreamRec {
	base: interop.Pointer | interop.Reference<any> | null;
	size: number;
	pos: number;
	descriptor: FT_StreamDesc;
	pathname: FT_StreamDesc;
	read: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<FT_StreamRec> | null, p2: number, p3: interop.Pointer | interop.Reference<any> | null, p4: number) => number>;
	close: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<FT_StreamRec> | null) => void>;
	memory: interop.Pointer | interop.Reference<FT_MemoryRec_> | null;
	cursor: interop.Pointer | interop.Reference<any> | null;
	limit: interop.Pointer | interop.Reference<any> | null;
}
declare var FT_StreamRec: interop.StructType<FT_StreamRec>;

interface FT_SubGlyphRec_ {
}
declare var FT_SubGlyphRec_: interop.StructType<FT_SubGlyphRec_>;

declare const FT_UINT_MAX: number;

declare const FT_ULLONG_MAX: bigint;

declare const FT_ULONG_MAX: bigint;

declare const FT_USHORT_MAX: number;

interface FT_UnitVector {
	x: number;
	y: number;
}
declare var FT_UnitVector: interop.StructType<FT_UnitVector>;

interface FT_Vector {
	x: number;
	y: number;
}
declare var FT_Vector: interop.StructType<FT_Vector>;

declare function FT_Vector_Transform(vector: interop.Pointer | interop.Reference<FT_Vector> | ArrayBufferLike | ArrayBufferView | null, matrix: interop.Pointer | interop.Reference<FT_Matrix> | ArrayBufferLike | ArrayBufferView | null): void;

declare const HAVE_FCNTL_H: number;

declare const HAVE_UNISTD_H: number;

declare const T1_MAX_CHARSTRINGS_OPERANDS: number;

declare const T1_MAX_DICT_DEPTH: number;

declare const T1_MAX_SUBRS_CALLS: number;

declare const TT_CONFIG_OPTION_MAX_RUNNABLE_OPCODES: number;

declare const ft_encoding_adobe_custom: number;

declare const ft_encoding_adobe_expert: number;

declare const ft_encoding_adobe_standard: number;

declare const ft_encoding_apple_roman: number;

declare const ft_encoding_big5: number;

declare const ft_encoding_gb2312: number;

declare const ft_encoding_johab: number;

declare const ft_encoding_latin_1: number;

declare const ft_encoding_latin_2: number;

declare const ft_encoding_none: number;

declare const ft_encoding_sjis: number;

declare const ft_encoding_symbol: number;

declare const ft_encoding_unicode: number;

declare const ft_encoding_wansung: number;

declare const ft_glyph_format_bitmap: number;

declare const ft_glyph_format_composite: number;

declare const ft_glyph_format_none: number;

declare const ft_glyph_format_outline: number;

declare const ft_glyph_format_plotter: number;

declare const ft_kerning_default: number;

declare const ft_kerning_unfitted: number;

declare const ft_kerning_unscaled: number;

declare const ft_open_driver: number;

declare const ft_open_memory: number;

declare const ft_open_params: number;

declare const ft_open_pathname: number;

declare const ft_open_stream: number;

declare const ft_outline_even_odd_fill: number;

declare const ft_outline_high_precision: number;

declare const ft_outline_ignore_dropouts: number;

declare const ft_outline_none: number;

declare const ft_outline_owner: number;

declare const ft_outline_reverse_fill: number;

declare const ft_outline_single_pass: number;

declare const ft_pixel_mode_grays: number;

declare const ft_pixel_mode_mono: number;

declare const ft_pixel_mode_none: number;

declare const ft_pixel_mode_pal2: number;

declare const ft_pixel_mode_pal4: number;

declare const ft_raster_flag_aa: number;

declare const ft_raster_flag_clip: number;

declare const ft_raster_flag_default: number;

declare const ft_raster_flag_direct: number;

declare const ft_render_mode_mono: number;

declare const ft_render_mode_normal: number;
