
declare const UUID_STR_LEN: number;

declare const UUID_TYPE_DCE_MD5: number;

declare const UUID_TYPE_DCE_NIL: number;

declare const UUID_TYPE_DCE_RANDOM: number;

declare const UUID_TYPE_DCE_SECURITY: number;

declare const UUID_TYPE_DCE_SHA1: number;

declare const UUID_TYPE_DCE_TIME: number;

declare const UUID_TYPE_MASK: number;

declare const UUID_TYPE_SHIFT: number;

declare const UUID_VARIANT_DCE: number;

declare const UUID_VARIANT_MASK: number;

declare const UUID_VARIANT_MICROSOFT: number;

declare const UUID_VARIANT_NCS: number;

declare const UUID_VARIANT_OTHER: number;

declare const UUID_VARIANT_SHIFT: number;

declare function uuid_clear(uu: interop.Reference<number>): void;

declare function uuid_compare(uu1: interop.Reference<number>, uu2: interop.Reference<number>): number;

declare function uuid_copy(dst: interop.Reference<number>, src: interop.Reference<number>): void;

declare function uuid_generate(out: interop.Reference<number>): void;

declare function uuid_generate_md5(out: interop.Reference<number>, ns: interop.Reference<number>, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): void;

declare function uuid_generate_random(out: interop.Reference<number>): void;

declare function uuid_generate_sha1(out: interop.Reference<number>, ns: interop.Reference<number>, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): void;

declare function uuid_generate_time(out: interop.Reference<number>): void;

declare function uuid_generate_time_safe(out: interop.Reference<number>): number;

declare function uuid_get_template(alias: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<interop.Reference<number>> | null;

declare function uuid_is_null(uu: interop.Reference<number>): number;

declare function uuid_parse(_in: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, uu: interop.Reference<number>): number;

declare function uuid_parse_range(in_start: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, in_end: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, uu: interop.Reference<number>): number;

declare function uuid_time(uu: interop.Reference<number>, ret_tv: interop.Pointer | interop.Reference<timeval> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uuid_type(uu: interop.Reference<number>): number;

declare function uuid_unparse(uu: interop.Reference<number>, out: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uuid_unparse_lower(uu: interop.Reference<number>, out: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uuid_unparse_upper(uu: interop.Reference<number>, out: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uuid_variant(uu: interop.Reference<number>): number;
