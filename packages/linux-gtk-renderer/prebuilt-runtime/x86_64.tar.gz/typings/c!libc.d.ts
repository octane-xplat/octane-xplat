
declare const ABDAY_1: number;

declare const ABDAY_2: number;

declare const ABDAY_3: number;

declare const ABDAY_4: number;

declare const ABDAY_5: number;

declare const ABDAY_6: number;

declare const ABDAY_7: number;

declare const ABMON_1: number;

declare const ABMON_10: number;

declare const ABMON_11: number;

declare const ABMON_12: number;

declare const ABMON_2: number;

declare const ABMON_3: number;

declare const ABMON_4: number;

declare const ABMON_5: number;

declare const ABMON_6: number;

declare const ABMON_7: number;

declare const ABMON_8: number;

declare const ABMON_9: number;

declare const enum ACTION {

	FIND = 0,

	ENTER = 1
}

declare const AIO_ALLDONE: number;

declare const AIO_CANCELED: number;

declare const AIO_NOTCANCELED: number;

declare const AI_ADDRCONFIG: number;

declare const AI_ALL: number;

declare const AI_CANONNAME: number;

declare const AI_NUMERICHOST: number;

declare const AI_NUMERICSERV: number;

declare const AI_PASSIVE: number;

declare const AI_V4MAPPED: number;

declare const ALT_DIGITS: number;

declare const AM_STR: number;

declare const AREGTYPE: number;

declare const AT_EACCESS: number;

declare const AT_FDCWD: number;

declare const AT_REMOVEDIR: number;

declare const AT_SYMLINK_FOLLOW: number;

declare const AT_SYMLINK_NOFOLLOW: number;

declare const BIG_ENDIAN: number;

declare const BLKTYPE: number;

declare const BUFSIZ: number;

declare const BYTE_ORDER: number;

declare const CHRTYPE: number;

declare const CODESET: number;

declare const CONTTYPE: number;

declare const CRNCYSTR: number;

declare const C_IRGRP: number;

declare const C_IROTH: number;

declare const C_IRUSR: number;

declare const C_ISBLK: number;

declare const C_ISCHR: number;

declare const C_ISCTG: number;

declare const C_ISDIR: number;

declare const C_ISFIFO: number;

declare const C_ISGID: number;

declare const C_ISLNK: number;

declare const C_ISREG: number;

declare const C_ISSOCK: number;

declare const C_ISUID: number;

declare const C_ISVTX: number;

declare const C_IWGRP: number;

declare const C_IWOTH: number;

declare const C_IWUSR: number;

declare const C_IXGRP: number;

declare const C_IXOTH: number;

declare const C_IXUSR: number;

declare const DAY_1: number;

declare const DAY_2: number;

declare const DAY_3: number;

declare const DAY_4: number;

declare const DAY_5: number;

declare const DAY_6: number;

declare const DAY_7: number;

interface DIR {
}
declare var DIR: interop.StructType<DIR>;

declare const DIRTYPE: number;

declare const DQF_PRIVATE: number;

declare const DQF_ROOT_SQUASH: number;

declare const DQF_ROOT_SQUASH_B: number;

declare const DQF_SYS_FILE: number;

declare const DQF_SYS_FILE_B: number;

declare const DT_BLK: number;

declare const DT_CHR: number;

declare const DT_DIR: number;

declare const DT_FIFO: number;

declare const DT_LNK: number;

declare const DT_REG: number;

declare const DT_SOCK: number;

declare const DT_UNKNOWN: number;

declare const DT_WHT: number;

declare const D_FMT: number;

declare const D_T_FMT: number;

declare const E2BIG: number;

declare const EACCES: number;

declare const EADDRINUSE: number;

declare const EADDRNOTAVAIL: number;

declare const EADV: number;

declare const EAFNOSUPPORT: number;

declare const EAGAIN: number;

declare const EAI_AGAIN: number;

declare const EAI_BADFLAGS: number;

declare const EAI_FAIL: number;

declare const EAI_FAMILY: number;

declare const EAI_MEMORY: number;

declare const EAI_NONAME: number;

declare const EAI_OVERFLOW: number;

declare const EAI_SERVICE: number;

declare const EAI_SOCKTYPE: number;

declare const EAI_SYSTEM: number;

declare const EALREADY: number;

declare const EBADE: number;

declare const EBADF: number;

declare const EBADFD: number;

declare const EBADMSG: number;

declare const EBADR: number;

declare const EBADRQC: number;

declare const EBADSLT: number;

declare const EBFONT: number;

declare const EBUSY: number;

declare const ECANCELED: number;

declare const ECHILD: number;

declare const ECHRNG: number;

declare const ECOMM: number;

declare const ECONNABORTED: number;

declare const ECONNREFUSED: number;

declare const ECONNRESET: number;

declare const EDEADLK: number;

declare const EDEADLOCK: number;

declare const EDESTADDRREQ: number;

declare const EDOM: number;

declare const EDOTDOT: number;

declare const EDQUOT: number;

declare const EEXIST: number;

declare const EFAULT: number;

declare const EFBIG: number;

declare const EHOSTDOWN: number;

declare const EHOSTUNREACH: number;

declare const EHWPOISON: number;

declare const EIDRM: number;

declare const EILSEQ: number;

declare const EINPROGRESS: number;

declare const EINTR: number;

declare const EINVAL: number;

declare const EIO: number;

declare const EISCONN: number;

declare const EISDIR: number;

declare const EISNAM: number;

declare const EKEYEXPIRED: number;

declare const EKEYREJECTED: number;

declare const EKEYREVOKED: number;

declare const EL2HLT: number;

declare const EL2NSYNC: number;

declare const EL3HLT: number;

declare const EL3RST: number;

declare const ELIBACC: number;

declare const ELIBBAD: number;

declare const ELIBEXEC: number;

declare const ELIBMAX: number;

declare const ELIBSCN: number;

declare const ELNRNG: number;

declare const ELOOP: number;

declare const EMEDIUMTYPE: number;

declare const EMFILE: number;

declare const EMLINK: number;

declare const EMSGSIZE: number;

declare const EMULTIHOP: number;

declare const ENAMETOOLONG: number;

declare const ENAVAIL: number;

declare const ENETDOWN: number;

declare const ENETRESET: number;

declare const ENETUNREACH: number;

declare const ENFILE: number;

declare const ENOANO: number;

declare const ENOBUFS: number;

declare const ENOCSI: number;

declare const ENODATA: number;

declare const ENODEV: number;

declare const ENOENT: number;

declare const ENOEXEC: number;

declare const ENOKEY: number;

declare const ENOLCK: number;

declare const ENOLINK: number;

declare const ENOMEDIUM: number;

declare const ENOMEM: number;

declare const ENOMSG: number;

declare const ENONET: number;

declare const ENOPKG: number;

declare const ENOPROTOOPT: number;

declare const ENOSPC: number;

declare const ENOSR: number;

declare const ENOSTR: number;

declare const ENOSYS: number;

declare const ENOTBLK: number;

declare const ENOTCONN: number;

declare const ENOTDIR: number;

declare const ENOTEMPTY: number;

declare const ENOTNAM: number;

declare const ENOTRECOVERABLE: number;

declare const ENOTSOCK: number;

declare const ENOTTY: number;

declare const ENOTUNIQ: number;

interface ENTRY {
	key: interop.Pointer | interop.Reference<any> | null;
	data: interop.Pointer | interop.Reference<any> | null;
}
declare var ENTRY: interop.StructType<ENTRY>;

declare const ENXIO: number;

declare const EOF: number;

declare const EOPNOTSUPP: number;

declare const EOVERFLOW: number;

declare const EOWNERDEAD: number;

declare const EPERM: number;

declare const EPFNOSUPPORT: number;

declare const EPIPE: number;

declare const EPROTO: number;

declare const EPROTONOSUPPORT: number;

declare const EPROTOTYPE: number;

declare const ERA: number;

declare const ERANGE: number;

declare const ERA_D_FMT: number;

declare const ERA_D_T_FMT: number;

declare const ERA_T_FMT: number;

declare const EREMCHG: number;

declare const EREMOTE: number;

declare const EREMOTEIO: number;

declare const ERESTART: number;

declare const ERFKILL: number;

declare const EROFS: number;

declare const ESHUTDOWN: number;

declare const ESOCKTNOSUPPORT: number;

declare const ESPIPE: number;

declare const ESRCH: number;

declare const ESRMNT: number;

declare const ESTALE: number;

declare const ESTRPIPE: number;

declare const ETIME: number;

declare const ETIMEDOUT: number;

declare const ETOOMANYREFS: number;

declare const ETXTBSY: number;

declare const EUCLEAN: number;

declare const EUNATCH: number;

declare const EUSERS: number;

declare const EWOULDBLOCK: number;

declare const EXDEV: number;

declare const EXEC_PAGESIZE: number;

declare const EXFULL: number;

declare const EXIT_FAILURE: number;

declare const EXIT_SUCCESS: number;

declare const EX_CANTCREAT: number;

declare const EX_CONFIG: number;

declare const EX_DATAERR: number;

declare const EX_IOERR: number;

declare const EX_NOHOST: number;

declare const EX_NOINPUT: number;

declare const EX_NOPERM: number;

declare const EX_NOUSER: number;

declare const EX_OK: number;

declare const EX_OSERR: number;

declare const EX_OSFILE: number;

declare const EX_PROTOCOL: number;

declare const EX_SOFTWARE: number;

declare const EX_TEMPFAIL: number;

declare const EX_UNAVAILABLE: number;

declare const EX_USAGE: number;

declare const EX__BASE: number;

declare const EX__MAX: number;

declare const FIFOTYPE: number;

declare const FIOASYNC: number;

declare const FIOCLEX: number;

declare const FIOGETOWN: number;

declare const FIONBIO: number;

declare const FIONCLEX: number;

declare const FIONREAD: number;

declare const FIOQSIZE: number;

declare const FIOSETOWN: number;

declare const FNM_NOESCAPE: number;

declare const FNM_NOMATCH: number;

declare const FNM_PATHNAME: number;

declare const FNM_PERIOD: number;

declare const FOPEN_MAX: number;

declare const FP_ILOGB0: number;

declare const FP_ILOGBNAN: number;

declare const FP_INFINITE: number;

declare const FP_NAN: number;

declare const FP_NORMAL: number;

declare const FP_SUBNORMAL: number;

declare const FP_ZERO: number;

declare const FTW_D: number;

declare const FTW_DNR: number;

declare const FTW_F: number;

declare const FTW_NS: number;

declare const FTW_SL: number;

declare const F_LOCK: number;

declare const F_OK: number;

declare const F_TEST: number;

declare const F_TLOCK: number;

declare const F_ULOCK: number;

declare const GLOB_ABORTED: number;

declare const GLOB_ALTDIRFUNC: number;

declare const GLOB_APPEND: number;

declare const GLOB_BRACE: number;

declare const GLOB_DOOFFS: number;

declare const GLOB_ERR: number;

declare const GLOB_MAGCHAR: number;

declare const GLOB_MARK: number;

declare const GLOB_NOCHECK: number;

declare const GLOB_NOESCAPE: number;

declare const GLOB_NOMAGIC: number;

declare const GLOB_NOMATCH: number;

declare const GLOB_NOSORT: number;

declare const GLOB_NOSPACE: number;

declare const GLOB_NOSYS: number;

declare const GLOB_ONLYDIR: number;

declare const GLOB_PERIOD: number;

declare const GLOB_TILDE: number;

declare const GLOB_TILDE_CHECK: number;

declare const GRPQUOTA: number;

declare const HOST_NOT_FOUND: number;

declare const HUGE_VAL: number;

declare const HUGE_VALF: number;

declare const HUGE_VALL: number;

declare const HZ: number;

declare const IFF_ALLMULTI: number;

declare const IFF_AUTOMEDIA: number;

declare const IFF_BROADCAST: number;

declare const IFF_DEBUG: number;

declare const IFF_DYNAMIC: number;

declare const IFF_LOOPBACK: number;

declare const IFF_MASTER: number;

declare const IFF_MULTICAST: number;

declare const IFF_NOARP: number;

declare const IFF_NOTRAILERS: number;

declare const IFF_POINTOPOINT: number;

declare const IFF_PORTSEL: number;

declare const IFF_PROMISC: number;

declare const IFF_RUNNING: number;

declare const IFF_SLAVE: number;

declare const IFF_UP: number;

declare const IFHWADDRLEN: number;

declare const IFNAMSIZ: number;

declare const IF_NAMESIZE: number;

declare const IIF_ALL: number;

declare const IIF_BGRACE: number;

declare const IIF_FLAGS: number;

declare const IIF_IGRACE: number;

declare const INADDR_ALLHOSTS_GROUP: number;

declare const INADDR_ALLRTRS_GROUP: number;

declare const INADDR_ALLSNOOPERS_GROUP: number;

declare const INADDR_ANY: number;

declare const INADDR_BROADCAST: number;

declare const INADDR_DUMMY: number;

declare const INADDR_LOOPBACK: number;

declare const INADDR_MAX_LOCAL_GROUP: number;

declare const INADDR_NONE: number;

declare const INADDR_UNSPEC_GROUP: number;

declare const INET6_ADDRSTRLEN: number;

declare const INET_ADDRSTRLEN: number;

declare const INFINITY: number;

declare const INT16_MAX: number;

declare const INT16_MIN: number;

declare const INT32_MAX: number;

declare const INT32_MIN: number;

declare const INT64_MAX: bigint;

declare const INT64_MIN: bigint;

declare const INT8_MAX: number;

declare const INT8_MIN: number;

declare const INTMAX_MAX: bigint;

declare const INTMAX_MIN: bigint;

declare const INTPTR_MAX: bigint;

declare const INTPTR_MIN: bigint;

declare const INT_FAST16_MAX: bigint;

declare const INT_FAST16_MIN: bigint;

declare const INT_FAST32_MAX: bigint;

declare const INT_FAST32_MIN: bigint;

declare const INT_FAST64_MAX: bigint;

declare const INT_FAST64_MIN: bigint;

declare const INT_FAST8_MAX: number;

declare const INT_FAST8_MIN: number;

declare const INT_LEAST16_MAX: number;

declare const INT_LEAST16_MIN: number;

declare const INT_LEAST32_MAX: number;

declare const INT_LEAST32_MIN: number;

declare const INT_LEAST64_MAX: bigint;

declare const INT_LEAST64_MIN: bigint;

declare const INT_LEAST8_MAX: number;

declare const INT_LEAST8_MIN: number;

declare const IN_CLASSA_HOST: number;

declare const IN_CLASSA_MAX: number;

declare const IN_CLASSA_NET: number;

declare const IN_CLASSA_NSHIFT: number;

declare const IN_CLASSB_HOST: number;

declare const IN_CLASSB_MAX: number;

declare const IN_CLASSB_NET: number;

declare const IN_CLASSB_NSHIFT: number;

declare const IN_CLASSC_HOST: number;

declare const IN_CLASSC_NET: number;

declare const IN_CLASSC_NSHIFT: number;

declare const IN_LOOPBACKNET: number;

declare const IOCSIZE_MASK: number;

declare const IOCSIZE_SHIFT: number;

declare const IOC_IN: number;

declare const IOC_INOUT: number;

declare const IOC_OUT: number;

declare const IPPORT_BIFFUDP: number;

declare const IPPORT_CMDSERVER: number;

declare const IPPORT_DAYTIME: number;

declare const IPPORT_DISCARD: number;

declare const IPPORT_ECHO: number;

declare const IPPORT_EFSSERVER: number;

declare const IPPORT_EXECSERVER: number;

declare const IPPORT_FINGER: number;

declare const IPPORT_FTP: number;

declare const IPPORT_LOGINSERVER: number;

declare const IPPORT_MTP: number;

declare const IPPORT_NAMESERVER: number;

declare const IPPORT_NETSTAT: number;

declare const IPPORT_RESERVED: number;

declare const IPPORT_RJE: number;

declare const IPPORT_ROUTESERVER: number;

declare const IPPORT_SMTP: number;

declare const IPPORT_SUPDUP: number;

declare const IPPORT_SYSTAT: number;

declare const IPPORT_TELNET: number;

declare const IPPORT_TFTP: number;

declare const IPPORT_TIMESERVER: number;

declare const IPPORT_TTYLINK: number;

declare const IPPORT_USERRESERVED: number;

declare const IPPORT_WHOIS: number;

declare const IPPORT_WHOSERVER: number;

declare const IPPROTO_AH: number;

declare const IPPROTO_BEETPH: number;

declare const IPPROTO_COMP: number;

declare const IPPROTO_DCCP: number;

declare const IPPROTO_DSTOPTS: number;

declare const IPPROTO_EGP: number;

declare const IPPROTO_ENCAP: number;

declare const IPPROTO_ESP: number;

declare const IPPROTO_ETHERNET: number;

declare const IPPROTO_FRAGMENT: number;

declare const IPPROTO_GRE: number;

declare const IPPROTO_HOPOPTS: number;

declare const IPPROTO_ICMP: number;

declare const IPPROTO_ICMPV6: number;

declare const IPPROTO_IDP: number;

declare const IPPROTO_IGMP: number;

declare const IPPROTO_IP: number;

declare const IPPROTO_IPIP: number;

declare const IPPROTO_IPV6: number;

declare const IPPROTO_L2TP: number;

declare const IPPROTO_MAX: number;

declare const IPPROTO_MH: number;

declare const IPPROTO_MPLS: number;

declare const IPPROTO_MPTCP: number;

declare const IPPROTO_MTP: number;

declare const IPPROTO_NONE: number;

declare const IPPROTO_PIM: number;

declare const IPPROTO_PUP: number;

declare const IPPROTO_RAW: number;

declare const IPPROTO_ROUTING: number;

declare const IPPROTO_RSVP: number;

declare const IPPROTO_SCTP: number;

declare const IPPROTO_TCP: number;

declare const IPPROTO_TP: number;

declare const IPPROTO_UDP: number;

declare const IPPROTO_UDPLITE: number;

declare const LC_ADDRESS: number;

declare const LC_ADDRESS_MASK: number;

declare const LC_ALL: number;

declare const LC_ALL_MASK: number;

declare const LC_COLLATE: number;

declare const LC_COLLATE_MASK: number;

declare const LC_CTYPE: number;

declare const LC_CTYPE_MASK: number;

declare const LC_IDENTIFICATION: number;

declare const LC_IDENTIFICATION_MASK: number;

declare const LC_MEASUREMENT: number;

declare const LC_MEASUREMENT_MASK: number;

declare const LC_MESSAGES: number;

declare const LC_MESSAGES_MASK: number;

declare const LC_MONETARY: number;

declare const LC_MONETARY_MASK: number;

declare const LC_NAME: number;

declare const LC_NAME_MASK: number;

declare const LC_NUMERIC: number;

declare const LC_NUMERIC_MASK: number;

declare const LC_PAPER: number;

declare const LC_PAPER_MASK: number;

declare const LC_TELEPHONE: number;

declare const LC_TELEPHONE_MASK: number;

declare const LC_TIME: number;

declare const LC_TIME_MASK: number;

declare const LIO_NOP: number;

declare const LIO_NOWAIT: number;

declare const LIO_READ: number;

declare const LIO_WAIT: number;

declare const LIO_WRITE: number;

declare const LITTLE_ENDIAN: number;

declare const LNKTYPE: number;

declare const LSMT_ROOT: bigint;

declare const L_INCR: number;

declare const L_SET: number;

declare const L_XTND: number;

declare const L_ctermid: number;

declare const L_tmpnam: number;

declare const MAGIC: string;

declare const MATH_ERREXCEPT: number;

declare const MATH_ERRNO: number;

declare const MAXHOSTNAMELEN: number;

declare const MAXNAMLEN: number;

declare const MAXQUOTAS: number;

declare const MAX_CANON: number;

declare const MAX_INPUT: number;

declare const MB_LEN_MAX: number;

declare const MM_APPL: number;

declare const MM_CONSOLE: number;

declare const MM_ERROR: number;

declare const MM_FIRM: number;

declare const MM_HALT: number;

declare const MM_HARD: number;

declare const MM_INFO: number;

declare const MM_NOCON: number;

declare const MM_NOMSG: number;

declare const MM_NOSEV: number;

declare const MM_NOTOK: number;

declare const MM_NRECOV: number;

declare const MM_NULLMC: number;

declare const MM_NULLSEV: number;

declare const MM_OK: number;

declare const MM_OPSYS: number;

declare const MM_PRINT: number;

declare const MM_RECOVER: number;

declare const MM_SOFT: number;

declare const MM_UTIL: number;

declare const MM_WARNING: number;

declare const MNT_ID_REQ_SIZE_VER0: number;

declare const MON_1: number;

declare const MON_10: number;

declare const MON_11: number;

declare const MON_12: number;

declare const MON_2: number;

declare const MON_3: number;

declare const MON_4: number;

declare const MON_5: number;

declare const MON_6: number;

declare const MON_7: number;

declare const MON_8: number;

declare const MON_9: number;

declare const MOVE_MOUNT__MASK: number;

declare const MS_BORN: number;

declare const MS_NOREMOTELOCK: number;

declare const MS_NOSEC: number;

declare const MS_SUBMOUNT: number;

declare const MS_VERBOSE: number;

declare const M_1_PI: number;

declare const M_2_PI: number;

declare const M_2_SQRTPI: number;

declare const M_E: number;

declare const M_LN10: number;

declare const M_LN2: number;

declare const M_LOG10E: number;

declare const M_LOG2E: number;

declare const M_PI: number;

declare const M_PI_2: number;

declare const M_PI_4: number;

declare const M_SQRT1_2: number;

declare const M_SQRT2: number;

declare const NAME_MAX: number;

declare const NAN: number;

declare const NETDB_INTERNAL: number;

declare const NETDB_SUCCESS: number;

declare const NGROUPS_MAX: number;

declare const NI_DGRAM: number;

declare const NI_MAXHOST: number;

declare const NI_MAXSERV: number;

declare const NI_NAMEREQD: number;

declare const NI_NOFQDN: number;

declare const NI_NUMERICHOST: number;

declare const NI_NUMERICSERV: number;

declare const NL_CAT_LOCALE: number;

declare const NL_SETD: number;

declare const NOEXPR: number;

declare const NOGROUP: number;

declare const NO_ADDRESS: number;

declare const NO_DATA: number;

declare const NO_RECOVERY: number;

declare const NSIG: number;

declare const NSS_BUFLEN_GROUP: number;

declare const NSS_BUFLEN_PASSWD: number;

declare const PATH_MAX: number;

declare const PDP_ENDIAN: number;

declare const PIPE_BUF: number;

declare const PM_STR: number;

declare const POSIX_SPAWN_RESETIDS: number;

declare const POSIX_SPAWN_SETPGROUP: number;

declare const POSIX_SPAWN_SETSCHEDPARAM: number;

declare const POSIX_SPAWN_SETSCHEDULER: number;

declare const POSIX_SPAWN_SETSIGDEF: number;

declare const POSIX_SPAWN_SETSIGMASK: number;

declare const PRIX16: string;

declare const PRIX32: string;

declare const PRIX64: string;

declare const PRIX8: string;

declare const PRIXFAST16: string;

declare const PRIXFAST32: string;

declare const PRIXFAST64: string;

declare const PRIXFAST8: string;

declare const PRIXLEAST16: string;

declare const PRIXLEAST32: string;

declare const PRIXLEAST64: string;

declare const PRIXLEAST8: string;

declare const PRIXMAX: string;

declare const PRIXPTR: string;

declare const PRId16: string;

declare const PRId32: string;

declare const PRId64: string;

declare const PRId8: string;

declare const PRIdFAST16: string;

declare const PRIdFAST32: string;

declare const PRIdFAST64: string;

declare const PRIdFAST8: string;

declare const PRIdLEAST16: string;

declare const PRIdLEAST32: string;

declare const PRIdLEAST64: string;

declare const PRIdLEAST8: string;

declare const PRIdMAX: string;

declare const PRIdPTR: string;

declare const PRIi16: string;

declare const PRIi32: string;

declare const PRIi64: string;

declare const PRIi8: string;

declare const PRIiFAST16: string;

declare const PRIiFAST32: string;

declare const PRIiFAST64: string;

declare const PRIiFAST8: string;

declare const PRIiLEAST16: string;

declare const PRIiLEAST32: string;

declare const PRIiLEAST64: string;

declare const PRIiLEAST8: string;

declare const PRIiMAX: string;

declare const PRIiPTR: string;

declare const PRIo16: string;

declare const PRIo32: string;

declare const PRIo64: string;

declare const PRIo8: string;

declare const PRIoFAST16: string;

declare const PRIoFAST32: string;

declare const PRIoFAST64: string;

declare const PRIoFAST8: string;

declare const PRIoLEAST16: string;

declare const PRIoLEAST32: string;

declare const PRIoLEAST64: string;

declare const PRIoLEAST8: string;

declare const PRIoMAX: string;

declare const PRIoPTR: string;

declare const PRIu16: string;

declare const PRIu32: string;

declare const PRIu64: string;

declare const PRIu8: string;

declare const PRIuFAST16: string;

declare const PRIuFAST32: string;

declare const PRIuFAST64: string;

declare const PRIuFAST8: string;

declare const PRIuLEAST16: string;

declare const PRIuLEAST32: string;

declare const PRIuLEAST64: string;

declare const PRIuLEAST8: string;

declare const PRIuMAX: string;

declare const PRIuPTR: string;

declare const PRIx16: string;

declare const PRIx32: string;

declare const PRIx64: string;

declare const PRIx8: string;

declare const PRIxFAST16: string;

declare const PRIxFAST32: string;

declare const PRIxFAST64: string;

declare const PRIxFAST8: string;

declare const PRIxLEAST16: string;

declare const PRIxLEAST32: string;

declare const PRIxLEAST64: string;

declare const PRIxLEAST8: string;

declare const PRIxMAX: string;

declare const PRIxPTR: string;

declare const PRJQUOTA: number;

declare const PTHREAD_BARRIER_SERIAL_THREAD: number;

declare const PTHREAD_CANCEL_ASYNCHRONOUS: number;

declare const PTHREAD_CANCEL_DEFERRED: number;

declare const PTHREAD_CANCEL_DISABLE: number;

declare const PTHREAD_CANCEL_ENABLE: number;

declare const PTHREAD_CREATE_DETACHED: number;

declare const PTHREAD_CREATE_JOINABLE: number;

declare const PTHREAD_EXPLICIT_SCHED: number;

declare const PTHREAD_INHERIT_SCHED: number;

declare const PTHREAD_MUTEX_ADAPTIVE_NP: number;

declare const PTHREAD_MUTEX_DEFAULT: number;

declare const PTHREAD_MUTEX_ERRORCHECK: number;

declare const PTHREAD_MUTEX_ERRORCHECK_NP: number;

declare const PTHREAD_MUTEX_NORMAL: number;

declare const PTHREAD_MUTEX_RECURSIVE: number;

declare const PTHREAD_MUTEX_RECURSIVE_NP: number;

declare const PTHREAD_MUTEX_ROBUST: number;

declare const PTHREAD_MUTEX_ROBUST_NP: number;

declare const PTHREAD_MUTEX_STALLED: number;

declare const PTHREAD_MUTEX_STALLED_NP: number;

declare const PTHREAD_MUTEX_TIMED_NP: number;

declare const PTHREAD_ONCE_INIT: number;

declare const PTHREAD_PRIO_INHERIT: number;

declare const PTHREAD_PRIO_NONE: number;

declare const PTHREAD_PRIO_PROTECT: number;

declare const PTHREAD_PROCESS_PRIVATE: number;

declare const PTHREAD_PROCESS_SHARED: number;

declare const PTHREAD_RWLOCK_DEFAULT_NP: number;

declare const PTHREAD_RWLOCK_PREFER_READER_NP: number;

declare const PTHREAD_RWLOCK_PREFER_WRITER_NONRECURSIVE_NP: number;

declare const PTHREAD_RWLOCK_PREFER_WRITER_NP: number;

declare const PTHREAD_SCOPE_PROCESS: number;

declare const PTHREAD_SCOPE_SYSTEM: number;

declare const PTRDIFF_MAX: bigint;

declare const PTRDIFF_MIN: bigint;

declare const P_tmpdir: string;

declare const QFMT_OCFS2: number;

declare const QFMT_SHMEM: number;

declare const QFMT_VFS_OLD: number;

declare const QFMT_VFS_V0: number;

declare const QFMT_VFS_V1: number;

declare const QIF_ALL: number;

declare const QIF_BLIMITS: number;

declare const QIF_BLIMITS_B: number;

declare const QIF_BTIME: number;

declare const QIF_BTIME_B: number;

declare const QIF_DQBLKSIZE: number;

declare const QIF_DQBLKSIZE_BITS: number;

declare const QIF_ILIMITS: number;

declare const QIF_ILIMITS_B: number;

declare const QIF_INODES: number;

declare const QIF_INODES_B: number;

declare const QIF_ITIME: number;

declare const QIF_ITIME_B: number;

declare const QIF_LIMITS: number;

declare const QIF_SPACE: number;

declare const QIF_SPACE_B: number;

declare const QIF_TIMES: number;

declare const QIF_USAGE: number;

declare const QUOTA_NL_A_CAUSED_ID: number;

declare const QUOTA_NL_A_DEV_MAJOR: number;

declare const QUOTA_NL_A_DEV_MINOR: number;

declare const QUOTA_NL_A_EXCESS_ID: number;

declare const QUOTA_NL_A_MAX: number;

declare const QUOTA_NL_A_PAD: number;

declare const QUOTA_NL_A_QTYPE: number;

declare const QUOTA_NL_A_UNSPEC: number;

declare const QUOTA_NL_A_WARNING: number;

declare const QUOTA_NL_BHARDBELOW: number;

declare const QUOTA_NL_BHARDWARN: number;

declare const QUOTA_NL_BSOFTBELOW: number;

declare const QUOTA_NL_BSOFTLONGWARN: number;

declare const QUOTA_NL_BSOFTWARN: number;

declare const QUOTA_NL_C_MAX: number;

declare const QUOTA_NL_C_UNSPEC: number;

declare const QUOTA_NL_C_WARNING: number;

declare const QUOTA_NL_IHARDBELOW: number;

declare const QUOTA_NL_IHARDWARN: number;

declare const QUOTA_NL_ISOFTBELOW: number;

declare const QUOTA_NL_ISOFTLONGWARN: number;

declare const QUOTA_NL_ISOFTWARN: number;

declare const QUOTA_NL_NOWARN: number;

declare const Q_GETFMT: number;

declare const Q_GETINFO: number;

declare const Q_GETNEXTQUOTA: number;

declare const Q_GETQUOTA: number;

declare const Q_QUOTAOFF: number;

declare const Q_QUOTAON: number;

declare const Q_SETINFO: number;

declare const Q_SETQUOTA: number;

declare const Q_SYNC: number;

declare const RADIXCHAR: number;

declare const RAND_MAX: number;

declare const REGTYPE: number;

declare const REG_BADBR: number;

declare const REG_BADPAT: number;

declare const REG_BADRPT: number;

declare const REG_EBRACE: number;

declare const REG_EBRACK: number;

declare const REG_ECOLLATE: number;

declare const REG_ECTYPE: number;

declare const REG_EEND: number;

declare const REG_EESCAPE: number;

declare const REG_ENOSYS: number;

declare const REG_EPAREN: number;

declare const REG_ERANGE: number;

declare const REG_ERPAREN: number;

declare const REG_ESIZE: number;

declare const REG_ESPACE: number;

declare const REG_ESUBREG: number;

declare const REG_EXTENDED: number;

declare const REG_ICASE: number;

declare const REG_NEWLINE: number;

declare const REG_NOERROR: number;

declare const REG_NOMATCH: number;

declare const REG_NOSUB: number;

declare const REG_NOTBOL: number;

declare const REG_NOTEOL: number;

declare const REG_STARTEND: number;

declare const RTSIG_MAX: number;

declare const R_OK: number;

declare const SCM_TIMESTAMP: number;

declare const SCM_TIMESTAMPING: number;

declare const SCM_TIMESTAMPING_OPT_STATS: number;

declare const SCM_TIMESTAMPING_PKTINFO: number;

declare const SCM_TIMESTAMPNS: number;

declare const SCM_TXTIME: number;

declare const SCM_WIFI_STATUS: number;

declare const SCNd16: string;

declare const SCNd32: string;

declare const SCNd64: string;

declare const SCNd8: string;

declare const SCNdFAST16: string;

declare const SCNdFAST32: string;

declare const SCNdFAST64: string;

declare const SCNdFAST8: string;

declare const SCNdLEAST16: string;

declare const SCNdLEAST32: string;

declare const SCNdLEAST64: string;

declare const SCNdLEAST8: string;

declare const SCNdMAX: string;

declare const SCNdPTR: string;

declare const SCNi16: string;

declare const SCNi32: string;

declare const SCNi64: string;

declare const SCNi8: string;

declare const SCNiFAST16: string;

declare const SCNiFAST32: string;

declare const SCNiFAST64: string;

declare const SCNiFAST8: string;

declare const SCNiLEAST16: string;

declare const SCNiLEAST32: string;

declare const SCNiLEAST64: string;

declare const SCNiLEAST8: string;

declare const SCNiMAX: string;

declare const SCNiPTR: string;

declare const SCNo16: string;

declare const SCNo32: string;

declare const SCNo64: string;

declare const SCNo8: string;

declare const SCNoFAST16: string;

declare const SCNoFAST32: string;

declare const SCNoFAST64: string;

declare const SCNoFAST8: string;

declare const SCNoLEAST16: string;

declare const SCNoLEAST32: string;

declare const SCNoLEAST64: string;

declare const SCNoLEAST8: string;

declare const SCNoMAX: string;

declare const SCNoPTR: string;

declare const SCNu16: string;

declare const SCNu32: string;

declare const SCNu64: string;

declare const SCNu8: string;

declare const SCNuFAST16: string;

declare const SCNuFAST32: string;

declare const SCNuFAST64: string;

declare const SCNuFAST8: string;

declare const SCNuLEAST16: string;

declare const SCNuLEAST32: string;

declare const SCNuLEAST64: string;

declare const SCNuLEAST8: string;

declare const SCNuMAX: string;

declare const SCNuPTR: string;

declare const SCNx16: string;

declare const SCNx32: string;

declare const SCNx64: string;

declare const SCNx8: string;

declare const SCNxFAST16: string;

declare const SCNxFAST32: string;

declare const SCNxFAST64: string;

declare const SCNxFAST8: string;

declare const SCNxLEAST16: string;

declare const SCNxLEAST32: string;

declare const SCNxLEAST64: string;

declare const SCNxLEAST8: string;

declare const SCNxMAX: string;

declare const SCNxPTR: string;

declare const SEEK_CUR: number;

declare const SEEK_END: number;

declare const SEEK_SET: number;

declare const SIG_ATOMIC_MAX: number;

declare const SIG_ATOMIC_MIN: number;

declare const SIOCATMARK: number;

declare const SIOCGPGRP: number;

declare const SIOCGSTAMPNS_OLD: number;

declare const SIOCGSTAMP_OLD: number;

declare const SIOCSPGRP: number;

declare const SIZE_MAX: bigint;

declare const SOL_SOCKET: number;

declare const SOL_TCP: number;

declare const SO_ACCEPTCONN: number;

declare const SO_ATTACH_BPF: number;

declare const SO_ATTACH_FILTER: number;

declare const SO_ATTACH_REUSEPORT_CBPF: number;

declare const SO_ATTACH_REUSEPORT_EBPF: number;

declare const SO_BINDTODEVICE: number;

declare const SO_BINDTOIFINDEX: number;

declare const SO_BPF_EXTENSIONS: number;

declare const SO_BROADCAST: number;

declare const SO_BSDCOMPAT: number;

declare const SO_BUF_LOCK: number;

declare const SO_BUSY_POLL: number;

declare const SO_BUSY_POLL_BUDGET: number;

declare const SO_CNX_ADVICE: number;

declare const SO_COOKIE: number;

declare const SO_DEBUG: number;

declare const SO_DETACH_BPF: number;

declare const SO_DETACH_FILTER: number;

declare const SO_DETACH_REUSEPORT_BPF: number;

declare const SO_DOMAIN: number;

declare const SO_DONTROUTE: number;

declare const SO_ERROR: number;

declare const SO_GET_FILTER: number;

declare const SO_INCOMING_CPU: number;

declare const SO_INCOMING_NAPI_ID: number;

declare const SO_KEEPALIVE: number;

declare const SO_LINGER: number;

declare const SO_LOCK_FILTER: number;

declare const SO_MARK: number;

declare const SO_MAX_PACING_RATE: number;

declare const SO_MEMINFO: number;

declare const SO_NETNS_COOKIE: number;

declare const SO_NOFCS: number;

declare const SO_NO_CHECK: number;

declare const SO_OOBINLINE: number;

declare const SO_PASSCRED: number;

declare const SO_PASSPIDFD: number;

declare const SO_PASSSEC: number;

declare const SO_PEEK_OFF: number;

declare const SO_PEERCRED: number;

declare const SO_PEERGROUPS: number;

declare const SO_PEERNAME: number;

declare const SO_PEERPIDFD: number;

declare const SO_PEERSEC: number;

declare const SO_PREFER_BUSY_POLL: number;

declare const SO_PRIORITY: number;

declare const SO_PROTOCOL: number;

declare const SO_RCVBUF: number;

declare const SO_RCVBUFFORCE: number;

declare const SO_RCVLOWAT: number;

declare const SO_RCVMARK: number;

declare const SO_RCVTIMEO: number;

declare const SO_RCVTIMEO_NEW: number;

declare const SO_RCVTIMEO_OLD: number;

declare const SO_RESERVE_MEM: number;

declare const SO_REUSEADDR: number;

declare const SO_REUSEPORT: number;

declare const SO_RXQ_OVFL: number;

declare const SO_SECURITY_AUTHENTICATION: number;

declare const SO_SECURITY_ENCRYPTION_NETWORK: number;

declare const SO_SECURITY_ENCRYPTION_TRANSPORT: number;

declare const SO_SELECT_ERR_QUEUE: number;

declare const SO_SNDBUF: number;

declare const SO_SNDBUFFORCE: number;

declare const SO_SNDLOWAT: number;

declare const SO_SNDTIMEO: number;

declare const SO_SNDTIMEO_NEW: number;

declare const SO_SNDTIMEO_OLD: number;

declare const SO_TIMESTAMP: number;

declare const SO_TIMESTAMPING: number;

declare const SO_TIMESTAMPING_NEW: number;

declare const SO_TIMESTAMPING_OLD: number;

declare const SO_TIMESTAMPNS: number;

declare const SO_TIMESTAMPNS_NEW: number;

declare const SO_TIMESTAMPNS_OLD: number;

declare const SO_TIMESTAMP_NEW: number;

declare const SO_TIMESTAMP_OLD: number;

declare const SO_TXREHASH: number;

declare const SO_TXTIME: number;

declare const SO_TYPE: number;

declare const SO_WIFI_STATUS: number;

declare const SO_ZEROCOPY: number;

declare const STATMOUNT_FS_TYPE: number;

declare const STATMOUNT_MNT_BASIC: number;

declare const STATMOUNT_MNT_POINT: number;

declare const STATMOUNT_MNT_ROOT: number;

declare const STATMOUNT_PROPAGATE_FROM: number;

declare const STATMOUNT_SB_BASIC: number;

declare const STDERR_FILENO: number;

declare const STDIN_FILENO: number;

declare const STDOUT_FILENO: number;

declare const SUBCMDMASK: number;

declare const SUBCMDSHIFT: number;

declare const SYMTYPE: number;

declare const TCFLSH: number;

declare const TCGETA: number;

declare const TCGETS: number;

declare const TCGETX: number;

declare const TCPI_OPT_ECN: number;

declare const TCPI_OPT_ECN_SEEN: number;

declare const TCPI_OPT_SACK: number;

declare const TCPI_OPT_SYN_DATA: number;

declare const TCPI_OPT_TIMESTAMPS: number;

declare const TCPI_OPT_WSCALE: number;

declare const TCPOLEN_MAXSEG: number;

declare const TCPOLEN_SACK_PERMITTED: number;

declare const TCPOLEN_TIMESTAMP: number;

declare const TCPOLEN_TSTAMP_APPA: number;

declare const TCPOLEN_WINDOW: number;

declare const TCPOPT_EOL: number;

declare const TCPOPT_MAXSEG: number;

declare const TCPOPT_NOP: number;

declare const TCPOPT_SACK: number;

declare const TCPOPT_SACK_PERMITTED: number;

declare const TCPOPT_TIMESTAMP: number;

declare const TCPOPT_TSTAMP_HDR: number;

declare const TCPOPT_WINDOW: number;

declare const TCP_CC_INFO: number;

declare const TCP_CLOSE: number;

declare const TCP_CLOSE_WAIT: number;

declare const TCP_CLOSING: number;

declare const TCP_CM_INQ: number;

declare const TCP_CONGESTION: number;

declare const TCP_COOKIE_IN_ALWAYS: number;

declare const TCP_COOKIE_MAX: number;

declare const TCP_COOKIE_MIN: number;

declare const TCP_COOKIE_OUT_NEVER: number;

declare const TCP_COOKIE_PAIR_SIZE: number;

declare const TCP_COOKIE_TRANSACTIONS: number;

declare const TCP_CORK: number;

declare const TCP_DEFER_ACCEPT: number;

declare const TCP_ESTABLISHED: number;

declare const TCP_FASTOPEN: number;

declare const TCP_FASTOPEN_CONNECT: number;

declare const TCP_FASTOPEN_KEY: number;

declare const TCP_FASTOPEN_NO_COOKIE: number;

declare const TCP_FIN_WAIT1: number;

declare const TCP_FIN_WAIT2: number;

declare const TCP_INFO: number;

declare const TCP_INQ: number;

declare const TCP_KEEPCNT: number;

declare const TCP_KEEPIDLE: number;

declare const TCP_KEEPINTVL: number;

declare const TCP_LAST_ACK: number;

declare const TCP_LINGER2: number;

declare const TCP_LISTEN: number;

declare const TCP_MAXSEG: number;

declare const TCP_MAXWIN: number;

declare const TCP_MAX_WINSHIFT: number;

declare const TCP_MD5SIG: number;

declare const TCP_MD5SIG_EXT: number;

declare const TCP_MD5SIG_FLAG_IFINDEX: number;

declare const TCP_MD5SIG_FLAG_PREFIX: number;

declare const TCP_MD5SIG_MAXKEYLEN: number;

declare const TCP_MSS: number;

declare const TCP_MSS_DEFAULT: number;

declare const TCP_MSS_DESIRED: number;

declare const TCP_NODELAY: number;

declare const TCP_NOTSENT_LOWAT: number;

declare const TCP_NO_QUEUE: number;

declare const TCP_QUEUES_NR: number;

declare const TCP_QUEUE_SEQ: number;

declare const TCP_QUICKACK: number;

declare const TCP_RECV_QUEUE: number;

declare const TCP_REPAIR: number;

declare const TCP_REPAIR_OFF: number;

declare const TCP_REPAIR_OFF_NO_WP: number;

declare const TCP_REPAIR_ON: number;

declare const TCP_REPAIR_OPTIONS: number;

declare const TCP_REPAIR_QUEUE: number;

declare const TCP_REPAIR_WINDOW: number;

declare const TCP_SAVED_SYN: number;

declare const TCP_SAVE_SYN: number;

declare const TCP_SEND_QUEUE: number;

declare const TCP_SYNCNT: number;

declare const TCP_SYN_RECV: number;

declare const TCP_SYN_SENT: number;

declare const TCP_S_DATA_IN: number;

declare const TCP_S_DATA_OUT: number;

declare const TCP_THIN_DUPACK: number;

declare const TCP_THIN_LINEAR_TIMEOUTS: number;

declare const TCP_TIMESTAMP: number;

declare const TCP_TIME_WAIT: number;

declare const TCP_TX_DELAY: number;

declare const TCP_ULP: number;

declare const TCP_USER_TIMEOUT: number;

declare const TCP_WINDOW_CLAMP: number;

declare const TCP_ZEROCOPY_RECEIVE: number;

declare const TCSBRK: number;

declare const TCSBRKP: number;

declare const TCSETA: number;

declare const TCSETAF: number;

declare const TCSETAW: number;

declare const TCSETS: number;

declare const TCSETSF: number;

declare const TCSETSW: number;

declare const TCSETX: number;

declare const TCSETXF: number;

declare const TCSETXW: number;

declare const TCXONC: number;

declare const TGEXEC: number;

declare const TGREAD: number;

declare const TGWRITE: number;

declare const THOUSEP: number;

declare const TH_ACK: number;

declare const TH_FIN: number;

declare const TH_PUSH: number;

declare const TH_RST: number;

declare const TH_SYN: number;

declare const TH_URG: number;

declare const TIME_UTC: number;

declare const TIOCCBRK: number;

declare const TIOCCONS: number;

declare const TIOCEXCL: number;

declare const TIOCGETD: number;

declare const TIOCGICOUNT: number;

declare const TIOCGLCKTRMIOS: number;

declare const TIOCGPGRP: number;

declare const TIOCGRS485: number;

declare const TIOCGSERIAL: number;

declare const TIOCGSID: number;

declare const TIOCGSOFTCAR: number;

declare const TIOCGWINSZ: number;

declare const TIOCINQ: number;

declare const TIOCLINUX: number;

declare const TIOCMBIC: number;

declare const TIOCMBIS: number;

declare const TIOCMGET: number;

declare const TIOCMIWAIT: number;

declare const TIOCMSET: number;

declare const TIOCNOTTY: number;

declare const TIOCNXCL: number;

declare const TIOCOUTQ: number;

declare const TIOCPKT: number;

declare const TIOCPKT_DATA: number;

declare const TIOCPKT_DOSTOP: number;

declare const TIOCPKT_FLUSHREAD: number;

declare const TIOCPKT_FLUSHWRITE: number;

declare const TIOCPKT_IOCTL: number;

declare const TIOCPKT_NOSTOP: number;

declare const TIOCPKT_START: number;

declare const TIOCPKT_STOP: number;

declare const TIOCSBRK: number;

declare const TIOCSCTTY: number;

declare const TIOCSERCONFIG: number;

declare const TIOCSERGETLSR: number;

declare const TIOCSERGETMULTI: number;

declare const TIOCSERGSTRUCT: number;

declare const TIOCSERGWILD: number;

declare const TIOCSERSETMULTI: number;

declare const TIOCSERSWILD: number;

declare const TIOCSETD: number;

declare const TIOCSLCKTRMIOS: number;

declare const TIOCSPGRP: number;

declare const TIOCSRS485: number;

declare const TIOCSSERIAL: number;

declare const TIOCSSOFTCAR: number;

declare const TIOCSTI: number;

declare const TIOCSWINSZ: number;

declare const TIOCVHANGUP: number;

declare const TMAGIC: string;

declare const TMAGLEN: number;

declare const TMP_MAX: number;

declare const TOEXEC: number;

declare const TOREAD: number;

declare const TOWRITE: number;

declare const TRY_AGAIN: number;

declare const TSGID: number;

declare const TSUID: number;

declare const TUEXEC: number;

declare const TUREAD: number;

declare const TUWRITE: number;

declare const TVERSION: string;

declare const TVERSLEN: number;

declare const T_FMT: number;

declare const T_FMT_AMPM: number;

declare const UINT16_MAX: number;

declare const UINT32_MAX: number;

declare const UINT64_MAX: bigint;

declare const UINT8_MAX: number;

declare const UINTMAX_MAX: bigint;

declare const UINTPTR_MAX: bigint;

declare const UINT_FAST16_MAX: bigint;

declare const UINT_FAST32_MAX: bigint;

declare const UINT_FAST64_MAX: bigint;

declare const UINT_FAST8_MAX: number;

declare const UINT_LEAST16_MAX: number;

declare const UINT_LEAST32_MAX: number;

declare const UINT_LEAST64_MAX: bigint;

declare const UINT_LEAST8_MAX: number;

declare const UL_GETFSIZE: number;

declare const UL_SETFSIZE: number;

declare const USRQUOTA: number;

declare const enum VISIT {

	preorder = 0,

	postorder = 1,

	endorder = 2,

	leaf = 3
}

declare const WCHAR_MAX: number;

declare const WCHAR_MIN: number;

declare const WEOF: number;

declare const WINT_MAX: number;

declare const WINT_MIN: number;

declare const WRDE_APPEND: number;

declare const WRDE_BADCHAR: number;

declare const WRDE_BADVAL: number;

declare const WRDE_CMDSUB: number;

declare const WRDE_DOOFFS: number;

declare const WRDE_NOCMD: number;

declare const WRDE_NOSPACE: number;

declare const WRDE_REUSE: number;

declare const WRDE_SHOWERR: number;

declare const WRDE_SYNTAX: number;

declare const WRDE_UNDEF: number;

declare const W_OK: number;

declare const XATTR_LIST_MAX: number;

declare const XATTR_NAME_MAX: number;

declare const XATTR_SIZE_MAX: number;

declare const X_OK: number;

declare const YESEXPR: number;

declare const _AIO_H: number;

declare const _ALLOCA_H: number;

declare const _ARPA_INET_H: number;

declare const _ATFILE_SOURCE: number;

declare const _COMPLEX_H: number;

declare const _CPIO_H: number;

declare const _CTYPE_H: number;

declare const _DATE_FMT: number;

declare const _DEFAULT_SOURCE: number;

declare const _DIRENT_H: number;

declare const _DLFCN_H: number;

declare const _ENDIAN_H: number;

interface _ENTRY {
}
declare var _ENTRY: interop.StructType<_ENTRY>;

declare const _ERRNO_H: number;

declare const _ERR_H: number;

declare function _Exit(__status: number): void;

declare const _FCNTL_H: number;

declare const _FEATURES_H: number;

declare const _FENV_H: number;

declare const _FNMATCH_H: number;

declare const _FTW_H: number;

declare const _GETOPT_H: number;

declare const _GLOB_H: number;

declare const _GRP_H: number;

declare const _ICONV_H: number;

declare const _IFADDRS_H: number;

declare const _INTTYPES_H: number;

declare const _IOC_DIRBITS: number;

declare const _IOC_DIRMASK: number;

declare const _IOC_DIRSHIFT: number;

declare const _IOC_NONE: number;

declare const _IOC_NRBITS: number;

declare const _IOC_NRMASK: number;

declare const _IOC_NRSHIFT: number;

declare const _IOC_READ: number;

declare const _IOC_SIZEBITS: number;

declare const _IOC_SIZEMASK: number;

declare const _IOC_SIZESHIFT: number;

declare const _IOC_TYPEBITS: number;

declare const _IOC_TYPEMASK: number;

declare const _IOC_TYPESHIFT: number;

declare const _IOC_WRITE: number;

declare const _IOFBF: number;

declare const _IOLBF: number;

declare const _IONBF: number;

declare const _ISalnum: number;

declare const _ISalpha: number;

declare const _ISblank: number;

declare const _IScntrl: number;

declare const _ISdigit: number;

declare const _ISgraph: number;

declare const _ISlower: number;

declare const _ISprint: number;

declare const _ISpunct: number;

declare const _ISspace: number;

declare const _ISupper: number;

declare const _ISxdigit: number;

declare const _LANGINFO_H: number;

declare const _LIBC_LIMITS_H_: number;

declare const _LIBGEN_H: number;

declare const _LOCALE_H: number;

declare const _MATH_H: number;

declare const _MONETARY_H: number;

declare const _NETDB_H: number;

declare const _NETINET_IN_H: number;

declare const _NETINET_TCP_H: number;

declare const _NET_IF_H: number;

declare const _NL_ABALTMON_1: number;

declare const _NL_ABALTMON_10: number;

declare const _NL_ABALTMON_11: number;

declare const _NL_ABALTMON_12: number;

declare const _NL_ABALTMON_2: number;

declare const _NL_ABALTMON_3: number;

declare const _NL_ABALTMON_4: number;

declare const _NL_ABALTMON_5: number;

declare const _NL_ABALTMON_6: number;

declare const _NL_ABALTMON_7: number;

declare const _NL_ABALTMON_8: number;

declare const _NL_ABALTMON_9: number;

declare const _NL_ADDRESS_CODESET: number;

declare const _NL_ADDRESS_COUNTRY_AB2: number;

declare const _NL_ADDRESS_COUNTRY_AB3: number;

declare const _NL_ADDRESS_COUNTRY_CAR: number;

declare const _NL_ADDRESS_COUNTRY_ISBN: number;

declare const _NL_ADDRESS_COUNTRY_NAME: number;

declare const _NL_ADDRESS_COUNTRY_NUM: number;

declare const _NL_ADDRESS_COUNTRY_POST: number;

declare const _NL_ADDRESS_LANG_AB: number;

declare const _NL_ADDRESS_LANG_LIB: number;

declare const _NL_ADDRESS_LANG_NAME: number;

declare const _NL_ADDRESS_LANG_TERM: number;

declare const _NL_ADDRESS_POSTAL_FMT: number;

declare const _NL_COLLATE_CODESET: number;

declare const _NL_COLLATE_COLLSEQMB: number;

declare const _NL_COLLATE_COLLSEQWC: number;

declare const _NL_COLLATE_EXTRAMB: number;

declare const _NL_COLLATE_EXTRAWC: number;

declare const _NL_COLLATE_GAP1: number;

declare const _NL_COLLATE_GAP2: number;

declare const _NL_COLLATE_GAP3: number;

declare const _NL_COLLATE_INDIRECTMB: number;

declare const _NL_COLLATE_INDIRECTWC: number;

declare const _NL_COLLATE_NRULES: number;

declare const _NL_COLLATE_RULESETS: number;

declare const _NL_COLLATE_SYMB_EXTRAMB: number;

declare const _NL_COLLATE_SYMB_HASH_SIZEMB: number;

declare const _NL_COLLATE_SYMB_TABLEMB: number;

declare const _NL_COLLATE_TABLEMB: number;

declare const _NL_COLLATE_TABLEWC: number;

declare const _NL_COLLATE_WEIGHTMB: number;

declare const _NL_COLLATE_WEIGHTWC: number;

declare const _NL_CTYPE_CLASS: number;

declare const _NL_CTYPE_CLASS32: number;

declare const _NL_CTYPE_CLASS_NAMES: number;

declare const _NL_CTYPE_CLASS_OFFSET: number;

declare const _NL_CTYPE_CODESET_NAME: number;

declare const _NL_CTYPE_EXTRA_MAP_1: number;

declare const _NL_CTYPE_EXTRA_MAP_10: number;

declare const _NL_CTYPE_EXTRA_MAP_11: number;

declare const _NL_CTYPE_EXTRA_MAP_12: number;

declare const _NL_CTYPE_EXTRA_MAP_13: number;

declare const _NL_CTYPE_EXTRA_MAP_14: number;

declare const _NL_CTYPE_EXTRA_MAP_2: number;

declare const _NL_CTYPE_EXTRA_MAP_3: number;

declare const _NL_CTYPE_EXTRA_MAP_4: number;

declare const _NL_CTYPE_EXTRA_MAP_5: number;

declare const _NL_CTYPE_EXTRA_MAP_6: number;

declare const _NL_CTYPE_EXTRA_MAP_7: number;

declare const _NL_CTYPE_EXTRA_MAP_8: number;

declare const _NL_CTYPE_EXTRA_MAP_9: number;

declare const _NL_CTYPE_GAP1: number;

declare const _NL_CTYPE_GAP2: number;

declare const _NL_CTYPE_GAP3: number;

declare const _NL_CTYPE_GAP4: number;

declare const _NL_CTYPE_GAP5: number;

declare const _NL_CTYPE_GAP6: number;

declare const _NL_CTYPE_INDIGITS0_MB: number;

declare const _NL_CTYPE_INDIGITS0_WC: number;

declare const _NL_CTYPE_INDIGITS1_MB: number;

declare const _NL_CTYPE_INDIGITS1_WC: number;

declare const _NL_CTYPE_INDIGITS2_MB: number;

declare const _NL_CTYPE_INDIGITS2_WC: number;

declare const _NL_CTYPE_INDIGITS3_MB: number;

declare const _NL_CTYPE_INDIGITS3_WC: number;

declare const _NL_CTYPE_INDIGITS4_MB: number;

declare const _NL_CTYPE_INDIGITS4_WC: number;

declare const _NL_CTYPE_INDIGITS5_MB: number;

declare const _NL_CTYPE_INDIGITS5_WC: number;

declare const _NL_CTYPE_INDIGITS6_MB: number;

declare const _NL_CTYPE_INDIGITS6_WC: number;

declare const _NL_CTYPE_INDIGITS7_MB: number;

declare const _NL_CTYPE_INDIGITS7_WC: number;

declare const _NL_CTYPE_INDIGITS8_MB: number;

declare const _NL_CTYPE_INDIGITS8_WC: number;

declare const _NL_CTYPE_INDIGITS9_MB: number;

declare const _NL_CTYPE_INDIGITS9_WC: number;

declare const _NL_CTYPE_INDIGITS_MB_LEN: number;

declare const _NL_CTYPE_INDIGITS_WC_LEN: number;

declare const _NL_CTYPE_MAP_NAMES: number;

declare const _NL_CTYPE_MAP_OFFSET: number;

declare const _NL_CTYPE_MAP_TO_NONASCII: number;

declare const _NL_CTYPE_MB_CUR_MAX: number;

declare const _NL_CTYPE_NONASCII_CASE: number;

declare const _NL_CTYPE_OUTDIGIT0_MB: number;

declare const _NL_CTYPE_OUTDIGIT0_WC: number;

declare const _NL_CTYPE_OUTDIGIT1_MB: number;

declare const _NL_CTYPE_OUTDIGIT1_WC: number;

declare const _NL_CTYPE_OUTDIGIT2_MB: number;

declare const _NL_CTYPE_OUTDIGIT2_WC: number;

declare const _NL_CTYPE_OUTDIGIT3_MB: number;

declare const _NL_CTYPE_OUTDIGIT3_WC: number;

declare const _NL_CTYPE_OUTDIGIT4_MB: number;

declare const _NL_CTYPE_OUTDIGIT4_WC: number;

declare const _NL_CTYPE_OUTDIGIT5_MB: number;

declare const _NL_CTYPE_OUTDIGIT5_WC: number;

declare const _NL_CTYPE_OUTDIGIT6_MB: number;

declare const _NL_CTYPE_OUTDIGIT6_WC: number;

declare const _NL_CTYPE_OUTDIGIT7_MB: number;

declare const _NL_CTYPE_OUTDIGIT7_WC: number;

declare const _NL_CTYPE_OUTDIGIT8_MB: number;

declare const _NL_CTYPE_OUTDIGIT8_WC: number;

declare const _NL_CTYPE_OUTDIGIT9_MB: number;

declare const _NL_CTYPE_OUTDIGIT9_WC: number;

declare const _NL_CTYPE_TOLOWER: number;

declare const _NL_CTYPE_TOLOWER32: number;

declare const _NL_CTYPE_TOUPPER: number;

declare const _NL_CTYPE_TOUPPER32: number;

declare const _NL_CTYPE_TRANSLIT_DEFAULT_MISSING: number;

declare const _NL_CTYPE_TRANSLIT_DEFAULT_MISSING_LEN: number;

declare const _NL_CTYPE_TRANSLIT_FROM_IDX: number;

declare const _NL_CTYPE_TRANSLIT_FROM_TBL: number;

declare const _NL_CTYPE_TRANSLIT_IGNORE: number;

declare const _NL_CTYPE_TRANSLIT_IGNORE_LEN: number;

declare const _NL_CTYPE_TRANSLIT_TAB_SIZE: number;

declare const _NL_CTYPE_TRANSLIT_TO_IDX: number;

declare const _NL_CTYPE_TRANSLIT_TO_TBL: number;

declare const _NL_CTYPE_WIDTH: number;

declare const _NL_IDENTIFICATION_ABBREVIATION: number;

declare const _NL_IDENTIFICATION_ADDRESS: number;

declare const _NL_IDENTIFICATION_APPLICATION: number;

declare const _NL_IDENTIFICATION_AUDIENCE: number;

declare const _NL_IDENTIFICATION_CATEGORY: number;

declare const _NL_IDENTIFICATION_CODESET: number;

declare const _NL_IDENTIFICATION_CONTACT: number;

declare const _NL_IDENTIFICATION_DATE: number;

declare const _NL_IDENTIFICATION_EMAIL: number;

declare const _NL_IDENTIFICATION_FAX: number;

declare const _NL_IDENTIFICATION_LANGUAGE: number;

declare const _NL_IDENTIFICATION_REVISION: number;

declare const _NL_IDENTIFICATION_SOURCE: number;

declare const _NL_IDENTIFICATION_TEL: number;

declare const _NL_IDENTIFICATION_TERRITORY: number;

declare const _NL_IDENTIFICATION_TITLE: number;

declare const _NL_MEASUREMENT_CODESET: number;

declare const _NL_MEASUREMENT_MEASUREMENT: number;

declare const _NL_MESSAGES_CODESET: number;

declare const _NL_MONETARY_CODESET: number;

declare const _NL_MONETARY_CONVERSION_RATE: number;

declare const _NL_MONETARY_CRNCYSTR: number;

declare const _NL_MONETARY_DECIMAL_POINT_WC: number;

declare const _NL_MONETARY_DUO_CURRENCY_SYMBOL: number;

declare const _NL_MONETARY_DUO_FRAC_DIGITS: number;

declare const _NL_MONETARY_DUO_INT_CURR_SYMBOL: number;

declare const _NL_MONETARY_DUO_INT_FRAC_DIGITS: number;

declare const _NL_MONETARY_DUO_INT_N_CS_PRECEDES: number;

declare const _NL_MONETARY_DUO_INT_N_SEP_BY_SPACE: number;

declare const _NL_MONETARY_DUO_INT_N_SIGN_POSN: number;

declare const _NL_MONETARY_DUO_INT_P_CS_PRECEDES: number;

declare const _NL_MONETARY_DUO_INT_P_SEP_BY_SPACE: number;

declare const _NL_MONETARY_DUO_INT_P_SIGN_POSN: number;

declare const _NL_MONETARY_DUO_N_CS_PRECEDES: number;

declare const _NL_MONETARY_DUO_N_SEP_BY_SPACE: number;

declare const _NL_MONETARY_DUO_N_SIGN_POSN: number;

declare const _NL_MONETARY_DUO_P_CS_PRECEDES: number;

declare const _NL_MONETARY_DUO_P_SEP_BY_SPACE: number;

declare const _NL_MONETARY_DUO_P_SIGN_POSN: number;

declare const _NL_MONETARY_DUO_VALID_FROM: number;

declare const _NL_MONETARY_DUO_VALID_TO: number;

declare const _NL_MONETARY_THOUSANDS_SEP_WC: number;

declare const _NL_MONETARY_UNO_VALID_FROM: number;

declare const _NL_MONETARY_UNO_VALID_TO: number;

declare const _NL_NAME_CODESET: number;

declare const _NL_NAME_NAME_FMT: number;

declare const _NL_NAME_NAME_GEN: number;

declare const _NL_NAME_NAME_MISS: number;

declare const _NL_NAME_NAME_MR: number;

declare const _NL_NAME_NAME_MRS: number;

declare const _NL_NAME_NAME_MS: number;

declare const _NL_NUM: number;

declare const _NL_NUMERIC_CODESET: number;

declare const _NL_NUMERIC_DECIMAL_POINT_WC: number;

declare const _NL_NUMERIC_THOUSANDS_SEP_WC: number;

declare const _NL_NUM_LC_ADDRESS: number;

declare const _NL_NUM_LC_COLLATE: number;

declare const _NL_NUM_LC_CTYPE: number;

declare const _NL_NUM_LC_IDENTIFICATION: number;

declare const _NL_NUM_LC_MEASUREMENT: number;

declare const _NL_NUM_LC_MESSAGES: number;

declare const _NL_NUM_LC_MONETARY: number;

declare const _NL_NUM_LC_NAME: number;

declare const _NL_NUM_LC_NUMERIC: number;

declare const _NL_NUM_LC_PAPER: number;

declare const _NL_NUM_LC_TELEPHONE: number;

declare const _NL_NUM_LC_TIME: number;

declare const _NL_PAPER_CODESET: number;

declare const _NL_PAPER_HEIGHT: number;

declare const _NL_PAPER_WIDTH: number;

declare const _NL_TELEPHONE_CODESET: number;

declare const _NL_TELEPHONE_INT_PREFIX: number;

declare const _NL_TELEPHONE_INT_SELECT: number;

declare const _NL_TELEPHONE_TEL_DOM_FMT: number;

declare const _NL_TELEPHONE_TEL_INT_FMT: number;

declare const _NL_TIME_CAL_DIRECTION: number;

declare const _NL_TIME_CODESET: number;

declare const _NL_TIME_ERA_ENTRIES: number;

declare const _NL_TIME_ERA_NUM_ENTRIES: number;

declare const _NL_TIME_FIRST_WEEKDAY: number;

declare const _NL_TIME_FIRST_WORKDAY: number;

declare const _NL_TIME_TIMEZONE: number;

declare const _NL_TIME_WEEK_1STDAY: number;

declare const _NL_TIME_WEEK_1STWEEK: number;

declare const _NL_TIME_WEEK_NDAYS: number;

declare const _NL_TYPES_H: number;

declare const _NL_WABALTMON_1: number;

declare const _NL_WABALTMON_10: number;

declare const _NL_WABALTMON_11: number;

declare const _NL_WABALTMON_12: number;

declare const _NL_WABALTMON_2: number;

declare const _NL_WABALTMON_3: number;

declare const _NL_WABALTMON_4: number;

declare const _NL_WABALTMON_5: number;

declare const _NL_WABALTMON_6: number;

declare const _NL_WABALTMON_7: number;

declare const _NL_WABALTMON_8: number;

declare const _NL_WABALTMON_9: number;

declare const _NL_WABDAY_1: number;

declare const _NL_WABDAY_2: number;

declare const _NL_WABDAY_3: number;

declare const _NL_WABDAY_4: number;

declare const _NL_WABDAY_5: number;

declare const _NL_WABDAY_6: number;

declare const _NL_WABDAY_7: number;

declare const _NL_WABMON_1: number;

declare const _NL_WABMON_10: number;

declare const _NL_WABMON_11: number;

declare const _NL_WABMON_12: number;

declare const _NL_WABMON_2: number;

declare const _NL_WABMON_3: number;

declare const _NL_WABMON_4: number;

declare const _NL_WABMON_5: number;

declare const _NL_WABMON_6: number;

declare const _NL_WABMON_7: number;

declare const _NL_WABMON_8: number;

declare const _NL_WABMON_9: number;

declare const _NL_WALTMON_1: number;

declare const _NL_WALTMON_10: number;

declare const _NL_WALTMON_11: number;

declare const _NL_WALTMON_12: number;

declare const _NL_WALTMON_2: number;

declare const _NL_WALTMON_3: number;

declare const _NL_WALTMON_4: number;

declare const _NL_WALTMON_5: number;

declare const _NL_WALTMON_6: number;

declare const _NL_WALTMON_7: number;

declare const _NL_WALTMON_8: number;

declare const _NL_WALTMON_9: number;

declare const _NL_WALT_DIGITS: number;

declare const _NL_WAM_STR: number;

declare const _NL_WDAY_1: number;

declare const _NL_WDAY_2: number;

declare const _NL_WDAY_3: number;

declare const _NL_WDAY_4: number;

declare const _NL_WDAY_5: number;

declare const _NL_WDAY_6: number;

declare const _NL_WDAY_7: number;

declare const _NL_WD_FMT: number;

declare const _NL_WD_T_FMT: number;

declare const _NL_WERA_D_FMT: number;

declare const _NL_WERA_D_T_FMT: number;

declare const _NL_WERA_T_FMT: number;

declare const _NL_WERA_YEAR: number;

declare const _NL_WMON_1: number;

declare const _NL_WMON_10: number;

declare const _NL_WMON_11: number;

declare const _NL_WMON_12: number;

declare const _NL_WMON_2: number;

declare const _NL_WMON_3: number;

declare const _NL_WMON_4: number;

declare const _NL_WMON_5: number;

declare const _NL_WMON_6: number;

declare const _NL_WMON_7: number;

declare const _NL_WMON_8: number;

declare const _NL_WMON_9: number;

declare const _NL_WPM_STR: number;

declare const _NL_WT_FMT: number;

declare const _NL_WT_FMT_AMPM: number;

declare const _NL_W_DATE_FMT: number;

declare const _PATH_HEQUIV: string;

declare const _PATH_HOSTS: string;

declare const _PATH_NETWORKS: string;

declare const _PATH_NSSWITCH_CONF: string;

declare const _PATH_PROTOCOLS: string;

declare const _PATH_SERVICES: string;

declare const _POSIX2_C_BIND: number;

declare const _POSIX2_C_DEV: number;

declare const _POSIX2_C_VERSION: number;

declare const _POSIX2_LOCALEDEF: number;

declare const _POSIX2_SW_DEV: number;

declare const _POSIX2_VERSION: number;

declare const _POSIX_C_SOURCE: number;

declare const _POSIX_SOURCE: number;

declare const _POSIX_VERSION: number;

declare const _PTHREAD_H: number;

declare const _PWD_H: number;

declare const _REGEX_H: number;

declare const _RPC_NETDB_H: number;

declare const _SCHED_H: number;

declare const _SEARCH_H: number;

declare const _SEMAPHORE_H: number;

declare const _SETJMP_H: number;

declare const _SPAWN_H: number;

declare const _STDC_PREDEF_H: number;

declare const _STDINT_H: number;

declare const _STDIO_H: number;

declare const _STDLIB_H: number;

declare const _STRINGS_H: number;

declare const _STRING_H: number;

declare const _SYSEXITS_H: number;

declare const _TAR_H: number;

declare const _TERMIOS_H: number;

declare const _TIME_H: number;

declare const _ULIMIT_H: number;

declare const _UNISTD_H: number;

declare const _UTIME_H: number;

declare const _UTMPX_H: number;

declare const _WCHAR_H: number;

declare const _WCTYPE_H: number;

declare const _WORDEXP_H: number;

declare const _XOPEN_ENH_I18N: number;

declare const _XOPEN_LEGACY: number;

declare const _XOPEN_UNIX: number;

declare const _XOPEN_VERSION: number;

declare const _XOPEN_XCU_VERSION: number;

declare const _XOPEN_XPG2: number;

declare const _XOPEN_XPG3: number;

declare const _XOPEN_XPG4: number;

declare const __ALTMON_1: number;

declare const __ALTMON_10: number;

declare const __ALTMON_11: number;

declare const __ALTMON_12: number;

declare const __ALTMON_2: number;

declare const __ALTMON_3: number;

declare const __ALTMON_4: number;

declare const __ALTMON_5: number;

declare const __ALTMON_6: number;

declare const __ALTMON_7: number;

declare const __ALTMON_8: number;

declare const __ALTMON_9: number;

declare const __CURRENCY_SYMBOL: number;

declare const __DECIMAL_POINT: number;

declare const __ERA_YEAR: number;

declare const __FRAC_DIGITS: number;

declare const __GROUPING: number;

declare const __INT_CURR_SYMBOL: number;

declare const __INT_FRAC_DIGITS: number;

declare const __INT_N_CS_PRECEDES: number;

declare const __INT_N_SEP_BY_SPACE: number;

declare const __INT_N_SIGN_POSN: number;

declare const __INT_P_CS_PRECEDES: number;

declare const __INT_P_SEP_BY_SPACE: number;

declare const __INT_P_SIGN_POSN: number;

declare const __MON_DECIMAL_POINT: number;

declare const __MON_GROUPING: number;

declare const __MON_THOUSANDS_SEP: number;

declare const __NEGATIVE_SIGN: number;

declare const __NOEXPR: number;

declare const __NOSTR: number;

declare const __N_CS_PRECEDES: number;

declare const __N_SEP_BY_SPACE: number;

declare const __N_SIGN_POSN: number;

declare const __POSITIVE_SIGN: number;

declare const __P_CS_PRECEDES: number;

declare const __P_SEP_BY_SPACE: number;

declare const __P_SIGN_POSN: number;

declare const __QUOTA_NL_A_MAX: number;

declare const __QUOTA_NL_C_MAX: number;

declare const __THOUSANDS_SEP: number;

declare const __UL_GETMAXBRK: number;

declare const __UL_GETOPENMAX: number;

declare const __WRDE_FLAGS: number;

declare const __YESEXPR: number;

declare const __YESSTR: number;

declare function __asprintf(__ptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __fmt: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

interface __cancel_jmp_buf_tag {
	__cancel_jmp_buf: interop.Reference<number>;
	__mask_was_saved: number;
}
declare var __cancel_jmp_buf_tag: interop.StructType<__cancel_jmp_buf_tag>;

declare function __ctype_b_loc(): interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | null;

declare function __ctype_get_mb_cur_max(): number;

declare function __ctype_tolower_loc(): interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | null;

declare function __ctype_toupper_loc(): interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | null;

declare var __daylight: number;

declare var __environ: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;

declare function __errno_location(): interop.Pointer | interop.Reference<number> | null;

declare function __getdelim(__lineptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __n: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __delimiter: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __getpgid(__pid: number): number;

declare function __h_errno_location(): interop.Pointer | interop.Reference<number> | null;

interface __kernel_fd_set {
	fds_bits: interop.Reference<number>;
}
declare var __kernel_fd_set: interop.StructType<__kernel_fd_set>;

interface __kernel_fsid_t {
	val: interop.Reference<number>;
}
declare var __kernel_fsid_t: interop.StructType<__kernel_fsid_t>;

declare function __libc_current_sigrtmax(): number;

declare function __libc_current_sigrtmin(): number;

declare function __mbrlen(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number, __ps: interop.Pointer | interop.Reference<__mbstate_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __memcmpeq(__s1: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function __mempcpy(__dest: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): interop.Pointer | interop.Reference<any> | null;

declare function __overflow(p1: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

interface __pthread_cleanup_frame {
	__cancel_routine: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>;
	__cancel_arg: interop.Pointer | interop.Reference<any> | null;
	__do_it: number;
	__cancel_type: number;
}
declare var __pthread_cleanup_frame: interop.StructType<__pthread_cleanup_frame>;

declare function __pthread_register_cancel(__buf: interop.Pointer | interop.Reference<__pthread_unwind_buf_t> | ArrayBufferLike | ArrayBufferView | null): void;

declare function __pthread_unregister_cancel(__buf: interop.Pointer | interop.Reference<__pthread_unwind_buf_t> | ArrayBufferLike | ArrayBufferView | null): void;

interface __pthread_unwind_buf_t {
	__cancel_jmp_buf: interop.Reference<__cancel_jmp_buf_tag>;
	__pad: interop.Reference<interop.Pointer | interop.Reference<any> | null>;
}
declare var __pthread_unwind_buf_t: interop.StructType<__pthread_unwind_buf_t>;

declare function __pthread_unwind_next(__buf: interop.Pointer | interop.Reference<__pthread_unwind_buf_t> | ArrayBufferLike | ArrayBufferView | null): void;

declare function __sigsetjmp(__env: interop.Reference<__jmp_buf_tag>, __savemask: number): number;

declare function __sigsetjmpFunction(__env: interop.Reference<__jmp_buf_tag>, __savemask: number): number;

interface __spawn_action {
}
declare var __spawn_action: interop.StructType<__spawn_action>;

declare function __stpcpy(__dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function __stpncpy(__dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): interop.Pointer | interop.Reference<any> | null;

declare function __strtok_r(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __delim: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __save_ptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function __sysv_signal(__sig: number, __handler: interop.FunctionReference<(p1: number) => void>): interop.FunctionReference<(p1: number) => void>;

declare var __timezone: number;

declare function __tolower_l(__c: number, __l: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __toupper_l(__c: number, __l: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare var __tzname: interop.Reference<interop.Pointer | interop.Reference<any> | null>;

declare function __uflow(p1: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __xpg_basename(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function _exit(__status: number): void;

declare function _longjmp(__env: interop.Reference<__jmp_buf_tag>, __val: number): void;

interface _pthread_cleanup_buffer {
	__routine: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>;
	__arg: interop.Pointer | interop.Reference<any> | null;
	__canceltype: number;
	__prev: interop.Pointer | interop.Reference<_pthread_cleanup_buffer> | null;
}
declare var _pthread_cleanup_buffer: interop.StructType<_pthread_cleanup_buffer>;

declare function _setjmp(__env: interop.Reference<__jmp_buf_tag>): number;

declare function _tolower(p1: number): number;

declare function _toupper(p1: number): number;

declare function a64l(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function abort(): void;

declare function abs(__x: number): number;

declare function access(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __type: number): number;

declare function acct(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

interface addrinfo {
	ai_flags: number;
	ai_family: number;
	ai_socktype: number;
	ai_protocol: number;
	ai_addrlen: number;
	ai_addr: interop.Pointer | interop.Reference<sockaddr> | null;
	ai_canonname: interop.Pointer | interop.Reference<any> | null;
	ai_next: interop.Pointer | interop.Reference<addrinfo> | null;
}
declare var addrinfo: interop.StructType<addrinfo>;

declare function addseverity(__severity: number, __string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function aio_cancel(__fildes: number, __aiocbp: interop.Pointer | interop.Reference<aiocb> | ArrayBufferLike | ArrayBufferView | null): number;

declare function aio_error(__aiocbp: interop.Pointer | interop.Reference<aiocb> | ArrayBufferLike | ArrayBufferView | null): number;

declare function aio_fsync(__operation: number, __aiocbp: interop.Pointer | interop.Reference<aiocb> | ArrayBufferLike | ArrayBufferView | null): number;

declare function aio_read(__aiocbp: interop.Pointer | interop.Reference<aiocb> | ArrayBufferLike | ArrayBufferView | null): number;

declare function aio_return(__aiocbp: interop.Pointer | interop.Reference<aiocb> | ArrayBufferLike | ArrayBufferView | null): number;

declare function aio_suspend(__list: interop.Reference<interop.Pointer | interop.Reference<aiocb> | null>, __nent: number, __timeout: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function aio_write(__aiocbp: interop.Pointer | interop.Reference<aiocb> | ArrayBufferLike | ArrayBufferView | null): number;

interface aiocb {
	aio_fildes: number;
	aio_lio_opcode: number;
	aio_reqprio: number;
	aio_buf: interop.Pointer | interop.Reference<any> | null;
	aio_nbytes: number;
	aio_sigevent: sigevent_t;
	__next_prio: interop.Pointer | interop.Reference<aiocb> | null;
	__abs_prio: number;
	__policy: number;
	__error_code: number;
	__return_value: number;
	aio_offset: number;
	__pad: interop.Reference<number>;
	__glibc_reserved: interop.Reference<number>;
}
declare var aiocb: interop.StructType<aiocb>;

declare function alarm(__seconds: number): number;

declare function aligned_alloc(__alignment: number, __size: number): interop.Pointer | interop.Reference<any> | null;

declare function alloca(__size: number): interop.Pointer | interop.Reference<any> | null;

declare function alphasort(__e1: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<dirent> | null> | ArrayBufferLike | ArrayBufferView | null, __e2: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<dirent> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function arc4random(): number;

declare function arc4random_buf(__buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number): void;

declare function arc4random_uniform(__upper_bound: number): number;

declare function asctime(__tp: interop.Pointer | interop.Reference<tm> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function asctime_r(__tp: interop.Pointer | interop.Reference<tm> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function asprintf(__ptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __fmt: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function at_quick_exit(__func: interop.FunctionReference<() => void>): number;

declare function atexit(__func: interop.FunctionReference<() => void>): number;

declare function atof(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function atoi(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function atol(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function atoll(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function bcmp(__s1: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function bcopy(__src: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __dest: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): void;

declare function bindresvport(__sockfd: number, __sock_in: interop.Pointer | interop.Reference<sockaddr_in> | ArrayBufferLike | ArrayBufferView | null): number;

declare function bindresvport6(__sockfd: number, __sock_in: interop.Pointer | interop.Reference<sockaddr_in6> | ArrayBufferLike | ArrayBufferView | null): number;

declare function brk(__addr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function bsearch(__key: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __base: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __nmemb: number, __size: number, __compar: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null) => number>): interop.Pointer | interop.Reference<any> | null;

declare function btowc(__c: number): number;

declare function bzero(__s: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): void;

declare function calloc(__nmemb: number, __size: number): interop.Pointer | interop.Reference<any> | null;

declare function catclose(__catalog: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function catgets(__catalog: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __set: number, __number: number, __string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function catopen(__cat_name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __flag: number): interop.Pointer | interop.Reference<any> | null;

declare function cfgetispeed(__termios_p: interop.Pointer | interop.Reference<termios> | ArrayBufferLike | ArrayBufferView | null): number;

declare function cfgetospeed(__termios_p: interop.Pointer | interop.Reference<termios> | ArrayBufferLike | ArrayBufferView | null): number;

declare function cfmakeraw(__termios_p: interop.Pointer | interop.Reference<termios> | ArrayBufferLike | ArrayBufferView | null): void;

declare function cfsetispeed(__termios_p: interop.Pointer | interop.Reference<termios> | ArrayBufferLike | ArrayBufferView | null, __speed: number): number;

declare function cfsetospeed(__termios_p: interop.Pointer | interop.Reference<termios> | ArrayBufferLike | ArrayBufferView | null, __speed: number): number;

declare function cfsetspeed(__termios_p: interop.Pointer | interop.Reference<termios> | ArrayBufferLike | ArrayBufferView | null, __speed: number): number;

declare function chdir(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function chown(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __owner: number, __group: number): number;

declare function chroot(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function clearenv(): number;

declare function clearerr(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): void;

declare function clearerr_unlocked(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): void;

declare function clock(): number;

declare function clock_getcpuclockid(__pid: number, __clock_id: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function clock_getres(__clock_id: number, __res: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function clock_gettime(__clock_id: number, __tp: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function clock_nanosleep(__clock_id: number, __flags: number, __req: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null, __rem: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function clock_settime(__clock_id: number, __tp: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function close(__fd: number): number;

declare function closedir(__dirp: interop.Pointer | interop.Reference<DIR> | ArrayBufferLike | ArrayBufferView | null): number;

declare function closefrom(__lowfd: number): void;

declare function confstr(__name: number, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function creat(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __mode: number): number;

declare function crypt(__key: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __salt: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function ctermid(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function ctime(__timer: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function ctime_r(__timer: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function daemon(__nochdir: number, __noclose: number): number;

declare var daylight: number;

declare function difftime(__time1: number, __time0: number): number;

declare function dirfd(__dirp: interop.Pointer | interop.Reference<DIR> | ArrayBufferLike | ArrayBufferView | null): number;

declare function dirname(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function div(__numer: number, __denom: number): div_t;

interface div_t {
	quot: number;
	rem: number;
}
declare var div_t: interop.StructType<div_t>;

declare function dlclose(__handle: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function dlerror(): interop.Pointer | interop.Reference<any> | null;

declare function dlopen(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __mode: number): interop.Pointer | interop.Reference<any> | null;

declare function dlsym(__handle: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function dprintf(__fd: number, __fmt: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function drand48(): number;

interface drand48_data {
	__x: interop.Reference<number>;
	__old_x: interop.Reference<number>;
	__c: number;
	__init: number;
	__a: number;
}
declare var drand48_data: interop.StructType<drand48_data>;

declare function drand48_r(__buffer: interop.Pointer | interop.Reference<drand48_data> | ArrayBufferLike | ArrayBufferView | null, __result: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function dup(__fd: number): number;

declare function dup2(__fd: number, __fd2: number): number;

declare function duplocale(__dataset: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<__locale_struct> | null;

declare function dysize(__year: number): number;

declare function ecvt(__value: number, __ndigit: number, __decpt: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __sign: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function ecvt_r(__value: number, __ndigit: number, __decpt: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __sign: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function endgrent(): void;

declare function endhostent(): void;

declare function endnetent(): void;

declare function endnetgrent(): void;

declare function endprotoent(): void;

declare function endpwent(): void;

declare function endrpcent(): void;

declare function endservent(): void;

declare function endusershell(): void;

declare function endutxent(): void;

declare function erand48(__xsubi: interop.Reference<number>): number;

declare function erand48_r(__xsubi: interop.Reference<number>, __buffer: interop.Pointer | interop.Reference<drand48_data> | ArrayBufferLike | ArrayBufferView | null, __result: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function err(__status: number, __format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): void;

declare function errx(__status: number, __format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): void;

declare function execl(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __arg: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function execle(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __arg: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function execlp(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __arg: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function execv(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __argv: interop.Reference<interop.Pointer | interop.Reference<any> | null>): number;

declare function execve(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __argv: interop.Reference<interop.Pointer | interop.Reference<any> | null>, __envp: interop.Reference<interop.Pointer | interop.Reference<any> | null>): number;

declare function execvp(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __argv: interop.Reference<interop.Pointer | interop.Reference<any> | null>): number;

declare function exit(__status: number): void;

declare function explicit_bzero(__s: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): void;

declare function faccessat(__fd: number, __file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __type: number, __flag: number): number;

declare function fchdir(__fd: number): number;

declare function fchown(__fd: number, __owner: number, __group: number): number;

declare function fchownat(__fd: number, __file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __owner: number, __group: number, __flag: number): number;

declare function fclose(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fcntl(__fd: number, __cmd: number, ...args: any[]): number;

declare function fcvt(__value: number, __ndigit: number, __decpt: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __sign: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function fcvt_r(__value: number, __ndigit: number, __decpt: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __sign: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function fdatasync(__fildes: number): number;

declare function fdopen(__fd: number, __modes: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FILE> | null;

declare function fdopendir(__fd: number): interop.Pointer | interop.Reference<DIR> | null;

declare function feclearexcept(__excepts: number): number;

declare function fegetenv(__envp: interop.Pointer | interop.Reference<fenv_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fegetexceptflag(__flagp: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __excepts: number): number;

declare function fegetround(): number;

declare function feholdexcept(__envp: interop.Pointer | interop.Reference<fenv_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function feof(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function feof_unlocked(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function feraiseexcept(__excepts: number): number;

declare function ferror(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ferror_unlocked(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fesetenv(__envp: interop.Pointer | interop.Reference<fenv_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fesetexceptflag(__flagp: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __excepts: number): number;

declare function fesetround(__rounding_direction: number): number;

declare function fetestexcept(__excepts: number): number;

declare function feupdateenv(__envp: interop.Pointer | interop.Reference<fenv_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fexecve(__fd: number, __argv: interop.Reference<interop.Pointer | interop.Reference<any> | null>, __envp: interop.Reference<interop.Pointer | interop.Reference<any> | null>): number;

declare function fflush(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fflush_unlocked(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ffs(__i: number): number;

declare function ffsl(__l: number): number;

declare function ffsll(__ll: number): number;

declare function fgetc(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fgetc_unlocked(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fgetgrent(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<group> | null;

declare function fgetgrent_r(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __resultbuf: interop.Pointer | interop.Reference<group> | ArrayBufferLike | ArrayBufferView | null, __buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<group> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fgetpos(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __pos: interop.Pointer | interop.Reference<__fpos_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fgetpwent(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<passwd> | null;

declare function fgetpwent_r(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __resultbuf: interop.Pointer | interop.Reference<passwd> | ArrayBufferLike | ArrayBufferView | null, __buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<passwd> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fgets(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function fgetwc(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fgetws(__ws: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function fileno(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fileno_unlocked(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function flockfile(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): void;

declare function fmemopen(__s: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number, __modes: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FILE> | null;

declare function fmtmsg(__classification: number, __label: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __severity: number, __text: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __action: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __tag: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fnmatch(__pattern: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __flags: number): number;

declare function fopen(__filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __modes: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FILE> | null;

declare function fopencookie(__magic_cookie: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __modes: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __io_funcs: cookie_io_functions_t): interop.Pointer | interop.Reference<FILE> | null;

declare function fork(): number;

declare function fpathconf(__fd: number, __name: number): number;

declare function fprintf(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function fputc(__c: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fputc_unlocked(__c: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fputs(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fputwc(__wc: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fputws(__ws: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fread(__ptr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number, __n: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fread_unlocked(__ptr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number, __n: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function free(__ptr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function freeaddrinfo(__ai: interop.Pointer | interop.Reference<addrinfo> | ArrayBufferLike | ArrayBufferView | null): void;

declare function freeifaddrs(__ifa: interop.Pointer | interop.Reference<ifaddrs> | ArrayBufferLike | ArrayBufferView | null): void;

declare function freelocale(__dataset: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): void;

declare function freopen(__filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __modes: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FILE> | null;

declare function fscanf(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function fscanfFunction(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare const enum fsconfig_command {

	SET_FLAG = 0,

	SET_STRING = 1,

	SET_BINARY = 2,

	SET_PATH = 3,

	SET_PATH_EMPTY = 4,

	SET_FD = 5,

	CMD_CREATE = 6,

	CMD_RECONFIGURE = 7,

	CMD_CREATE_EXCL = 8
}

declare function fseek(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __off: number, __whence: number): number;

declare function fseeko(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __off: number, __whence: number): number;

declare function fsetpos(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __pos: interop.Pointer | interop.Reference<__fpos_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fsync(__fd: number): number;

declare function ftell(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ftello(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ftruncate(__fd: number, __length: number): number;

declare function ftrylockfile(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ftw(__dir: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __func: interop.FunctionReference<(p1: string | null, p2: interop.Pointer | interop.Reference<statStruct> | null, p3: number) => number>, __descriptors: number): number;

declare function funlockfile(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): void;

declare function fwide(__fp: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __mode: number): number;

declare function fwprintf(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __format: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function fwrite(__ptr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number, __n: number, __s: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fwrite_unlocked(__ptr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number, __n: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fwscanf(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __format: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function fwscanfFunction(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __format: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function gai_strerror(__ecode: number): string | null;

declare function gcvt(__value: number, __ndigit: number, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function getaddrinfo(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __service: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __req: interop.Pointer | interop.Reference<addrinfo> | ArrayBufferLike | ArrayBufferView | null, __pai: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<addrinfo> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getc(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getc_unlocked(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getchar(): number;

declare function getchar_unlocked(): number;

declare function getcwd(__buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number): interop.Pointer | interop.Reference<any> | null;

declare function getdelim(__lineptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __n: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __delimiter: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getdirentries(__fd: number, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __nbytes: number, __basep: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getdomainname(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function getdtablesize(): number;

declare function getegid(): number;

declare function getentropy(__buffer: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __length: number): number;

declare function getenv(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function geteuid(): number;

declare function getgid(): number;

declare function getgrent(): interop.Pointer | interop.Reference<group> | null;

declare function getgrgid(__gid: number): interop.Pointer | interop.Reference<group> | null;

declare function getgrgid_r(__gid: number, __resultbuf: interop.Pointer | interop.Reference<group> | ArrayBufferLike | ArrayBufferView | null, __buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<group> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getgrnam(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<group> | null;

declare function getgrnam_r(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __resultbuf: interop.Pointer | interop.Reference<group> | ArrayBufferLike | ArrayBufferView | null, __buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<group> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getgrouplist(__user: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __group: number, __groups: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __ngroups: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getgroups(__size: number, __list: interop.Reference<number>): number;

declare function gethostbyaddr(__addr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number, __type: number): interop.Pointer | interop.Reference<hostent> | null;

declare function gethostbyaddr_r(__addr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number, __type: number, __result_buf: interop.Pointer | interop.Reference<hostent> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<hostent> | null> | ArrayBufferLike | ArrayBufferView | null, __h_errnop: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gethostbyname(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<hostent> | null;

declare function gethostbyname2(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __af: number): interop.Pointer | interop.Reference<hostent> | null;

declare function gethostbyname2_r(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __af: number, __result_buf: interop.Pointer | interop.Reference<hostent> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<hostent> | null> | ArrayBufferLike | ArrayBufferView | null, __h_errnop: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gethostbyname_r(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __result_buf: interop.Pointer | interop.Reference<hostent> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<hostent> | null> | ArrayBufferLike | ArrayBufferView | null, __h_errnop: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gethostent(): interop.Pointer | interop.Reference<hostent> | null;

declare function gethostent_r(__result_buf: interop.Pointer | interop.Reference<hostent> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<hostent> | null> | ArrayBufferLike | ArrayBufferView | null, __h_errnop: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gethostid(): number;

declare function gethostname(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function getifaddrs(__ifap: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<ifaddrs> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getline(__lineptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __n: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getloadavg(__loadavg: interop.Reference<number>, __nelem: number): number;

declare function getlogin(): interop.Pointer | interop.Reference<any> | null;

declare function getlogin_r(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __name_len: number): number;

declare function getnameinfo(__sa: interop.Pointer | interop.Reference<sockaddr> | ArrayBufferLike | ArrayBufferView | null, __salen: number, __host: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __hostlen: number, __serv: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __servlen: number, __flags: number): number;

declare function getnetbyaddr(__net: number, __type: number): interop.Pointer | interop.Reference<netent> | null;

declare function getnetbyaddr_r(__net: number, __type: number, __result_buf: interop.Pointer | interop.Reference<netent> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<netent> | null> | ArrayBufferLike | ArrayBufferView | null, __h_errnop: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getnetbyname(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<netent> | null;

declare function getnetbyname_r(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __result_buf: interop.Pointer | interop.Reference<netent> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<netent> | null> | ArrayBufferLike | ArrayBufferView | null, __h_errnop: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getnetent(): interop.Pointer | interop.Reference<netent> | null;

declare function getnetent_r(__result_buf: interop.Pointer | interop.Reference<netent> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<netent> | null> | ArrayBufferLike | ArrayBufferView | null, __h_errnop: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getnetgrent(__hostp: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __userp: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __domainp: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getnetgrent_r(__hostp: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __userp: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __domainp: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number): number;

declare function getpagesize(): number;

declare function getpass(__prompt: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function getpgid(__pid: number): number;

declare function getpgrp(): number;

declare function getpid(): number;

declare function getppid(): number;

declare function getprotobyname(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<protoent> | null;

declare function getprotobyname_r(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __result_buf: interop.Pointer | interop.Reference<protoent> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<protoent> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getprotobynumber(__proto: number): interop.Pointer | interop.Reference<protoent> | null;

declare function getprotobynumber_r(__proto: number, __result_buf: interop.Pointer | interop.Reference<protoent> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<protoent> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getprotoent(): interop.Pointer | interop.Reference<protoent> | null;

declare function getprotoent_r(__result_buf: interop.Pointer | interop.Reference<protoent> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<protoent> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getpwent(): interop.Pointer | interop.Reference<passwd> | null;

declare function getpwent_r(__resultbuf: interop.Pointer | interop.Reference<passwd> | ArrayBufferLike | ArrayBufferView | null, __buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<passwd> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getpwnam(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<passwd> | null;

declare function getpwnam_r(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __resultbuf: interop.Pointer | interop.Reference<passwd> | ArrayBufferLike | ArrayBufferView | null, __buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<passwd> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getpwuid(__uid: number): interop.Pointer | interop.Reference<passwd> | null;

declare function getpwuid_r(__uid: number, __resultbuf: interop.Pointer | interop.Reference<passwd> | ArrayBufferLike | ArrayBufferView | null, __buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<passwd> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getrpcbyname(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<rpcent> | null;

declare function getrpcbyname_r(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __result_buf: interop.Pointer | interop.Reference<rpcent> | ArrayBufferLike | ArrayBufferView | null, __buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<rpcent> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getrpcbynumber(__number: number): interop.Pointer | interop.Reference<rpcent> | null;

declare function getrpcbynumber_r(__number: number, __result_buf: interop.Pointer | interop.Reference<rpcent> | ArrayBufferLike | ArrayBufferView | null, __buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<rpcent> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getrpcent(): interop.Pointer | interop.Reference<rpcent> | null;

declare function getrpcent_r(__result_buf: interop.Pointer | interop.Reference<rpcent> | ArrayBufferLike | ArrayBufferView | null, __buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<rpcent> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getservbyname(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __proto: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<servent> | null;

declare function getservbyname_r(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __proto: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __result_buf: interop.Pointer | interop.Reference<servent> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<servent> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getservbyport(__port: number, __proto: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<servent> | null;

declare function getservbyport_r(__port: number, __proto: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __result_buf: interop.Pointer | interop.Reference<servent> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<servent> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getservent(): interop.Pointer | interop.Reference<servent> | null;

declare function getservent_r(__result_buf: interop.Pointer | interop.Reference<servent> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<servent> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getsid(__pid: number): number;

declare function getsubopt(__optionp: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __tokens: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __valuep: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getuid(): number;

declare function getusershell(): interop.Pointer | interop.Reference<any> | null;

declare function getutxent(): interop.Pointer | interop.Reference<utmpx> | null;

declare function getutxid(__id: interop.Pointer | interop.Reference<utmpx> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<utmpx> | null;

declare function getutxline(__line: interop.Pointer | interop.Reference<utmpx> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<utmpx> | null;

declare function getw(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getwc(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getwchar(): number;

declare function getwd(__buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function glob(__pattern: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __flags: number, __errfunc: interop.FunctionReference<(p1: string | null, p2: number) => number>, __pglob: interop.Pointer | interop.Reference<glob_t> | ArrayBufferLike | ArrayBufferView | null): number;

interface glob_t {
	gl_pathc: number;
	gl_pathv: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;
	gl_offs: number;
	gl_flags: number;
	gl_closedir: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>;
	gl_readdir: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => interop.Pointer | interop.Reference<any> | null>;
	gl_opendir: interop.FunctionReference<(p1: string | null) => interop.Pointer | interop.Reference<any> | null>;
	gl_lstat: interop.FunctionReference<(p1: string | null, p2: interop.Pointer | interop.Reference<any> | null) => number>;
	gl_stat: interop.FunctionReference<(p1: string | null, p2: interop.Pointer | interop.Reference<any> | null) => number>;
}
declare var glob_t: interop.StructType<glob_t>;

declare function globfree(__pglob: interop.Pointer | interop.Reference<glob_t> | ArrayBufferLike | ArrayBufferView | null): void;

declare function gmtime(__timer: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<tm> | null;

declare function gmtime_r(__timer: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __tp: interop.Pointer | interop.Reference<tm> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<tm> | null;

interface group {
	gr_name: interop.Pointer | interop.Reference<any> | null;
	gr_passwd: interop.Pointer | interop.Reference<any> | null;
	gr_gid: number;
	gr_mem: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;
}
declare var group: interop.StructType<group>;

interface group_filter {
	gf_interface: number;
	gf_group: sockaddr_storage;
	gf_fmode: number;
	gf_numsrc: number;
	gf_slist: interop.Reference<sockaddr_storage>;
}
declare var group_filter: interop.StructType<group_filter>;

interface group_req {
	gr_interface: number;
	gr_group: sockaddr_storage;
}
declare var group_req: interop.StructType<group_req>;

interface group_source_req {
	gsr_interface: number;
	gsr_group: sockaddr_storage;
	gsr_source: sockaddr_storage;
}
declare var group_source_req: interop.StructType<group_source_req>;

declare function gsignal(__sig: number): number;

declare function hcreate(__nel: number): number;

declare function hdestroy(): void;

declare function herror(__str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

interface hostent {
	h_name: interop.Pointer | interop.Reference<any> | null;
	h_aliases: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;
	h_addrtype: number;
	h_length: number;
	h_addr_list: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;
}
declare var hostent: interop.StructType<hostent>;

declare function hsearch(__item: ENTRY, __action: ACTION): interop.Pointer | interop.Reference<ENTRY> | null;

declare function hstrerror(__err_num: number): string | null;

declare function htonl(__hostlong: number): number;

declare function htons(__hostshort: number): number;

declare function iconv(__cd: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __inbuf: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __inbytesleft: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __outbuf: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __outbytesleft: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iconv_close(__cd: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iconv_open(__tocode: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __fromcode: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

interface if_dqblk {
	dqb_bhardlimit: number;
	dqb_bsoftlimit: number;
	dqb_curspace: number;
	dqb_ihardlimit: number;
	dqb_isoftlimit: number;
	dqb_curinodes: number;
	dqb_btime: number;
	dqb_itime: number;
	dqb_valid: number;
}
declare var if_dqblk: interop.StructType<if_dqblk>;

interface if_dqinfo {
	dqi_bgrace: number;
	dqi_igrace: number;
	dqi_flags: number;
	dqi_valid: number;
}
declare var if_dqinfo: interop.StructType<if_dqinfo>;

declare function if_freenameindex(__ptr: interop.Pointer | interop.Reference<if_nameindexStruct> | ArrayBufferLike | ArrayBufferView | null): void;

declare function if_indextoname(__ifindex: number, __ifname: interop.Reference<number>): interop.Pointer | interop.Reference<any> | null;

declare function if_nameindex(): interop.Pointer | interop.Reference<if_nameindexStruct> | null;

interface if_nameindexStruct {
	if_index: number;
	if_name: interop.Pointer | interop.Reference<any> | null;
}
declare var if_nameindexStruct: interop.StructType<if_nameindexStruct>;

declare function if_nametoindex(__ifname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

interface if_nextdqblk {
	dqb_bhardlimit: number;
	dqb_bsoftlimit: number;
	dqb_curspace: number;
	dqb_ihardlimit: number;
	dqb_isoftlimit: number;
	dqb_curinodes: number;
	dqb_btime: number;
	dqb_itime: number;
	dqb_valid: number;
	dqb_id: number;
}
declare var if_nextdqblk: interop.StructType<if_nextdqblk>;

interface iface {
}
declare var iface: interop.StructType<iface>;

interface ifaddr {
	ifa_addr: sockaddr;
	ifa_ifu: { ifu_broadaddr: sockaddr; ifu_dstaddr: sockaddr; };
	ifa_ifp: interop.Pointer | interop.Reference<iface> | null;
	ifa_next: interop.Pointer | interop.Reference<ifaddr> | null;
}
declare var ifaddr: interop.StructType<ifaddr>;

interface ifaddrs {
	ifa_next: interop.Pointer | interop.Reference<ifaddrs> | null;
	ifa_name: interop.Pointer | interop.Reference<any> | null;
	ifa_flags: number;
	ifa_addr: interop.Pointer | interop.Reference<sockaddr> | null;
	ifa_netmask: interop.Pointer | interop.Reference<sockaddr> | null;
	ifa_ifu: { ifu_broadaddr: interop.Pointer | interop.Reference<sockaddr> | null; ifu_dstaddr: interop.Pointer | interop.Reference<sockaddr> | null; };
	ifa_data: interop.Pointer | interop.Reference<any> | null;
}
declare var ifaddrs: interop.StructType<ifaddrs>;

interface ifconf {
	ifc_len: number;
	ifc_ifcu: { ifcu_buf: interop.Pointer | interop.Reference<any> | null; ifcu_req: interop.Pointer | interop.Reference<ifreq> | null; };
}
declare var ifconf: interop.StructType<ifconf>;

interface ifmap {
	mem_start: number;
	mem_end: number;
	base_addr: number;
	irq: number;
	dma: number;
	port: number;
}
declare var ifmap: interop.StructType<ifmap>;

interface ifreq {
	ifr_ifrn: { ifrn_name: interop.Reference<number>; };
	ifr_ifru: { ifru_addr: sockaddr; ifru_dstaddr: sockaddr; ifru_broadaddr: sockaddr; ifru_netmask: sockaddr; ifru_hwaddr: sockaddr; ifru_flags: number; ifru_ivalue: number; ifru_mtu: number; ifru_map: ifmap; ifru_slave: interop.Reference<number>; ifru_newname: interop.Reference<number>; ifru_data: interop.Pointer | interop.Reference<any> | null; };
}
declare var ifreq: interop.StructType<ifreq>;

declare function imaxabs(__n: number): number;

declare function imaxdiv(__numer: number, __denom: number): imaxdiv_t;

interface imaxdiv_t {
	quot: number;
	rem: number;
}
declare var imaxdiv_t: interop.StructType<imaxdiv_t>;

interface in6_addr {
	__in6_u: { __u6_addr8: interop.Reference<number>; __u6_addr16: interop.Reference<number>; __u6_addr32: interop.Reference<number>; };
}
declare var in6_addr: interop.StructType<in6_addr>;

declare var in6addr_any: in6_addr;

declare var in6addr_loopback: in6_addr;

interface in_addr {
	s_addr: number;
}
declare var in_addr: interop.StructType<in_addr>;

declare function index(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __c: number): interop.Pointer | interop.Reference<any> | null;

declare function inet_addr(__cp: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inet_aton(__cp: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __inp: interop.Pointer | interop.Reference<in_addr> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inet_lnaof(__in: in_addr): number;

declare function inet_makeaddr(__net: number, __host: number): in_addr;

declare function inet_net_ntop(__af: number, __cp: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __bits: number, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): interop.Pointer | interop.Reference<any> | null;

declare function inet_net_pton(__af: number, __cp: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function inet_neta(__net: number, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): interop.Pointer | interop.Reference<any> | null;

declare function inet_netof(__in: in_addr): number;

declare function inet_network(__cp: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function inet_nsap_addr(__cp: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function inet_nsap_ntoa(__len: number, __cp: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function inet_ntoa(__in: in_addr): interop.Pointer | interop.Reference<any> | null;

declare function inet_ntop(__af: number, __cp: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): string | null;

declare function inet_pton(__af: number, __cp: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function initgroups(__user: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __group: number): number;

declare function initstate(__seed: number, __statebuf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __statelen: number): interop.Pointer | interop.Reference<any> | null;

declare function initstate_r(__seed: number, __statebuf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __statelen: number, __buf: interop.Pointer | interop.Reference<random_data> | ArrayBufferLike | ArrayBufferView | null): number;

declare function innetgr(__netgroup: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __host: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __user: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __domain: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function insque(__elem: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __prev: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

interface ip_mreq {
	imr_multiaddr: in_addr;
	imr_interface: in_addr;
}
declare var ip_mreq: interop.StructType<ip_mreq>;

interface ip_mreq_source {
	imr_multiaddr: in_addr;
	imr_interface: in_addr;
	imr_sourceaddr: in_addr;
}
declare var ip_mreq_source: interop.StructType<ip_mreq_source>;

interface ip_mreqn {
	imr_multiaddr: in_addr;
	imr_address: in_addr;
	imr_ifindex: number;
}
declare var ip_mreqn: interop.StructType<ip_mreqn>;

interface ip_msfilter {
	imsf_multiaddr: in_addr;
	imsf_interface: in_addr;
	imsf_fmode: number;
	imsf_numsrc: number;
	imsf_slist: interop.Reference<in_addr>;
}
declare var ip_msfilter: interop.StructType<ip_msfilter>;

interface ipv6_mreq {
	ipv6mr_multiaddr: in6_addr;
	ipv6mr_interface: number;
}
declare var ipv6_mreq: interop.StructType<ipv6_mreq>;

declare function iruserok(__raddr: number, __suser: number, __remuser: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __locuser: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iruserok_af(__raddr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __suser: number, __remuser: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __locuser: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __af: number): number;

declare function isalnum(p1: number): number;

declare function isalnum_l(p1: number, p2: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function isalpha(p1: number): number;

declare function isalpha_l(p1: number, p2: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function isascii(__c: number): number;

declare function isatty(__fd: number): number;

declare function isblank(p1: number): number;

declare function isblank_l(p1: number, p2: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iscntrl(p1: number): number;

declare function iscntrl_l(p1: number, p2: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function isdigit(p1: number): number;

declare function isdigit_l(p1: number, p2: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function isgraph(p1: number): number;

declare function isgraph_l(p1: number, p2: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function islower(p1: number): number;

declare function islower_l(p1: number, p2: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function isprint(p1: number): number;

declare function isprint_l(p1: number, p2: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ispunct(p1: number): number;

declare function ispunct_l(p1: number, p2: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function isspace(p1: number): number;

declare function isspace_l(p1: number, p2: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function isupper(p1: number): number;

declare function isupper_l(p1: number, p2: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iswalnum_l(__wc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iswalpha_l(__wc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iswblank_l(__wc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iswcntrl_l(__wc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iswctype_l(__wc: number, __desc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iswdigit_l(__wc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iswgraph_l(__wc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iswlower_l(__wc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iswprint_l(__wc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iswpunct_l(__wc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iswspace_l(__wc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iswupper_l(__wc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function iswxdigit_l(__wc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function isxdigit(p1: number): number;

declare function isxdigit_l(p1: number, p2: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function jrand48(__xsubi: interop.Reference<number>): number;

declare function jrand48_r(__xsubi: interop.Reference<number>, __buffer: interop.Pointer | interop.Reference<drand48_data> | ArrayBufferLike | ArrayBufferView | null, __result: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function kill(__pid: number, __sig: number): number;

declare function killpg(__pgrp: number, __sig: number): number;

declare function l64a(__n: number): interop.Pointer | interop.Reference<any> | null;

declare function labs(__x: number): number;

declare function lchown(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __owner: number, __group: number): number;

declare function lcong48(__param: interop.Reference<number>): void;

declare function lcong48_r(__param: interop.Reference<number>, __buffer: interop.Pointer | interop.Reference<drand48_data> | ArrayBufferLike | ArrayBufferView | null): number;

interface lconv {
	decimal_point: interop.Pointer | interop.Reference<any> | null;
	thousands_sep: interop.Pointer | interop.Reference<any> | null;
	grouping: interop.Pointer | interop.Reference<any> | null;
	int_curr_symbol: interop.Pointer | interop.Reference<any> | null;
	currency_symbol: interop.Pointer | interop.Reference<any> | null;
	mon_decimal_point: interop.Pointer | interop.Reference<any> | null;
	mon_thousands_sep: interop.Pointer | interop.Reference<any> | null;
	mon_grouping: interop.Pointer | interop.Reference<any> | null;
	positive_sign: interop.Pointer | interop.Reference<any> | null;
	negative_sign: interop.Pointer | interop.Reference<any> | null;
	int_frac_digits: number;
	frac_digits: number;
	p_cs_precedes: number;
	p_sep_by_space: number;
	n_cs_precedes: number;
	n_sep_by_space: number;
	p_sign_posn: number;
	n_sign_posn: number;
	int_p_cs_precedes: number;
	int_p_sep_by_space: number;
	int_n_cs_precedes: number;
	int_n_sep_by_space: number;
	int_p_sign_posn: number;
	int_n_sign_posn: number;
}
declare var lconv: interop.StructType<lconv>;

declare function ldiv(__numer: number, __denom: number): ldiv_t;

interface ldiv_t {
	quot: number;
	rem: number;
}
declare var ldiv_t: interop.StructType<ldiv_t>;

declare function lfind(__key: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __base: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __nmemb: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __size: number, __compar: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null) => number>): interop.Pointer | interop.Reference<any> | null;

declare function link(__from: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __to: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function linkat(__fromfd: number, __from: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __tofd: number, __to: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __flags: number): number;

declare function lio_listio(__mode: number, __list: interop.Reference<interop.Pointer | interop.Reference<aiocb> | null>, __nent: number, __sig: interop.Pointer | interop.Reference<sigevent_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function llabs(__x: number): number;

declare function lldiv(__numer: number, __denom: number): lldiv_t;

interface lldiv_t {
	quot: number;
	rem: number;
}
declare var lldiv_t: interop.StructType<lldiv_t>;

declare function localeconv(): interop.Pointer | interop.Reference<lconv> | null;

declare function localtime(__timer: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<tm> | null;

declare function localtime_r(__timer: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __tp: interop.Pointer | interop.Reference<tm> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<tm> | null;

declare function lockf(__fd: number, __cmd: number, __len: number): number;

declare function longjmp(__env: interop.Reference<__jmp_buf_tag>, __val: number): void;

declare function lrand48(): number;

declare function lrand48_r(__buffer: interop.Pointer | interop.Reference<drand48_data> | ArrayBufferLike | ArrayBufferView | null, __result: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function lsearch(__key: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __base: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __nmemb: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __size: number, __compar: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null) => number>): interop.Pointer | interop.Reference<any> | null;

declare function lseek(__fd: number, __offset: number, __whence: number): number;

declare function malloc(__size: number): interop.Pointer | interop.Reference<any> | null;

declare const math_errhandling: number;

declare function mblen(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function mbrlen(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number, __ps: interop.Pointer | interop.Reference<__mbstate_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function mbrtowc(__pwc: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number, __p: interop.Pointer | interop.Reference<__mbstate_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function mbsinit(__ps: interop.Pointer | interop.Reference<__mbstate_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function mbsnrtowcs(__dst: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null, __nmc: number, __len: number, __ps: interop.Pointer | interop.Reference<__mbstate_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function mbsrtowcs(__dst: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null, __len: number, __ps: interop.Pointer | interop.Reference<__mbstate_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function mbstowcs(__pwcs: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function mbtowc(__pwc: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function memccpy(__dest: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __c: number, __n: number): interop.Pointer | interop.Reference<any> | null;

declare function memchr(__s: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __c: number, __n: number): interop.Pointer | interop.Reference<any> | null;

declare function memcmp(__s1: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function memcpy(__dest: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): interop.Pointer | interop.Reference<any> | null;

declare function memmem(__haystack: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __haystacklen: number, __needle: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __needlelen: number): interop.Pointer | interop.Reference<any> | null;

declare function memmove(__dest: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): interop.Pointer | interop.Reference<any> | null;

declare function mempcpy(__dest: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): interop.Pointer | interop.Reference<any> | null;

declare function memset(__s: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __c: number, __n: number): interop.Pointer | interop.Reference<any> | null;

declare function mkdtemp(__template: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function mkstemp(__template: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function mkstemps(__template: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __suffixlen: number): number;

declare function mktemp(__template: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function mktime(__tp: interop.Pointer | interop.Reference<tm> | ArrayBufferLike | ArrayBufferView | null): number;

interface mnt_id_req {
	size: number;
	spare: number;
	mnt_id: number;
	param: number;
}
declare var mnt_id_req: interop.StructType<mnt_id_req>;

interface mount_attr {
	attr_set: number;
	attr_clr: number;
	propagation: number;
	userns_fd: number;
}
declare var mount_attr: interop.StructType<mount_attr>;

declare function mrand48(): number;

declare function mrand48_r(__buffer: interop.Pointer | interop.Reference<drand48_data> | ArrayBufferLike | ArrayBufferView | null, __result: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function nanosleep(__requested_time: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null, __remaining: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function newlocale(__category_mask: number, __locale: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __base: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<__locale_struct> | null;

declare function nice(__inc: number): number;

declare function nl_langinfo(__item: number): interop.Pointer | interop.Reference<any> | null;

declare function nl_langinfo_l(__item: number, __l: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function nrand48(__xsubi: interop.Reference<number>): number;

declare function nrand48_r(__xsubi: interop.Reference<number>, __buffer: interop.Pointer | interop.Reference<drand48_data> | ArrayBufferLike | ArrayBufferView | null, __result: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ntohl(__netlong: number): number;

declare function ntohs(__netshort: number): number;

declare function on_exit(__func: interop.FunctionReference<(p1: number, p2: interop.Pointer | interop.Reference<any> | null) => void>, __arg: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function open(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __oflag: number, ...args: any[]): number;

declare function open_memstream(__bufloc: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __sizeloc: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FILE> | null;

declare function open_wmemstream(__bufloc: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, __sizeloc: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FILE> | null;

declare function openat(__fd: number, __file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __oflag: number, ...args: any[]): number;

declare function opendir(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<DIR> | null;

interface passwd {
	pw_name: interop.Pointer | interop.Reference<any> | null;
	pw_passwd: interop.Pointer | interop.Reference<any> | null;
	pw_uid: number;
	pw_gid: number;
	pw_gecos: interop.Pointer | interop.Reference<any> | null;
	pw_dir: interop.Pointer | interop.Reference<any> | null;
	pw_shell: interop.Pointer | interop.Reference<any> | null;
}
declare var passwd: interop.StructType<passwd>;

declare function pathconf(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __name: number): number;

declare function pause(): number;

declare function pclose(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function perror(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function pipe(__pipedes: interop.Reference<number>): number;

declare function popen(__command: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __modes: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FILE> | null;

declare function posix_fadvise(__fd: number, __offset: number, __len: number, __advise: number): number;

declare function posix_fallocate(__fd: number, __offset: number, __len: number): number;

declare function posix_memalign(__memptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __alignment: number, __size: number): number;

declare function posix_spawn(__pid: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __file_actions: interop.Pointer | interop.Reference<posix_spawn_file_actions_t> | ArrayBufferLike | ArrayBufferView | null, __attrp: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __argv: interop.Reference<interop.Pointer | interop.Reference<any> | null>, __envp: interop.Reference<interop.Pointer | interop.Reference<any> | null>): number;

declare function posix_spawn_file_actions_addchdir_np(__actions: interop.Pointer | interop.Reference<posix_spawn_file_actions_t> | ArrayBufferLike | ArrayBufferView | null, __path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function posix_spawn_file_actions_addclose(__file_actions: interop.Pointer | interop.Reference<posix_spawn_file_actions_t> | ArrayBufferLike | ArrayBufferView | null, __fd: number): number;

declare function posix_spawn_file_actions_addclosefrom_np(p1: interop.Pointer | interop.Reference<posix_spawn_file_actions_t> | ArrayBufferLike | ArrayBufferView | null, __from: number): number;

declare function posix_spawn_file_actions_adddup2(__file_actions: interop.Pointer | interop.Reference<posix_spawn_file_actions_t> | ArrayBufferLike | ArrayBufferView | null, __fd: number, __newfd: number): number;

declare function posix_spawn_file_actions_addfchdir_np(p1: interop.Pointer | interop.Reference<posix_spawn_file_actions_t> | ArrayBufferLike | ArrayBufferView | null, __fd: number): number;

declare function posix_spawn_file_actions_addopen(__file_actions: interop.Pointer | interop.Reference<posix_spawn_file_actions_t> | ArrayBufferLike | ArrayBufferView | null, __fd: number, __path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __oflag: number, __mode: number): number;

declare function posix_spawn_file_actions_addtcsetpgrp_np(p1: interop.Pointer | interop.Reference<posix_spawn_file_actions_t> | ArrayBufferLike | ArrayBufferView | null, __tcfd: number): number;

declare function posix_spawn_file_actions_destroy(__file_actions: interop.Pointer | interop.Reference<posix_spawn_file_actions_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function posix_spawn_file_actions_init(__file_actions: interop.Pointer | interop.Reference<posix_spawn_file_actions_t> | ArrayBufferLike | ArrayBufferView | null): number;

interface posix_spawn_file_actions_t {
	__allocated: number;
	__used: number;
	__actions: interop.Pointer | interop.Reference<__spawn_action> | null;
	__pad: interop.Reference<number>;
}
declare var posix_spawn_file_actions_t: interop.StructType<posix_spawn_file_actions_t>;

declare function posix_spawnattr_destroy(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function posix_spawnattr_getflags(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __flags: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function posix_spawnattr_getpgroup(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __pgroup: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function posix_spawnattr_getschedparam(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __schedparam: interop.Pointer | interop.Reference<sched_param> | ArrayBufferLike | ArrayBufferView | null): number;

declare function posix_spawnattr_getschedpolicy(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __schedpolicy: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function posix_spawnattr_getsigdefault(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __sigdefault: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function posix_spawnattr_getsigmask(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __sigmask: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function posix_spawnattr_init(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function posix_spawnattr_setflags(_attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __flags: number): number;

declare function posix_spawnattr_setpgroup(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __pgroup: number): number;

declare function posix_spawnattr_setschedparam(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __schedparam: interop.Pointer | interop.Reference<sched_param> | ArrayBufferLike | ArrayBufferView | null): number;

declare function posix_spawnattr_setschedpolicy(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __schedpolicy: number): number;

declare function posix_spawnattr_setsigdefault(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __sigdefault: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function posix_spawnattr_setsigmask(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __sigmask: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null): number;

interface posix_spawnattr_t {
	__flags: number;
	__pgrp: number;
	__sd: __sigset_t;
	__ss: __sigset_t;
	__sp: sched_param;
	__policy: number;
	__cgroup: number;
	__pad: interop.Reference<number>;
}
declare var posix_spawnattr_t: interop.StructType<posix_spawnattr_t>;

declare function posix_spawnp(__pid: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __file_actions: interop.Pointer | interop.Reference<posix_spawn_file_actions_t> | ArrayBufferLike | ArrayBufferView | null, __attrp: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __argv: interop.Reference<interop.Pointer | interop.Reference<any> | null>, __envp: interop.Reference<interop.Pointer | interop.Reference<any> | null>): number;

declare function pread(__fd: number, __buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __nbytes: number, __offset: number): number;

declare function printf(__format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function profil(__sample_buffer: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __size: number, __offset: number, __scale: number): number;

interface protoent {
	p_name: interop.Pointer | interop.Reference<any> | null;
	p_aliases: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;
	p_proto: number;
}
declare var protoent: interop.StructType<protoent>;

declare function psiginfo(__pinfo: interop.Pointer | interop.Reference<siginfo_t> | ArrayBufferLike | ArrayBufferView | null, __s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function psignal(__sig: number, __s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function pthread_atfork(__prepare: interop.FunctionReference<() => void>, __parent: interop.FunctionReference<() => void>, __child: interop.FunctionReference<() => void>): number;

declare function pthread_attr_destroy(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_attr_getdetachstate(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __detachstate: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_attr_getguardsize(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __guardsize: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_attr_getinheritsched(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __inherit: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_attr_getschedparam(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __param: interop.Pointer | interop.Reference<sched_param> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_attr_getschedpolicy(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __policy: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_attr_getscope(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __scope: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_attr_getstack(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __stackaddr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __stacksize: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_attr_getstackaddr(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __stackaddr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_attr_getstacksize(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __stacksize: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_attr_init(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_attr_setdetachstate(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __detachstate: number): number;

declare function pthread_attr_setguardsize(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __guardsize: number): number;

declare function pthread_attr_setinheritsched(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __inherit: number): number;

declare function pthread_attr_setschedparam(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __param: interop.Pointer | interop.Reference<sched_param> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_attr_setschedpolicy(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __policy: number): number;

declare function pthread_attr_setscope(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __scope: number): number;

declare function pthread_attr_setstack(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __stackaddr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __stacksize: number): number;

declare function pthread_attr_setstackaddr(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __stackaddr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_attr_setstacksize(__attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __stacksize: number): number;

declare function pthread_barrier_destroy(__barrier: interop.Pointer | interop.Reference<pthread_barrier_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_barrier_init(__barrier: interop.Pointer | interop.Reference<pthread_barrier_t> | ArrayBufferLike | ArrayBufferView | null, __attr: interop.Pointer | interop.Reference<pthread_barrierattr_t> | ArrayBufferLike | ArrayBufferView | null, __count: number): number;

declare function pthread_barrier_wait(__barrier: interop.Pointer | interop.Reference<pthread_barrier_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_barrierattr_destroy(__attr: interop.Pointer | interop.Reference<pthread_barrierattr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_barrierattr_getpshared(__attr: interop.Pointer | interop.Reference<pthread_barrierattr_t> | ArrayBufferLike | ArrayBufferView | null, __pshared: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_barrierattr_init(__attr: interop.Pointer | interop.Reference<pthread_barrierattr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_barrierattr_setpshared(__attr: interop.Pointer | interop.Reference<pthread_barrierattr_t> | ArrayBufferLike | ArrayBufferView | null, __pshared: number): number;

declare function pthread_cancel(__th: number): number;

declare function pthread_cond_broadcast(__cond: interop.Pointer | interop.Reference<pthread_cond_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_cond_destroy(__cond: interop.Pointer | interop.Reference<pthread_cond_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_cond_init(__cond: interop.Pointer | interop.Reference<pthread_cond_t> | ArrayBufferLike | ArrayBufferView | null, __cond_attr: interop.Pointer | interop.Reference<pthread_condattr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_cond_signal(__cond: interop.Pointer | interop.Reference<pthread_cond_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_cond_timedwait(__cond: interop.Pointer | interop.Reference<pthread_cond_t> | ArrayBufferLike | ArrayBufferView | null, __mutex: interop.Pointer | interop.Reference<pthread_mutex_t> | ArrayBufferLike | ArrayBufferView | null, __abstime: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_cond_wait(__cond: interop.Pointer | interop.Reference<pthread_cond_t> | ArrayBufferLike | ArrayBufferView | null, __mutex: interop.Pointer | interop.Reference<pthread_mutex_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_condattr_destroy(__attr: interop.Pointer | interop.Reference<pthread_condattr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_condattr_getclock(__attr: interop.Pointer | interop.Reference<pthread_condattr_t> | ArrayBufferLike | ArrayBufferView | null, __clock_id: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_condattr_getpshared(__attr: interop.Pointer | interop.Reference<pthread_condattr_t> | ArrayBufferLike | ArrayBufferView | null, __pshared: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_condattr_init(__attr: interop.Pointer | interop.Reference<pthread_condattr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_condattr_setclock(__attr: interop.Pointer | interop.Reference<pthread_condattr_t> | ArrayBufferLike | ArrayBufferView | null, __clock_id: number): number;

declare function pthread_condattr_setpshared(__attr: interop.Pointer | interop.Reference<pthread_condattr_t> | ArrayBufferLike | ArrayBufferView | null, __pshared: number): number;

declare function pthread_create(__newthread: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __attr: interop.Pointer | interop.Reference<pthread_attr_t> | ArrayBufferLike | ArrayBufferView | null, __start_routine: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => interop.Pointer | interop.Reference<any> | null>, __arg: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_detach(__th: number): number;

declare function pthread_equal(__thread1: number, __thread2: number): number;

declare function pthread_exit(__retval: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function pthread_getcpuclockid(__thread_id: number, __clock_id: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_getschedparam(__target_thread: number, __policy: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __param: interop.Pointer | interop.Reference<sched_param> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_getspecific(__key: number): interop.Pointer | interop.Reference<any> | null;

declare function pthread_join(__th: number, __thread_return: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_key_create(__key: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __destr_function: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>): number;

declare function pthread_key_delete(__key: number): number;

declare function pthread_mutex_consistent(__mutex: interop.Pointer | interop.Reference<pthread_mutex_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutex_destroy(__mutex: interop.Pointer | interop.Reference<pthread_mutex_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutex_getprioceiling(__mutex: interop.Pointer | interop.Reference<pthread_mutex_t> | ArrayBufferLike | ArrayBufferView | null, __prioceiling: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutex_init(__mutex: interop.Pointer | interop.Reference<pthread_mutex_t> | ArrayBufferLike | ArrayBufferView | null, __mutexattr: interop.Pointer | interop.Reference<pthread_mutexattr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutex_lock(__mutex: interop.Pointer | interop.Reference<pthread_mutex_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutex_setprioceiling(__mutex: interop.Pointer | interop.Reference<pthread_mutex_t> | ArrayBufferLike | ArrayBufferView | null, __prioceiling: number, __old_ceiling: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutex_timedlock(__mutex: interop.Pointer | interop.Reference<pthread_mutex_t> | ArrayBufferLike | ArrayBufferView | null, __abstime: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutex_trylock(__mutex: interop.Pointer | interop.Reference<pthread_mutex_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutex_unlock(__mutex: interop.Pointer | interop.Reference<pthread_mutex_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutexattr_destroy(__attr: interop.Pointer | interop.Reference<pthread_mutexattr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutexattr_getprioceiling(__attr: interop.Pointer | interop.Reference<pthread_mutexattr_t> | ArrayBufferLike | ArrayBufferView | null, __prioceiling: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutexattr_getprotocol(__attr: interop.Pointer | interop.Reference<pthread_mutexattr_t> | ArrayBufferLike | ArrayBufferView | null, __protocol: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutexattr_getpshared(__attr: interop.Pointer | interop.Reference<pthread_mutexattr_t> | ArrayBufferLike | ArrayBufferView | null, __pshared: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutexattr_getrobust(__attr: interop.Pointer | interop.Reference<pthread_mutexattr_t> | ArrayBufferLike | ArrayBufferView | null, __robustness: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutexattr_gettype(__attr: interop.Pointer | interop.Reference<pthread_mutexattr_t> | ArrayBufferLike | ArrayBufferView | null, __kind: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutexattr_init(__attr: interop.Pointer | interop.Reference<pthread_mutexattr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_mutexattr_setprioceiling(__attr: interop.Pointer | interop.Reference<pthread_mutexattr_t> | ArrayBufferLike | ArrayBufferView | null, __prioceiling: number): number;

declare function pthread_mutexattr_setprotocol(__attr: interop.Pointer | interop.Reference<pthread_mutexattr_t> | ArrayBufferLike | ArrayBufferView | null, __protocol: number): number;

declare function pthread_mutexattr_setpshared(__attr: interop.Pointer | interop.Reference<pthread_mutexattr_t> | ArrayBufferLike | ArrayBufferView | null, __pshared: number): number;

declare function pthread_mutexattr_setrobust(__attr: interop.Pointer | interop.Reference<pthread_mutexattr_t> | ArrayBufferLike | ArrayBufferView | null, __robustness: number): number;

declare function pthread_mutexattr_settype(__attr: interop.Pointer | interop.Reference<pthread_mutexattr_t> | ArrayBufferLike | ArrayBufferView | null, __kind: number): number;

declare function pthread_once(__once_control: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __init_routine: interop.FunctionReference<() => void>): number;

declare function pthread_rwlock_destroy(__rwlock: interop.Pointer | interop.Reference<pthread_rwlock_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_rwlock_init(__rwlock: interop.Pointer | interop.Reference<pthread_rwlock_t> | ArrayBufferLike | ArrayBufferView | null, __attr: interop.Pointer | interop.Reference<pthread_rwlockattr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_rwlock_rdlock(__rwlock: interop.Pointer | interop.Reference<pthread_rwlock_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_rwlock_timedrdlock(__rwlock: interop.Pointer | interop.Reference<pthread_rwlock_t> | ArrayBufferLike | ArrayBufferView | null, __abstime: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_rwlock_timedwrlock(__rwlock: interop.Pointer | interop.Reference<pthread_rwlock_t> | ArrayBufferLike | ArrayBufferView | null, __abstime: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_rwlock_tryrdlock(__rwlock: interop.Pointer | interop.Reference<pthread_rwlock_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_rwlock_trywrlock(__rwlock: interop.Pointer | interop.Reference<pthread_rwlock_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_rwlock_unlock(__rwlock: interop.Pointer | interop.Reference<pthread_rwlock_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_rwlock_wrlock(__rwlock: interop.Pointer | interop.Reference<pthread_rwlock_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_rwlockattr_destroy(__attr: interop.Pointer | interop.Reference<pthread_rwlockattr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_rwlockattr_getkind_np(__attr: interop.Pointer | interop.Reference<pthread_rwlockattr_t> | ArrayBufferLike | ArrayBufferView | null, __pref: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_rwlockattr_getpshared(__attr: interop.Pointer | interop.Reference<pthread_rwlockattr_t> | ArrayBufferLike | ArrayBufferView | null, __pshared: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_rwlockattr_init(__attr: interop.Pointer | interop.Reference<pthread_rwlockattr_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_rwlockattr_setkind_np(__attr: interop.Pointer | interop.Reference<pthread_rwlockattr_t> | ArrayBufferLike | ArrayBufferView | null, __pref: number): number;

declare function pthread_rwlockattr_setpshared(__attr: interop.Pointer | interop.Reference<pthread_rwlockattr_t> | ArrayBufferLike | ArrayBufferView | null, __pshared: number): number;

declare function pthread_self(): number;

declare function pthread_setcancelstate(__state: number, __oldstate: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_setcanceltype(__type: number, __oldtype: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_setschedparam(__target_thread: number, __policy: number, __param: interop.Pointer | interop.Reference<sched_param> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_setschedprio(__target_thread: number, __prio: number): number;

declare function pthread_setspecific(__key: number, __pointer: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_spin_destroy(__lock: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_spin_init(__lock: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __pshared: number): number;

declare function pthread_spin_lock(__lock: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_spin_trylock(__lock: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_spin_unlock(__lock: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pthread_testcancel(): void;

declare function putc(__c: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function putc_unlocked(__c: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function putchar(__c: number): number;

declare function putchar_unlocked(__c: number): number;

declare function putenv(__string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function putpwent(__p: interop.Pointer | interop.Reference<passwd> | ArrayBufferLike | ArrayBufferView | null, __f: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function puts(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pututxline(__utmpx: interop.Pointer | interop.Reference<utmpx> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<utmpx> | null;

declare function putw(__w: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function putwc(__wc: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function putwchar(__wc: number): number;

declare function pwrite(__fd: number, __buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number, __offset: number): number;

declare function qecvt(__value: number, __ndigit: number, __decpt: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __sign: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function qecvt_r(__value: number, __ndigit: number, __decpt: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __sign: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function qfcvt(__value: number, __ndigit: number, __decpt: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __sign: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function qfcvt_r(__value: number, __ndigit: number, __decpt: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __sign: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function qgcvt(__value: number, __ndigit: number, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function qsort(__base: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __nmemb: number, __size: number, __compar: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null) => number>): void;

declare function quick_exit(__status: number): void;

declare function raise(__sig: number): number;

declare function rand(): number;

declare function rand_r(__seed: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function random(): number;

interface random_data {
	fptr: interop.Pointer | interop.Reference<number> | null;
	rptr: interop.Pointer | interop.Reference<number> | null;
	state: interop.Pointer | interop.Reference<number> | null;
	rand_type: number;
	rand_deg: number;
	rand_sep: number;
	end_ptr: interop.Pointer | interop.Reference<number> | null;
}
declare var random_data: interop.StructType<random_data>;

declare function random_r(__buf: interop.Pointer | interop.Reference<random_data> | ArrayBufferLike | ArrayBufferView | null, __result: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function rcmd(__ahost: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __rport: number, __locuser: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __remuser: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __cmd: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __fd2p: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function rcmd_af(__ahost: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __rport: number, __locuser: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __remuser: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __cmd: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __fd2p: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __af: number): number;

interface re_dfa_t {
}
declare var re_dfa_t: interop.StructType<re_dfa_t>;

declare var re_syntax_options: number;

declare function read(__fd: number, __buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __nbytes: number): number;

declare function readdir(__dirp: interop.Pointer | interop.Reference<DIR> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<dirent> | null;

declare function readdir_r(__dirp: interop.Pointer | interop.Reference<DIR> | ArrayBufferLike | ArrayBufferView | null, __entry: interop.Pointer | interop.Reference<dirent> | ArrayBufferLike | ArrayBufferView | null, __result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<dirent> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function readlink(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function readlinkat(__fd: number, __path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function realloc(__ptr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number): interop.Pointer | interop.Reference<any> | null;

declare function reallocarray(__ptr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __nmemb: number, __size: number): interop.Pointer | interop.Reference<any> | null;

declare function reallocarrayFunction(__ptr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __nmemb: number, __size: number): interop.Pointer | interop.Reference<any> | null;

declare function realpath(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __resolved: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare const enum reg_errcode_t {

	ENOSYS = -1,

	NOERROR = 0,

	NOMATCH = 1,

	BADPAT = 2,

	ECOLLATE = 3,

	ECTYPE = 4,

	EESCAPE = 5,

	ESUBREG = 6,

	EBRACK = 7,

	EPAREN = 8,

	EBRACE = 9,

	BADBR = 10,

	ERANGE = 11,

	ESPACE = 12,

	BADRPT = 13,

	EEND = 14,

	ESIZE = 15,

	ERPAREN = 16
}

declare function regcomp(__preg: interop.Pointer | interop.Reference<regex_t> | ArrayBufferLike | ArrayBufferView | null, __pattern: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __cflags: number): number;

declare function regerror(__errcode: number, __preg: interop.Pointer | interop.Reference<regex_t> | ArrayBufferLike | ArrayBufferView | null, __errbuf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __errbuf_size: number): number;

interface regex_t {
	__buffer: interop.Pointer | interop.Reference<re_dfa_t> | null;
	__allocated: number;
	__used: number;
	__syntax: number;
	__fastmap: interop.Pointer | interop.Reference<any> | null;
	__translate: interop.Pointer | interop.Reference<any> | null;
	re_nsub: number;
	__can_be_null: number;
	__regs_allocated: number;
	__fastmap_accurate: number;
	__no_sub: number;
	__not_bol: number;
	__not_eol: number;
	__newline_anchor: number;
}
declare var regex_t: interop.StructType<regex_t>;

/** Struct tag of {@link regex_t}. */
type re_pattern_buffer = regex_t;
declare var re_pattern_buffer: typeof regex_t;

declare function regfree(__preg: interop.Pointer | interop.Reference<regex_t> | ArrayBufferLike | ArrayBufferView | null): void;

interface regmatch_t {
	rm_so: number;
	rm_eo: number;
}
declare var regmatch_t: interop.StructType<regmatch_t>;

declare function remove(__filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function remque(__elem: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function rename(__old: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __new: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function renameat(__oldfd: number, __old: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __newfd: number, __new: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function revoke(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function rewind(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): void;

declare function rewinddir(__dirp: interop.Pointer | interop.Reference<DIR> | ArrayBufferLike | ArrayBufferView | null): void;

declare function rexec(__ahost: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __rport: number, __name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __pass: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __cmd: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __fd2p: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function rexec_af(__ahost: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __rport: number, __name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __pass: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __cmd: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __fd2p: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __af: number): number;

declare function rindex(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __c: number): interop.Pointer | interop.Reference<any> | null;

declare function rmdir(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

interface rpcent {
	r_name: interop.Pointer | interop.Reference<any> | null;
	r_aliases: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;
	r_number: number;
}
declare var rpcent: interop.StructType<rpcent>;

declare function rpmatch(__response: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function rresvport(__alport: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function rresvport_af(__alport: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __af: number): number;

declare function ruserok(__rhost: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __suser: number, __remuser: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __locuser: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ruserok_af(__rhost: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __suser: number, __remuser: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __locuser: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __af: number): number;

declare function sbrk(__delta: number): interop.Pointer | interop.Reference<any> | null;

declare function scandir(__dir: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __namelist: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<dirent> | null> | null> | ArrayBufferLike | ArrayBufferView | null, __selector: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<dirent> | null) => number>, __cmp: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<dirent> | null> | null, p2: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<dirent> | null> | null) => number>): number;

declare function scanf(__format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function scanfFunction(__format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function sched_get_priority_max(__algorithm: number): number;

declare function sched_get_priority_min(__algorithm: number): number;

declare function sched_getparam(__pid: number, __param: interop.Pointer | interop.Reference<sched_param> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sched_getscheduler(__pid: number): number;

declare function sched_rr_get_interval(__pid: number, __t: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sched_setparam(__pid: number, __param: interop.Pointer | interop.Reference<sched_param> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sched_setscheduler(__pid: number, __policy: number, __param: interop.Pointer | interop.Reference<sched_param> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sched_yield(): number;

declare function seed48(__seed16v: interop.Reference<number>): interop.Pointer | interop.Reference<number> | null;

declare function seed48_r(__seed16v: interop.Reference<number>, __buffer: interop.Pointer | interop.Reference<drand48_data> | ArrayBufferLike | ArrayBufferView | null): number;

declare function seekdir(__dirp: interop.Pointer | interop.Reference<DIR> | ArrayBufferLike | ArrayBufferView | null, __pos: number): void;

declare function sem_close(__sem: interop.Pointer | interop.Reference<sem_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sem_destroy(__sem: interop.Pointer | interop.Reference<sem_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sem_getvalue(__sem: interop.Pointer | interop.Reference<sem_t> | ArrayBufferLike | ArrayBufferView | null, __sval: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sem_init(__sem: interop.Pointer | interop.Reference<sem_t> | ArrayBufferLike | ArrayBufferView | null, __pshared: number, __value: number): number;

declare function sem_open(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __oflag: number, ...args: any[]): interop.Pointer | interop.Reference<sem_t> | null;

declare function sem_post(__sem: interop.Pointer | interop.Reference<sem_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sem_timedwait(__sem: interop.Pointer | interop.Reference<sem_t> | ArrayBufferLike | ArrayBufferView | null, __abstime: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sem_trywait(__sem: interop.Pointer | interop.Reference<sem_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sem_unlink(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sem_wait(__sem: interop.Pointer | interop.Reference<sem_t> | ArrayBufferLike | ArrayBufferView | null): number;

interface servent {
	s_name: interop.Pointer | interop.Reference<any> | null;
	s_aliases: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;
	s_port: number;
	s_proto: interop.Pointer | interop.Reference<any> | null;
}
declare var servent: interop.StructType<servent>;

declare function setbuf(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function setbuffer(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number): void;

declare function setdomainname(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function setegid(__gid: number): number;

declare function setenv(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __replace: number): number;

declare function seteuid(__uid: number): number;

declare function setgid(__gid: number): number;

declare function setgrent(): void;

declare function setgroups(__n: number, __groups: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sethostent(__stay_open: number): void;

declare function sethostid(__id: number): number;

declare function sethostname(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function setjmp(__env: interop.Reference<__jmp_buf_tag>): number;

declare function setlinebuf(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): void;

declare function setlocale(__category: number, __locale: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function setlogin(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function setnetent(__stay_open: number): void;

declare function setnetgrent(__netgroup: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function setpgid(__pid: number, __pgid: number): number;

declare function setpgrp(): number;

declare function setprotoent(__stay_open: number): void;

declare function setpwent(): void;

declare function setregid(__rgid: number, __egid: number): number;

declare function setreuid(__ruid: number, __euid: number): number;

declare function setrpcent(__stayopen: number): void;

declare function setservent(__stay_open: number): void;

declare function setsid(): number;

declare function setstate(__statebuf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function setstate_r(__statebuf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buf: interop.Pointer | interop.Reference<random_data> | ArrayBufferLike | ArrayBufferView | null): number;

declare function setuid(__uid: number): number;

declare function setusershell(): void;

declare function setutxent(): void;

declare function setvbuf(__stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __modes: number, __n: number): number;

declare function sigaction(__sig: number, __act: interop.Pointer | interop.Reference<sigaction> | ArrayBufferLike | ArrayBufferView | null, __oact: interop.Pointer | interop.Reference<sigaction> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sigaddset(__set: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null, __signo: number): number;

declare function sigaltstack(__ss: interop.Pointer | interop.Reference<stack_t> | ArrayBufferLike | ArrayBufferView | null, __oss: interop.Pointer | interop.Reference<stack_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sigblock(__mask: number): number;

declare function sigdelset(__set: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null, __signo: number): number;

declare function sigemptyset(__set: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sigfillset(__set: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function siggetmask(): number;

declare function siginterrupt(__sig: number, __interrupt: number): number;

declare function sigismember(__set: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null, __signo: number): number;

declare function siglongjmp(__env: interop.Reference<__jmp_buf_tag>, __val: number): void;

declare function signal(__sig: number, __handler: interop.FunctionReference<(p1: number) => void>): interop.FunctionReference<(p1: number) => void>;

declare var signgam: number;

declare function sigpending(__set: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sigprocmask(__how: number, __set: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null, __oset: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sigqueue(__pid: number, __sig: number, __val: __sigval_t): number;

declare function sigreturn(__scp: interop.Pointer | interop.Reference<sigcontext> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sigsetmask(__mask: number): number;

declare function sigstack(__ss: interop.Pointer | interop.Reference<sigstack> | ArrayBufferLike | ArrayBufferView | null, __oss: interop.Pointer | interop.Reference<sigstack> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sigsuspend(__set: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sigtimedwait(__set: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null, __info: interop.Pointer | interop.Reference<siginfo_t> | ArrayBufferLike | ArrayBufferView | null, __timeout: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sigwait(__set: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null, __sig: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sigwaitinfo(__set: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null, __info: interop.Pointer | interop.Reference<siginfo_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sleep(__seconds: number): number;

declare function snprintf(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __maxlen: number, __format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

interface sockaddr_in {
	sin_family: number;
	sin_port: number;
	sin_addr: in_addr;
	sin_zero: interop.Reference<number>;
}
declare var sockaddr_in: interop.StructType<sockaddr_in>;

interface sockaddr_in6 {
	sin6_family: number;
	sin6_port: number;
	sin6_flowinfo: number;
	sin6_addr: in6_addr;
	sin6_scope_id: number;
}
declare var sockaddr_in6: interop.StructType<sockaddr_in6>;

declare function sprintf(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function srand(__seed: number): void;

declare function srand48(__seedval: number): void;

declare function srand48_r(__seedval: number, __buffer: interop.Pointer | interop.Reference<drand48_data> | ArrayBufferLike | ArrayBufferView | null): number;

declare function srandom(__seed: number): void;

declare function srandom_r(__seed: number, __buf: interop.Pointer | interop.Reference<random_data> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sscanf(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function sscanfFunction(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function ssignal(__sig: number, __handler: interop.FunctionReference<(p1: number) => void>): interop.FunctionReference<(p1: number) => void>;

interface statmount {
	size: number;
	__spare1: number;
	mask: number;
	sb_dev_major: number;
	sb_dev_minor: number;
	sb_magic: number;
	sb_flags: number;
	fs_type: number;
	mnt_id: number;
	mnt_parent_id: number;
	mnt_id_old: number;
	mnt_parent_id_old: number;
	mnt_attr: number;
	mnt_propagation: number;
	mnt_peer_group: number;
	mnt_master: number;
	propagate_from: number;
	mnt_root: number;
	mnt_point: number;
	__spare2: interop.Reference<number>;
	str: interop.Reference<number>;
}
declare var statmount: interop.StructType<statmount>;

declare var stderr: interop.Pointer | interop.Reference<FILE> | null;

declare var stdin: interop.Pointer | interop.Reference<FILE> | null;

declare var stdout: interop.Pointer | interop.Reference<FILE> | null;

declare function stpcpy(__dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function stpncpy(__dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): interop.Pointer | interop.Reference<any> | null;

declare function strcasecmp(__s1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __s2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function strcasecmp_l(__s1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __s2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __loc: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function strcasestr(__haystack: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __needle: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function strcat(__dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function strchr(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __c: number): interop.Pointer | interop.Reference<any> | null;

declare function strchrnul(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __c: number): interop.Pointer | interop.Reference<any> | null;

declare function strcmp(__s1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __s2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function strcoll(__s1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __s2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function strcoll_l(__s1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __s2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __l: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function strcpy(__dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function strcspn(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __reject: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function strdup(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function strerror(__errnum: number): interop.Pointer | interop.Reference<any> | null;

declare function strerror_l(__errnum: number, __l: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function strerror_r(__errnum: number, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number): number;

declare function strfmon(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __maxsize: number, __format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function strfmon_l(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __maxsize: number, __loc: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null, __format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function strftime(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __maxsize: number, __format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __tp: interop.Pointer | interop.Reference<tm> | ArrayBufferLike | ArrayBufferView | null): number;

declare function strftime_l(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __maxsize: number, __format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __tp: interop.Pointer | interop.Reference<tm> | ArrayBufferLike | ArrayBufferView | null, __loc: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function strlcat(__dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function strlcpy(__dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function strlen(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function strncasecmp(__s1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __s2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function strncasecmp_l(__s1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __s2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number, __loc: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function strncat(__dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): interop.Pointer | interop.Reference<any> | null;

declare function strncmp(__s1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __s2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function strncpy(__dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): interop.Pointer | interop.Reference<any> | null;

declare function strndup(__string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): interop.Pointer | interop.Reference<any> | null;

declare function strnlen(__string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __maxlen: number): number;

declare function strpbrk(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __accept: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function strrchr(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __c: number): interop.Pointer | interop.Reference<any> | null;

declare function strsep(__stringp: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __delim: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function strsignal(__sig: number): interop.Pointer | interop.Reference<any> | null;

declare function strspn(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __accept: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function strstr(__haystack: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __needle: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function strtod(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function strtof(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function strtoimax(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare function strtok(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __delim: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function strtok_r(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __delim: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __save_ptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function strtol(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare function strtold(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function strtoll(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare function strtoq(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare function strtoul(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare function strtoull(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare function strtoumax(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare function strtouq(__nptr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare function strxfrm(__dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function strxfrm_l(__dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number, __l: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function swprintf(__s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number, __format: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function swscanf(__s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __format: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function swscanfFunction(__s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __format: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function symlink(__from: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __to: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function symlinkat(__from: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __tofd: number, __to: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function sync(): void;

declare function syscall(__sysno: number, ...args: any[]): number;

declare function sysconf(__name: number): number;

declare function system(__command: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function tcdrain(__fd: number): number;

declare function tcflow(__fd: number, __action: number): number;

declare function tcflush(__fd: number, __queue_selector: number): number;

declare function tcgetattr(__fd: number, __termios_p: interop.Pointer | interop.Reference<termios> | ArrayBufferLike | ArrayBufferView | null): number;

declare function tcgetpgrp(__fd: number): number;

declare function tcgetsid(__fd: number): number;

declare const enum tcp_ca_state {

	Open = 0,

	Disorder = 1,

	CWR = 2,

	Recovery = 3,

	Loss = 4
}

interface tcp_cookie_transactions {
	tcpct_flags: number;
	__tcpct_pad1: number;
	tcpct_cookie_desired: number;
	tcpct_s_data_desired: number;
	tcpct_used: number;
	tcpct_value: interop.Reference<number>;
}
declare var tcp_cookie_transactions: interop.StructType<tcp_cookie_transactions>;

interface tcp_info {
	tcpi_state: number;
	tcpi_ca_state: number;
	tcpi_retransmits: number;
	tcpi_probes: number;
	tcpi_backoff: number;
	tcpi_options: number;
	tcpi_snd_wscale: number;
	tcpi_rcv_wscale: number;
	tcpi_rto: number;
	tcpi_ato: number;
	tcpi_snd_mss: number;
	tcpi_rcv_mss: number;
	tcpi_unacked: number;
	tcpi_sacked: number;
	tcpi_lost: number;
	tcpi_retrans: number;
	tcpi_fackets: number;
	tcpi_last_data_sent: number;
	tcpi_last_ack_sent: number;
	tcpi_last_data_recv: number;
	tcpi_last_ack_recv: number;
	tcpi_pmtu: number;
	tcpi_rcv_ssthresh: number;
	tcpi_rtt: number;
	tcpi_rttvar: number;
	tcpi_snd_ssthresh: number;
	tcpi_snd_cwnd: number;
	tcpi_advmss: number;
	tcpi_reordering: number;
	tcpi_rcv_rtt: number;
	tcpi_rcv_space: number;
	tcpi_total_retrans: number;
}
declare var tcp_info: interop.StructType<tcp_info>;

interface tcp_md5sig {
	tcpm_addr: sockaddr_storage;
	tcpm_flags: number;
	tcpm_prefixlen: number;
	tcpm_keylen: number;
	tcpm_ifindex: number;
	tcpm_key: interop.Reference<number>;
}
declare var tcp_md5sig: interop.StructType<tcp_md5sig>;

interface tcp_repair_opt {
	opt_code: number;
	opt_val: number;
}
declare var tcp_repair_opt: interop.StructType<tcp_repair_opt>;

interface tcp_repair_window {
	snd_wl1: number;
	snd_wnd: number;
	max_window: number;
	rcv_wnd: number;
	rcv_wup: number;
}
declare var tcp_repair_window: interop.StructType<tcp_repair_window>;

interface tcp_zerocopy_receive {
	address: number;
	length: number;
	recv_skip_hint: number;
}
declare var tcp_zerocopy_receive: interop.StructType<tcp_zerocopy_receive>;

interface tcphdr {
}
declare var tcphdr: interop.StructType<tcphdr>;

declare function tcsendbreak(__fd: number, __duration: number): number;

declare function tcsetattr(__fd: number, __optional_actions: number, __termios_p: interop.Pointer | interop.Reference<termios> | ArrayBufferLike | ArrayBufferView | null): number;

declare function tcsetpgrp(__fd: number, __pgrp_id: number): number;

declare function tdelete(__key: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __rootp: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __compar: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null) => number>): interop.Pointer | interop.Reference<any> | null;

declare function telldir(__dirp: interop.Pointer | interop.Reference<DIR> | ArrayBufferLike | ArrayBufferView | null): number;

declare function tempnam(__dir: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __pfx: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function tfind(__key: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __rootp: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __compar: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null) => number>): interop.Pointer | interop.Reference<any> | null;

declare function time(__timer: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function timegm(__tp: interop.Pointer | interop.Reference<tm> | ArrayBufferLike | ArrayBufferView | null): number;

declare function timelocal(__tp: interop.Pointer | interop.Reference<tm> | ArrayBufferLike | ArrayBufferView | null): number;

declare function timer_create(__clock_id: number, __evp: interop.Pointer | interop.Reference<sigevent_t> | ArrayBufferLike | ArrayBufferView | null, __timerid: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function timer_delete(__timerid: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function timer_getoverrun(__timerid: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function timer_gettime(__timerid: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __value: interop.Pointer | interop.Reference<itimerspec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function timer_settime(__timerid: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __flags: number, __value: interop.Pointer | interop.Reference<itimerspec> | ArrayBufferLike | ArrayBufferView | null, __ovalue: interop.Pointer | interop.Reference<itimerspec> | ArrayBufferLike | ArrayBufferView | null): number;

declare function timespec_get(__ts: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare var timezone: number;

declare function tmpfile(): interop.Pointer | interop.Reference<FILE> | null;

declare function tmpnam(p1: interop.Reference<number>): interop.Pointer | interop.Reference<any> | null;

declare function tmpnam_r(__s: interop.Reference<number>): interop.Pointer | interop.Reference<any> | null;

declare function toascii(__c: number): number;

declare function tolower(__c: number): number;

declare function tolower_l(__c: number, __l: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function toupper(__c: number): number;

declare function toupper_l(__c: number, __l: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function towctrans(__wc: number, __desc: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function towctrans_l(__wc: number, __desc: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function towlower_l(__wc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function towupper_l(__wc: number, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function truncate(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __length: number): number;

declare function tsearch(__key: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __rootp: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __compar: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null) => number>): interop.Pointer | interop.Reference<any> | null;

declare function ttyname(__fd: number): interop.Pointer | interop.Reference<any> | null;

declare function ttyname_r(__fd: number, __buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buflen: number): number;

declare function ttyslot(): number;

declare function twalk(__root: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __action: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: VISIT, p3: number) => void>): void;

declare var tzname: interop.Reference<interop.Pointer | interop.Reference<any> | null>;

declare function tzset(): void;

declare function ualarm(__value: number, __interval: number): number;

declare function ulimit(__cmd: number, ...args: any[]): number;

declare function ungetc(__c: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ungetwc(__wc: number, __stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): number;

declare function unlink(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function unlinkat(__fd: number, __name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __flag: number): number;

declare function unsetenv(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uselocale(__dataset: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<__locale_struct> | null;

declare function usleep(__useconds: number): number;

interface utimbuf {
	actime: number;
	modtime: number;
}
declare var utimbuf: interop.StructType<utimbuf>;

declare function utime(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __file_times: interop.Pointer | interop.Reference<utimbuf> | ArrayBufferLike | ArrayBufferView | null): number;

declare function valloc(__size: number): interop.Pointer | interop.Reference<any> | null;

declare function vfork(): number;

declare function vhangup(): number;

declare function warn(__format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): void;

declare function warnx(__format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): void;

declare function wcpcpy(__dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function wcpncpy(__dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number): interop.Pointer | interop.Reference<number> | null;

declare function wcrtomb(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __wc: number, __ps: interop.Pointer | interop.Reference<__mbstate_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcscasecmp(__s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcscasecmp_l(__s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __loc: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcscat(__dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function wcschr(__wcs: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __wc: number): interop.Pointer | interop.Reference<number> | null;

declare function wcscmp(__s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcscoll(__s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcscoll_l(__s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __loc: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcscpy(__dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function wcscspn(__wcs: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __reject: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcsdup(__s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function wcsftime(__s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __maxsize: number, __format: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __tp: interop.Pointer | interop.Reference<tm> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcslcat(__dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function wcslcpy(__dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function wcslen(__s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcsncasecmp(__s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function wcsncasecmp_l(__s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number, __loc: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcsncat(__dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number): interop.Pointer | interop.Reference<number> | null;

declare function wcsncmp(__s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function wcsncpy(__dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number): interop.Pointer | interop.Reference<number> | null;

declare function wcsnlen(__s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __maxlen: number): number;

declare function wcsnrtombs(__dst: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, __nwc: number, __len: number, __ps: interop.Pointer | interop.Reference<__mbstate_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcspbrk(__wcs: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __accept: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function wcsrchr(__wcs: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __wc: number): interop.Pointer | interop.Reference<number> | null;

declare function wcsrtombs(__dst: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __src: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, __len: number, __ps: interop.Pointer | interop.Reference<__mbstate_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcsspn(__wcs: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __accept: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcsstr(__haystack: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __needle: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function wcstod(__nptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcstof(__nptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcstoimax(__nptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare function wcstok(__s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __delim: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __ptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function wcstol(__nptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare function wcstold(__nptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wcstoll(__nptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare function wcstombs(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __pwcs: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function wcstoul(__nptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare function wcstoull(__nptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare function wcstoumax(__nptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __endptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, __base: number): number;

declare function wcsxfrm(__s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function wcsxfrm_l(__s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number, __loc: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wctob(__c: number): number;

declare function wctomb(__s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __wchar: number): number;

declare function wctrans(__property: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function wctrans_l(__property: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function wctype_l(__property: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __locale: interop.Pointer | interop.Reference<__locale_struct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wmemchr(__s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __c: number, __n: number): interop.Pointer | interop.Reference<number> | null;

declare function wmemcmp(__s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function wmemcpy(__s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number): interop.Pointer | interop.Reference<number> | null;

declare function wmemmove(__s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __n: number): interop.Pointer | interop.Reference<number> | null;

declare function wmemset(__s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __c: number, __n: number): interop.Pointer | interop.Reference<number> | null;

declare function wordexp(__words: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __pwordexp: interop.Pointer | interop.Reference<wordexp_t> | ArrayBufferLike | ArrayBufferView | null, __flags: number): number;

interface wordexp_t {
	we_wordc: number;
	we_wordv: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;
	we_offs: number;
}
declare var wordexp_t: interop.StructType<wordexp_t>;

declare function wordfree(__wordexp: interop.Pointer | interop.Reference<wordexp_t> | ArrayBufferLike | ArrayBufferView | null): void;

declare function wprintf(__format: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function write(__fd: number, __buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number): number;

declare function wscanf(__format: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function wscanfFunction(__format: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;
