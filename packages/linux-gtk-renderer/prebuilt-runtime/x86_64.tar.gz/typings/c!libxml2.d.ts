
declare const BASE_BUFFER_SIZE: number;

declare const HTML_COMMENT_NODE: number;

declare const HTML_ENTITY_REF_NODE: number;

declare const HTML_PI_NODE: number;

declare const HTML_PRESERVE_NODE: number;

declare const HTML_TEXT_NODE: number;

declare const ICU_PIVOT_BUF_SIZE: number;

declare const INPUT_CHUNK: number;

declare const INVALID_SOCKET: number;

declare const LIBXML_DOTTED_VERSION: string;

declare const LIBXML_MODULE_EXTENSION: string;

declare const LIBXML_VERSION: number;

declare const LIBXML_VERSION_EXTRA: string;

declare const LIBXML_VERSION_STRING: string;

declare function UTF8ToHtml(out: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, outlen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, _in: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, inlen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function UTF8Toisolat1(out: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, outlen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, _in: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, inlen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare const XML_COMPLETE_ATTRS: number;

declare const XML_DEFAULT_VERSION: string;

declare const XML_DETECT_IDS: number;

declare const XML_ENT_CHECKED: number;

declare const XML_ENT_EXPANDING: number;

declare const XML_ENT_PARSED: number;

declare const XML_ENT_VALIDATED: number;

declare const XML_LOCAL_NAMESPACE: number;

declare const XML_MAX_DICTIONARY_LIMIT: number;

declare const XML_MAX_LOOKUP_LIMIT: number;

declare const XML_MAX_NAMELEN: number;

declare const XML_MAX_NAME_LENGTH: number;

declare const XML_MAX_TEXT_LENGTH: number;

declare const XML_SAX2_MAGIC: number;

declare const XML_SCHEMAS_ANYATTR_LAX: number;

declare const XML_SCHEMAS_ANYATTR_SKIP: number;

declare const XML_SCHEMAS_ANYATTR_STRICT: number;

declare const XML_SCHEMAS_ANY_LAX: number;

declare const XML_SCHEMAS_ANY_SKIP: number;

declare const XML_SCHEMAS_ANY_STRICT: number;

declare const XML_SCHEMAS_ATTRGROUP_GLOBAL: number;

declare const XML_SCHEMAS_ATTRGROUP_HAS_REFS: number;

declare const XML_SCHEMAS_ATTRGROUP_MARKED: number;

declare const XML_SCHEMAS_ATTRGROUP_REDEFINED: number;

declare const XML_SCHEMAS_ATTRGROUP_WILDCARD_BUILDED: number;

declare const XML_SCHEMAS_ATTR_FIXED: number;

declare const XML_SCHEMAS_ATTR_GLOBAL: number;

declare const XML_SCHEMAS_ATTR_INTERNAL_RESOLVED: number;

declare const XML_SCHEMAS_ATTR_NSDEFAULT: number;

declare const XML_SCHEMAS_ATTR_USE_OPTIONAL: number;

declare const XML_SCHEMAS_ATTR_USE_PROHIBITED: number;

declare const XML_SCHEMAS_ATTR_USE_REQUIRED: number;

declare const XML_SCHEMAS_BLOCK_DEFAULT_EXTENSION: number;

declare const XML_SCHEMAS_BLOCK_DEFAULT_RESTRICTION: number;

declare const XML_SCHEMAS_BLOCK_DEFAULT_SUBSTITUTION: number;

declare const XML_SCHEMAS_ELEM_ABSTRACT: number;

declare const XML_SCHEMAS_ELEM_BLOCK_ABSENT: number;

declare const XML_SCHEMAS_ELEM_BLOCK_EXTENSION: number;

declare const XML_SCHEMAS_ELEM_BLOCK_RESTRICTION: number;

declare const XML_SCHEMAS_ELEM_BLOCK_SUBSTITUTION: number;

declare const XML_SCHEMAS_ELEM_CIRCULAR: number;

declare const XML_SCHEMAS_ELEM_DEFAULT: number;

declare const XML_SCHEMAS_ELEM_FINAL_ABSENT: number;

declare const XML_SCHEMAS_ELEM_FINAL_EXTENSION: number;

declare const XML_SCHEMAS_ELEM_FINAL_RESTRICTION: number;

declare const XML_SCHEMAS_ELEM_FIXED: number;

declare const XML_SCHEMAS_ELEM_GLOBAL: number;

declare const XML_SCHEMAS_ELEM_INTERNAL_CHECKED: number;

declare const XML_SCHEMAS_ELEM_INTERNAL_RESOLVED: number;

declare const XML_SCHEMAS_ELEM_NILLABLE: number;

declare const XML_SCHEMAS_ELEM_NSDEFAULT: number;

declare const XML_SCHEMAS_ELEM_REF: number;

declare const XML_SCHEMAS_ELEM_SUBST_GROUP_HEAD: number;

declare const XML_SCHEMAS_ELEM_TOPLEVEL: number;

declare const XML_SCHEMAS_FACET_COLLAPSE: number;

declare const XML_SCHEMAS_FACET_PRESERVE: number;

declare const XML_SCHEMAS_FACET_REPLACE: number;

declare const XML_SCHEMAS_FACET_UNKNOWN: number;

declare const XML_SCHEMAS_FINAL_DEFAULT_EXTENSION: number;

declare const XML_SCHEMAS_FINAL_DEFAULT_LIST: number;

declare const XML_SCHEMAS_FINAL_DEFAULT_RESTRICTION: number;

declare const XML_SCHEMAS_FINAL_DEFAULT_UNION: number;

declare const XML_SCHEMAS_INCLUDING_CONVERT_NS: number;

declare const XML_SCHEMAS_QUALIF_ATTR: number;

declare const XML_SCHEMAS_QUALIF_ELEM: number;

declare const XML_SCHEMAS_TYPE_ABSTRACT: number;

declare const XML_SCHEMAS_TYPE_BLOCK_DEFAULT: number;

declare const XML_SCHEMAS_TYPE_BLOCK_EXTENSION: number;

declare const XML_SCHEMAS_TYPE_BLOCK_RESTRICTION: number;

declare const XML_SCHEMAS_TYPE_BUILTIN_PRIMITIVE: number;

declare const XML_SCHEMAS_TYPE_DERIVATION_METHOD_EXTENSION: number;

declare const XML_SCHEMAS_TYPE_DERIVATION_METHOD_RESTRICTION: number;

declare const XML_SCHEMAS_TYPE_FACETSNEEDVALUE: number;

declare const XML_SCHEMAS_TYPE_FINAL_DEFAULT: number;

declare const XML_SCHEMAS_TYPE_FINAL_EXTENSION: number;

declare const XML_SCHEMAS_TYPE_FINAL_LIST: number;

declare const XML_SCHEMAS_TYPE_FINAL_RESTRICTION: number;

declare const XML_SCHEMAS_TYPE_FINAL_UNION: number;

declare const XML_SCHEMAS_TYPE_FIXUP_1: number;

declare const XML_SCHEMAS_TYPE_GLOBAL: number;

declare const XML_SCHEMAS_TYPE_HAS_FACETS: number;

declare const XML_SCHEMAS_TYPE_INTERNAL_INVALID: number;

declare const XML_SCHEMAS_TYPE_INTERNAL_RESOLVED: number;

declare const XML_SCHEMAS_TYPE_MARKED: number;

declare const XML_SCHEMAS_TYPE_MIXED: number;

declare const XML_SCHEMAS_TYPE_NORMVALUENEEDED: number;

declare const XML_SCHEMAS_TYPE_OWNED_ATTR_WILDCARD: number;

declare const XML_SCHEMAS_TYPE_REDEFINED: number;

declare const XML_SCHEMAS_TYPE_VARIETY_ABSENT: number;

declare const XML_SCHEMAS_TYPE_VARIETY_ATOMIC: number;

declare const XML_SCHEMAS_TYPE_VARIETY_LIST: number;

declare const XML_SCHEMAS_TYPE_VARIETY_UNION: number;

declare const XML_SCHEMAS_TYPE_WHITESPACE_COLLAPSE: number;

declare const XML_SCHEMAS_TYPE_WHITESPACE_PRESERVE: number;

declare const XML_SCHEMAS_TYPE_WHITESPACE_REPLACE: number;

declare const XML_SCHEMAS_WILDCARD_COMPLETE: number;

declare const XML_SKIP_IDS: number;

declare const XML_SUBSTITUTE_BOTH: number;

declare const XML_SUBSTITUTE_NONE: number;

declare const XML_SUBSTITUTE_PEREF: number;

declare const XML_SUBSTITUTE_REF: number;

declare const XML_XPATH_CHECKNS: number;

declare const XML_XPATH_NOVAR: number;

declare function __docbDefaultSAXHandler(): interop.Pointer | interop.Reference<xmlSAXHandlerV1> | null;

declare function __htmlDefaultSAXHandler(): interop.Pointer | interop.Reference<xmlSAXHandlerV1> | null;

declare function __oldXMLWDcompatibility(): interop.Pointer | interop.Reference<number> | null;

declare function __xmlBufferAllocScheme(): interop.Pointer | interop.Reference<xmlBufferAllocationScheme> | null;

declare function __xmlDefaultBufferSize(): interop.Pointer | interop.Reference<number> | null;

declare function __xmlDefaultSAXHandler(): interop.Pointer | interop.Reference<xmlSAXHandlerV1> | null;

declare function __xmlDefaultSAXLocator(): interop.Pointer | interop.Reference<xmlSAXLocator> | null;

declare function __xmlDeregisterNodeDefaultValue(): interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlNode> | null) => void>> | null;

declare function __xmlDoValidityCheckingDefaultValue(): interop.Pointer | interop.Reference<number> | null;

declare function __xmlGenericError(): interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>> | null;

declare function __xmlGenericErrorContext(): interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;

declare function __xmlGetWarningsDefaultValue(): interop.Pointer | interop.Reference<number> | null;

declare function __xmlIndentTreeOutput(): interop.Pointer | interop.Reference<number> | null;

declare function __xmlKeepBlanksDefaultValue(): interop.Pointer | interop.Reference<number> | null;

declare function __xmlLastError(): interop.Pointer | interop.Reference<xmlError> | null;

declare function __xmlLineNumbersDefaultValue(): interop.Pointer | interop.Reference<number> | null;

declare function __xmlLoadExtDtdDefaultValue(): interop.Pointer | interop.Reference<number> | null;

declare function __xmlOutputBufferCreateFilename(URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoder: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | ArrayBufferLike | ArrayBufferView | null, compression: number): interop.Pointer | interop.Reference<xmlOutputBuffer> | null;

declare function __xmlOutputBufferCreateFilenameValue(): interop.Pointer | interop.Reference<interop.FunctionReference<(p1: string | null, p2: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | null, p3: number) => interop.Pointer | interop.Reference<xmlOutputBuffer> | null>> | null;

declare function __xmlParserDebugEntities(): interop.Pointer | interop.Reference<number> | null;

declare function __xmlParserInputBufferCreateFilename(URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, enc: xmlCharEncoding): interop.Pointer | interop.Reference<xmlParserInputBuffer> | null;

declare function __xmlParserInputBufferCreateFilenameValue(): interop.Pointer | interop.Reference<interop.FunctionReference<(p1: string | null, p2: xmlCharEncoding) => interop.Pointer | interop.Reference<xmlParserInputBuffer> | null>> | null;

declare function __xmlParserVersion(): interop.Pointer | interop.Reference<string | null> | null;

declare function __xmlPedanticParserDefaultValue(): interop.Pointer | interop.Reference<number> | null;

declare function __xmlRegisterNodeDefaultValue(): interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlNode> | null) => void>> | null;

declare function __xmlSaveNoEmptyTags(): interop.Pointer | interop.Reference<number> | null;

declare function __xmlStructuredError(): interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlError> | null) => void>> | null;

declare function __xmlStructuredErrorContext(): interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;

declare function __xmlSubstituteEntitiesDefaultValue(): interop.Pointer | interop.Reference<number> | null;

declare function __xmlTreeIndentString(): interop.Pointer | interop.Reference<string | null> | null;

declare function attribute(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, fullname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function attributeDecl(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, elem: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, fullname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: number, def: number, defaultValue: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, tree: interop.Pointer | interop.Reference<xmlEnumeration> | ArrayBufferLike | ArrayBufferView | null): void;

declare function cdataBlock(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): void;

declare function characters(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ch: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): void;

declare function checkNamespace(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, nameSpace: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function comment(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function docbDefaultSAXHandlerInit(): void;

declare function elementDecl(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: number, content: interop.Pointer | interop.Reference<xmlElementContent> | ArrayBufferLike | ArrayBufferView | null): void;

declare function endDocument(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function endElement(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function entityDecl(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: number, publicId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, systemId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function externalSubset(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ExternalID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, SystemID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function getColumnNumber(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getEntity(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEntity> | null;

declare function getLineNumber(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getNamespace(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNs> | null;

declare function getParameterEntity(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEntity> | null;

declare function getPublicId(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function getSystemId(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function globalNamespace(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, href: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function hasExternalSubset(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function hasInternalSubset(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function htmlAttrAllowed(p1: interop.Pointer | interop.Reference<htmlElemDesc> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number): htmlStatus;

declare function htmlAutoCloseTag(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function htmlCreateFileParserCtxt(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserCtxt> | null;

declare function htmlCreateMemoryParserCtxt(buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number): interop.Pointer | interop.Reference<xmlParserCtxt> | null;

declare function htmlCreatePushParserCtxt(sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, user_data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, chunk: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, enc: xmlCharEncoding): interop.Pointer | interop.Reference<xmlParserCtxt> | null;

declare function htmlCtxtReadDoc(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlCtxtReadFd(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, fd: number, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlCtxtReadFile(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlCtxtReadIO(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, ioread: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number) => number>, ioclose: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>, ioctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlCtxtReadMemory(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlCtxtReset(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function htmlCtxtUseOptions(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function htmlDefaultSAXHandlerInit(): void;

declare function htmlDocContentDumpFormatOutput(buf: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: number): void;

declare function htmlDocContentDumpOutput(buf: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function htmlDocDump(f: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare function htmlDocDumpMemory(cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, mem: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, size: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function htmlDocDumpMemoryFormat(cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, mem: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, size: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, format: number): void;

interface htmlElemDesc {
	name: string | null;
	startTag: number;
	endTag: number;
	saveEndTag: number;
	empty: number;
	depr: number;
	dtd: number;
	isinline: number;
	desc: string | null;
	subelts: interop.Pointer | interop.Reference<string | null> | null;
	defaultsubelt: string | null;
	attrs_opt: interop.Pointer | interop.Reference<string | null> | null;
	attrs_depr: interop.Pointer | interop.Reference<string | null> | null;
	attrs_req: interop.Pointer | interop.Reference<string | null> | null;
}
declare var htmlElemDesc: interop.StructType<htmlElemDesc>;

/** Struct tag of {@link htmlElemDesc}. */
type _htmlElemDesc = htmlElemDesc;
declare var _htmlElemDesc: typeof htmlElemDesc;

declare function htmlElementAllowedHere(p1: interop.Pointer | interop.Reference<htmlElemDesc> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function htmlElementStatusHere(p1: interop.Pointer | interop.Reference<htmlElemDesc> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<htmlElemDesc> | ArrayBufferLike | ArrayBufferView | null): htmlStatus;

declare function htmlEncodeEntities(out: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, outlen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, _in: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, inlen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, quoteChar: number): number;

interface htmlEntityDesc {
	value: number;
	name: string | null;
	desc: string | null;
}
declare var htmlEntityDesc: interop.StructType<htmlEntityDesc>;

/** Struct tag of {@link htmlEntityDesc}. */
type _htmlEntityDesc = htmlEntityDesc;
declare var _htmlEntityDesc: typeof htmlEntityDesc;

declare function htmlEntityLookup(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<htmlEntityDesc> | null;

declare function htmlEntityValueLookup(value: number): interop.Pointer | interop.Reference<htmlEntityDesc> | null;

declare function htmlFreeParserCtxt(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function htmlGetMetaEncoding(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function htmlHandleOmittedElem(val: number): number;

declare function htmlInitAutoClose(): void;

declare function htmlIsAutoClosed(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function htmlIsBooleanAttr(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function htmlIsScriptAttribute(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function htmlNewDoc(URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ExternalID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlNewDocNoDtD(URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ExternalID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlNewParserCtxt(): interop.Pointer | interop.Reference<xmlParserCtxt> | null;

declare function htmlNodeDump(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function htmlNodeDumpFile(out: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function htmlNodeDumpFileFormat(out: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: number): number;

declare function htmlNodeDumpFormatOutput(buf: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: number): void;

declare function htmlNodeDumpOutput(buf: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function htmlNodeStatus(p1: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, p2: number): htmlStatus;

declare function htmlParseCharRef(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function htmlParseChunk(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, chunk: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, terminate: number): number;

declare function htmlParseDoc(cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlParseDocument(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function htmlParseElement(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function htmlParseEntityRef(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, str: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<htmlEntityDesc> | null;

declare function htmlParseFile(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare const enum htmlParserOption {

	RECOVER = 1,

	NODEFDTD = 4,

	NOERROR = 32,

	NOWARNING = 64,

	PEDANTIC = 128,

	NOBLANKS = 256,

	NONET = 2048,

	NOIMPLIED = 8192,

	COMPACT = 65536,

	IGNORE_ENC = 2097152
}

declare function htmlReadDoc(cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlReadFd(fd: number, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlReadFile(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlReadIO(ioread: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number) => number>, ioclose: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>, ioctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlReadMemory(buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlSAXParseDoc(cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, userData: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlSAXParseFile(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, userData: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function htmlSaveFile(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare function htmlSaveFileEnc(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function htmlSaveFileFormat(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: number): number;

declare function htmlSetMetaEncoding(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare const enum htmlStatus {

	NA = 0,

	INVALID = 1,

	DEPRECATED = 2,

	VALID = 4,

	REQUIRED = 12
}

declare function htmlTagLookup(tag: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<htmlElemDesc> | null;

declare function ignorableWhitespace(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ch: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): void;

declare function initGenericErrorDefaultFunc(handler: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>> | ArrayBufferLike | ArrayBufferView | null): void;

declare function initdocbDefaultSAXHandler(hdlr: interop.Pointer | interop.Reference<xmlSAXHandlerV1> | ArrayBufferLike | ArrayBufferView | null): void;

declare function inithtmlDefaultSAXHandler(hdlr: interop.Pointer | interop.Reference<xmlSAXHandlerV1> | ArrayBufferLike | ArrayBufferView | null): void;

declare function initxmlDefaultSAXHandler(hdlr: interop.Pointer | interop.Reference<xmlSAXHandlerV1> | ArrayBufferLike | ArrayBufferView | null, warning: number): void;

declare function inputPop(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserInput> | null;

declare function inputPush(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, value: interop.Pointer | interop.Reference<xmlParserInput> | ArrayBufferLike | ArrayBufferView | null): number;

declare function internalSubset(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ExternalID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, SystemID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function isStandalone(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function isolat1ToUTF8(out: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, outlen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, _in: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, inlen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function namePop(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function namePush(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function namespaceDecl(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, href: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function nodePop(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function nodePush(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, value: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function notationDecl(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, publicId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, systemId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function processingInstruction(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, target: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, data: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function reference(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function resolveEntity(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, publicId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, systemId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserInput> | null;

declare function setDocumentLocator(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, loc: interop.Pointer | interop.Reference<xmlSAXLocator> | ArrayBufferLike | ArrayBufferView | null): void;

declare function setNamespace(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function startDocument(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function startElement(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, fullname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, atts: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null): void;

interface uconv_t {
	uconv: interop.Pointer | interop.Reference<UConverter> | null;
	utf8: interop.Pointer | interop.Reference<UConverter> | null;
	pivot_buf: interop.Reference<number>;
	pivot_source: interop.Pointer | interop.Reference<number> | null;
	pivot_target: interop.Pointer | interop.Reference<number> | null;
}
declare var uconv_t: interop.StructType<uconv_t>;

/** Struct tag of {@link uconv_t}. */
type _uconv_t = uconv_t;
declare var _uconv_t: typeof uconv_t;

declare function unparsedEntityDecl(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, publicId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, systemId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, notationName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function valuePop(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function valuePush(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, value: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): number;

declare const enum xlinkActuate {

	NONE = 0,

	AUTO = 1,

	ONREQUEST = 2
}

declare function xlinkGetDefaultDetect(): interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlNode> | null) => void>;

declare function xlinkGetDefaultHandler(): interop.Pointer | interop.Reference<xlinkHandler> | null;

interface xlinkHandler {
	simple: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlNode> | null, p3: interop.Pointer | interop.Reference<any> | null, p4: interop.Pointer | interop.Reference<any> | null, p5: interop.Pointer | interop.Reference<any> | null) => void>;
	extended: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlNode> | null, p3: number, p4: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null, p5: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null, p6: number, p7: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null, p8: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null, p9: interop.Pointer | interop.Reference<xlinkShow> | null, p10: interop.Pointer | interop.Reference<xlinkActuate> | null, p11: number, p12: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null, p13: interop.Pointer | interop.Reference<string | null> | null) => void>;
	set: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlNode> | null, p3: number, p4: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null, p5: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null, p6: number, p7: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null, p8: interop.Pointer | interop.Reference<string | null> | null) => void>;
}
declare var xlinkHandler: interop.StructType<xlinkHandler>;

/** Struct tag of {@link xlinkHandler}. */
type _xlinkHandler = xlinkHandler;
declare var _xlinkHandler: typeof xlinkHandler;

declare function xlinkIsLink(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): xlinkType;

declare function xlinkSetDefaultDetect(func: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlNode> | null) => void>): void;

declare function xlinkSetDefaultHandler(handler: interop.Pointer | interop.Reference<xlinkHandler> | ArrayBufferLike | ArrayBufferView | null): void;

declare const enum xlinkShow {

	NONE = 0,

	NEW = 1,

	EMBED = 2,

	REPLACE = 3
}

declare const enum xlinkType {

	NONE = 0,

	SIMPLE = 1,

	EXTENDED = 2,

	EXTENDED_SET = 3
}

declare function xmlACatalogAdd(catal: interop.Pointer | interop.Reference<xmlCatalog> | ArrayBufferLike | ArrayBufferView | null, type: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, orig: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, replace: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlACatalogDump(catal: interop.Pointer | interop.Reference<xmlCatalog> | ArrayBufferLike | ArrayBufferView | null, out: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlACatalogRemove(catal: interop.Pointer | interop.Reference<xmlCatalog> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlACatalogResolve(catal: interop.Pointer | interop.Reference<xmlCatalog> | ArrayBufferLike | ArrayBufferView | null, pubID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sysID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlACatalogResolvePublic(catal: interop.Pointer | interop.Reference<xmlCatalog> | ArrayBufferLike | ArrayBufferView | null, pubID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlACatalogResolveSystem(catal: interop.Pointer | interop.Reference<xmlCatalog> | ArrayBufferLike | ArrayBufferView | null, sysID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlACatalogResolveURI(catal: interop.Pointer | interop.Reference<xmlCatalog> | ArrayBufferLike | ArrayBufferView | null, URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlAddAttributeDecl(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, dtd: interop.Pointer | interop.Reference<xmlDtd> | ArrayBufferLike | ArrayBufferView | null, elem: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ns: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: xmlAttributeType, def: xmlAttributeDefault, defaultValue: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, tree: interop.Pointer | interop.Reference<xmlEnumeration> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAttribute> | null;

declare function xmlAddChild(parent: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlAddChildList(parent: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlAddDocEntity(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: number, ExternalID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, SystemID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEntity> | null;

declare function xmlAddDtdEntity(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: number, ExternalID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, SystemID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEntity> | null;

declare function xmlAddElementDecl(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, dtd: interop.Pointer | interop.Reference<xmlDtd> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: xmlElementTypeVal, content: interop.Pointer | interop.Reference<xmlElementContent> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlElement> | null;

declare function xmlAddEncodingAlias(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, alias: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlAddID(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attr: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlID> | null;

declare function xmlAddNextSibling(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlAddNotationDecl(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, dtd: interop.Pointer | interop.Reference<xmlDtd> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, PublicID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, SystemID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNotation> | null;

declare function xmlAddPrevSibling(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlAddRef(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, attr: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlRef> | null;

declare function xmlAddSibling(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlAllocOutputBuffer(encoder: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlOutputBuffer> | null;

declare function xmlAllocParserInputBuffer(enc: xmlCharEncoding): interop.Pointer | interop.Reference<xmlParserInputBuffer> | null;

interface xmlAttr {
	_private: interop.Pointer | interop.Reference<any> | null;
	type: xmlElementType;
	name: string | null;
	children: interop.Pointer | interop.Reference<xmlNode> | null;
	last: interop.Pointer | interop.Reference<xmlNode> | null;
	parent: interop.Pointer | interop.Reference<xmlNode> | null;
	next: interop.Pointer | interop.Reference<xmlAttr> | null;
	prev: interop.Pointer | interop.Reference<xmlAttr> | null;
	doc: interop.Pointer | interop.Reference<xmlDoc> | null;
	ns: interop.Pointer | interop.Reference<xmlNs> | null;
	atype: xmlAttributeType;
	psvi: interop.Pointer | interop.Reference<any> | null;
}
declare var xmlAttr: interop.StructType<xmlAttr>;

/** Struct tag of {@link xmlAttr}. */
type _xmlAttr = xmlAttr;
declare var _xmlAttr: typeof xmlAttr;

declare function xmlAttrSerializeTxtContent(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, attr: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null, string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

interface xmlAttribute {
	_private: interop.Pointer | interop.Reference<any> | null;
	type: xmlElementType;
	name: string | null;
	children: interop.Pointer | interop.Reference<xmlNode> | null;
	last: interop.Pointer | interop.Reference<xmlNode> | null;
	parent: interop.Pointer | interop.Reference<xmlDtd> | null;
	next: interop.Pointer | interop.Reference<xmlNode> | null;
	prev: interop.Pointer | interop.Reference<xmlNode> | null;
	doc: interop.Pointer | interop.Reference<xmlDoc> | null;
	nexth: interop.Pointer | interop.Reference<xmlAttribute> | null;
	atype: xmlAttributeType;
	def: xmlAttributeDefault;
	defaultValue: string | null;
	tree: interop.Pointer | interop.Reference<xmlEnumeration> | null;
	prefix: string | null;
	elem: string | null;
}
declare var xmlAttribute: interop.StructType<xmlAttribute>;

/** Struct tag of {@link xmlAttribute}. */
type _xmlAttribute = xmlAttribute;
declare var _xmlAttribute: typeof xmlAttribute;

declare const enum xmlAttributeDefault {

	NONE = 1,

	REQUIRED = 2,

	IMPLIED = 3,

	FIXED = 4
}

declare const enum xmlAttributeType {

	CDATA = 1,

	ID = 2,

	IDREF = 3,

	IDREFS = 4,

	ENTITY = 5,

	ENTITIES = 6,

	NMTOKEN = 7,

	NMTOKENS = 8,

	ENUMERATION = 9,

	NOTATION = 10
}

interface xmlAutomata {
}
declare var xmlAutomata: interop.StructType<xmlAutomata>;

declare function xmlAutomataCompile(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlRegexp> | null;

declare function xmlAutomataGetInitState(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAutomataState> | null;

declare function xmlAutomataIsDeterminist(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlAutomataNewAllTrans(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null, from: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, to: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, lax: number): interop.Pointer | interop.Reference<xmlAutomataState> | null;

declare function xmlAutomataNewCountTrans(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null, from: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, to: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, token: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, min: number, max: number, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAutomataState> | null;

declare function xmlAutomataNewCountTrans2(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null, from: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, to: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, token: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, token2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, min: number, max: number, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAutomataState> | null;

declare function xmlAutomataNewCountedTrans(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null, from: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, to: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, counter: number): interop.Pointer | interop.Reference<xmlAutomataState> | null;

declare function xmlAutomataNewCounter(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null, min: number, max: number): number;

declare function xmlAutomataNewCounterTrans(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null, from: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, to: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, counter: number): interop.Pointer | interop.Reference<xmlAutomataState> | null;

declare function xmlAutomataNewEpsilon(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null, from: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, to: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAutomataState> | null;

declare function xmlAutomataNewNegTrans(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null, from: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, to: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, token: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, token2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAutomataState> | null;

declare function xmlAutomataNewOnceTrans(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null, from: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, to: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, token: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, min: number, max: number, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAutomataState> | null;

declare function xmlAutomataNewOnceTrans2(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null, from: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, to: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, token: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, token2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, min: number, max: number, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAutomataState> | null;

declare function xmlAutomataNewState(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAutomataState> | null;

declare function xmlAutomataNewTransition(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null, from: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, to: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, token: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAutomataState> | null;

declare function xmlAutomataNewTransition2(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null, from: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, to: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null, token: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, token2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAutomataState> | null;

declare function xmlAutomataSetFinalState(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null, state: interop.Pointer | interop.Reference<xmlAutomataState> | ArrayBufferLike | ArrayBufferView | null): number;

interface xmlAutomataState {
}
declare var xmlAutomataState: interop.StructType<xmlAutomataState>;

declare function xmlBoolToText(boolval: number): string | null;

interface xmlBuf {
}
declare var xmlBuf: interop.StructType<xmlBuf>;

declare function xmlBufContent(buf: interop.Pointer | interop.Reference<xmlBuf> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlBufEnd(buf: interop.Pointer | interop.Reference<xmlBuf> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlBufGetNodeContent(buf: interop.Pointer | interop.Reference<xmlBuf> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlBufNodeDump(buf: interop.Pointer | interop.Reference<xmlBuf> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, level: number, format: number): number;

declare function xmlBufShrink(buf: interop.Pointer | interop.Reference<xmlBuf> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlBufUse(buf: interop.Pointer | interop.Reference<xmlBuf> | ArrayBufferLike | ArrayBufferView | null): number;

interface xmlBuffer {
	content: interop.Pointer | interop.Reference<any> | null;
	use: number;
	size: number;
	alloc: xmlBufferAllocationScheme;
	contentIO: interop.Pointer | interop.Reference<any> | null;
}
declare var xmlBuffer: interop.StructType<xmlBuffer>;

/** Struct tag of {@link xmlBuffer}. */
type _xmlBuffer = xmlBuffer;
declare var _xmlBuffer: typeof xmlBuffer;

declare function xmlBufferAdd(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlBufferAddHead(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare const enum xmlBufferAllocationScheme {

	DOUBLEIT = 0,

	EXACT = 1,

	IMMUTABLE = 2,

	IO = 3,

	HYBRID = 4,

	BOUNDED = 5
}

declare function xmlBufferCCat(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlBufferCat(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlBufferContent(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlBufferCreate(): interop.Pointer | interop.Reference<xmlBuffer> | null;

declare function xmlBufferCreateSize(size: number): interop.Pointer | interop.Reference<xmlBuffer> | null;

declare function xmlBufferCreateStatic(mem: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number): interop.Pointer | interop.Reference<xmlBuffer> | null;

declare function xmlBufferDetach(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlBufferDump(file: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlBufferEmpty(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlBufferFree(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlBufferGrow(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlBufferLength(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlBufferResize(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, size: number): number;

declare function xmlBufferSetAllocationScheme(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, scheme: xmlBufferAllocationScheme): void;

declare function xmlBufferShrink(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlBufferWriteCHAR(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlBufferWriteChar(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlBufferWriteQuotedString(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlBuildQName(ncname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, memory: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlBuildRelativeURI(URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, base: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlBuildURI(URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, base: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlByteConsumed(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlC14NDocDumpMemory(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, nodes: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, mode: number, inclusive_ns_prefixes: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, with_comments: number, doc_txt_ptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlC14NDocSave(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, nodes: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, mode: number, inclusive_ns_prefixes: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, with_comments: number, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, compression: number): number;

declare function xmlC14NDocSaveTo(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, nodes: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, mode: number, inclusive_ns_prefixes: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, with_comments: number, buf: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlC14NExecute(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, is_visible_callback: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlNode> | null, p3: interop.Pointer | interop.Reference<xmlNode> | null) => number>, user_data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, mode: number, inclusive_ns_prefixes: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, with_comments: number, buf: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null): number;

declare const enum xmlC14NMode {

	C14N_1_0 = 0,

	C14N_EXCLUSIVE_1_0 = 1,

	C14N_1_1 = 2
}

declare function xmlCanonicPath(path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

interface xmlCatalog {
}
declare var xmlCatalog: interop.StructType<xmlCatalog>;

declare function xmlCatalogAdd(type: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, orig: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, replace: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlCatalogAddLocal(catalogs: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare const enum xmlCatalogAllow {

	NONE = 0,

	GLOBAL = 1,

	DOCUMENT = 2,

	ALL = 3
}

declare function xmlCatalogCleanup(): void;

declare function xmlCatalogConvert(): number;

declare function xmlCatalogDump(out: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlCatalogFreeLocal(catalogs: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlCatalogGetDefaults(): xmlCatalogAllow;

declare function xmlCatalogGetPublic(pubID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlCatalogGetSystem(sysID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlCatalogIsEmpty(catal: interop.Pointer | interop.Reference<xmlCatalog> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlCatalogLocalResolve(catalogs: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pubID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sysID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlCatalogLocalResolveURI(catalogs: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare const enum xmlCatalogPrefer {

	NONE = 0,

	PUBLIC = 1,

	SYSTEM = 2
}

declare function xmlCatalogRemove(value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlCatalogResolve(pubID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sysID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlCatalogResolvePublic(pubID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlCatalogResolveSystem(sysID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlCatalogResolveURI(URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlCatalogSetDebug(level: number): number;

declare function xmlCatalogSetDefaultPrefer(prefer: xmlCatalogPrefer): xmlCatalogPrefer;

declare function xmlCatalogSetDefaults(allow: xmlCatalogAllow): void;

interface xmlChLRange {
	low: number;
	high: number;
}
declare var xmlChLRange: interop.StructType<xmlChLRange>;

/** Struct tag of {@link xmlChLRange}. */
type _xmlChLRange = xmlChLRange;
declare var _xmlChLRange: typeof xmlChLRange;

interface xmlChRangeGroup {
	nbShortRange: number;
	nbLongRange: number;
	shortRange: interop.Pointer | interop.Reference<xmlChSRange> | null;
	longRange: interop.Pointer | interop.Reference<xmlChLRange> | null;
}
declare var xmlChRangeGroup: interop.StructType<xmlChRangeGroup>;

/** Struct tag of {@link xmlChRangeGroup}. */
type _xmlChRangeGroup = xmlChRangeGroup;
declare var _xmlChRangeGroup: typeof xmlChRangeGroup;

interface xmlChSRange {
	low: number;
	high: number;
}
declare var xmlChSRange: interop.StructType<xmlChSRange>;

/** Struct tag of {@link xmlChSRange}. */
type _xmlChSRange = xmlChSRange;
declare var _xmlChSRange: typeof xmlChSRange;

declare function xmlCharEncCloseFunc(handler: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlCharEncFirstLine(handler: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | ArrayBufferLike | ArrayBufferView | null, out: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, _in: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlCharEncInFunc(handler: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | ArrayBufferLike | ArrayBufferView | null, out: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, _in: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlCharEncOutFunc(handler: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | ArrayBufferLike | ArrayBufferView | null, out: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, _in: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null): number;

declare const enum xmlCharEncoding {

	ENCODING_ERROR = -1,

	ENCODING_NONE = 0,

	ENCODING_UTF8 = 1,

	ENCODING_UTF16LE = 2,

	ENCODING_UTF16BE = 3,

	ENCODING_UCS4LE = 4,

	ENCODING_UCS4BE = 5,

	ENCODING_EBCDIC = 6,

	ENCODING_UCS4_2143 = 7,

	ENCODING_UCS4_3412 = 8,

	ENCODING_UCS2 = 9,

	ENCODING_8859_1 = 10,

	ENCODING_8859_2 = 11,

	ENCODING_8859_3 = 12,

	ENCODING_8859_4 = 13,

	ENCODING_8859_5 = 14,

	ENCODING_8859_6 = 15,

	ENCODING_8859_7 = 16,

	ENCODING_8859_8 = 17,

	ENCODING_8859_9 = 18,

	ENCODING_2022_JP = 19,

	ENCODING_SHIFT_JIS = 20,

	ENCODING_EUC_JP = 21,

	ENCODING_ASCII = 22
}

interface xmlCharEncodingHandler {
	name: interop.Pointer | interop.Reference<any> | null;
	input: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<number> | null, p3: string | null, p4: interop.Pointer | interop.Reference<number> | null) => number>;
	output: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<number> | null, p3: string | null, p4: interop.Pointer | interop.Reference<number> | null) => number>;
	iconv_in: interop.Pointer | interop.Reference<any> | null;
	iconv_out: interop.Pointer | interop.Reference<any> | null;
	uconv_in: interop.Pointer | interop.Reference<uconv_t> | null;
	uconv_out: interop.Pointer | interop.Reference<uconv_t> | null;
}
declare var xmlCharEncodingHandler: interop.StructType<xmlCharEncodingHandler>;

/** Struct tag of {@link xmlCharEncodingHandler}. */
type _xmlCharEncodingHandler = xmlCharEncodingHandler;
declare var _xmlCharEncodingHandler: typeof xmlCharEncodingHandler;

declare function xmlCharInRange(val: number, group: interop.Pointer | interop.Reference<xmlChRangeGroup> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlCharStrdup(cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlCharStrndup(cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlCheckFilename(path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlCheckHTTPInput(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, ret: interop.Pointer | interop.Reference<xmlParserInput> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserInput> | null;

declare function xmlCheckLanguageID(lang: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlCheckUTF8(utf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlCheckVersion(version: number): void;

declare function xmlChildElementCount(parent: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlCleanupCharEncodingHandlers(): void;

declare function xmlCleanupEncodingAliases(): void;

declare function xmlCleanupGlobals(): void;

declare function xmlCleanupInputCallbacks(): void;

declare function xmlCleanupMemory(): void;

declare function xmlCleanupOutputCallbacks(): void;

declare function xmlCleanupParser(): void;

declare function xmlCleanupPredefinedEntities(): void;

declare function xmlCleanupThreads(): void;

declare function xmlClearNodeInfoSeq(seq: interop.Pointer | interop.Reference<xmlParserNodeInfoSeq> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlClearParserCtxt(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlConvertSGMLCatalog(catal: interop.Pointer | interop.Reference<xmlCatalog> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlCopyAttributeTable(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlHashTable> | null;

declare function xmlCopyChar(len: number, out: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, val: number): number;

declare function xmlCopyCharMultiByte(out: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, val: number): number;

declare function xmlCopyDoc(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, recursive: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlCopyDocElementContent(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, content: interop.Pointer | interop.Reference<xmlElementContent> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlElementContent> | null;

declare function xmlCopyDtd(dtd: interop.Pointer | interop.Reference<xmlDtd> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDtd> | null;

declare function xmlCopyElementContent(content: interop.Pointer | interop.Reference<xmlElementContent> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlElementContent> | null;

declare function xmlCopyElementTable(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlHashTable> | null;

declare function xmlCopyEntitiesTable(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlHashTable> | null;

declare function xmlCopyEnumeration(cur: interop.Pointer | interop.Reference<xmlEnumeration> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEnumeration> | null;

declare function xmlCopyError(from: interop.Pointer | interop.Reference<xmlError> | ArrayBufferLike | ArrayBufferView | null, to: interop.Pointer | interop.Reference<xmlError> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlCopyNamespace(cur: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNs> | null;

declare function xmlCopyNamespaceList(cur: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNs> | null;

declare function xmlCopyNode(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, recursive: number): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlCopyNodeList(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlCopyNotationTable(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlHashTable> | null;

declare function xmlCopyProp(target: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAttr> | null;

declare function xmlCopyPropList(target: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAttr> | null;

declare function xmlCreateDocParserCtxt(cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserCtxt> | null;

declare function xmlCreateEntitiesTable(): interop.Pointer | interop.Reference<xmlHashTable> | null;

declare function xmlCreateEntityParserCtxt(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, base: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserCtxt> | null;

declare function xmlCreateEnumeration(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEnumeration> | null;

declare function xmlCreateFileParserCtxt(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserCtxt> | null;

declare function xmlCreateIOParserCtxt(sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, user_data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ioread: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number) => number>, ioclose: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>, ioctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, enc: xmlCharEncoding): interop.Pointer | interop.Reference<xmlParserCtxt> | null;

declare function xmlCreateIntSubset(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ExternalID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, SystemID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDtd> | null;

declare function xmlCreateMemoryParserCtxt(buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number): interop.Pointer | interop.Reference<xmlParserCtxt> | null;

declare function xmlCreatePushParserCtxt(sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, user_data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, chunk: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserCtxt> | null;

declare function xmlCreateURI(): interop.Pointer | interop.Reference<xmlURI> | null;

declare function xmlCreateURLParserCtxt(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlParserCtxt> | null;

declare function xmlCtxtGetLastError(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlError> | null;

declare function xmlCtxtReadDoc(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlCtxtReadFd(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, fd: number, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlCtxtReadFile(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlCtxtReadIO(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, ioread: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number) => number>, ioclose: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>, ioctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlCtxtReadMemory(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlCtxtReset(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlCtxtResetLastError(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlCtxtResetPush(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, chunk: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlCtxtUseOptions(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function xmlCurrentChar(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlDOMWrapAdoptNode(ctxt: interop.Pointer | interop.Reference<xmlDOMWrapCtxt> | ArrayBufferLike | ArrayBufferView | null, sourceDoc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, destDoc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, destParent: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function xmlDOMWrapCloneNode(ctxt: interop.Pointer | interop.Reference<xmlDOMWrapCtxt> | ArrayBufferLike | ArrayBufferView | null, sourceDoc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, clonedNode: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlNode> | null> | ArrayBufferLike | ArrayBufferView | null, destDoc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, destParent: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, deep: number, options: number): number;

interface xmlDOMWrapCtxt {
	_private: interop.Pointer | interop.Reference<any> | null;
	type: number;
	namespaceMap: interop.Pointer | interop.Reference<any> | null;
	getNsForNodeFunc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlDOMWrapCtxt> | null, p2: interop.Pointer | interop.Reference<xmlNode> | null, p3: string | null, p4: string | null) => interop.Pointer | interop.Reference<xmlNs> | null>;
}
declare var xmlDOMWrapCtxt: interop.StructType<xmlDOMWrapCtxt>;

/** Struct tag of {@link xmlDOMWrapCtxt}. */
type _xmlDOMWrapCtxt = xmlDOMWrapCtxt;
declare var _xmlDOMWrapCtxt: typeof xmlDOMWrapCtxt;

declare function xmlDOMWrapFreeCtxt(ctxt: interop.Pointer | interop.Reference<xmlDOMWrapCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDOMWrapNewCtxt(): interop.Pointer | interop.Reference<xmlDOMWrapCtxt> | null;

declare function xmlDOMWrapReconcileNamespaces(ctxt: interop.Pointer | interop.Reference<xmlDOMWrapCtxt> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function xmlDOMWrapRemoveNode(ctxt: interop.Pointer | interop.Reference<xmlDOMWrapCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function xmlDebugCheckDocument(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlDebugDumpAttr(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, attr: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null, depth: number): void;

declare function xmlDebugDumpAttrList(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, attr: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null, depth: number): void;

declare function xmlDebugDumpDTD(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, dtd: interop.Pointer | interop.Reference<xmlDtd> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDebugDumpDocument(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDebugDumpDocumentHead(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDebugDumpEntities(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDebugDumpNode(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, depth: number): void;

declare function xmlDebugDumpNodeList(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, depth: number): void;

declare function xmlDebugDumpOneNode(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, depth: number): void;

declare function xmlDebugDumpString(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDecodeEntities(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, len: number, what: number, end: number, end2: number, end3: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlDefaultSAXHandlerInit(): void;

declare function xmlDelEncodingAlias(alias: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlDeregisterNodeDefault(func: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlNode> | null) => void>): interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlNode> | null) => void>;

declare function xmlDetectCharEncoding(_in: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): xmlCharEncoding;

interface xmlDict {
}
declare var xmlDict: interop.StructType<xmlDict>;

declare function xmlDictCleanup(): void;

declare function xmlDictCreate(): interop.Pointer | interop.Reference<xmlDict> | null;

declare function xmlDictCreateSub(sub: interop.Pointer | interop.Reference<xmlDict> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDict> | null;

declare function xmlDictExists(dict: interop.Pointer | interop.Reference<xmlDict> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): string | null;

declare function xmlDictFree(dict: interop.Pointer | interop.Reference<xmlDict> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDictGetUsage(dict: interop.Pointer | interop.Reference<xmlDict> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlDictLookup(dict: interop.Pointer | interop.Reference<xmlDict> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): string | null;

declare function xmlDictOwns(dict: interop.Pointer | interop.Reference<xmlDict> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlDictQLookup(dict: interop.Pointer | interop.Reference<xmlDict> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlDictReference(dict: interop.Pointer | interop.Reference<xmlDict> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlDictSetLimit(dict: interop.Pointer | interop.Reference<xmlDict> | ArrayBufferLike | ArrayBufferView | null, limit: number): number;

declare function xmlDictSize(dict: interop.Pointer | interop.Reference<xmlDict> | ArrayBufferLike | ArrayBufferView | null): number;

interface xmlDoc {
	_private: interop.Pointer | interop.Reference<any> | null;
	type: xmlElementType;
	name: interop.Pointer | interop.Reference<any> | null;
	children: interop.Pointer | interop.Reference<xmlNode> | null;
	last: interop.Pointer | interop.Reference<xmlNode> | null;
	parent: interop.Pointer | interop.Reference<xmlNode> | null;
	next: interop.Pointer | interop.Reference<xmlNode> | null;
	prev: interop.Pointer | interop.Reference<xmlNode> | null;
	doc: interop.Pointer | interop.Reference<xmlDoc> | null;
	compression: number;
	standalone: number;
	intSubset: interop.Pointer | interop.Reference<xmlDtd> | null;
	extSubset: interop.Pointer | interop.Reference<xmlDtd> | null;
	oldNs: interop.Pointer | interop.Reference<xmlNs> | null;
	version: string | null;
	encoding: string | null;
	ids: interop.Pointer | interop.Reference<any> | null;
	refs: interop.Pointer | interop.Reference<any> | null;
	URL: string | null;
	charset: number;
	dict: interop.Pointer | interop.Reference<xmlDict> | null;
	psvi: interop.Pointer | interop.Reference<any> | null;
	parseFlags: number;
	properties: number;
}
declare var xmlDoc: interop.StructType<xmlDoc>;

/** Struct tag of {@link xmlDoc}. */
type _xmlDoc = xmlDoc;
declare var _xmlDoc: typeof xmlDoc;

declare function xmlDocCopyNode(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, recursive: number): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlDocCopyNodeList(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlDocDump(f: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlDocDumpFormatMemory(cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, mem: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, size: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, format: number): void;

declare function xmlDocDumpFormatMemoryEnc(out_doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, doc_txt_ptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, doc_txt_len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, txt_encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: number): void;

declare function xmlDocDumpMemory(cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, mem: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, size: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDocDumpMemoryEnc(out_doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, doc_txt_ptr: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, doc_txt_len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, txt_encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDocFormatDump(f: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, format: number): number;

declare function xmlDocGetRootElement(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare const enum xmlDocProperties {

	WELLFORMED = 1,

	NSVALID = 2,

	OLD10 = 4,

	DTDVALID = 8,

	XINCLUDE = 16,

	USERBUILT = 32,

	INTERNAL = 64,

	HTML = 128
}

declare function xmlDocSetRootElement(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, root: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

interface xmlDtd {
	_private: interop.Pointer | interop.Reference<any> | null;
	type: xmlElementType;
	name: string | null;
	children: interop.Pointer | interop.Reference<xmlNode> | null;
	last: interop.Pointer | interop.Reference<xmlNode> | null;
	parent: interop.Pointer | interop.Reference<xmlDoc> | null;
	next: interop.Pointer | interop.Reference<xmlNode> | null;
	prev: interop.Pointer | interop.Reference<xmlNode> | null;
	doc: interop.Pointer | interop.Reference<xmlDoc> | null;
	notations: interop.Pointer | interop.Reference<any> | null;
	elements: interop.Pointer | interop.Reference<any> | null;
	attributes: interop.Pointer | interop.Reference<any> | null;
	entities: interop.Pointer | interop.Reference<any> | null;
	ExternalID: string | null;
	SystemID: string | null;
	pentities: interop.Pointer | interop.Reference<any> | null;
}
declare var xmlDtd: interop.StructType<xmlDtd>;

/** Struct tag of {@link xmlDtd}. */
type _xmlDtd = xmlDtd;
declare var _xmlDtd: typeof xmlDtd;

declare function xmlDumpAttributeDecl(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, attr: interop.Pointer | interop.Reference<xmlAttribute> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDumpAttributeTable(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDumpElementDecl(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlElement> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDumpElementTable(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDumpEntitiesTable(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDumpEntityDecl(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, ent: interop.Pointer | interop.Reference<xmlEntity> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDumpNotationDecl(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, nota: interop.Pointer | interop.Reference<xmlNotation> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlDumpNotationTable(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlElemDump(f: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): void;

interface xmlElement {
	_private: interop.Pointer | interop.Reference<any> | null;
	type: xmlElementType;
	name: string | null;
	children: interop.Pointer | interop.Reference<xmlNode> | null;
	last: interop.Pointer | interop.Reference<xmlNode> | null;
	parent: interop.Pointer | interop.Reference<xmlDtd> | null;
	next: interop.Pointer | interop.Reference<xmlNode> | null;
	prev: interop.Pointer | interop.Reference<xmlNode> | null;
	doc: interop.Pointer | interop.Reference<xmlDoc> | null;
	etype: xmlElementTypeVal;
	content: interop.Pointer | interop.Reference<xmlElementContent> | null;
	attributes: interop.Pointer | interop.Reference<xmlAttribute> | null;
	prefix: string | null;
	contModel: interop.Pointer | interop.Reference<xmlRegexp> | null;
}
declare var xmlElement: interop.StructType<xmlElement>;

/** Struct tag of {@link xmlElement}. */
type _xmlElement = xmlElement;
declare var _xmlElement: typeof xmlElement;

interface xmlElementContent {
	type: xmlElementContentType;
	ocur: xmlElementContentOccur;
	name: string | null;
	c1: interop.Pointer | interop.Reference<xmlElementContent> | null;
	c2: interop.Pointer | interop.Reference<xmlElementContent> | null;
	parent: interop.Pointer | interop.Reference<xmlElementContent> | null;
	prefix: string | null;
}
declare var xmlElementContent: interop.StructType<xmlElementContent>;

/** Struct tag of {@link xmlElementContent}. */
type _xmlElementContent = xmlElementContent;
declare var _xmlElementContent: typeof xmlElementContent;

declare const enum xmlElementContentOccur {

	ONCE = 1,

	OPT = 2,

	MULT = 3,

	PLUS = 4
}

declare const enum xmlElementContentType {

	PCDATA = 1,

	ELEMENT = 2,

	SEQ = 3,

	OR = 4
}

declare const enum xmlElementType {

	ELEMENT_NODE = 1,

	ATTRIBUTE_NODE = 2,

	TEXT_NODE = 3,

	CDATA_SECTION_NODE = 4,

	ENTITY_REF_NODE = 5,

	ENTITY_NODE = 6,

	PI_NODE = 7,

	COMMENT_NODE = 8,

	DOCUMENT_NODE = 9,

	DOCUMENT_TYPE_NODE = 10,

	DOCUMENT_FRAG_NODE = 11,

	NOTATION_NODE = 12,

	HTML_DOCUMENT_NODE = 13,

	DTD_NODE = 14,

	ELEMENT_DECL = 15,

	ATTRIBUTE_DECL = 16,

	ENTITY_DECL = 17,

	NAMESPACE_DECL = 18,

	XINCLUDE_START = 19,

	XINCLUDE_END = 20,

	DOCB_DOCUMENT_NODE = 21
}

declare const enum xmlElementTypeVal {

	UNDEFINED = 0,

	EMPTY = 1,

	ANY = 2,

	MIXED = 3,

	ELEMENT = 4
}

declare function xmlEncodeEntities(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, input: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlEncodeEntitiesReentrant(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, input: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlEncodeSpecialChars(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, input: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

interface xmlEntity {
	_private: interop.Pointer | interop.Reference<any> | null;
	type: xmlElementType;
	name: string | null;
	children: interop.Pointer | interop.Reference<xmlNode> | null;
	last: interop.Pointer | interop.Reference<xmlNode> | null;
	parent: interop.Pointer | interop.Reference<xmlDtd> | null;
	next: interop.Pointer | interop.Reference<xmlNode> | null;
	prev: interop.Pointer | interop.Reference<xmlNode> | null;
	doc: interop.Pointer | interop.Reference<xmlDoc> | null;
	orig: interop.Pointer | interop.Reference<any> | null;
	content: interop.Pointer | interop.Reference<any> | null;
	length: number;
	etype: xmlEntityType;
	ExternalID: string | null;
	SystemID: string | null;
	nexte: interop.Pointer | interop.Reference<xmlEntity> | null;
	URI: string | null;
	owner: number;
	checked: number;
	flags: number;
	expandedSize: number;
}
declare var xmlEntity: interop.StructType<xmlEntity>;

/** Struct tag of {@link xmlEntity}. */
type _xmlEntity = xmlEntity;
declare var _xmlEntity: typeof xmlEntity;

declare const enum xmlEntityType {

	INTERNAL_GENERAL_ENTITY = 1,

	EXTERNAL_GENERAL_PARSED_ENTITY = 2,

	EXTERNAL_GENERAL_UNPARSED_ENTITY = 3,

	INTERNAL_PARAMETER_ENTITY = 4,

	EXTERNAL_PARAMETER_ENTITY = 5,

	INTERNAL_PREDEFINED_ENTITY = 6
}

interface xmlEnumeration {
	next: interop.Pointer | interop.Reference<xmlEnumeration> | null;
	name: string | null;
}
declare var xmlEnumeration: interop.StructType<xmlEnumeration>;

/** Struct tag of {@link xmlEnumeration}. */
type _xmlEnumeration = xmlEnumeration;
declare var _xmlEnumeration: typeof xmlEnumeration;

interface xmlError {
	domain: number;
	code: number;
	message: interop.Pointer | interop.Reference<any> | null;
	level: xmlErrorLevel;
	file: interop.Pointer | interop.Reference<any> | null;
	line: number;
	str1: interop.Pointer | interop.Reference<any> | null;
	str2: interop.Pointer | interop.Reference<any> | null;
	str3: interop.Pointer | interop.Reference<any> | null;
	int1: number;
	int2: number;
	ctxt: interop.Pointer | interop.Reference<any> | null;
	node: interop.Pointer | interop.Reference<any> | null;
}
declare var xmlError: interop.StructType<xmlError>;

/** Struct tag of {@link xmlError}. */
type _xmlError = xmlError;
declare var _xmlError: typeof xmlError;

declare const enum xmlErrorDomain {

	NONE = 0,

	PARSER = 1,

	TREE = 2,

	NAMESPACE = 3,

	DTD = 4,

	HTML = 5,

	MEMORY = 6,

	OUTPUT = 7,

	IO = 8,

	FTP = 9,

	HTTP = 10,

	XINCLUDE = 11,

	XPATH = 12,

	XPOINTER = 13,

	REGEXP = 14,

	DATATYPE = 15,

	SCHEMASP = 16,

	SCHEMASV = 17,

	RELAXNGP = 18,

	RELAXNGV = 19,

	CATALOG = 20,

	C14N = 21,

	XSLT = 22,

	VALID = 23,

	CHECK = 24,

	WRITER = 25,

	MODULE = 26,

	I18N = 27,

	SCHEMATRONV = 28,

	BUFFER = 29,

	URI = 30
}

declare const enum xmlErrorLevel {

	NONE = 0,

	WARNING = 1,

	ERROR = 2,

	FATAL = 3
}

declare const enum xmlFeature {

	THREAD = 1,

	TREE = 2,

	OUTPUT = 3,

	PUSH = 4,

	READER = 5,

	PATTERN = 6,

	WRITER = 7,

	SAX1 = 8,

	FTP = 9,

	HTTP = 10,

	VALID = 11,

	HTML = 12,

	LEGACY = 13,

	C14N = 14,

	CATALOG = 15,

	XPATH = 16,

	XPTR = 17,

	XINCLUDE = 18,

	ICONV = 19,

	ISO8859X = 20,

	UNICODE = 21,

	REGEXP = 22,

	AUTOMATA = 23,

	EXPR = 24,

	SCHEMAS = 25,

	SCHEMATRON = 26,

	MODULES = 27,

	DEBUG = 28,

	DEBUG_MEM = 29,

	DEBUG_RUN = 30,

	ZLIB = 31,

	ICU = 32,

	LZMA = 33,

	NONE = 99999
}

declare function xmlFileClose(context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlFileMatch(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlFileOpen(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlFileRead(context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlFindCharEncodingHandler(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlCharEncodingHandler> | null;

declare function xmlFirstElementChild(parent: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare var xmlFree: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>;

declare function xmlFreeAttributeTable(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeAutomata(am: interop.Pointer | interop.Reference<xmlAutomata> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeCatalog(catal: interop.Pointer | interop.Reference<xmlCatalog> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeDoc(cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeDocElementContent(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlElementContent> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeDtd(cur: interop.Pointer | interop.Reference<xmlDtd> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeElementContent(cur: interop.Pointer | interop.Reference<xmlElementContent> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeElementTable(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeEntitiesTable(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeEnumeration(cur: interop.Pointer | interop.Reference<xmlEnumeration> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeIDTable(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeInputStream(input: interop.Pointer | interop.Reference<xmlParserInput> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeMutex(tok: interop.Pointer | interop.Reference<xmlMutex> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeNode(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeNodeList(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeNotationTable(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeNs(cur: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeNsList(cur: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeParserCtxt(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeParserInputBuffer(_in: interop.Pointer | interop.Reference<xmlParserInputBuffer> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreePattern(comp: interop.Pointer | interop.Reference<xmlPattern> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreePatternList(comp: interop.Pointer | interop.Reference<xmlPattern> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeProp(cur: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreePropList(cur: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeRMutex(tok: interop.Pointer | interop.Reference<xmlRMutex> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeRefTable(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeStreamCtxt(stream: interop.Pointer | interop.Reference<xmlStreamCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeTextReader(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeTextWriter(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeURI(uri: interop.Pointer | interop.Reference<xmlURI> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlFreeValidCtxt(p1: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlGcMemGet(freeFunc: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>> | ArrayBufferLike | ArrayBufferView | null, mallocFunc: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: number) => interop.Pointer | interop.Reference<any> | null>> | ArrayBufferLike | ArrayBufferView | null, mallocAtomicFunc: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: number) => interop.Pointer | interop.Reference<any> | null>> | ArrayBufferLike | ArrayBufferView | null, reallocFunc: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: number) => interop.Pointer | interop.Reference<any> | null>> | ArrayBufferLike | ArrayBufferView | null, strdupFunc: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: string | null) => interop.Pointer | interop.Reference<any> | null>> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlGcMemSetup(freeFunc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>, mallocFunc: interop.FunctionReference<(p1: number) => interop.Pointer | interop.Reference<any> | null>, mallocAtomicFunc: interop.FunctionReference<(p1: number) => interop.Pointer | interop.Reference<any> | null>, reallocFunc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: number) => interop.Pointer | interop.Reference<any> | null>, strdupFunc: interop.FunctionReference<(p1: string | null) => interop.Pointer | interop.Reference<any> | null>): number;

declare function xmlGetBufferAllocationScheme(): xmlBufferAllocationScheme;

declare function xmlGetCharEncodingHandler(enc: xmlCharEncoding): interop.Pointer | interop.Reference<xmlCharEncodingHandler> | null;

declare function xmlGetCharEncodingName(enc: xmlCharEncoding): string | null;

declare function xmlGetCompressMode(): number;

declare function xmlGetDocCompressMode(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlGetDocEntity(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEntity> | null;

declare function xmlGetDtdAttrDesc(dtd: interop.Pointer | interop.Reference<xmlDtd> | ArrayBufferLike | ArrayBufferView | null, elem: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAttribute> | null;

declare function xmlGetDtdElementDesc(dtd: interop.Pointer | interop.Reference<xmlDtd> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlElement> | null;

declare function xmlGetDtdEntity(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEntity> | null;

declare function xmlGetDtdNotationDesc(dtd: interop.Pointer | interop.Reference<xmlDtd> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNotation> | null;

declare function xmlGetDtdQAttrDesc(dtd: interop.Pointer | interop.Reference<xmlDtd> | ArrayBufferLike | ArrayBufferView | null, elem: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAttribute> | null;

declare function xmlGetDtdQElementDesc(dtd: interop.Pointer | interop.Reference<xmlDtd> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlElement> | null;

declare function xmlGetEncodingAlias(alias: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlGetExternalEntityLoader(): interop.FunctionReference<(p1: string | null, p2: string | null, p3: interop.Pointer | interop.Reference<xmlParserCtxt> | null) => interop.Pointer | interop.Reference<xmlParserInput> | null>;

declare function xmlGetFeature(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, result: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlGetFeaturesList(len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, result: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlGetGlobalState(): interop.Pointer | interop.Reference<xmlGlobalState> | null;

declare function xmlGetID(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, ID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAttr> | null;

declare function xmlGetIntSubset(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDtd> | null;

declare function xmlGetLastChild(parent: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlGetLastError(): interop.Pointer | interop.Reference<xmlError> | null;

declare function xmlGetLineNo(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlGetNoNsProp(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlGetNodePath(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlGetNsList(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlNs> | null> | null;

declare function xmlGetNsProp(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, nameSpace: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlGetParameterEntity(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEntity> | null;

declare function xmlGetPredefinedEntity(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEntity> | null;

declare function xmlGetProp(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlGetRefs(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, ID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlList> | null;

declare function xmlGetThreadId(): number;

declare function xmlGetUTF8Char(utf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

interface xmlGlobalState {
	xmlParserVersion: string | null;
	xmlDefaultSAXLocator: xmlSAXLocator;
	xmlDefaultSAXHandler: xmlSAXHandlerV1;
	docbDefaultSAXHandler: xmlSAXHandlerV1;
	htmlDefaultSAXHandler: xmlSAXHandlerV1;
	xmlFree: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>;
	xmlMalloc: interop.FunctionReference<(p1: number) => interop.Pointer | interop.Reference<any> | null>;
	xmlMemStrdup: interop.FunctionReference<(p1: string | null) => interop.Pointer | interop.Reference<any> | null>;
	xmlRealloc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: number) => interop.Pointer | interop.Reference<any> | null>;
	xmlGenericError: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	xmlStructuredError: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlError> | null) => void>;
	xmlGenericErrorContext: interop.Pointer | interop.Reference<any> | null;
	oldXMLWDcompatibility: number;
	xmlBufferAllocScheme: xmlBufferAllocationScheme;
	xmlDefaultBufferSize: number;
	xmlSubstituteEntitiesDefaultValue: number;
	xmlDoValidityCheckingDefaultValue: number;
	xmlGetWarningsDefaultValue: number;
	xmlKeepBlanksDefaultValue: number;
	xmlLineNumbersDefaultValue: number;
	xmlLoadExtDtdDefaultValue: number;
	xmlParserDebugEntities: number;
	xmlPedanticParserDefaultValue: number;
	xmlSaveNoEmptyTags: number;
	xmlIndentTreeOutput: number;
	xmlTreeIndentString: string | null;
	xmlRegisterNodeDefaultValue: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlNode> | null) => void>;
	xmlDeregisterNodeDefaultValue: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlNode> | null) => void>;
	xmlMallocAtomic: interop.FunctionReference<(p1: number) => interop.Pointer | interop.Reference<any> | null>;
	xmlLastError: xmlError;
	xmlParserInputBufferCreateFilenameValue: interop.FunctionReference<(p1: string | null, p2: xmlCharEncoding) => interop.Pointer | interop.Reference<xmlParserInputBuffer> | null>;
	xmlOutputBufferCreateFilenameValue: interop.FunctionReference<(p1: string | null, p2: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | null, p3: number) => interop.Pointer | interop.Reference<xmlOutputBuffer> | null>;
	xmlStructuredErrorContext: interop.Pointer | interop.Reference<any> | null;
}
declare var xmlGlobalState: interop.StructType<xmlGlobalState>;

/** Struct tag of {@link xmlGlobalState}. */
type _xmlGlobalState = xmlGlobalState;
declare var _xmlGlobalState: typeof xmlGlobalState;

declare function xmlHandleEntity(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, entity: interop.Pointer | interop.Reference<xmlEntity> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlHasFeature(feature: xmlFeature): number;

declare function xmlHasNsProp(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, nameSpace: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAttr> | null;

declare function xmlHasProp(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAttr> | null;

declare function xmlHashAddEntry(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, userdata: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlHashAddEntry2(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, userdata: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlHashAddEntry3(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, userdata: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlHashCopy(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => interop.Pointer | interop.Reference<any> | null>): interop.Pointer | interop.Reference<xmlHashTable> | null;

declare function xmlHashCreate(size: number): interop.Pointer | interop.Reference<xmlHashTable> | null;

declare function xmlHashCreateDict(size: number, dict: interop.Pointer | interop.Reference<xmlDict> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlHashTable> | null;

declare function xmlHashDefaultDeallocator(entry: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlHashFree(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>): void;

declare function xmlHashLookup(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlHashLookup2(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlHashLookup3(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlHashQLookup(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlHashQLookup2(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlHashQLookup3(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlHashRemoveEntry(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>): number;

declare function xmlHashRemoveEntry2(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>): number;

declare function xmlHashRemoveEntry3(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>): number;

declare function xmlHashScan(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: string | null) => void>, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlHashScan3(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: string | null) => void>, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlHashScanFull(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: string | null, p4: string | null, p5: string | null) => void>, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlHashScanFull3(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: string | null, p4: string | null, p5: string | null) => void>, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlHashSize(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null): number;

interface xmlHashTable {
}
declare var xmlHashTable: interop.StructType<xmlHashTable>;

declare function xmlHashUpdateEntry(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, userdata: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>): number;

declare function xmlHashUpdateEntry2(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, userdata: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>): number;

declare function xmlHashUpdateEntry3(table: interop.Pointer | interop.Reference<xmlHashTable> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, userdata: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>): number;

interface xmlID {
	next: interop.Pointer | interop.Reference<xmlID> | null;
	value: string | null;
	attr: interop.Pointer | interop.Reference<xmlAttr> | null;
	name: string | null;
	lineno: number;
	doc: interop.Pointer | interop.Reference<xmlDoc> | null;
}
declare var xmlID: interop.StructType<xmlID>;

/** Struct tag of {@link xmlID}. */
type _xmlID = xmlID;
declare var _xmlID: typeof xmlID;

declare function xmlIOFTPClose(context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlIOFTPMatch(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlIOFTPOpen(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlIOFTPRead(context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlIOHTTPClose(context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlIOHTTPMatch(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlIOHTTPOpen(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlIOHTTPOpenW(post_uri: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, compression: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlIOHTTPRead(context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlIOParseDTD(sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, input: interop.Pointer | interop.Reference<xmlParserInputBuffer> | ArrayBufferLike | ArrayBufferView | null, enc: xmlCharEncoding): interop.Pointer | interop.Reference<xmlDtd> | null;

declare function xmlInitCharEncodingHandlers(): void;

declare function xmlInitGlobals(): void;

declare function xmlInitMemory(): number;

declare function xmlInitNodeInfoSeq(seq: interop.Pointer | interop.Reference<xmlParserNodeInfoSeq> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlInitParser(): void;

declare function xmlInitParserCtxt(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlInitThreads(): void;

declare function xmlInitializeCatalog(): void;

declare function xmlInitializeDict(): number;

declare function xmlInitializeGlobalState(gs: interop.Pointer | interop.Reference<xmlGlobalState> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlInitializePredefinedEntities(): void;

declare function xmlIsBaseChar(ch: number): number;

declare var xmlIsBaseCharGroup: xmlChRangeGroup;

declare function xmlIsBlank(ch: number): number;

declare function xmlIsBlankNode(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlIsChar(ch: number): number;

declare var xmlIsCharGroup: xmlChRangeGroup;

declare function xmlIsCombining(ch: number): number;

declare var xmlIsCombiningGroup: xmlChRangeGroup;

declare function xmlIsDigit(ch: number): number;

declare var xmlIsDigitGroup: xmlChRangeGroup;

declare function xmlIsExtender(ch: number): number;

declare var xmlIsExtenderGroup: xmlChRangeGroup;

declare function xmlIsID(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, attr: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlIsIdeographic(ch: number): number;

declare var xmlIsIdeographicGroup: xmlChRangeGroup;

declare function xmlIsLetter(c: number): number;

declare function xmlIsMainThread(): number;

declare function xmlIsMixedElement(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlIsPubidChar(ch: number): number;

declare var xmlIsPubidChar_tab: interop.Reference<number>;

declare function xmlIsRef(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, attr: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlIsXHTML(systemID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, publicID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlKeepBlanksDefault(val: number): number;

declare function xmlLastElementChild(parent: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlLineNumbersDefault(val: number): number;

interface xmlLink {
}
declare var xmlLink: interop.StructType<xmlLink>;

declare function xmlLinkGetData(lk: interop.Pointer | interop.Reference<xmlLink> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

interface xmlList {
}
declare var xmlList: interop.StructType<xmlList>;

declare function xmlListAppend(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlListClear(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlListCopy(cur: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null, old: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlListCreate(deallocator: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlLink> | null) => void>, compare: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null) => number>): interop.Pointer | interop.Reference<xmlList> | null;

declare function xmlListDelete(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlListDup(old: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlList> | null;

declare function xmlListEmpty(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlListEnd(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlLink> | null;

declare function xmlListFront(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlLink> | null;

declare function xmlListInsert(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlListMerge(l1: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null, l2: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlListPopBack(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlListPopFront(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlListPushBack(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlListPushFront(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlListRemoveAll(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlListRemoveFirst(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlListRemoveLast(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlListReverse(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlListReverseSearch(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlListReverseWalk(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null, walker: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null) => number>, user: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlListSearch(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlListSize(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlListSort(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlListWalk(l: interop.Pointer | interop.Reference<xmlList> | ArrayBufferLike | ArrayBufferView | null, walker: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null) => number>, user: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlLoadACatalog(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlCatalog> | null;

declare function xmlLoadCatalog(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlLoadCatalogs(paths: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlLoadExternalEntity(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserInput> | null;

declare function xmlLoadSGMLSuperCatalog(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlCatalog> | null;

interface xmlLocationSet {
	locNr: number;
	locMax: number;
	locTab: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlXPathObject> | null> | null;
}
declare var xmlLocationSet: interop.StructType<xmlLocationSet>;

/** Struct tag of {@link xmlLocationSet}. */
type _xmlLocationSet = xmlLocationSet;
declare var _xmlLocationSet: typeof xmlLocationSet;

declare function xmlLockLibrary(): void;

declare function xmlLsCountNode(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlLsOneNode(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): void;

declare var xmlMalloc: interop.FunctionReference<(p1: number) => interop.Pointer | interop.Reference<any> | null>;

declare var xmlMallocAtomic: interop.FunctionReference<(p1: number) => interop.Pointer | interop.Reference<any> | null>;

declare function xmlMallocAtomicLoc(size: number, file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, line: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlMallocLoc(size: number, file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, line: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlMemBlocks(): number;

declare function xmlMemDisplay(fp: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlMemDisplayLast(fp: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, nbBytes: number): void;

declare function xmlMemFree(ptr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlMemGet(freeFunc: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>> | ArrayBufferLike | ArrayBufferView | null, mallocFunc: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: number) => interop.Pointer | interop.Reference<any> | null>> | ArrayBufferLike | ArrayBufferView | null, reallocFunc: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: number) => interop.Pointer | interop.Reference<any> | null>> | ArrayBufferLike | ArrayBufferView | null, strdupFunc: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: string | null) => interop.Pointer | interop.Reference<any> | null>> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlMemMalloc(size: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlMemRealloc(ptr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlMemSetup(freeFunc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>, mallocFunc: interop.FunctionReference<(p1: number) => interop.Pointer | interop.Reference<any> | null>, reallocFunc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: number) => interop.Pointer | interop.Reference<any> | null>, strdupFunc: interop.FunctionReference<(p1: string | null) => interop.Pointer | interop.Reference<any> | null>): number;

declare function xmlMemShow(fp: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, nr: number): void;

declare var xmlMemStrdup: interop.FunctionReference<(p1: string | null) => interop.Pointer | interop.Reference<any> | null>;

declare function xmlMemStrdupLoc(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, line: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlMemUsed(): number;

declare function xmlMemoryDump(): void;

declare function xmlMemoryStrdup(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

interface xmlModule {
}
declare var xmlModule: interop.StructType<xmlModule>;

declare function xmlModuleClose(module: interop.Pointer | interop.Reference<xmlModule> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlModuleFree(module: interop.Pointer | interop.Reference<xmlModule> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlModuleOpen(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlModule> | null;

declare const enum xmlModuleOption {

	LAZY = 1,

	LOCAL = 2
}

declare function xmlModuleSymbol(module: interop.Pointer | interop.Reference<xmlModule> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

interface xmlMutex {
}
declare var xmlMutex: interop.StructType<xmlMutex>;

declare function xmlMutexLock(tok: interop.Pointer | interop.Reference<xmlMutex> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlMutexUnlock(tok: interop.Pointer | interop.Reference<xmlMutex> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlNamespaceParseNCName(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlNamespaceParseNSDef(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlNamespaceParseQName(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, prefix: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlNanoFTPCheckResponse(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoFTPCleanup(): void;

declare function xmlNanoFTPClose(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoFTPCloseConnection(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoFTPConnect(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoFTPConnectTo(server: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, port: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlNanoFTPCwd(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, directory: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoFTPDele(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoFTPFreeCtxt(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlNanoFTPGet(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, callback: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number) => void>, userData: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoFTPGetConnection(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoFTPGetResponse(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoFTPGetSocket(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoFTPInit(): void;

declare function xmlNanoFTPList(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, callback: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null, p4: string | null, p5: string | null, p6: number, p7: number, p8: number, p9: string | null, p10: number, p11: number, p12: number) => void>, userData: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoFTPNewCtxt(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlNanoFTPOpen(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlNanoFTPProxy(host: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, port: number, user: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, passwd: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: number): void;

declare function xmlNanoFTPQuit(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoFTPRead(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, dest: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlNanoFTPScanProxy(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlNanoFTPUpdateURL(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoHTTPAuthHeader(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlNanoHTTPCleanup(): void;

declare function xmlNanoHTTPClose(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlNanoHTTPContentLength(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoHTTPEncoding(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlNanoHTTPFetch(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, contentType: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoHTTPInit(): void;

declare function xmlNanoHTTPMethod(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, method: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, input: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, contentType: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, headers: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ilen: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlNanoHTTPMethodRedir(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, method: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, input: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, contentType: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, redir: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, headers: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ilen: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlNanoHTTPMimeType(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlNanoHTTPOpen(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, contentType: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlNanoHTTPOpenRedir(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, contentType: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, redir: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlNanoHTTPRead(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, dest: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlNanoHTTPRedir(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlNanoHTTPReturnCode(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoHTTPSave(ctxt: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNanoHTTPScanProxy(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlNewAutomata(): interop.Pointer | interop.Reference<xmlAutomata> | null;

declare function xmlNewCDataBlock(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewCatalog(sgml: number): interop.Pointer | interop.Reference<xmlCatalog> | null;

declare function xmlNewCharEncodingHandler(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, input: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<number> | null, p3: string | null, p4: interop.Pointer | interop.Reference<number> | null) => number>, output: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<number> | null, p3: string | null, p4: interop.Pointer | interop.Reference<number> | null) => number>): interop.Pointer | interop.Reference<xmlCharEncodingHandler> | null;

declare function xmlNewCharRef(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewChild(parent: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewComment(content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewDoc(version: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlNewDocComment(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewDocElementContent(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: xmlElementContentType): interop.Pointer | interop.Reference<xmlElementContent> | null;

declare function xmlNewDocFragment(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewDocNode(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewDocNodeEatName(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewDocPI(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewDocProp(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAttr> | null;

declare function xmlNewDocRawNode(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewDocText(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewDocTextLen(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewDtd(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ExternalID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, SystemID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDtd> | null;

declare function xmlNewElementContent(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: xmlElementContentType): interop.Pointer | interop.Reference<xmlElementContent> | null;

declare function xmlNewEntity(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: number, ExternalID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, SystemID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEntity> | null;

declare function xmlNewEntityInputStream(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, entity: interop.Pointer | interop.Reference<xmlEntity> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserInput> | null;

declare function xmlNewGlobalNs(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, href: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNs> | null;

declare function xmlNewIOInputStream(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, input: interop.Pointer | interop.Reference<xmlParserInputBuffer> | ArrayBufferLike | ArrayBufferView | null, enc: xmlCharEncoding): interop.Pointer | interop.Reference<xmlParserInput> | null;

declare function xmlNewInputFromFile(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserInput> | null;

declare function xmlNewInputStream(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserInput> | null;

declare function xmlNewMutex(): interop.Pointer | interop.Reference<xmlMutex> | null;

declare function xmlNewNode(ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewNodeEatName(ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewNs(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, href: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNs> | null;

declare function xmlNewNsProp(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAttr> | null;

declare function xmlNewNsPropEatName(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAttr> | null;

declare function xmlNewPI(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewParserCtxt(): interop.Pointer | interop.Reference<xmlParserCtxt> | null;

declare function xmlNewProp(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAttr> | null;

declare function xmlNewRMutex(): interop.Pointer | interop.Reference<xmlRMutex> | null;

declare function xmlNewReference(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewStringInputStream(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserInput> | null;

declare function xmlNewText(content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewTextChild(parent: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewTextLen(content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNewTextReader(input: interop.Pointer | interop.Reference<xmlParserInputBuffer> | ArrayBufferLike | ArrayBufferView | null, URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlTextReader> | null;

declare function xmlNewTextReaderFilename(URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlTextReader> | null;

declare function xmlNewTextWriter(out: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlTextWriter> | null;

declare function xmlNewTextWriterDoc(doc: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlDoc> | null> | ArrayBufferLike | ArrayBufferView | null, compression: number): interop.Pointer | interop.Reference<xmlTextWriter> | null;

declare function xmlNewTextWriterFilename(uri: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, compression: number): interop.Pointer | interop.Reference<xmlTextWriter> | null;

declare function xmlNewTextWriterMemory(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, compression: number): interop.Pointer | interop.Reference<xmlTextWriter> | null;

declare function xmlNewTextWriterPushParser(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, compression: number): interop.Pointer | interop.Reference<xmlTextWriter> | null;

declare function xmlNewTextWriterTree(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, compression: number): interop.Pointer | interop.Reference<xmlTextWriter> | null;

declare function xmlNewValidCtxt(): interop.Pointer | interop.Reference<xmlValidCtxt> | null;

declare function xmlNextChar(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlNextElementSibling(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlNoNetExternalEntityLoader(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserInput> | null;

interface xmlNode {
	_private: interop.Pointer | interop.Reference<any> | null;
	type: xmlElementType;
	name: string | null;
	children: interop.Pointer | interop.Reference<xmlNode> | null;
	last: interop.Pointer | interop.Reference<xmlNode> | null;
	parent: interop.Pointer | interop.Reference<xmlNode> | null;
	next: interop.Pointer | interop.Reference<xmlNode> | null;
	prev: interop.Pointer | interop.Reference<xmlNode> | null;
	doc: interop.Pointer | interop.Reference<xmlDoc> | null;
	ns: interop.Pointer | interop.Reference<xmlNs> | null;
	content: interop.Pointer | interop.Reference<any> | null;
	properties: interop.Pointer | interop.Reference<xmlAttr> | null;
	nsDef: interop.Pointer | interop.Reference<xmlNs> | null;
	psvi: interop.Pointer | interop.Reference<any> | null;
	line: number;
	extra: number;
}
declare var xmlNode: interop.StructType<xmlNode>;

/** Struct tag of {@link xmlNode}. */
type _xmlNode = xmlNode;
declare var _xmlNode: typeof xmlNode;

declare function xmlNodeAddContent(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlNodeAddContentLen(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): void;

declare function xmlNodeBufGetContent(buffer: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNodeDump(buf: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, level: number, format: number): number;

declare function xmlNodeDumpOutput(buf: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, level: number, format: number, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlNodeGetBase(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlNodeGetContent(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlNodeGetLang(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlNodeGetSpacePreserve(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNodeIsText(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNodeListGetRawString(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, list: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, inLine: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlNodeListGetString(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, list: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, inLine: number): interop.Pointer | interop.Reference<any> | null;

interface xmlNodeSet {
	nodeNr: number;
	nodeMax: number;
	nodeTab: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlNode> | null> | null;
}
declare var xmlNodeSet: interop.StructType<xmlNodeSet>;

/** Struct tag of {@link xmlNodeSet}. */
type _xmlNodeSet = xmlNodeSet;
declare var _xmlNodeSet: typeof xmlNodeSet;

declare function xmlNodeSetBase(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, uri: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlNodeSetContent(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlNodeSetContentLen(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): void;

declare function xmlNodeSetLang(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, lang: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlNodeSetName(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlNodeSetSpacePreserve(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, val: number): void;

declare function xmlNormalizeURIPath(path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlNormalizeWindowsPath(path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

interface xmlNotation {
	name: string | null;
	PublicID: string | null;
	SystemID: string | null;
}
declare var xmlNotation: interop.StructType<xmlNotation>;

/** Struct tag of {@link xmlNotation}. */
type _xmlNotation = xmlNotation;
declare var _xmlNotation: typeof xmlNotation;

interface xmlNs {
	next: interop.Pointer | interop.Reference<xmlNs> | null;
	type: xmlElementType;
	href: string | null;
	prefix: string | null;
	_private: interop.Pointer | interop.Reference<any> | null;
	context: interop.Pointer | interop.Reference<xmlDoc> | null;
}
declare var xmlNs: interop.StructType<xmlNs>;

/** Struct tag of {@link xmlNs}. */
type _xmlNs = xmlNs;
declare var _xmlNs: typeof xmlNs;

interface xmlOutputBuffer {
	context: interop.Pointer | interop.Reference<any> | null;
	writecallback: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number) => number>;
	closecallback: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>;
	encoder: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | null;
	buffer: interop.Pointer | interop.Reference<xmlBuf> | null;
	conv: interop.Pointer | interop.Reference<xmlBuf> | null;
	written: number;
	error: number;
}
declare var xmlOutputBuffer: interop.StructType<xmlOutputBuffer>;

/** Struct tag of {@link xmlOutputBuffer}. */
type _xmlOutputBuffer = xmlOutputBuffer;
declare var _xmlOutputBuffer: typeof xmlOutputBuffer;

declare function xmlOutputBufferClose(out: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlOutputBufferCreateBuffer(buffer: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, encoder: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlOutputBuffer> | null;

declare function xmlOutputBufferCreateFd(fd: number, encoder: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlOutputBuffer> | null;

declare function xmlOutputBufferCreateFile(file: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, encoder: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlOutputBuffer> | null;

declare function xmlOutputBufferCreateFilename(URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoder: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | ArrayBufferLike | ArrayBufferView | null, compression: number): interop.Pointer | interop.Reference<xmlOutputBuffer> | null;

declare function xmlOutputBufferCreateFilenameDefault(func: interop.FunctionReference<(p1: string | null, p2: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | null, p3: number) => interop.Pointer | interop.Reference<xmlOutputBuffer> | null>): interop.FunctionReference<(p1: string | null, p2: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | null, p3: number) => interop.Pointer | interop.Reference<xmlOutputBuffer> | null>;

declare function xmlOutputBufferCreateIO(iowrite: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number) => number>, ioclose: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>, ioctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoder: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlOutputBuffer> | null;

declare function xmlOutputBufferFlush(out: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlOutputBufferGetContent(out: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlOutputBufferGetSize(out: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlOutputBufferWrite(out: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null, len: number, buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlOutputBufferWriteEscape(out: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, escaping: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<number> | null, p3: string | null, p4: interop.Pointer | interop.Reference<number> | null) => number>): number;

declare function xmlOutputBufferWriteString(out: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParseAttValue(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlParseAttribute(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, value: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlParseAttributeListDecl(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseAttributeType(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, tree: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlEnumeration> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParseBalancedChunkMemory(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, user_data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, depth: number, string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, lst: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlNode> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParseBalancedChunkMemoryRecover(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, user_data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, depth: number, string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, lst: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlNode> | null> | ArrayBufferLike | ArrayBufferView | null, recover: number): number;

declare function xmlParseCDSect(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseCatalogFile(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlParseCharData(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, cdata: number): void;

declare function xmlParseCharEncoding(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): xmlCharEncoding;

declare function xmlParseCharRef(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParseChunk(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, chunk: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, terminate: number): number;

declare function xmlParseComment(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseContent(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseCtxtExternalEntity(ctx: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, lst: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlNode> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParseDTD(ExternalID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, SystemID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDtd> | null;

declare function xmlParseDefaultDecl(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, value: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParseDoc(cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlParseDocTypeDecl(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseDocument(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParseElement(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseElementChildrenContentDecl(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, inputchk: number): interop.Pointer | interop.Reference<xmlElementContent> | null;

declare function xmlParseElementContentDecl(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, result: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlElementContent> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParseElementDecl(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParseElementMixedContentDecl(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, inputchk: number): interop.Pointer | interop.Reference<xmlElementContent> | null;

declare function xmlParseEncName(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlParseEncodingDecl(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlParseEndTag(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseEntity(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlParseEntityDecl(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseEntityRef(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEntity> | null;

declare function xmlParseEntityValue(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, orig: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlParseEnumeratedType(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, tree: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlEnumeration> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParseEnumerationType(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEnumeration> | null;

declare function xmlParseExtParsedEnt(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParseExternalEntity(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, user_data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, depth: number, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, lst: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlNode> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParseExternalID(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, publicID: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, strict: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlParseExternalSubset(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, ExternalID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, SystemID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseFile(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlParseInNodeContext(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, data: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, datalen: number, options: number, lst: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlNode> | null> | ArrayBufferLike | ArrayBufferView | null): xmlParserErrors;

declare function xmlParseMarkupDecl(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseMemory(buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlParseMisc(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseName(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlParseNamespace(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseNmtoken(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlParseNotationDecl(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseNotationType(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEnumeration> | null;

declare function xmlParsePEReference(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParsePI(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParsePITarget(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlParsePubidLiteral(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlParseQuotedString(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlParseReference(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseSDDecl(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParseStartTag(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlParseSystemLiteral(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlParseTextDecl(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParseURI(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlURI> | null;

declare function xmlParseURIRaw(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, raw: number): interop.Pointer | interop.Reference<xmlURI> | null;

declare function xmlParseURIReference(uri: interop.Pointer | interop.Reference<xmlURI> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParseVersionInfo(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlParseVersionNum(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlParseXMLDecl(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParserAddNodeInfo(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, info: interop.Pointer | interop.Reference<xmlParserNodeInfo> | ArrayBufferLike | ArrayBufferView | null): void;

interface xmlParserCtxt {
	sax: interop.Pointer | interop.Reference<xmlSAXHandler> | null;
	userData: interop.Pointer | interop.Reference<any> | null;
	myDoc: interop.Pointer | interop.Reference<xmlDoc> | null;
	wellFormed: number;
	replaceEntities: number;
	version: string | null;
	encoding: string | null;
	standalone: number;
	html: number;
	input: interop.Pointer | interop.Reference<xmlParserInput> | null;
	inputNr: number;
	inputMax: number;
	inputTab: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlParserInput> | null> | null;
	node: interop.Pointer | interop.Reference<xmlNode> | null;
	nodeNr: number;
	nodeMax: number;
	nodeTab: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlNode> | null> | null;
	record_info: number;
	node_seq: xmlParserNodeInfoSeq;
	errNo: number;
	hasExternalSubset: number;
	hasPErefs: number;
	external: number;
	valid: number;
	validate: number;
	vctxt: xmlValidCtxt;
	instate: xmlParserInputState;
	token: number;
	directory: interop.Pointer | interop.Reference<any> | null;
	name: string | null;
	nameNr: number;
	nameMax: number;
	nameTab: interop.Pointer | interop.Reference<string | null> | null;
	nbChars: number;
	checkIndex: number;
	keepBlanks: number;
	disableSAX: number;
	inSubset: number;
	intSubName: string | null;
	extSubURI: interop.Pointer | interop.Reference<any> | null;
	extSubSystem: interop.Pointer | interop.Reference<any> | null;
	space: interop.Pointer | interop.Reference<number> | null;
	spaceNr: number;
	spaceMax: number;
	spaceTab: interop.Pointer | interop.Reference<number> | null;
	depth: number;
	entity: interop.Pointer | interop.Reference<xmlParserInput> | null;
	charset: number;
	nodelen: number;
	nodemem: number;
	pedantic: number;
	_private: interop.Pointer | interop.Reference<any> | null;
	loadsubset: number;
	linenumbers: number;
	catalogs: interop.Pointer | interop.Reference<any> | null;
	recovery: number;
	progressive: number;
	dict: interop.Pointer | interop.Reference<xmlDict> | null;
	atts: interop.Pointer | interop.Reference<string | null> | null;
	maxatts: number;
	docdict: number;
	str_xml: string | null;
	str_xmlns: string | null;
	str_xml_ns: string | null;
	sax2: number;
	nsNr: number;
	nsMax: number;
	nsTab: interop.Pointer | interop.Reference<string | null> | null;
	attallocs: interop.Pointer | interop.Reference<number> | null;
	pushTab: interop.Pointer | interop.Reference<xmlStartTag> | null;
	attsDefault: interop.Pointer | interop.Reference<xmlHashTable> | null;
	attsSpecial: interop.Pointer | interop.Reference<xmlHashTable> | null;
	nsWellFormed: number;
	options: number;
	dictNames: number;
	freeElemsNr: number;
	freeElems: interop.Pointer | interop.Reference<xmlNode> | null;
	freeAttrsNr: number;
	freeAttrs: interop.Pointer | interop.Reference<xmlAttr> | null;
	lastError: xmlError;
	parseMode: xmlParserMode;
	nbentities: number;
	sizeentities: number;
	nodeInfo: interop.Pointer | interop.Reference<xmlParserNodeInfo> | null;
	nodeInfoNr: number;
	nodeInfoMax: number;
	nodeInfoTab: interop.Pointer | interop.Reference<xmlParserNodeInfo> | null;
	input_id: number;
	sizeentcopy: number;
}
declare var xmlParserCtxt: interop.StructType<xmlParserCtxt>;

/** Struct tag of {@link xmlParserCtxt}. */
type _xmlParserCtxt = xmlParserCtxt;
declare var _xmlParserCtxt: typeof xmlParserCtxt;

declare function xmlParserError(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, msg: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): void;

declare const enum xmlParserErrors {

	ERR_OK = 0,

	ERR_INTERNAL_ERROR = 1,

	ERR_NO_MEMORY = 2,

	ERR_DOCUMENT_START = 3,

	ERR_DOCUMENT_EMPTY = 4,

	ERR_DOCUMENT_END = 5,

	ERR_INVALID_HEX_CHARREF = 6,

	ERR_INVALID_DEC_CHARREF = 7,

	ERR_INVALID_CHARREF = 8,

	ERR_INVALID_CHAR = 9,

	ERR_CHARREF_AT_EOF = 10,

	ERR_CHARREF_IN_PROLOG = 11,

	ERR_CHARREF_IN_EPILOG = 12,

	ERR_CHARREF_IN_DTD = 13,

	ERR_ENTITYREF_AT_EOF = 14,

	ERR_ENTITYREF_IN_PROLOG = 15,

	ERR_ENTITYREF_IN_EPILOG = 16,

	ERR_ENTITYREF_IN_DTD = 17,

	ERR_PEREF_AT_EOF = 18,

	ERR_PEREF_IN_PROLOG = 19,

	ERR_PEREF_IN_EPILOG = 20,

	ERR_PEREF_IN_INT_SUBSET = 21,

	ERR_ENTITYREF_NO_NAME = 22,

	ERR_ENTITYREF_SEMICOL_MISSING = 23,

	ERR_PEREF_NO_NAME = 24,

	ERR_PEREF_SEMICOL_MISSING = 25,

	ERR_UNDECLARED_ENTITY = 26,

	WAR_UNDECLARED_ENTITY = 27,

	ERR_UNPARSED_ENTITY = 28,

	ERR_ENTITY_IS_EXTERNAL = 29,

	ERR_ENTITY_IS_PARAMETER = 30,

	ERR_UNKNOWN_ENCODING = 31,

	ERR_UNSUPPORTED_ENCODING = 32,

	ERR_STRING_NOT_STARTED = 33,

	ERR_STRING_NOT_CLOSED = 34,

	ERR_NS_DECL_ERROR = 35,

	ERR_ENTITY_NOT_STARTED = 36,

	ERR_ENTITY_NOT_FINISHED = 37,

	ERR_LT_IN_ATTRIBUTE = 38,

	ERR_ATTRIBUTE_NOT_STARTED = 39,

	ERR_ATTRIBUTE_NOT_FINISHED = 40,

	ERR_ATTRIBUTE_WITHOUT_VALUE = 41,

	ERR_ATTRIBUTE_REDEFINED = 42,

	ERR_LITERAL_NOT_STARTED = 43,

	ERR_LITERAL_NOT_FINISHED = 44,

	ERR_COMMENT_NOT_FINISHED = 45,

	ERR_PI_NOT_STARTED = 46,

	ERR_PI_NOT_FINISHED = 47,

	ERR_NOTATION_NOT_STARTED = 48,

	ERR_NOTATION_NOT_FINISHED = 49,

	ERR_ATTLIST_NOT_STARTED = 50,

	ERR_ATTLIST_NOT_FINISHED = 51,

	ERR_MIXED_NOT_STARTED = 52,

	ERR_MIXED_NOT_FINISHED = 53,

	ERR_ELEMCONTENT_NOT_STARTED = 54,

	ERR_ELEMCONTENT_NOT_FINISHED = 55,

	ERR_XMLDECL_NOT_STARTED = 56,

	ERR_XMLDECL_NOT_FINISHED = 57,

	ERR_CONDSEC_NOT_STARTED = 58,

	ERR_CONDSEC_NOT_FINISHED = 59,

	ERR_EXT_SUBSET_NOT_FINISHED = 60,

	ERR_DOCTYPE_NOT_FINISHED = 61,

	ERR_MISPLACED_CDATA_END = 62,

	ERR_CDATA_NOT_FINISHED = 63,

	ERR_RESERVED_XML_NAME = 64,

	ERR_SPACE_REQUIRED = 65,

	ERR_SEPARATOR_REQUIRED = 66,

	ERR_NMTOKEN_REQUIRED = 67,

	ERR_NAME_REQUIRED = 68,

	ERR_PCDATA_REQUIRED = 69,

	ERR_URI_REQUIRED = 70,

	ERR_PUBID_REQUIRED = 71,

	ERR_LT_REQUIRED = 72,

	ERR_GT_REQUIRED = 73,

	ERR_LTSLASH_REQUIRED = 74,

	ERR_EQUAL_REQUIRED = 75,

	ERR_TAG_NAME_MISMATCH = 76,

	ERR_TAG_NOT_FINISHED = 77,

	ERR_STANDALONE_VALUE = 78,

	ERR_ENCODING_NAME = 79,

	ERR_HYPHEN_IN_COMMENT = 80,

	ERR_INVALID_ENCODING = 81,

	ERR_EXT_ENTITY_STANDALONE = 82,

	ERR_CONDSEC_INVALID = 83,

	ERR_VALUE_REQUIRED = 84,

	ERR_NOT_WELL_BALANCED = 85,

	ERR_EXTRA_CONTENT = 86,

	ERR_ENTITY_CHAR_ERROR = 87,

	ERR_ENTITY_PE_INTERNAL = 88,

	ERR_ENTITY_LOOP = 89,

	ERR_ENTITY_BOUNDARY = 90,

	ERR_INVALID_URI = 91,

	ERR_URI_FRAGMENT = 92,

	WAR_CATALOG_PI = 93,

	ERR_NO_DTD = 94,

	ERR_CONDSEC_INVALID_KEYWORD = 95,

	ERR_VERSION_MISSING = 96,

	WAR_UNKNOWN_VERSION = 97,

	WAR_LANG_VALUE = 98,

	WAR_NS_URI = 99,

	WAR_NS_URI_RELATIVE = 100,

	ERR_MISSING_ENCODING = 101,

	WAR_SPACE_VALUE = 102,

	ERR_NOT_STANDALONE = 103,

	ERR_ENTITY_PROCESSING = 104,

	ERR_NOTATION_PROCESSING = 105,

	WAR_NS_COLUMN = 106,

	WAR_ENTITY_REDEFINED = 107,

	ERR_UNKNOWN_VERSION = 108,

	ERR_VERSION_MISMATCH = 109,

	ERR_NAME_TOO_LONG = 110,

	ERR_USER_STOP = 111,

	NS_ERR_XML_NAMESPACE = 200,

	NS_ERR_UNDEFINED_NAMESPACE = 201,

	NS_ERR_QNAME = 202,

	NS_ERR_ATTRIBUTE_REDEFINED = 203,

	NS_ERR_EMPTY = 204,

	NS_ERR_COLON = 205,

	DTD_ATTRIBUTE_DEFAULT = 500,

	DTD_ATTRIBUTE_REDEFINED = 501,

	DTD_ATTRIBUTE_VALUE = 502,

	DTD_CONTENT_ERROR = 503,

	DTD_CONTENT_MODEL = 504,

	DTD_CONTENT_NOT_DETERMINIST = 505,

	DTD_DIFFERENT_PREFIX = 506,

	DTD_ELEM_DEFAULT_NAMESPACE = 507,

	DTD_ELEM_NAMESPACE = 508,

	DTD_ELEM_REDEFINED = 509,

	DTD_EMPTY_NOTATION = 510,

	DTD_ENTITY_TYPE = 511,

	DTD_ID_FIXED = 512,

	DTD_ID_REDEFINED = 513,

	DTD_ID_SUBSET = 514,

	DTD_INVALID_CHILD = 515,

	DTD_INVALID_DEFAULT = 516,

	DTD_LOAD_ERROR = 517,

	DTD_MISSING_ATTRIBUTE = 518,

	DTD_MIXED_CORRUPT = 519,

	DTD_MULTIPLE_ID = 520,

	DTD_NO_DOC = 521,

	DTD_NO_DTD = 522,

	DTD_NO_ELEM_NAME = 523,

	DTD_NO_PREFIX = 524,

	DTD_NO_ROOT = 525,

	DTD_NOTATION_REDEFINED = 526,

	DTD_NOTATION_VALUE = 527,

	DTD_NOT_EMPTY = 528,

	DTD_NOT_PCDATA = 529,

	DTD_NOT_STANDALONE = 530,

	DTD_ROOT_NAME = 531,

	DTD_STANDALONE_WHITE_SPACE = 532,

	DTD_UNKNOWN_ATTRIBUTE = 533,

	DTD_UNKNOWN_ELEM = 534,

	DTD_UNKNOWN_ENTITY = 535,

	DTD_UNKNOWN_ID = 536,

	DTD_UNKNOWN_NOTATION = 537,

	DTD_STANDALONE_DEFAULTED = 538,

	DTD_XMLID_VALUE = 539,

	DTD_XMLID_TYPE = 540,

	DTD_DUP_TOKEN = 541,

	HTML_STRUCURE_ERROR = 800,

	HTML_UNKNOWN_TAG = 801,

	RNGP_ANYNAME_ATTR_ANCESTOR = 1000,

	RNGP_ATTR_CONFLICT = 1001,

	RNGP_ATTRIBUTE_CHILDREN = 1002,

	RNGP_ATTRIBUTE_CONTENT = 1003,

	RNGP_ATTRIBUTE_EMPTY = 1004,

	RNGP_ATTRIBUTE_NOOP = 1005,

	RNGP_CHOICE_CONTENT = 1006,

	RNGP_CHOICE_EMPTY = 1007,

	RNGP_CREATE_FAILURE = 1008,

	RNGP_DATA_CONTENT = 1009,

	RNGP_DEF_CHOICE_AND_INTERLEAVE = 1010,

	RNGP_DEFINE_CREATE_FAILED = 1011,

	RNGP_DEFINE_EMPTY = 1012,

	RNGP_DEFINE_MISSING = 1013,

	RNGP_DEFINE_NAME_MISSING = 1014,

	RNGP_ELEM_CONTENT_EMPTY = 1015,

	RNGP_ELEM_CONTENT_ERROR = 1016,

	RNGP_ELEMENT_EMPTY = 1017,

	RNGP_ELEMENT_CONTENT = 1018,

	RNGP_ELEMENT_NAME = 1019,

	RNGP_ELEMENT_NO_CONTENT = 1020,

	RNGP_ELEM_TEXT_CONFLICT = 1021,

	RNGP_EMPTY = 1022,

	RNGP_EMPTY_CONSTRUCT = 1023,

	RNGP_EMPTY_CONTENT = 1024,

	RNGP_EMPTY_NOT_EMPTY = 1025,

	RNGP_ERROR_TYPE_LIB = 1026,

	RNGP_EXCEPT_EMPTY = 1027,

	RNGP_EXCEPT_MISSING = 1028,

	RNGP_EXCEPT_MULTIPLE = 1029,

	RNGP_EXCEPT_NO_CONTENT = 1030,

	RNGP_EXTERNALREF_EMTPY = 1031,

	RNGP_EXTERNAL_REF_FAILURE = 1032,

	RNGP_EXTERNALREF_RECURSE = 1033,

	RNGP_FORBIDDEN_ATTRIBUTE = 1034,

	RNGP_FOREIGN_ELEMENT = 1035,

	RNGP_GRAMMAR_CONTENT = 1036,

	RNGP_GRAMMAR_EMPTY = 1037,

	RNGP_GRAMMAR_MISSING = 1038,

	RNGP_GRAMMAR_NO_START = 1039,

	RNGP_GROUP_ATTR_CONFLICT = 1040,

	RNGP_HREF_ERROR = 1041,

	RNGP_INCLUDE_EMPTY = 1042,

	RNGP_INCLUDE_FAILURE = 1043,

	RNGP_INCLUDE_RECURSE = 1044,

	RNGP_INTERLEAVE_ADD = 1045,

	RNGP_INTERLEAVE_CREATE_FAILED = 1046,

	RNGP_INTERLEAVE_EMPTY = 1047,

	RNGP_INTERLEAVE_NO_CONTENT = 1048,

	RNGP_INVALID_DEFINE_NAME = 1049,

	RNGP_INVALID_URI = 1050,

	RNGP_INVALID_VALUE = 1051,

	RNGP_MISSING_HREF = 1052,

	RNGP_NAME_MISSING = 1053,

	RNGP_NEED_COMBINE = 1054,

	RNGP_NOTALLOWED_NOT_EMPTY = 1055,

	RNGP_NSNAME_ATTR_ANCESTOR = 1056,

	RNGP_NSNAME_NO_NS = 1057,

	RNGP_PARAM_FORBIDDEN = 1058,

	RNGP_PARAM_NAME_MISSING = 1059,

	RNGP_PARENTREF_CREATE_FAILED = 1060,

	RNGP_PARENTREF_NAME_INVALID = 1061,

	RNGP_PARENTREF_NO_NAME = 1062,

	RNGP_PARENTREF_NO_PARENT = 1063,

	RNGP_PARENTREF_NOT_EMPTY = 1064,

	RNGP_PARSE_ERROR = 1065,

	RNGP_PAT_ANYNAME_EXCEPT_ANYNAME = 1066,

	RNGP_PAT_ATTR_ATTR = 1067,

	RNGP_PAT_ATTR_ELEM = 1068,

	RNGP_PAT_DATA_EXCEPT_ATTR = 1069,

	RNGP_PAT_DATA_EXCEPT_ELEM = 1070,

	RNGP_PAT_DATA_EXCEPT_EMPTY = 1071,

	RNGP_PAT_DATA_EXCEPT_GROUP = 1072,

	RNGP_PAT_DATA_EXCEPT_INTERLEAVE = 1073,

	RNGP_PAT_DATA_EXCEPT_LIST = 1074,

	RNGP_PAT_DATA_EXCEPT_ONEMORE = 1075,

	RNGP_PAT_DATA_EXCEPT_REF = 1076,

	RNGP_PAT_DATA_EXCEPT_TEXT = 1077,

	RNGP_PAT_LIST_ATTR = 1078,

	RNGP_PAT_LIST_ELEM = 1079,

	RNGP_PAT_LIST_INTERLEAVE = 1080,

	RNGP_PAT_LIST_LIST = 1081,

	RNGP_PAT_LIST_REF = 1082,

	RNGP_PAT_LIST_TEXT = 1083,

	RNGP_PAT_NSNAME_EXCEPT_ANYNAME = 1084,

	RNGP_PAT_NSNAME_EXCEPT_NSNAME = 1085,

	RNGP_PAT_ONEMORE_GROUP_ATTR = 1086,

	RNGP_PAT_ONEMORE_INTERLEAVE_ATTR = 1087,

	RNGP_PAT_START_ATTR = 1088,

	RNGP_PAT_START_DATA = 1089,

	RNGP_PAT_START_EMPTY = 1090,

	RNGP_PAT_START_GROUP = 1091,

	RNGP_PAT_START_INTERLEAVE = 1092,

	RNGP_PAT_START_LIST = 1093,

	RNGP_PAT_START_ONEMORE = 1094,

	RNGP_PAT_START_TEXT = 1095,

	RNGP_PAT_START_VALUE = 1096,

	RNGP_PREFIX_UNDEFINED = 1097,

	RNGP_REF_CREATE_FAILED = 1098,

	RNGP_REF_CYCLE = 1099,

	RNGP_REF_NAME_INVALID = 1100,

	RNGP_REF_NO_DEF = 1101,

	RNGP_REF_NO_NAME = 1102,

	RNGP_REF_NOT_EMPTY = 1103,

	RNGP_START_CHOICE_AND_INTERLEAVE = 1104,

	RNGP_START_CONTENT = 1105,

	RNGP_START_EMPTY = 1106,

	RNGP_START_MISSING = 1107,

	RNGP_TEXT_EXPECTED = 1108,

	RNGP_TEXT_HAS_CHILD = 1109,

	RNGP_TYPE_MISSING = 1110,

	RNGP_TYPE_NOT_FOUND = 1111,

	RNGP_TYPE_VALUE = 1112,

	RNGP_UNKNOWN_ATTRIBUTE = 1113,

	RNGP_UNKNOWN_COMBINE = 1114,

	RNGP_UNKNOWN_CONSTRUCT = 1115,

	RNGP_UNKNOWN_TYPE_LIB = 1116,

	RNGP_URI_FRAGMENT = 1117,

	RNGP_URI_NOT_ABSOLUTE = 1118,

	RNGP_VALUE_EMPTY = 1119,

	RNGP_VALUE_NO_CONTENT = 1120,

	RNGP_XMLNS_NAME = 1121,

	RNGP_XML_NS = 1122,

	XPATH_EXPRESSION_OK = 1200,

	XPATH_NUMBER_ERROR = 1201,

	XPATH_UNFINISHED_LITERAL_ERROR = 1202,

	XPATH_START_LITERAL_ERROR = 1203,

	XPATH_VARIABLE_REF_ERROR = 1204,

	XPATH_UNDEF_VARIABLE_ERROR = 1205,

	XPATH_INVALID_PREDICATE_ERROR = 1206,

	XPATH_EXPR_ERROR = 1207,

	XPATH_UNCLOSED_ERROR = 1208,

	XPATH_UNKNOWN_FUNC_ERROR = 1209,

	XPATH_INVALID_OPERAND = 1210,

	XPATH_INVALID_TYPE = 1211,

	XPATH_INVALID_ARITY = 1212,

	XPATH_INVALID_CTXT_SIZE = 1213,

	XPATH_INVALID_CTXT_POSITION = 1214,

	XPATH_MEMORY_ERROR = 1215,

	XPTR_SYNTAX_ERROR = 1216,

	XPTR_RESOURCE_ERROR = 1217,

	XPTR_SUB_RESOURCE_ERROR = 1218,

	XPATH_UNDEF_PREFIX_ERROR = 1219,

	XPATH_ENCODING_ERROR = 1220,

	XPATH_INVALID_CHAR_ERROR = 1221,

	TREE_INVALID_HEX = 1300,

	TREE_INVALID_DEC = 1301,

	TREE_UNTERMINATED_ENTITY = 1302,

	TREE_NOT_UTF8 = 1303,

	SAVE_NOT_UTF8 = 1400,

	SAVE_CHAR_INVALID = 1401,

	SAVE_NO_DOCTYPE = 1402,

	SAVE_UNKNOWN_ENCODING = 1403,

	REGEXP_COMPILE_ERROR = 1450,

	IO_UNKNOWN = 1500,

	IO_EACCES = 1501,

	IO_EAGAIN = 1502,

	IO_EBADF = 1503,

	IO_EBADMSG = 1504,

	IO_EBUSY = 1505,

	IO_ECANCELED = 1506,

	IO_ECHILD = 1507,

	IO_EDEADLK = 1508,

	IO_EDOM = 1509,

	IO_EEXIST = 1510,

	IO_EFAULT = 1511,

	IO_EFBIG = 1512,

	IO_EINPROGRESS = 1513,

	IO_EINTR = 1514,

	IO_EINVAL = 1515,

	IO_EIO = 1516,

	IO_EISDIR = 1517,

	IO_EMFILE = 1518,

	IO_EMLINK = 1519,

	IO_EMSGSIZE = 1520,

	IO_ENAMETOOLONG = 1521,

	IO_ENFILE = 1522,

	IO_ENODEV = 1523,

	IO_ENOENT = 1524,

	IO_ENOEXEC = 1525,

	IO_ENOLCK = 1526,

	IO_ENOMEM = 1527,

	IO_ENOSPC = 1528,

	IO_ENOSYS = 1529,

	IO_ENOTDIR = 1530,

	IO_ENOTEMPTY = 1531,

	IO_ENOTSUP = 1532,

	IO_ENOTTY = 1533,

	IO_ENXIO = 1534,

	IO_EPERM = 1535,

	IO_EPIPE = 1536,

	IO_ERANGE = 1537,

	IO_EROFS = 1538,

	IO_ESPIPE = 1539,

	IO_ESRCH = 1540,

	IO_ETIMEDOUT = 1541,

	IO_EXDEV = 1542,

	IO_NETWORK_ATTEMPT = 1543,

	IO_ENCODER = 1544,

	IO_FLUSH = 1545,

	IO_WRITE = 1546,

	IO_NO_INPUT = 1547,

	IO_BUFFER_FULL = 1548,

	IO_LOAD_ERROR = 1549,

	IO_ENOTSOCK = 1550,

	IO_EISCONN = 1551,

	IO_ECONNREFUSED = 1552,

	IO_ENETUNREACH = 1553,

	IO_EADDRINUSE = 1554,

	IO_EALREADY = 1555,

	IO_EAFNOSUPPORT = 1556,

	XINCLUDE_RECURSION = 1600,

	XINCLUDE_PARSE_VALUE = 1601,

	XINCLUDE_ENTITY_DEF_MISMATCH = 1602,

	XINCLUDE_NO_HREF = 1603,

	XINCLUDE_NO_FALLBACK = 1604,

	XINCLUDE_HREF_URI = 1605,

	XINCLUDE_TEXT_FRAGMENT = 1606,

	XINCLUDE_TEXT_DOCUMENT = 1607,

	XINCLUDE_INVALID_CHAR = 1608,

	XINCLUDE_BUILD_FAILED = 1609,

	XINCLUDE_UNKNOWN_ENCODING = 1610,

	XINCLUDE_MULTIPLE_ROOT = 1611,

	XINCLUDE_XPTR_FAILED = 1612,

	XINCLUDE_XPTR_RESULT = 1613,

	XINCLUDE_INCLUDE_IN_INCLUDE = 1614,

	XINCLUDE_FALLBACKS_IN_INCLUDE = 1615,

	XINCLUDE_FALLBACK_NOT_IN_INCLUDE = 1616,

	XINCLUDE_DEPRECATED_NS = 1617,

	XINCLUDE_FRAGMENT_ID = 1618,

	CATALOG_MISSING_ATTR = 1650,

	CATALOG_ENTRY_BROKEN = 1651,

	CATALOG_PREFER_VALUE = 1652,

	CATALOG_NOT_CATALOG = 1653,

	CATALOG_RECURSION = 1654,

	SCHEMAP_PREFIX_UNDEFINED = 1700,

	SCHEMAP_ATTRFORMDEFAULT_VALUE = 1701,

	SCHEMAP_ATTRGRP_NONAME_NOREF = 1702,

	SCHEMAP_ATTR_NONAME_NOREF = 1703,

	SCHEMAP_COMPLEXTYPE_NONAME_NOREF = 1704,

	SCHEMAP_ELEMFORMDEFAULT_VALUE = 1705,

	SCHEMAP_ELEM_NONAME_NOREF = 1706,

	SCHEMAP_EXTENSION_NO_BASE = 1707,

	SCHEMAP_FACET_NO_VALUE = 1708,

	SCHEMAP_FAILED_BUILD_IMPORT = 1709,

	SCHEMAP_GROUP_NONAME_NOREF = 1710,

	SCHEMAP_IMPORT_NAMESPACE_NOT_URI = 1711,

	SCHEMAP_IMPORT_REDEFINE_NSNAME = 1712,

	SCHEMAP_IMPORT_SCHEMA_NOT_URI = 1713,

	SCHEMAP_INVALID_BOOLEAN = 1714,

	SCHEMAP_INVALID_ENUM = 1715,

	SCHEMAP_INVALID_FACET = 1716,

	SCHEMAP_INVALID_FACET_VALUE = 1717,

	SCHEMAP_INVALID_MAXOCCURS = 1718,

	SCHEMAP_INVALID_MINOCCURS = 1719,

	SCHEMAP_INVALID_REF_AND_SUBTYPE = 1720,

	SCHEMAP_INVALID_WHITE_SPACE = 1721,

	SCHEMAP_NOATTR_NOREF = 1722,

	SCHEMAP_NOTATION_NO_NAME = 1723,

	SCHEMAP_NOTYPE_NOREF = 1724,

	SCHEMAP_REF_AND_SUBTYPE = 1725,

	SCHEMAP_RESTRICTION_NONAME_NOREF = 1726,

	SCHEMAP_SIMPLETYPE_NONAME = 1727,

	SCHEMAP_TYPE_AND_SUBTYPE = 1728,

	SCHEMAP_UNKNOWN_ALL_CHILD = 1729,

	SCHEMAP_UNKNOWN_ANYATTRIBUTE_CHILD = 1730,

	SCHEMAP_UNKNOWN_ATTR_CHILD = 1731,

	SCHEMAP_UNKNOWN_ATTRGRP_CHILD = 1732,

	SCHEMAP_UNKNOWN_ATTRIBUTE_GROUP = 1733,

	SCHEMAP_UNKNOWN_BASE_TYPE = 1734,

	SCHEMAP_UNKNOWN_CHOICE_CHILD = 1735,

	SCHEMAP_UNKNOWN_COMPLEXCONTENT_CHILD = 1736,

	SCHEMAP_UNKNOWN_COMPLEXTYPE_CHILD = 1737,

	SCHEMAP_UNKNOWN_ELEM_CHILD = 1738,

	SCHEMAP_UNKNOWN_EXTENSION_CHILD = 1739,

	SCHEMAP_UNKNOWN_FACET_CHILD = 1740,

	SCHEMAP_UNKNOWN_FACET_TYPE = 1741,

	SCHEMAP_UNKNOWN_GROUP_CHILD = 1742,

	SCHEMAP_UNKNOWN_IMPORT_CHILD = 1743,

	SCHEMAP_UNKNOWN_LIST_CHILD = 1744,

	SCHEMAP_UNKNOWN_NOTATION_CHILD = 1745,

	SCHEMAP_UNKNOWN_PROCESSCONTENT_CHILD = 1746,

	SCHEMAP_UNKNOWN_REF = 1747,

	SCHEMAP_UNKNOWN_RESTRICTION_CHILD = 1748,

	SCHEMAP_UNKNOWN_SCHEMAS_CHILD = 1749,

	SCHEMAP_UNKNOWN_SEQUENCE_CHILD = 1750,

	SCHEMAP_UNKNOWN_SIMPLECONTENT_CHILD = 1751,

	SCHEMAP_UNKNOWN_SIMPLETYPE_CHILD = 1752,

	SCHEMAP_UNKNOWN_TYPE = 1753,

	SCHEMAP_UNKNOWN_UNION_CHILD = 1754,

	SCHEMAP_ELEM_DEFAULT_FIXED = 1755,

	SCHEMAP_REGEXP_INVALID = 1756,

	SCHEMAP_FAILED_LOAD = 1757,

	SCHEMAP_NOTHING_TO_PARSE = 1758,

	SCHEMAP_NOROOT = 1759,

	SCHEMAP_REDEFINED_GROUP = 1760,

	SCHEMAP_REDEFINED_TYPE = 1761,

	SCHEMAP_REDEFINED_ELEMENT = 1762,

	SCHEMAP_REDEFINED_ATTRGROUP = 1763,

	SCHEMAP_REDEFINED_ATTR = 1764,

	SCHEMAP_REDEFINED_NOTATION = 1765,

	SCHEMAP_FAILED_PARSE = 1766,

	SCHEMAP_UNKNOWN_PREFIX = 1767,

	SCHEMAP_DEF_AND_PREFIX = 1768,

	SCHEMAP_UNKNOWN_INCLUDE_CHILD = 1769,

	SCHEMAP_INCLUDE_SCHEMA_NOT_URI = 1770,

	SCHEMAP_INCLUDE_SCHEMA_NO_URI = 1771,

	SCHEMAP_NOT_SCHEMA = 1772,

	SCHEMAP_UNKNOWN_MEMBER_TYPE = 1773,

	SCHEMAP_INVALID_ATTR_USE = 1774,

	SCHEMAP_RECURSIVE = 1775,

	SCHEMAP_SUPERNUMEROUS_LIST_ITEM_TYPE = 1776,

	SCHEMAP_INVALID_ATTR_COMBINATION = 1777,

	SCHEMAP_INVALID_ATTR_INLINE_COMBINATION = 1778,

	SCHEMAP_MISSING_SIMPLETYPE_CHILD = 1779,

	SCHEMAP_INVALID_ATTR_NAME = 1780,

	SCHEMAP_REF_AND_CONTENT = 1781,

	SCHEMAP_CT_PROPS_CORRECT_1 = 1782,

	SCHEMAP_CT_PROPS_CORRECT_2 = 1783,

	SCHEMAP_CT_PROPS_CORRECT_3 = 1784,

	SCHEMAP_CT_PROPS_CORRECT_4 = 1785,

	SCHEMAP_CT_PROPS_CORRECT_5 = 1786,

	SCHEMAP_DERIVATION_OK_RESTRICTION_1 = 1787,

	SCHEMAP_DERIVATION_OK_RESTRICTION_2_1_1 = 1788,

	SCHEMAP_DERIVATION_OK_RESTRICTION_2_1_2 = 1789,

	SCHEMAP_DERIVATION_OK_RESTRICTION_2_2 = 1790,

	SCHEMAP_DERIVATION_OK_RESTRICTION_3 = 1791,

	SCHEMAP_WILDCARD_INVALID_NS_MEMBER = 1792,

	SCHEMAP_INTERSECTION_NOT_EXPRESSIBLE = 1793,

	SCHEMAP_UNION_NOT_EXPRESSIBLE = 1794,

	SCHEMAP_SRC_IMPORT_3_1 = 1795,

	SCHEMAP_SRC_IMPORT_3_2 = 1796,

	SCHEMAP_DERIVATION_OK_RESTRICTION_4_1 = 1797,

	SCHEMAP_DERIVATION_OK_RESTRICTION_4_2 = 1798,

	SCHEMAP_DERIVATION_OK_RESTRICTION_4_3 = 1799,

	SCHEMAP_COS_CT_EXTENDS_1_3 = 1800,

	SCHEMAV_NOROOT = 1801,

	SCHEMAV_UNDECLAREDELEM = 1802,

	SCHEMAV_NOTTOPLEVEL = 1803,

	SCHEMAV_MISSING = 1804,

	SCHEMAV_WRONGELEM = 1805,

	SCHEMAV_NOTYPE = 1806,

	SCHEMAV_NOROLLBACK = 1807,

	SCHEMAV_ISABSTRACT = 1808,

	SCHEMAV_NOTEMPTY = 1809,

	SCHEMAV_ELEMCONT = 1810,

	SCHEMAV_HAVEDEFAULT = 1811,

	SCHEMAV_NOTNILLABLE = 1812,

	SCHEMAV_EXTRACONTENT = 1813,

	SCHEMAV_INVALIDATTR = 1814,

	SCHEMAV_INVALIDELEM = 1815,

	SCHEMAV_NOTDETERMINIST = 1816,

	SCHEMAV_CONSTRUCT = 1817,

	SCHEMAV_INTERNAL = 1818,

	SCHEMAV_NOTSIMPLE = 1819,

	SCHEMAV_ATTRUNKNOWN = 1820,

	SCHEMAV_ATTRINVALID = 1821,

	SCHEMAV_VALUE = 1822,

	SCHEMAV_FACET = 1823,

	SCHEMAV_CVC_DATATYPE_VALID_1_2_1 = 1824,

	SCHEMAV_CVC_DATATYPE_VALID_1_2_2 = 1825,

	SCHEMAV_CVC_DATATYPE_VALID_1_2_3 = 1826,

	SCHEMAV_CVC_TYPE_3_1_1 = 1827,

	SCHEMAV_CVC_TYPE_3_1_2 = 1828,

	SCHEMAV_CVC_FACET_VALID = 1829,

	SCHEMAV_CVC_LENGTH_VALID = 1830,

	SCHEMAV_CVC_MINLENGTH_VALID = 1831,

	SCHEMAV_CVC_MAXLENGTH_VALID = 1832,

	SCHEMAV_CVC_MININCLUSIVE_VALID = 1833,

	SCHEMAV_CVC_MAXINCLUSIVE_VALID = 1834,

	SCHEMAV_CVC_MINEXCLUSIVE_VALID = 1835,

	SCHEMAV_CVC_MAXEXCLUSIVE_VALID = 1836,

	SCHEMAV_CVC_TOTALDIGITS_VALID = 1837,

	SCHEMAV_CVC_FRACTIONDIGITS_VALID = 1838,

	SCHEMAV_CVC_PATTERN_VALID = 1839,

	SCHEMAV_CVC_ENUMERATION_VALID = 1840,

	SCHEMAV_CVC_COMPLEX_TYPE_2_1 = 1841,

	SCHEMAV_CVC_COMPLEX_TYPE_2_2 = 1842,

	SCHEMAV_CVC_COMPLEX_TYPE_2_3 = 1843,

	SCHEMAV_CVC_COMPLEX_TYPE_2_4 = 1844,

	SCHEMAV_CVC_ELT_1 = 1845,

	SCHEMAV_CVC_ELT_2 = 1846,

	SCHEMAV_CVC_ELT_3_1 = 1847,

	SCHEMAV_CVC_ELT_3_2_1 = 1848,

	SCHEMAV_CVC_ELT_3_2_2 = 1849,

	SCHEMAV_CVC_ELT_4_1 = 1850,

	SCHEMAV_CVC_ELT_4_2 = 1851,

	SCHEMAV_CVC_ELT_4_3 = 1852,

	SCHEMAV_CVC_ELT_5_1_1 = 1853,

	SCHEMAV_CVC_ELT_5_1_2 = 1854,

	SCHEMAV_CVC_ELT_5_2_1 = 1855,

	SCHEMAV_CVC_ELT_5_2_2_1 = 1856,

	SCHEMAV_CVC_ELT_5_2_2_2_1 = 1857,

	SCHEMAV_CVC_ELT_5_2_2_2_2 = 1858,

	SCHEMAV_CVC_ELT_6 = 1859,

	SCHEMAV_CVC_ELT_7 = 1860,

	SCHEMAV_CVC_ATTRIBUTE_1 = 1861,

	SCHEMAV_CVC_ATTRIBUTE_2 = 1862,

	SCHEMAV_CVC_ATTRIBUTE_3 = 1863,

	SCHEMAV_CVC_ATTRIBUTE_4 = 1864,

	SCHEMAV_CVC_COMPLEX_TYPE_3_1 = 1865,

	SCHEMAV_CVC_COMPLEX_TYPE_3_2_1 = 1866,

	SCHEMAV_CVC_COMPLEX_TYPE_3_2_2 = 1867,

	SCHEMAV_CVC_COMPLEX_TYPE_4 = 1868,

	SCHEMAV_CVC_COMPLEX_TYPE_5_1 = 1869,

	SCHEMAV_CVC_COMPLEX_TYPE_5_2 = 1870,

	SCHEMAV_ELEMENT_CONTENT = 1871,

	SCHEMAV_DOCUMENT_ELEMENT_MISSING = 1872,

	SCHEMAV_CVC_COMPLEX_TYPE_1 = 1873,

	SCHEMAV_CVC_AU = 1874,

	SCHEMAV_CVC_TYPE_1 = 1875,

	SCHEMAV_CVC_TYPE_2 = 1876,

	SCHEMAV_CVC_IDC = 1877,

	SCHEMAV_CVC_WILDCARD = 1878,

	SCHEMAV_MISC = 1879,

	XPTR_UNKNOWN_SCHEME = 1900,

	XPTR_CHILDSEQ_START = 1901,

	XPTR_EVAL_FAILED = 1902,

	XPTR_EXTRA_OBJECTS = 1903,

	C14N_CREATE_CTXT = 1950,

	C14N_REQUIRES_UTF8 = 1951,

	C14N_CREATE_STACK = 1952,

	C14N_INVALID_NODE = 1953,

	C14N_UNKNOW_NODE = 1954,

	C14N_RELATIVE_NAMESPACE = 1955,

	FTP_PASV_ANSWER = 2000,

	FTP_EPSV_ANSWER = 2001,

	FTP_ACCNT = 2002,

	FTP_URL_SYNTAX = 2003,

	HTTP_URL_SYNTAX = 2020,

	HTTP_USE_IP = 2021,

	HTTP_UNKNOWN_HOST = 2022,

	SCHEMAP_SRC_SIMPLE_TYPE_1 = 3000,

	SCHEMAP_SRC_SIMPLE_TYPE_2 = 3001,

	SCHEMAP_SRC_SIMPLE_TYPE_3 = 3002,

	SCHEMAP_SRC_SIMPLE_TYPE_4 = 3003,

	SCHEMAP_SRC_RESOLVE = 3004,

	SCHEMAP_SRC_RESTRICTION_BASE_OR_SIMPLETYPE = 3005,

	SCHEMAP_SRC_LIST_ITEMTYPE_OR_SIMPLETYPE = 3006,

	SCHEMAP_SRC_UNION_MEMBERTYPES_OR_SIMPLETYPES = 3007,

	SCHEMAP_ST_PROPS_CORRECT_1 = 3008,

	SCHEMAP_ST_PROPS_CORRECT_2 = 3009,

	SCHEMAP_ST_PROPS_CORRECT_3 = 3010,

	SCHEMAP_COS_ST_RESTRICTS_1_1 = 3011,

	SCHEMAP_COS_ST_RESTRICTS_1_2 = 3012,

	SCHEMAP_COS_ST_RESTRICTS_1_3_1 = 3013,

	SCHEMAP_COS_ST_RESTRICTS_1_3_2 = 3014,

	SCHEMAP_COS_ST_RESTRICTS_2_1 = 3015,

	SCHEMAP_COS_ST_RESTRICTS_2_3_1_1 = 3016,

	SCHEMAP_COS_ST_RESTRICTS_2_3_1_2 = 3017,

	SCHEMAP_COS_ST_RESTRICTS_2_3_2_1 = 3018,

	SCHEMAP_COS_ST_RESTRICTS_2_3_2_2 = 3019,

	SCHEMAP_COS_ST_RESTRICTS_2_3_2_3 = 3020,

	SCHEMAP_COS_ST_RESTRICTS_2_3_2_4 = 3021,

	SCHEMAP_COS_ST_RESTRICTS_2_3_2_5 = 3022,

	SCHEMAP_COS_ST_RESTRICTS_3_1 = 3023,

	SCHEMAP_COS_ST_RESTRICTS_3_3_1 = 3024,

	SCHEMAP_COS_ST_RESTRICTS_3_3_1_2 = 3025,

	SCHEMAP_COS_ST_RESTRICTS_3_3_2_2 = 3026,

	SCHEMAP_COS_ST_RESTRICTS_3_3_2_1 = 3027,

	SCHEMAP_COS_ST_RESTRICTS_3_3_2_3 = 3028,

	SCHEMAP_COS_ST_RESTRICTS_3_3_2_4 = 3029,

	SCHEMAP_COS_ST_RESTRICTS_3_3_2_5 = 3030,

	SCHEMAP_COS_ST_DERIVED_OK_2_1 = 3031,

	SCHEMAP_COS_ST_DERIVED_OK_2_2 = 3032,

	SCHEMAP_S4S_ELEM_NOT_ALLOWED = 3033,

	SCHEMAP_S4S_ELEM_MISSING = 3034,

	SCHEMAP_S4S_ATTR_NOT_ALLOWED = 3035,

	SCHEMAP_S4S_ATTR_MISSING = 3036,

	SCHEMAP_S4S_ATTR_INVALID_VALUE = 3037,

	SCHEMAP_SRC_ELEMENT_1 = 3038,

	SCHEMAP_SRC_ELEMENT_2_1 = 3039,

	SCHEMAP_SRC_ELEMENT_2_2 = 3040,

	SCHEMAP_SRC_ELEMENT_3 = 3041,

	SCHEMAP_P_PROPS_CORRECT_1 = 3042,

	SCHEMAP_P_PROPS_CORRECT_2_1 = 3043,

	SCHEMAP_P_PROPS_CORRECT_2_2 = 3044,

	SCHEMAP_E_PROPS_CORRECT_2 = 3045,

	SCHEMAP_E_PROPS_CORRECT_3 = 3046,

	SCHEMAP_E_PROPS_CORRECT_4 = 3047,

	SCHEMAP_E_PROPS_CORRECT_5 = 3048,

	SCHEMAP_E_PROPS_CORRECT_6 = 3049,

	SCHEMAP_SRC_INCLUDE = 3050,

	SCHEMAP_SRC_ATTRIBUTE_1 = 3051,

	SCHEMAP_SRC_ATTRIBUTE_2 = 3052,

	SCHEMAP_SRC_ATTRIBUTE_3_1 = 3053,

	SCHEMAP_SRC_ATTRIBUTE_3_2 = 3054,

	SCHEMAP_SRC_ATTRIBUTE_4 = 3055,

	SCHEMAP_NO_XMLNS = 3056,

	SCHEMAP_NO_XSI = 3057,

	SCHEMAP_COS_VALID_DEFAULT_1 = 3058,

	SCHEMAP_COS_VALID_DEFAULT_2_1 = 3059,

	SCHEMAP_COS_VALID_DEFAULT_2_2_1 = 3060,

	SCHEMAP_COS_VALID_DEFAULT_2_2_2 = 3061,

	SCHEMAP_CVC_SIMPLE_TYPE = 3062,

	SCHEMAP_COS_CT_EXTENDS_1_1 = 3063,

	SCHEMAP_SRC_IMPORT_1_1 = 3064,

	SCHEMAP_SRC_IMPORT_1_2 = 3065,

	SCHEMAP_SRC_IMPORT_2 = 3066,

	SCHEMAP_SRC_IMPORT_2_1 = 3067,

	SCHEMAP_SRC_IMPORT_2_2 = 3068,

	SCHEMAP_INTERNAL = 3069,

	SCHEMAP_NOT_DETERMINISTIC = 3070,

	SCHEMAP_SRC_ATTRIBUTE_GROUP_1 = 3071,

	SCHEMAP_SRC_ATTRIBUTE_GROUP_2 = 3072,

	SCHEMAP_SRC_ATTRIBUTE_GROUP_3 = 3073,

	SCHEMAP_MG_PROPS_CORRECT_1 = 3074,

	SCHEMAP_MG_PROPS_CORRECT_2 = 3075,

	SCHEMAP_SRC_CT_1 = 3076,

	SCHEMAP_DERIVATION_OK_RESTRICTION_2_1_3 = 3077,

	SCHEMAP_AU_PROPS_CORRECT_2 = 3078,

	SCHEMAP_A_PROPS_CORRECT_2 = 3079,

	SCHEMAP_C_PROPS_CORRECT = 3080,

	SCHEMAP_SRC_REDEFINE = 3081,

	SCHEMAP_SRC_IMPORT = 3082,

	SCHEMAP_WARN_SKIP_SCHEMA = 3083,

	SCHEMAP_WARN_UNLOCATED_SCHEMA = 3084,

	SCHEMAP_WARN_ATTR_REDECL_PROH = 3085,

	SCHEMAP_WARN_ATTR_POINTLESS_PROH = 3086,

	SCHEMAP_AG_PROPS_CORRECT = 3087,

	SCHEMAP_COS_CT_EXTENDS_1_2 = 3088,

	SCHEMAP_AU_PROPS_CORRECT = 3089,

	SCHEMAP_A_PROPS_CORRECT_3 = 3090,

	SCHEMAP_COS_ALL_LIMITED = 3091,

	SCHEMATRONV_ASSERT = 4000,

	SCHEMATRONV_REPORT = 4001,

	MODULE_OPEN = 4900,

	MODULE_CLOSE = 4901,

	CHECK_FOUND_ELEMENT = 5000,

	CHECK_FOUND_ATTRIBUTE = 5001,

	CHECK_FOUND_TEXT = 5002,

	CHECK_FOUND_CDATA = 5003,

	CHECK_FOUND_ENTITYREF = 5004,

	CHECK_FOUND_ENTITY = 5005,

	CHECK_FOUND_PI = 5006,

	CHECK_FOUND_COMMENT = 5007,

	CHECK_FOUND_DOCTYPE = 5008,

	CHECK_FOUND_FRAGMENT = 5009,

	CHECK_FOUND_NOTATION = 5010,

	CHECK_UNKNOWN_NODE = 5011,

	CHECK_ENTITY_TYPE = 5012,

	CHECK_NO_PARENT = 5013,

	CHECK_NO_DOC = 5014,

	CHECK_NO_NAME = 5015,

	CHECK_NO_ELEM = 5016,

	CHECK_WRONG_DOC = 5017,

	CHECK_NO_PREV = 5018,

	CHECK_WRONG_PREV = 5019,

	CHECK_NO_NEXT = 5020,

	CHECK_WRONG_NEXT = 5021,

	CHECK_NOT_DTD = 5022,

	CHECK_NOT_ATTR = 5023,

	CHECK_NOT_ATTR_DECL = 5024,

	CHECK_NOT_ELEM_DECL = 5025,

	CHECK_NOT_ENTITY_DECL = 5026,

	CHECK_NOT_NS_DECL = 5027,

	CHECK_NO_HREF = 5028,

	CHECK_WRONG_PARENT = 5029,

	CHECK_NS_SCOPE = 5030,

	CHECK_NS_ANCESTOR = 5031,

	CHECK_NOT_UTF8 = 5032,

	CHECK_NO_DICT = 5033,

	CHECK_NOT_NCNAME = 5034,

	CHECK_OUTSIDE_DICT = 5035,

	CHECK_WRONG_NAME = 5036,

	CHECK_NAME_NOT_NULL = 5037,

	I18N_NO_NAME = 6000,

	I18N_NO_HANDLER = 6001,

	I18N_EXCESS_HANDLER = 6002,

	I18N_CONV_FAILED = 6003,

	I18N_NO_OUTPUT = 6004,

	BUF_OVERFLOW = 7000
}

declare function xmlParserFindNodeInfo(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserNodeInfo> | null;

declare function xmlParserFindNodeInfoIndex(seq: interop.Pointer | interop.Reference<xmlParserNodeInfoSeq> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParserGetDirectory(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlParserHandlePEReference(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParserHandleReference(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

interface xmlParserInput {
	buf: interop.Pointer | interop.Reference<xmlParserInputBuffer> | null;
	filename: string | null;
	directory: string | null;
	base: string | null;
	cur: string | null;
	end: string | null;
	length: number;
	line: number;
	col: number;
	consumed: number;
	free: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>;
	encoding: string | null;
	version: string | null;
	standalone: number;
	id: number;
	parentConsumed: number;
	entity: interop.Pointer | interop.Reference<xmlEntity> | null;
}
declare var xmlParserInput: interop.StructType<xmlParserInput>;

/** Struct tag of {@link xmlParserInput}. */
type _xmlParserInput = xmlParserInput;
declare var _xmlParserInput: typeof xmlParserInput;

interface xmlParserInputBuffer {
	context: interop.Pointer | interop.Reference<any> | null;
	readcallback: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number) => number>;
	closecallback: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>;
	encoder: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | null;
	buffer: interop.Pointer | interop.Reference<xmlBuf> | null;
	raw: interop.Pointer | interop.Reference<xmlBuf> | null;
	compressed: number;
	error: number;
	rawconsumed: number;
}
declare var xmlParserInputBuffer: interop.StructType<xmlParserInputBuffer>;

/** Struct tag of {@link xmlParserInputBuffer}. */
type _xmlParserInputBuffer = xmlParserInputBuffer;
declare var _xmlParserInputBuffer: typeof xmlParserInputBuffer;

declare function xmlParserInputBufferCreateFd(fd: number, enc: xmlCharEncoding): interop.Pointer | interop.Reference<xmlParserInputBuffer> | null;

declare function xmlParserInputBufferCreateFile(file: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, enc: xmlCharEncoding): interop.Pointer | interop.Reference<xmlParserInputBuffer> | null;

declare function xmlParserInputBufferCreateFilename(URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, enc: xmlCharEncoding): interop.Pointer | interop.Reference<xmlParserInputBuffer> | null;

declare function xmlParserInputBufferCreateFilenameDefault(func: interop.FunctionReference<(p1: string | null, p2: xmlCharEncoding) => interop.Pointer | interop.Reference<xmlParserInputBuffer> | null>): interop.FunctionReference<(p1: string | null, p2: xmlCharEncoding) => interop.Pointer | interop.Reference<xmlParserInputBuffer> | null>;

declare function xmlParserInputBufferCreateIO(ioread: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number) => number>, ioclose: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>, ioctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, enc: xmlCharEncoding): interop.Pointer | interop.Reference<xmlParserInputBuffer> | null;

declare function xmlParserInputBufferCreateMem(mem: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, enc: xmlCharEncoding): interop.Pointer | interop.Reference<xmlParserInputBuffer> | null;

declare function xmlParserInputBufferCreateStatic(mem: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, enc: xmlCharEncoding): interop.Pointer | interop.Reference<xmlParserInputBuffer> | null;

declare function xmlParserInputBufferGrow(_in: interop.Pointer | interop.Reference<xmlParserInputBuffer> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlParserInputBufferPush(_in: interop.Pointer | interop.Reference<xmlParserInputBuffer> | ArrayBufferLike | ArrayBufferView | null, len: number, buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlParserInputBufferRead(_in: interop.Pointer | interop.Reference<xmlParserInputBuffer> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlParserInputGrow(_in: interop.Pointer | interop.Reference<xmlParserInput> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlParserInputRead(_in: interop.Pointer | interop.Reference<xmlParserInput> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlParserInputShrink(_in: interop.Pointer | interop.Reference<xmlParserInput> | ArrayBufferLike | ArrayBufferView | null): void;

declare const enum xmlParserInputState {

	EOF = -1,

	START = 0,

	MISC = 1,

	PI = 2,

	DTD = 3,

	PROLOG = 4,

	COMMENT = 5,

	START_TAG = 6,

	CONTENT = 7,

	CDATA_SECTION = 8,

	END_TAG = 9,

	ENTITY_DECL = 10,

	ENTITY_VALUE = 11,

	ATTRIBUTE_VALUE = 12,

	SYSTEM_LITERAL = 13,

	EPILOG = 14,

	IGNORE = 15,

	PUBLIC_LITERAL = 16
}

declare var xmlParserMaxDepth: number;

declare const enum xmlParserMode {

	UNKNOWN = 0,

	DOM = 1,

	SAX = 2,

	PUSH_DOM = 3,

	PUSH_SAX = 4,

	READER = 5
}

interface xmlParserNodeInfo {
	node: interop.Pointer | interop.Reference<xmlNode> | null;
	begin_pos: number;
	begin_line: number;
	end_pos: number;
	end_line: number;
}
declare var xmlParserNodeInfo: interop.StructType<xmlParserNodeInfo>;

/** Struct tag of {@link xmlParserNodeInfo}. */
type _xmlParserNodeInfo = xmlParserNodeInfo;
declare var _xmlParserNodeInfo: typeof xmlParserNodeInfo;

interface xmlParserNodeInfoSeq {
	maximum: number;
	length: number;
	buffer: interop.Pointer | interop.Reference<xmlParserNodeInfo> | null;
}
declare var xmlParserNodeInfoSeq: interop.StructType<xmlParserNodeInfoSeq>;

/** Struct tag of {@link xmlParserNodeInfoSeq}. */
type _xmlParserNodeInfoSeq = xmlParserNodeInfoSeq;
declare var _xmlParserNodeInfoSeq: typeof xmlParserNodeInfoSeq;

declare const enum xmlParserOption {

	RECOVER = 1,

	NOENT = 2,

	DTDLOAD = 4,

	DTDATTR = 8,

	DTDVALID = 16,

	NOERROR = 32,

	NOWARNING = 64,

	PEDANTIC = 128,

	NOBLANKS = 256,

	SAX1 = 512,

	XINCLUDE = 1024,

	NONET = 2048,

	NODICT = 4096,

	NSCLEAN = 8192,

	NOCDATA = 16384,

	NOXINCNODE = 32768,

	COMPACT = 65536,

	OLD10 = 131072,

	NOBASEFIX = 262144,

	HUGE = 524288,

	OLDSAX = 1048576,

	IGNORE_ENC = 2097152,

	BIG_LINES = 4194304
}

declare function xmlParserPrintFileContext(input: interop.Pointer | interop.Reference<xmlParserInput> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlParserPrintFileInfo(input: interop.Pointer | interop.Reference<xmlParserInput> | ArrayBufferLike | ArrayBufferView | null): void;

declare const enum xmlParserProperties {

	LOADDTD = 1,

	DEFAULTATTRS = 2,

	VALIDATE = 3,

	SUBST_ENTITIES = 4
}

declare const enum xmlParserSeverities {

	VALIDITY_WARNING = 1,

	VALIDITY_ERROR = 2,

	WARNING = 3,

	ERROR = 4
}

declare function xmlParserValidityError(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, msg: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): void;

declare function xmlParserValidityWarning(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, msg: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): void;

declare function xmlParserWarning(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, msg: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): void;

declare function xmlPathToURI(path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

interface xmlPattern {
}
declare var xmlPattern: interop.StructType<xmlPattern>;

declare const enum xmlPatternFlags {

	DEFAULT = 0,

	XPATH = 1,

	XSSEL = 2,

	XSFIELD = 4
}

declare function xmlPatternFromRoot(comp: interop.Pointer | interop.Reference<xmlPattern> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlPatternGetStreamCtxt(comp: interop.Pointer | interop.Reference<xmlPattern> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlStreamCtxt> | null;

declare function xmlPatternMatch(comp: interop.Pointer | interop.Reference<xmlPattern> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlPatternMaxDepth(comp: interop.Pointer | interop.Reference<xmlPattern> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlPatternMinDepth(comp: interop.Pointer | interop.Reference<xmlPattern> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlPatternStreamable(comp: interop.Pointer | interop.Reference<xmlPattern> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlPatterncompile(pattern: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, dict: interop.Pointer | interop.Reference<xmlDict> | ArrayBufferLike | ArrayBufferView | null, flags: number, namespaces: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlPattern> | null;

declare function xmlPedanticParserDefault(val: number): number;

declare function xmlPopInput(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlPopInputCallbacks(): number;

declare function xmlPopOutputCallbacks(): number;

declare function xmlPreviousElementSibling(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlPrintURI(stream: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, uri: interop.Pointer | interop.Reference<xmlURI> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlPushInput(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, input: interop.Pointer | interop.Reference<xmlParserInput> | ArrayBufferLike | ArrayBufferView | null): number;

interface xmlRMutex {
}
declare var xmlRMutex: interop.StructType<xmlRMutex>;

declare function xmlRMutexLock(tok: interop.Pointer | interop.Reference<xmlRMutex> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlRMutexUnlock(tok: interop.Pointer | interop.Reference<xmlRMutex> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlReadDoc(cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlReadFd(fd: number, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlReadFile(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlReadIO(ioread: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number) => number>, ioclose: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>, ioctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlReadMemory(buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlReaderForDoc(cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlTextReader> | null;

declare function xmlReaderForFd(fd: number, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlTextReader> | null;

declare function xmlReaderForFile(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlTextReader> | null;

declare function xmlReaderForIO(ioread: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number) => number>, ioclose: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>, ioctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlTextReader> | null;

declare function xmlReaderForMemory(buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlTextReader> | null;

declare function xmlReaderNewDoc(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function xmlReaderNewFd(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, fd: number, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function xmlReaderNewFile(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function xmlReaderNewIO(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, ioread: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number) => number>, ioclose: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>, ioctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function xmlReaderNewMemory(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function xmlReaderNewWalker(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare const enum xmlReaderTypes {

	NONE = 0,

	ELEMENT = 1,

	ATTRIBUTE = 2,

	TEXT = 3,

	CDATA = 4,

	ENTITY_REFERENCE = 5,

	ENTITY = 6,

	PROCESSING_INSTRUCTION = 7,

	COMMENT = 8,

	DOCUMENT = 9,

	DOCUMENT_TYPE = 10,

	DOCUMENT_FRAGMENT = 11,

	NOTATION = 12,

	WHITESPACE = 13,

	SIGNIFICANT_WHITESPACE = 14,

	END_ELEMENT = 15,

	END_ENTITY = 16,

	XML_DECLARATION = 17
}

declare function xmlReaderWalker(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlTextReader> | null;

declare var xmlRealloc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: number) => interop.Pointer | interop.Reference<any> | null>;

declare function xmlReallocLoc(ptr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, line: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlReconciliateNs(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, tree: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRecoverDoc(cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlRecoverFile(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlRecoverMemory(buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number): interop.Pointer | interop.Reference<xmlDoc> | null;

interface xmlRef {
	next: interop.Pointer | interop.Reference<xmlRef> | null;
	value: string | null;
	attr: interop.Pointer | interop.Reference<xmlAttr> | null;
	name: string | null;
	lineno: number;
}
declare var xmlRef: interop.StructType<xmlRef>;

/** Struct tag of {@link xmlRef}. */
type _xmlRef = xmlRef;
declare var _xmlRef: typeof xmlRef;

interface xmlRegExecCtxt {
}
declare var xmlRegExecCtxt: interop.StructType<xmlRegExecCtxt>;

declare function xmlRegExecErrInfo(exec: interop.Pointer | interop.Reference<xmlRegExecCtxt> | ArrayBufferLike | ArrayBufferView | null, string: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null, nbval: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, nbneg: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, values: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, terminal: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRegExecNextValues(exec: interop.Pointer | interop.Reference<xmlRegExecCtxt> | ArrayBufferLike | ArrayBufferView | null, nbval: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, nbneg: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, values: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, terminal: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRegExecPushString(exec: interop.Pointer | interop.Reference<xmlRegExecCtxt> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRegExecPushString2(exec: interop.Pointer | interop.Reference<xmlRegExecCtxt> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRegFreeExecCtxt(exec: interop.Pointer | interop.Reference<xmlRegExecCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlRegFreeRegexp(regexp: interop.Pointer | interop.Reference<xmlRegexp> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlRegNewExecCtxt(comp: interop.Pointer | interop.Reference<xmlRegexp> | ArrayBufferLike | ArrayBufferView | null, callback: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlRegExecCtxt> | null, p2: string | null, p3: interop.Pointer | interop.Reference<any> | null, p4: interop.Pointer | interop.Reference<any> | null) => void>, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlRegExecCtxt> | null;

interface xmlRegexp {
}
declare var xmlRegexp: interop.StructType<xmlRegexp>;

declare function xmlRegexpCompile(regexp: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlRegexp> | null;

declare function xmlRegexpExec(comp: interop.Pointer | interop.Reference<xmlRegexp> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRegexpIsDeterminist(comp: interop.Pointer | interop.Reference<xmlRegexp> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRegexpPrint(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, regexp: interop.Pointer | interop.Reference<xmlRegexp> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlRegisterCharEncodingHandler(handler: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlRegisterDefaultInputCallbacks(): void;

declare function xmlRegisterDefaultOutputCallbacks(): void;

declare function xmlRegisterHTTPPostCallbacks(): void;

declare function xmlRegisterInputCallbacks(matchFunc: interop.FunctionReference<(p1: string | null) => number>, openFunc: interop.FunctionReference<(p1: string | null) => interop.Pointer | interop.Reference<any> | null>, readFunc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number) => number>, closeFunc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>): number;

declare function xmlRegisterNodeDefault(func: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlNode> | null) => void>): interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlNode> | null) => void>;

declare function xmlRegisterOutputCallbacks(matchFunc: interop.FunctionReference<(p1: string | null) => number>, openFunc: interop.FunctionReference<(p1: string | null) => interop.Pointer | interop.Reference<any> | null>, writeFunc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number) => number>, closeFunc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>): number;

interface xmlRelaxNG {
}
declare var xmlRelaxNG: interop.StructType<xmlRelaxNG>;

declare function xmlRelaxNGCleanupTypes(): void;

declare function xmlRelaxNGDump(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, schema: interop.Pointer | interop.Reference<xmlRelaxNG> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlRelaxNGDumpTree(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, schema: interop.Pointer | interop.Reference<xmlRelaxNG> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlRelaxNGFree(schema: interop.Pointer | interop.Reference<xmlRelaxNG> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlRelaxNGFreeParserCtxt(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlRelaxNGFreeValidCtxt(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGValidCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlRelaxNGGetParserErrors(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGParserCtxt> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>> | ArrayBufferLike | ArrayBufferView | null, warn: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>> | ArrayBufferLike | ArrayBufferView | null, ctx: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRelaxNGGetValidErrors(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGValidCtxt> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>> | ArrayBufferLike | ArrayBufferView | null, warn: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>> | ArrayBufferLike | ArrayBufferView | null, ctx: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRelaxNGInitTypes(): number;

declare function xmlRelaxNGNewDocParserCtxt(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlRelaxNGParserCtxt> | null;

declare function xmlRelaxNGNewMemParserCtxt(buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number): interop.Pointer | interop.Reference<xmlRelaxNGParserCtxt> | null;

declare function xmlRelaxNGNewParserCtxt(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlRelaxNGParserCtxt> | null;

declare function xmlRelaxNGNewValidCtxt(schema: interop.Pointer | interop.Reference<xmlRelaxNG> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlRelaxNGValidCtxt> | null;

declare function xmlRelaxNGParse(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlRelaxNG> | null;

interface xmlRelaxNGParserCtxt {
}
declare var xmlRelaxNGParserCtxt: interop.StructType<xmlRelaxNGParserCtxt>;

declare const enum xmlRelaxNGParserFlag {

	NONE = 0,

	FREE_DOC = 1,

	CRNG = 2
}

declare function xmlRelaxNGSetParserErrors(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGParserCtxt> | ArrayBufferLike | ArrayBufferView | null, err: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>, warn: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>, ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlRelaxNGSetParserStructuredErrors(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGParserCtxt> | ArrayBufferLike | ArrayBufferView | null, serror: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlError> | null) => void>, ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlRelaxNGSetValidErrors(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGValidCtxt> | ArrayBufferLike | ArrayBufferView | null, err: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>, warn: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>, ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlRelaxNGSetValidStructuredErrors(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGValidCtxt> | ArrayBufferLike | ArrayBufferView | null, serror: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlError> | null) => void>, ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

interface xmlRelaxNGValidCtxt {
}
declare var xmlRelaxNGValidCtxt: interop.StructType<xmlRelaxNGValidCtxt>;

declare const enum xmlRelaxNGValidErr {

	OK = 0,

	ERR_MEMORY = 1,

	ERR_TYPE = 2,

	ERR_TYPEVAL = 3,

	ERR_DUPID = 4,

	ERR_TYPECMP = 5,

	ERR_NOSTATE = 6,

	ERR_NODEFINE = 7,

	ERR_LISTEXTRA = 8,

	ERR_LISTEMPTY = 9,

	ERR_INTERNODATA = 10,

	ERR_INTERSEQ = 11,

	ERR_INTEREXTRA = 12,

	ERR_ELEMNAME = 13,

	ERR_ATTRNAME = 14,

	ERR_ELEMNONS = 15,

	ERR_ATTRNONS = 16,

	ERR_ELEMWRONGNS = 17,

	ERR_ATTRWRONGNS = 18,

	ERR_ELEMEXTRANS = 19,

	ERR_ATTREXTRANS = 20,

	ERR_ELEMNOTEMPTY = 21,

	ERR_NOELEM = 22,

	ERR_NOTELEM = 23,

	ERR_ATTRVALID = 24,

	ERR_CONTENTVALID = 25,

	ERR_EXTRACONTENT = 26,

	ERR_INVALIDATTR = 27,

	ERR_DATAELEM = 28,

	ERR_VALELEM = 29,

	ERR_LISTELEM = 30,

	ERR_DATATYPE = 31,

	ERR_VALUE = 32,

	ERR_LIST = 33,

	ERR_NOGRAMMAR = 34,

	ERR_EXTRADATA = 35,

	ERR_LACKDATA = 36,

	ERR_INTERNAL = 37,

	ERR_ELEMWRONG = 38,

	ERR_TEXTWRONG = 39
}

declare function xmlRelaxNGValidateDoc(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRelaxNGValidateFullElement(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRelaxNGValidatePopElement(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRelaxNGValidatePushCData(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGValidCtxt> | ArrayBufferLike | ArrayBufferView | null, data: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlRelaxNGValidatePushElement(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRelaxParserSetFlag(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGParserCtxt> | ArrayBufferLike | ArrayBufferView | null, flag: number): number;

declare function xmlRelaxParserSetIncLImit(ctxt: interop.Pointer | interop.Reference<xmlRelaxNGParserCtxt> | ArrayBufferLike | ArrayBufferView | null, limit: number): number;

declare function xmlRemoveID(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, attr: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRemoveProp(cur: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlRemoveRef(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, attr: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlReplaceNode(old: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlResetError(err: interop.Pointer | interop.Reference<xmlError> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlResetLastError(): void;

declare function xmlSAX2AttributeDecl(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, elem: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, fullname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: number, def: number, defaultValue: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, tree: interop.Pointer | interop.Reference<xmlEnumeration> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2CDataBlock(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): void;

declare function xmlSAX2Characters(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ch: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): void;

declare function xmlSAX2Comment(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2ElementDecl(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: number, content: interop.Pointer | interop.Reference<xmlElementContent> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2EndDocument(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2EndElement(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2EndElementNs(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, localname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2EntityDecl(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, type: number, publicId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, systemId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2ExternalSubset(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ExternalID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, SystemID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2GetColumnNumber(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSAX2GetEntity(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEntity> | null;

declare function xmlSAX2GetLineNumber(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSAX2GetParameterEntity(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlEntity> | null;

declare function xmlSAX2GetPublicId(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlSAX2GetSystemId(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlSAX2HasExternalSubset(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSAX2HasInternalSubset(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSAX2IgnorableWhitespace(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ch: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): void;

declare function xmlSAX2InitDefaultSAXHandler(hdlr: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, warning: number): void;

declare function xmlSAX2InitDocbDefaultSAXHandler(hdlr: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2InitHtmlDefaultSAXHandler(hdlr: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2InternalSubset(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ExternalID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, SystemID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2IsStandalone(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSAX2NotationDecl(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, publicId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, systemId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2ProcessingInstruction(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, target: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, data: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2Reference(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2ResolveEntity(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, publicId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, systemId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserInput> | null;

declare function xmlSAX2SetDocumentLocator(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, loc: interop.Pointer | interop.Reference<xmlSAXLocator> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2StartDocument(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2StartElement(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, fullname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, atts: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2StartElementNs(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, localname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, URI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, nb_namespaces: number, namespaces: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null, nb_attributes: number, nb_defaulted: number, attributes: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAX2UnparsedEntityDecl(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, publicId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, systemId: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, notationName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSAXDefaultVersion(version: number): number;

interface xmlSAXHandler {
	internalSubset: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null, p4: string | null) => void>;
	isStandalone: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>;
	hasInternalSubset: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>;
	hasExternalSubset: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>;
	resolveEntity: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null) => interop.Pointer | interop.Reference<xmlParserInput> | null>;
	getEntity: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => interop.Pointer | interop.Reference<xmlEntity> | null>;
	entityDecl: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number, p4: string | null, p5: string | null, p6: interop.Pointer | interop.Reference<any> | null) => void>;
	notationDecl: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null, p4: string | null) => void>;
	attributeDecl: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null, p4: number, p5: number, p6: string | null, p7: interop.Pointer | interop.Reference<xmlEnumeration> | null) => void>;
	elementDecl: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number, p4: interop.Pointer | interop.Reference<xmlElementContent> | null) => void>;
	unparsedEntityDecl: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null, p4: string | null, p5: string | null) => void>;
	setDocumentLocator: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlSAXLocator> | null) => void>;
	startDocument: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>;
	endDocument: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>;
	startElement: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: interop.Pointer | interop.Reference<string | null> | null) => void>;
	endElement: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	reference: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	characters: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number) => void>;
	ignorableWhitespace: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number) => void>;
	processingInstruction: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null) => void>;
	comment: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	warning: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	error: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	fatalError: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	getParameterEntity: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => interop.Pointer | interop.Reference<xmlEntity> | null>;
	cdataBlock: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number) => void>;
	externalSubset: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null, p4: string | null) => void>;
	initialized: number;
	_private: interop.Pointer | interop.Reference<any> | null;
	startElementNs: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null, p4: string | null, p5: number, p6: interop.Pointer | interop.Reference<string | null> | null, p7: number, p8: number, p9: interop.Pointer | interop.Reference<string | null> | null) => void>;
	endElementNs: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null, p4: string | null) => void>;
	serror: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlError> | null) => void>;
}
declare var xmlSAXHandler: interop.StructType<xmlSAXHandler>;

/** Struct tag of {@link xmlSAXHandler}. */
type _xmlSAXHandler = xmlSAXHandler;
declare var _xmlSAXHandler: typeof xmlSAXHandler;

interface xmlSAXHandlerV1 {
	internalSubset: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null, p4: string | null) => void>;
	isStandalone: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>;
	hasInternalSubset: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>;
	hasExternalSubset: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>;
	resolveEntity: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null) => interop.Pointer | interop.Reference<xmlParserInput> | null>;
	getEntity: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => interop.Pointer | interop.Reference<xmlEntity> | null>;
	entityDecl: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number, p4: string | null, p5: string | null, p6: interop.Pointer | interop.Reference<any> | null) => void>;
	notationDecl: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null, p4: string | null) => void>;
	attributeDecl: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null, p4: number, p5: number, p6: string | null, p7: interop.Pointer | interop.Reference<xmlEnumeration> | null) => void>;
	elementDecl: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number, p4: interop.Pointer | interop.Reference<xmlElementContent> | null) => void>;
	unparsedEntityDecl: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null, p4: string | null, p5: string | null) => void>;
	setDocumentLocator: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlSAXLocator> | null) => void>;
	startDocument: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>;
	endDocument: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => void>;
	startElement: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: interop.Pointer | interop.Reference<string | null> | null) => void>;
	endElement: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	reference: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	characters: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number) => void>;
	ignorableWhitespace: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number) => void>;
	processingInstruction: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null) => void>;
	comment: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	warning: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	error: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	fatalError: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	getParameterEntity: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => interop.Pointer | interop.Reference<xmlEntity> | null>;
	cdataBlock: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number) => void>;
	externalSubset: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null, p4: string | null) => void>;
	initialized: number;
}
declare var xmlSAXHandlerV1: interop.StructType<xmlSAXHandlerV1>;

/** Struct tag of {@link xmlSAXHandlerV1}. */
type _xmlSAXHandlerV1 = xmlSAXHandlerV1;
declare var _xmlSAXHandlerV1: typeof xmlSAXHandlerV1;

interface xmlSAXLocator {
	getPublicId: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => string | null>;
	getSystemId: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => string | null>;
	getLineNumber: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>;
	getColumnNumber: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>;
}
declare var xmlSAXLocator: interop.StructType<xmlSAXLocator>;

/** Struct tag of {@link xmlSAXLocator}. */
type _xmlSAXLocator = xmlSAXLocator;
declare var _xmlSAXLocator: typeof xmlSAXLocator;

declare function xmlSAXParseDTD(sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, ExternalID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, SystemID: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDtd> | null;

declare function xmlSAXParseDoc(sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, recovery: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlSAXParseEntity(sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlSAXParseFile(sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, recovery: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlSAXParseFileWithData(sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, recovery: number, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlSAXParseMemory(sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, recovery: number): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlSAXParseMemoryWithData(sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, recovery: number, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlSAXUserParseFile(sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, user_data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSAXUserParseMemory(sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, user_data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number): number;

declare function xmlSAXVersion(hdlr: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, version: number): number;

declare function xmlSaveClose(ctxt: interop.Pointer | interop.Reference<xmlSaveCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

interface xmlSaveCtxt {
}
declare var xmlSaveCtxt: interop.StructType<xmlSaveCtxt>;

declare function xmlSaveDoc(ctxt: interop.Pointer | interop.Reference<xmlSaveCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSaveFile(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSaveFileEnc(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSaveFileTo(buf: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSaveFlush(ctxt: interop.Pointer | interop.Reference<xmlSaveCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSaveFormatFile(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, format: number): number;

declare function xmlSaveFormatFileEnc(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: number): number;

declare function xmlSaveFormatFileTo(buf: interop.Pointer | interop.Reference<xmlOutputBuffer> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: number): number;

declare const enum xmlSaveOption {

	FORMAT = 1,

	NO_DECL = 2,

	NO_EMPTY = 4,

	NO_XHTML = 8,

	XHTML = 16,

	AS_XML = 32,

	AS_HTML = 64,

	WSNONSIG = 128
}

declare function xmlSaveSetAttrEscape(ctxt: interop.Pointer | interop.Reference<xmlSaveCtxt> | ArrayBufferLike | ArrayBufferView | null, escape: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<number> | null, p3: string | null, p4: interop.Pointer | interop.Reference<number> | null) => number>): number;

declare function xmlSaveSetEscape(ctxt: interop.Pointer | interop.Reference<xmlSaveCtxt> | ArrayBufferLike | ArrayBufferView | null, escape: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<number> | null, p3: string | null, p4: interop.Pointer | interop.Reference<number> | null) => number>): number;

declare function xmlSaveToBuffer(buffer: interop.Pointer | interop.Reference<xmlBuffer> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlSaveCtxt> | null;

declare function xmlSaveToFd(fd: number, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlSaveCtxt> | null;

declare function xmlSaveToFilename(filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlSaveCtxt> | null;

declare function xmlSaveToIO(iowrite: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number) => number>, ioclose: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>, ioctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlSaveCtxt> | null;

declare function xmlSaveTree(ctxt: interop.Pointer | interop.Reference<xmlSaveCtxt> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSaveUri(uri: interop.Pointer | interop.Reference<xmlURI> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlScanName(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

interface xmlSchema {
	name: string | null;
	targetNamespace: string | null;
	version: string | null;
	id: string | null;
	doc: interop.Pointer | interop.Reference<xmlDoc> | null;
	annot: interop.Pointer | interop.Reference<xmlSchemaAnnot> | null;
	flags: number;
	typeDecl: interop.Pointer | interop.Reference<xmlHashTable> | null;
	attrDecl: interop.Pointer | interop.Reference<xmlHashTable> | null;
	attrgrpDecl: interop.Pointer | interop.Reference<xmlHashTable> | null;
	elemDecl: interop.Pointer | interop.Reference<xmlHashTable> | null;
	notaDecl: interop.Pointer | interop.Reference<xmlHashTable> | null;
	schemasImports: interop.Pointer | interop.Reference<xmlHashTable> | null;
	_private: interop.Pointer | interop.Reference<any> | null;
	groupDecl: interop.Pointer | interop.Reference<xmlHashTable> | null;
	dict: interop.Pointer | interop.Reference<xmlDict> | null;
	includes: interop.Pointer | interop.Reference<any> | null;
	preserve: number;
	counter: number;
	idcDef: interop.Pointer | interop.Reference<xmlHashTable> | null;
	volatiles: interop.Pointer | interop.Reference<any> | null;
}
declare var xmlSchema: interop.StructType<xmlSchema>;

/** Struct tag of {@link xmlSchema}. */
type _xmlSchema = xmlSchema;
declare var _xmlSchema: typeof xmlSchema;

interface xmlSchemaAnnot {
	next: interop.Pointer | interop.Reference<xmlSchemaAnnot> | null;
	content: interop.Pointer | interop.Reference<xmlNode> | null;
}
declare var xmlSchemaAnnot: interop.StructType<xmlSchemaAnnot>;

/** Struct tag of {@link xmlSchemaAnnot}. */
type _xmlSchemaAnnot = xmlSchemaAnnot;
declare var _xmlSchemaAnnot: typeof xmlSchemaAnnot;

interface xmlSchemaAttribute {
	type: xmlSchemaTypeType;
	next: interop.Pointer | interop.Reference<xmlSchemaAttribute> | null;
	name: string | null;
	id: string | null;
	ref: string | null;
	refNs: string | null;
	typeName: string | null;
	typeNs: string | null;
	annot: interop.Pointer | interop.Reference<xmlSchemaAnnot> | null;
	base: interop.Pointer | interop.Reference<xmlSchemaType> | null;
	occurs: number;
	defValue: string | null;
	subtypes: interop.Pointer | interop.Reference<xmlSchemaType> | null;
	node: interop.Pointer | interop.Reference<xmlNode> | null;
	targetNamespace: string | null;
	flags: number;
	refPrefix: string | null;
	defVal: interop.Pointer | interop.Reference<xmlSchemaVal> | null;
	refDecl: interop.Pointer | interop.Reference<xmlSchemaAttribute> | null;
}
declare var xmlSchemaAttribute: interop.StructType<xmlSchemaAttribute>;

/** Struct tag of {@link xmlSchemaAttribute}. */
type _xmlSchemaAttribute = xmlSchemaAttribute;
declare var _xmlSchemaAttribute: typeof xmlSchemaAttribute;

interface xmlSchemaAttributeGroup {
	type: xmlSchemaTypeType;
	next: interop.Pointer | interop.Reference<xmlSchemaAttribute> | null;
	name: string | null;
	id: string | null;
	ref: string | null;
	refNs: string | null;
	annot: interop.Pointer | interop.Reference<xmlSchemaAnnot> | null;
	attributes: interop.Pointer | interop.Reference<xmlSchemaAttribute> | null;
	node: interop.Pointer | interop.Reference<xmlNode> | null;
	flags: number;
	attributeWildcard: interop.Pointer | interop.Reference<xmlSchemaWildcard> | null;
	refPrefix: string | null;
	refItem: interop.Pointer | interop.Reference<xmlSchemaAttributeGroup> | null;
	targetNamespace: string | null;
	attrUses: interop.Pointer | interop.Reference<any> | null;
}
declare var xmlSchemaAttributeGroup: interop.StructType<xmlSchemaAttributeGroup>;

/** Struct tag of {@link xmlSchemaAttributeGroup}. */
type _xmlSchemaAttributeGroup = xmlSchemaAttributeGroup;
declare var _xmlSchemaAttributeGroup: typeof xmlSchemaAttributeGroup;

interface xmlSchemaAttributeLink {
	next: interop.Pointer | interop.Reference<xmlSchemaAttributeLink> | null;
	attr: interop.Pointer | interop.Reference<xmlSchemaAttribute> | null;
}
declare var xmlSchemaAttributeLink: interop.StructType<xmlSchemaAttributeLink>;

/** Struct tag of {@link xmlSchemaAttributeLink}. */
type _xmlSchemaAttributeLink = xmlSchemaAttributeLink;
declare var _xmlSchemaAttributeLink: typeof xmlSchemaAttributeLink;

declare function xmlSchemaCheckFacet(facet: interop.Pointer | interop.Reference<xmlSchemaFacet> | ArrayBufferLike | ArrayBufferView | null, typeDecl: interop.Pointer | interop.Reference<xmlSchemaType> | ArrayBufferLike | ArrayBufferView | null, ctxt: interop.Pointer | interop.Reference<xmlSchemaParserCtxt> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaCleanupTypes(): void;

declare function xmlSchemaCollapseString(value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlSchemaCompareValues(x: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null, y: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaCompareValuesWhtsp(x: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null, xws: xmlSchemaWhitespaceValueType, y: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null, yws: xmlSchemaWhitespaceValueType): number;

declare const enum xmlSchemaContentType {

	UNKNOWN = 0,

	EMPTY = 1,

	ELEMENTS = 2,

	MIXED = 3,

	SIMPLE = 4,

	MIXED_OR_ELEMENTS = 5,

	BASIC = 6,

	ANY = 7
}

declare function xmlSchemaCopyValue(val: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchemaVal> | null;

declare function xmlSchemaDump(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, schema: interop.Pointer | interop.Reference<xmlSchema> | ArrayBufferLike | ArrayBufferView | null): void;

interface xmlSchemaElement {
	type: xmlSchemaTypeType;
	next: interop.Pointer | interop.Reference<xmlSchemaType> | null;
	name: string | null;
	id: string | null;
	ref: string | null;
	refNs: string | null;
	annot: interop.Pointer | interop.Reference<xmlSchemaAnnot> | null;
	subtypes: interop.Pointer | interop.Reference<xmlSchemaType> | null;
	attributes: interop.Pointer | interop.Reference<xmlSchemaAttribute> | null;
	node: interop.Pointer | interop.Reference<xmlNode> | null;
	minOccurs: number;
	maxOccurs: number;
	flags: number;
	targetNamespace: string | null;
	namedType: string | null;
	namedTypeNs: string | null;
	substGroup: string | null;
	substGroupNs: string | null;
	scope: string | null;
	value: string | null;
	refDecl: interop.Pointer | interop.Reference<xmlSchemaElement> | null;
	contModel: interop.Pointer | interop.Reference<xmlRegexp> | null;
	contentType: xmlSchemaContentType;
	refPrefix: string | null;
	defVal: interop.Pointer | interop.Reference<xmlSchemaVal> | null;
	idcs: interop.Pointer | interop.Reference<any> | null;
}
declare var xmlSchemaElement: interop.StructType<xmlSchemaElement>;

/** Struct tag of {@link xmlSchemaElement}. */
type _xmlSchemaElement = xmlSchemaElement;
declare var _xmlSchemaElement: typeof xmlSchemaElement;

interface xmlSchemaFacet {
	type: xmlSchemaTypeType;
	next: interop.Pointer | interop.Reference<xmlSchemaFacet> | null;
	value: string | null;
	id: string | null;
	annot: interop.Pointer | interop.Reference<xmlSchemaAnnot> | null;
	node: interop.Pointer | interop.Reference<xmlNode> | null;
	fixed: number;
	whitespace: number;
	val: interop.Pointer | interop.Reference<xmlSchemaVal> | null;
	regexp: interop.Pointer | interop.Reference<xmlRegexp> | null;
}
declare var xmlSchemaFacet: interop.StructType<xmlSchemaFacet>;

/** Struct tag of {@link xmlSchemaFacet}. */
type _xmlSchemaFacet = xmlSchemaFacet;
declare var _xmlSchemaFacet: typeof xmlSchemaFacet;

interface xmlSchemaFacetLink {
	next: interop.Pointer | interop.Reference<xmlSchemaFacetLink> | null;
	facet: interop.Pointer | interop.Reference<xmlSchemaFacet> | null;
}
declare var xmlSchemaFacetLink: interop.StructType<xmlSchemaFacetLink>;

/** Struct tag of {@link xmlSchemaFacetLink}. */
type _xmlSchemaFacetLink = xmlSchemaFacetLink;
declare var _xmlSchemaFacetLink: typeof xmlSchemaFacetLink;

declare function xmlSchemaFree(schema: interop.Pointer | interop.Reference<xmlSchema> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchemaFreeFacet(facet: interop.Pointer | interop.Reference<xmlSchemaFacet> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchemaFreeParserCtxt(ctxt: interop.Pointer | interop.Reference<xmlSchemaParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchemaFreeType(type: interop.Pointer | interop.Reference<xmlSchemaType> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchemaFreeValidCtxt(ctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchemaFreeValue(val: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchemaFreeWildcard(wildcard: interop.Pointer | interop.Reference<xmlSchemaWildcard> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchemaGetBuiltInListSimpleTypeItemType(type: interop.Pointer | interop.Reference<xmlSchemaType> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchemaType> | null;

declare function xmlSchemaGetBuiltInType(type: xmlSchemaValType): interop.Pointer | interop.Reference<xmlSchemaType> | null;

declare function xmlSchemaGetCanonValue(val: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null, retValue: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaGetCanonValueWhtsp(val: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null, retValue: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null, ws: xmlSchemaWhitespaceValueType): number;

declare function xmlSchemaGetFacetValueAsULong(facet: interop.Pointer | interop.Reference<xmlSchemaFacet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaGetParserErrors(ctxt: interop.Pointer | interop.Reference<xmlSchemaParserCtxt> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>> | ArrayBufferLike | ArrayBufferView | null, warn: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>> | ArrayBufferLike | ArrayBufferView | null, ctx: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaGetPredefinedType(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ns: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchemaType> | null;

declare function xmlSchemaGetValType(val: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null): xmlSchemaValType;

declare function xmlSchemaGetValidErrors(ctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>> | ArrayBufferLike | ArrayBufferView | null, warn: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>> | ArrayBufferLike | ArrayBufferView | null, ctx: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaInitTypes(): void;

declare function xmlSchemaIsBuiltInTypeFacet(type: interop.Pointer | interop.Reference<xmlSchemaType> | ArrayBufferLike | ArrayBufferView | null, facetType: number): number;

declare function xmlSchemaIsValid(ctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaNewDocParserCtxt(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchemaParserCtxt> | null;

declare function xmlSchemaNewFacet(): interop.Pointer | interop.Reference<xmlSchemaFacet> | null;

declare function xmlSchemaNewMemParserCtxt(buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number): interop.Pointer | interop.Reference<xmlSchemaParserCtxt> | null;

declare function xmlSchemaNewNOTATIONValue(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ns: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchemaVal> | null;

declare function xmlSchemaNewParserCtxt(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchemaParserCtxt> | null;

declare function xmlSchemaNewQNameValue(namespaceName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, localName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchemaVal> | null;

declare function xmlSchemaNewStringValue(type: xmlSchemaValType, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchemaVal> | null;

declare function xmlSchemaNewValidCtxt(schema: interop.Pointer | interop.Reference<xmlSchema> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | null;

interface xmlSchemaNotation {
	type: xmlSchemaTypeType;
	name: string | null;
	annot: interop.Pointer | interop.Reference<xmlSchemaAnnot> | null;
	identifier: string | null;
	targetNamespace: string | null;
}
declare var xmlSchemaNotation: interop.StructType<xmlSchemaNotation>;

/** Struct tag of {@link xmlSchemaNotation}. */
type _xmlSchemaNotation = xmlSchemaNotation;
declare var _xmlSchemaNotation: typeof xmlSchemaNotation;

declare function xmlSchemaParse(ctxt: interop.Pointer | interop.Reference<xmlSchemaParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchema> | null;

interface xmlSchemaParserCtxt {
}
declare var xmlSchemaParserCtxt: interop.StructType<xmlSchemaParserCtxt>;

declare function xmlSchemaSAXPlug(ctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null, sax: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlSAXHandler> | null> | ArrayBufferLike | ArrayBufferView | null, user_data: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchemaSAXPlugStruct> | null;

interface xmlSchemaSAXPlugStruct {
}
declare var xmlSchemaSAXPlugStruct: interop.StructType<xmlSchemaSAXPlugStruct>;

declare function xmlSchemaSAXUnplug(plug: interop.Pointer | interop.Reference<xmlSchemaSAXPlugStruct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaSetParserErrors(ctxt: interop.Pointer | interop.Reference<xmlSchemaParserCtxt> | ArrayBufferLike | ArrayBufferView | null, err: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>, warn: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>, ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchemaSetParserStructuredErrors(ctxt: interop.Pointer | interop.Reference<xmlSchemaParserCtxt> | ArrayBufferLike | ArrayBufferView | null, serror: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlError> | null) => void>, ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchemaSetValidErrors(ctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null, err: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>, warn: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>, ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchemaSetValidOptions(ctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function xmlSchemaSetValidStructuredErrors(ctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null, serror: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlError> | null) => void>, ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

interface xmlSchemaType {
	type: xmlSchemaTypeType;
	next: interop.Pointer | interop.Reference<xmlSchemaType> | null;
	name: string | null;
	id: string | null;
	ref: string | null;
	refNs: string | null;
	annot: interop.Pointer | interop.Reference<xmlSchemaAnnot> | null;
	subtypes: interop.Pointer | interop.Reference<xmlSchemaType> | null;
	attributes: interop.Pointer | interop.Reference<xmlSchemaAttribute> | null;
	node: interop.Pointer | interop.Reference<xmlNode> | null;
	minOccurs: number;
	maxOccurs: number;
	flags: number;
	contentType: xmlSchemaContentType;
	base: string | null;
	baseNs: string | null;
	baseType: interop.Pointer | interop.Reference<xmlSchemaType> | null;
	facets: interop.Pointer | interop.Reference<xmlSchemaFacet> | null;
	redef: interop.Pointer | interop.Reference<xmlSchemaType> | null;
	recurse: number;
	attributeUses: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlSchemaAttributeLink> | null> | null;
	attributeWildcard: interop.Pointer | interop.Reference<xmlSchemaWildcard> | null;
	builtInType: number;
	memberTypes: interop.Pointer | interop.Reference<xmlSchemaTypeLink> | null;
	facetSet: interop.Pointer | interop.Reference<xmlSchemaFacetLink> | null;
	refPrefix: string | null;
	contentTypeDef: interop.Pointer | interop.Reference<xmlSchemaType> | null;
	contModel: interop.Pointer | interop.Reference<xmlRegexp> | null;
	targetNamespace: string | null;
	attrUses: interop.Pointer | interop.Reference<any> | null;
}
declare var xmlSchemaType: interop.StructType<xmlSchemaType>;

/** Struct tag of {@link xmlSchemaType}. */
type _xmlSchemaType = xmlSchemaType;
declare var _xmlSchemaType: typeof xmlSchemaType;

interface xmlSchemaTypeLink {
	next: interop.Pointer | interop.Reference<xmlSchemaTypeLink> | null;
	type: interop.Pointer | interop.Reference<xmlSchemaType> | null;
}
declare var xmlSchemaTypeLink: interop.StructType<xmlSchemaTypeLink>;

/** Struct tag of {@link xmlSchemaTypeLink}. */
type _xmlSchemaTypeLink = xmlSchemaTypeLink;
declare var _xmlSchemaTypeLink: typeof xmlSchemaTypeLink;

declare const enum xmlSchemaTypeType {

	TYPE_BASIC = 1,

	TYPE_ANY = 2,

	TYPE_FACET = 3,

	TYPE_SIMPLE = 4,

	TYPE_COMPLEX = 5,

	TYPE_SEQUENCE = 6,

	TYPE_CHOICE = 7,

	TYPE_ALL = 8,

	TYPE_SIMPLE_CONTENT = 9,

	TYPE_COMPLEX_CONTENT = 10,

	TYPE_UR = 11,

	TYPE_RESTRICTION = 12,

	TYPE_EXTENSION = 13,

	TYPE_ELEMENT = 14,

	TYPE_ATTRIBUTE = 15,

	TYPE_ATTRIBUTEGROUP = 16,

	TYPE_GROUP = 17,

	TYPE_NOTATION = 18,

	TYPE_LIST = 19,

	TYPE_UNION = 20,

	TYPE_ANY_ATTRIBUTE = 21,

	TYPE_IDC_UNIQUE = 22,

	TYPE_IDC_KEY = 23,

	TYPE_IDC_KEYREF = 24,

	TYPE_PARTICLE = 25,

	TYPE_ATTRIBUTE_USE = 26,

	FACET_MININCLUSIVE = 1000,

	FACET_MINEXCLUSIVE = 1001,

	FACET_MAXINCLUSIVE = 1002,

	FACET_MAXEXCLUSIVE = 1003,

	FACET_TOTALDIGITS = 1004,

	FACET_FRACTIONDIGITS = 1005,

	FACET_PATTERN = 1006,

	FACET_ENUMERATION = 1007,

	FACET_WHITESPACE = 1008,

	FACET_LENGTH = 1009,

	FACET_MAXLENGTH = 1010,

	FACET_MINLENGTH = 1011,

	EXTRA_QNAMEREF = 2000,

	EXTRA_ATTR_USE_PROHIB = 2001
}

interface xmlSchemaVal {
}
declare var xmlSchemaVal: interop.StructType<xmlSchemaVal>;

declare function xmlSchemaValPredefTypeNode(type: interop.Pointer | interop.Reference<xmlSchemaType> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, val: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlSchemaVal> | null> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaValPredefTypeNodeNoNorm(type: interop.Pointer | interop.Reference<xmlSchemaType> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, val: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlSchemaVal> | null> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare const enum xmlSchemaValType {

	UNKNOWN = 0,

	STRING = 1,

	NORMSTRING = 2,

	DECIMAL = 3,

	TIME = 4,

	GDAY = 5,

	GMONTH = 6,

	GMONTHDAY = 7,

	GYEAR = 8,

	GYEARMONTH = 9,

	DATE = 10,

	DATETIME = 11,

	DURATION = 12,

	FLOAT = 13,

	DOUBLE = 14,

	BOOLEAN = 15,

	TOKEN = 16,

	LANGUAGE = 17,

	NMTOKEN = 18,

	NMTOKENS = 19,

	NAME = 20,

	QNAME = 21,

	NCNAME = 22,

	ID = 23,

	IDREF = 24,

	IDREFS = 25,

	ENTITY = 26,

	ENTITIES = 27,

	NOTATION = 28,

	ANYURI = 29,

	INTEGER = 30,

	NPINTEGER = 31,

	NINTEGER = 32,

	NNINTEGER = 33,

	PINTEGER = 34,

	INT = 35,

	UINT = 36,

	LONG = 37,

	ULONG = 38,

	SHORT = 39,

	USHORT = 40,

	BYTE = 41,

	UBYTE = 42,

	HEXBINARY = 43,

	BASE64BINARY = 44,

	ANYTYPE = 45,

	ANYSIMPLETYPE = 46
}

interface xmlSchemaValidCtxt {
}
declare var xmlSchemaValidCtxt: interop.StructType<xmlSchemaValidCtxt>;

declare function xmlSchemaValidCtxtGetOptions(ctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaValidCtxtGetParserCtxt(ctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserCtxt> | null;

declare const enum xmlSchemaValidError {

	ERR_OK = 0,

	ERR_NOROOT = 1,

	ERR_UNDECLAREDELEM = 2,

	ERR_NOTTOPLEVEL = 3,

	ERR_MISSING = 4,

	ERR_WRONGELEM = 5,

	ERR_NOTYPE = 6,

	ERR_NOROLLBACK = 7,

	ERR_ISABSTRACT = 8,

	ERR_NOTEMPTY = 9,

	ERR_ELEMCONT = 10,

	ERR_HAVEDEFAULT = 11,

	ERR_NOTNILLABLE = 12,

	ERR_EXTRACONTENT = 13,

	ERR_INVALIDATTR = 14,

	ERR_INVALIDELEM = 15,

	ERR_NOTDETERMINIST = 16,

	ERR_CONSTRUCT = 17,

	ERR_INTERNAL = 18,

	ERR_NOTSIMPLE = 19,

	ERR_ATTRUNKNOWN = 20,

	ERR_ATTRINVALID = 21,

	ERR_VALUE = 22,

	ERR_FACET = 23,

	ERR_ = 24,

	ERR_XXX = 25
}

declare const enum xmlSchemaValidOption {

	XML_SCHEMA_VAL_VC_I_CREATE = 1
}

declare function xmlSchemaValidateDoc(ctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null, instance: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaValidateFacet(base: interop.Pointer | interop.Reference<xmlSchemaType> | ArrayBufferLike | ArrayBufferView | null, facet: interop.Pointer | interop.Reference<xmlSchemaFacet> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, val: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaValidateFacetWhtsp(facet: interop.Pointer | interop.Reference<xmlSchemaFacet> | ArrayBufferLike | ArrayBufferView | null, fws: xmlSchemaWhitespaceValueType, valType: xmlSchemaValType, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, val: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null, ws: xmlSchemaWhitespaceValueType): number;

declare function xmlSchemaValidateFile(ctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function xmlSchemaValidateLengthFacet(type: interop.Pointer | interop.Reference<xmlSchemaType> | ArrayBufferLike | ArrayBufferView | null, facet: interop.Pointer | interop.Reference<xmlSchemaFacet> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, val: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null, length: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaValidateLengthFacetWhtsp(facet: interop.Pointer | interop.Reference<xmlSchemaFacet> | ArrayBufferLike | ArrayBufferView | null, valType: xmlSchemaValType, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, val: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null, length: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, ws: xmlSchemaWhitespaceValueType): number;

declare function xmlSchemaValidateListSimpleTypeFacet(facet: interop.Pointer | interop.Reference<xmlSchemaFacet> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, actualLen: number, expectedLen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaValidateOneElement(ctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaValidatePredefinedType(type: interop.Pointer | interop.Reference<xmlSchemaType> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, val: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlSchemaVal> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaValidateSetFilename(vctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchemaValidateSetLocator(vctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<string | null> | null, p3: interop.Pointer | interop.Reference<number> | null) => number>, ctxt: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchemaValidateStream(ctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null, input: interop.Pointer | interop.Reference<xmlParserInputBuffer> | ArrayBufferLike | ArrayBufferView | null, enc: xmlCharEncoding, sax: interop.Pointer | interop.Reference<xmlSAXHandler> | ArrayBufferLike | ArrayBufferView | null, user_data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaValueAppend(prev: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaValueGetAsBoolean(val: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSchemaValueGetAsString(val: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlSchemaValueGetNext(cur: interop.Pointer | interop.Reference<xmlSchemaVal> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchemaVal> | null;

declare function xmlSchemaWhiteSpaceReplace(value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare const enum xmlSchemaWhitespaceValueType {

	UNKNOWN = 0,

	PRESERVE = 1,

	REPLACE = 2,

	COLLAPSE = 3
}

interface xmlSchemaWildcard {
	type: xmlSchemaTypeType;
	id: string | null;
	annot: interop.Pointer | interop.Reference<xmlSchemaAnnot> | null;
	node: interop.Pointer | interop.Reference<xmlNode> | null;
	minOccurs: number;
	maxOccurs: number;
	processContents: number;
	any: number;
	nsSet: interop.Pointer | interop.Reference<xmlSchemaWildcardNs> | null;
	negNsSet: interop.Pointer | interop.Reference<xmlSchemaWildcardNs> | null;
	flags: number;
}
declare var xmlSchemaWildcard: interop.StructType<xmlSchemaWildcard>;

/** Struct tag of {@link xmlSchemaWildcard}. */
type _xmlSchemaWildcard = xmlSchemaWildcard;
declare var _xmlSchemaWildcard: typeof xmlSchemaWildcard;

interface xmlSchemaWildcardNs {
	next: interop.Pointer | interop.Reference<xmlSchemaWildcardNs> | null;
	value: string | null;
}
declare var xmlSchemaWildcardNs: interop.StructType<xmlSchemaWildcardNs>;

/** Struct tag of {@link xmlSchemaWildcardNs}. */
type _xmlSchemaWildcardNs = xmlSchemaWildcardNs;
declare var _xmlSchemaWildcardNs: typeof xmlSchemaWildcardNs;

interface xmlSchematron {
}
declare var xmlSchematron: interop.StructType<xmlSchematron>;

declare function xmlSchematronFree(schema: interop.Pointer | interop.Reference<xmlSchematron> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchematronFreeParserCtxt(ctxt: interop.Pointer | interop.Reference<xmlSchematronParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchematronFreeValidCtxt(ctxt: interop.Pointer | interop.Reference<xmlSchematronValidCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSchematronNewDocParserCtxt(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchematronParserCtxt> | null;

declare function xmlSchematronNewMemParserCtxt(buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number): interop.Pointer | interop.Reference<xmlSchematronParserCtxt> | null;

declare function xmlSchematronNewParserCtxt(URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchematronParserCtxt> | null;

declare function xmlSchematronNewValidCtxt(schema: interop.Pointer | interop.Reference<xmlSchematron> | ArrayBufferLike | ArrayBufferView | null, options: number): interop.Pointer | interop.Reference<xmlSchematronValidCtxt> | null;

declare function xmlSchematronParse(ctxt: interop.Pointer | interop.Reference<xmlSchematronParserCtxt> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlSchematron> | null;

interface xmlSchematronParserCtxt {
}
declare var xmlSchematronParserCtxt: interop.StructType<xmlSchematronParserCtxt>;

declare function xmlSchematronSetValidStructuredErrors(ctxt: interop.Pointer | interop.Reference<xmlSchematronValidCtxt> | ArrayBufferLike | ArrayBufferView | null, serror: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlError> | null) => void>, ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

interface xmlSchematronValidCtxt {
}
declare var xmlSchematronValidCtxt: interop.StructType<xmlSchematronValidCtxt>;

declare const enum xmlSchematronValidOptions {

	QUIET = 1,

	TEXT = 2,

	XML = 4,

	ERROR = 8,

	FILE = 256,

	BUFFER = 512,

	IO = 1024
}

declare function xmlSchematronValidateDoc(ctxt: interop.Pointer | interop.Reference<xmlSchematronValidCtxt> | ArrayBufferLike | ArrayBufferView | null, instance: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSearchNs(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, nameSpace: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNs> | null;

declare function xmlSearchNsByHref(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, href: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNs> | null;

declare function xmlSetBufferAllocationScheme(scheme: xmlBufferAllocationScheme): void;

declare function xmlSetCompressMode(mode: number): void;

declare function xmlSetDocCompressMode(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, mode: number): void;

declare function xmlSetEntityReferenceFunc(func: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlEntity> | null, p2: interop.Pointer | interop.Reference<xmlNode> | null, p3: interop.Pointer | interop.Reference<xmlNode> | null) => void>): void;

declare function xmlSetExternalEntityLoader(f: interop.FunctionReference<(p1: string | null, p2: string | null, p3: interop.Pointer | interop.Reference<xmlParserCtxt> | null) => interop.Pointer | interop.Reference<xmlParserInput> | null>): void;

declare function xmlSetFeature(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSetGenericErrorFunc(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, handler: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>): void;

declare function xmlSetListDoc(list: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSetNs(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSetNsProp(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAttr> | null;

declare function xmlSetProp(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlAttr> | null;

declare function xmlSetStructuredErrorFunc(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, handler: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlError> | null) => void>): void;

declare function xmlSetTreeDoc(tree: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlSetupParserForBuffer(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlShell(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, input: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => interop.Pointer | interop.Reference<any> | null>, output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlShellBase(ctxt: interop.Pointer | interop.Reference<xmlShellCtxt> | ArrayBufferLike | ArrayBufferView | null, arg: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, node2: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlShellCat(ctxt: interop.Pointer | interop.Reference<xmlShellCtxt> | ArrayBufferLike | ArrayBufferView | null, arg: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, node2: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

interface xmlShellCtxt {
	filename: interop.Pointer | interop.Reference<any> | null;
	doc: interop.Pointer | interop.Reference<xmlDoc> | null;
	node: interop.Pointer | interop.Reference<xmlNode> | null;
	pctxt: interop.Pointer | interop.Reference<xmlXPathContext> | null;
	loaded: number;
	output: interop.Pointer | interop.Reference<FILE> | null;
	input: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => interop.Pointer | interop.Reference<any> | null>;
}
declare var xmlShellCtxt: interop.StructType<xmlShellCtxt>;

/** Struct tag of {@link xmlShellCtxt}. */
type _xmlShellCtxt = xmlShellCtxt;
declare var _xmlShellCtxt: typeof xmlShellCtxt;

declare function xmlShellDir(ctxt: interop.Pointer | interop.Reference<xmlShellCtxt> | ArrayBufferLike | ArrayBufferView | null, arg: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, node2: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlShellDu(ctxt: interop.Pointer | interop.Reference<xmlShellCtxt> | ArrayBufferLike | ArrayBufferView | null, arg: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, tree: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, node2: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlShellList(ctxt: interop.Pointer | interop.Reference<xmlShellCtxt> | ArrayBufferLike | ArrayBufferView | null, arg: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, node2: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlShellLoad(ctxt: interop.Pointer | interop.Reference<xmlShellCtxt> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, node2: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlShellPrintNode(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlShellPrintXPathError(errorType: number, arg: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlShellPrintXPathResult(list: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlShellPwd(ctxt: interop.Pointer | interop.Reference<xmlShellCtxt> | ArrayBufferLike | ArrayBufferView | null, buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, node2: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlShellSave(ctxt: interop.Pointer | interop.Reference<xmlShellCtxt> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, node2: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlShellValidate(ctxt: interop.Pointer | interop.Reference<xmlShellCtxt> | ArrayBufferLike | ArrayBufferView | null, dtd: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, node2: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlShellWrite(ctxt: interop.Pointer | interop.Reference<xmlShellCtxt> | ArrayBufferLike | ArrayBufferView | null, filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, node2: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSkipBlankChars(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSnprintfElementContent(buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, size: number, content: interop.Pointer | interop.Reference<xmlElementContent> | ArrayBufferLike | ArrayBufferView | null, englob: number): void;

declare function xmlSplitQName(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlSplitQName2(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, prefix: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlSplitQName3(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlSprintfElementContent(buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: interop.Pointer | interop.Reference<xmlElementContent> | ArrayBufferLike | ArrayBufferView | null, englob: number): void;

interface xmlStartTag {
}
declare var xmlStartTag: interop.StructType<xmlStartTag>;

declare function xmlStopParser(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlStrEqual(str1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, str2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlStrPrintf(buf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number, msg: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function xmlStrQEqual(pref: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlStrcasecmp(str1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, str2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlStrcasestr(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, val: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlStrcat(cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, add: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlStrchr(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, val: number): string | null;

declare function xmlStrcmp(str1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, str2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlStrdup(cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

interface xmlStreamCtxt {
}
declare var xmlStreamCtxt: interop.StructType<xmlStreamCtxt>;

declare function xmlStreamPop(stream: interop.Pointer | interop.Reference<xmlStreamCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlStreamPush(stream: interop.Pointer | interop.Reference<xmlStreamCtxt> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ns: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlStreamPushAttr(stream: interop.Pointer | interop.Reference<xmlStreamCtxt> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ns: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlStreamPushNode(stream: interop.Pointer | interop.Reference<xmlStreamCtxt> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ns: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, nodeType: number): number;

declare function xmlStreamWantsAnyNode(stream: interop.Pointer | interop.Reference<xmlStreamCtxt> | ArrayBufferLike | ArrayBufferView | null): number;

declare var xmlStringComment: interop.Reference<number>;

declare function xmlStringCurrentChar(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlStringDecodeEntities(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, what: number, end: number, end2: number, end3: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlStringGetNodeList(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlStringLenDecodeEntities(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number, what: number, end: number, end2: number, end3: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlStringLenGetNodeList(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): interop.Pointer | interop.Reference<xmlNode> | null;

declare var xmlStringText: interop.Reference<number>;

declare var xmlStringTextNoenc: interop.Reference<number>;

declare function xmlStrlen(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlStrncasecmp(str1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, str2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlStrncat(cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, add: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlStrncatNew(str1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, str2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlStrncmp(str1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, str2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlStrndup(cur: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlStrstr(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, val: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlStrsub(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, start: number, len: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlSubstituteEntitiesDefault(val: number): number;

declare function xmlSwitchEncoding(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, enc: xmlCharEncoding): number;

declare function xmlSwitchInputEncoding(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, input: interop.Pointer | interop.Reference<xmlParserInput> | ArrayBufferLike | ArrayBufferView | null, handler: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlSwitchToEncoding(ctxt: interop.Pointer | interop.Reference<xmlParserCtxt> | ArrayBufferLike | ArrayBufferView | null, handler: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextConcat(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlTextMerge(first: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, second: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

interface xmlTextReader {
}
declare var xmlTextReader: interop.StructType<xmlTextReader>;

declare function xmlTextReaderAttributeCount(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderBaseUri(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlTextReaderByteConsumed(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderClose(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderConstBaseUri(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlTextReaderConstEncoding(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlTextReaderConstLocalName(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlTextReaderConstName(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlTextReaderConstNamespaceUri(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlTextReaderConstPrefix(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlTextReaderConstString(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlTextReaderConstValue(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlTextReaderConstXmlLang(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlTextReaderConstXmlVersion(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlTextReaderCurrentDoc(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlDoc> | null;

declare function xmlTextReaderCurrentNode(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlTextReaderDepth(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderExpand(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlTextReaderGetAttribute(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlTextReaderGetAttributeNo(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, no: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlTextReaderGetAttributeNs(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, localName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, namespaceURI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlTextReaderGetErrorHandler(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, f: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: xmlParserSeverities, p4: interop.Pointer | interop.Reference<any> | null) => void>> | ArrayBufferLike | ArrayBufferView | null, arg: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlTextReaderGetParserColumnNumber(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderGetParserLineNumber(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderGetParserProp(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, prop: number): number;

declare function xmlTextReaderGetRemainder(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlParserInputBuffer> | null;

declare function xmlTextReaderHasAttributes(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderHasValue(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderIsDefault(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderIsEmptyElement(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderIsNamespaceDecl(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderIsValid(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderLocalName(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlTextReaderLocatorBaseURI(locator: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlTextReaderLocatorLineNumber(locator: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderLookupNamespace(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare const enum xmlTextReaderMode {

	INITIAL = 0,

	INTERACTIVE = 1,

	ERROR = 2,

	EOF = 3,

	CLOSED = 4,

	READING = 5
}

declare function xmlTextReaderMoveToAttribute(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderMoveToAttributeNo(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, no: number): number;

declare function xmlTextReaderMoveToAttributeNs(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, localName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, namespaceURI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderMoveToElement(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderMoveToFirstAttribute(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderMoveToNextAttribute(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderName(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlTextReaderNamespaceUri(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlTextReaderNext(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderNextSibling(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderNodeType(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderNormalization(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderPrefix(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlTextReaderPreserve(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlTextReaderPreservePattern(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, pattern: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, namespaces: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderQuoteChar(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderRead(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderReadAttributeValue(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderReadInnerXml(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlTextReaderReadOuterXml(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlTextReaderReadState(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderReadString(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlTextReaderRelaxNGSetSchema(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, schema: interop.Pointer | interop.Reference<xmlRelaxNG> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderRelaxNGValidate(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, rng: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderRelaxNGValidateCtxt(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, ctxt: interop.Pointer | interop.Reference<xmlRelaxNGValidCtxt> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function xmlTextReaderSchemaValidate(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, xsd: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderSchemaValidateCtxt(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, ctxt: interop.Pointer | interop.Reference<xmlSchemaValidCtxt> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function xmlTextReaderSetErrorHandler(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: xmlParserSeverities, p4: interop.Pointer | interop.Reference<any> | null) => void>, arg: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlTextReaderSetParserProp(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, prop: number, value: number): number;

declare function xmlTextReaderSetSchema(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, schema: interop.Pointer | interop.Reference<xmlSchema> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderSetStructuredErrorHandler(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlError> | null) => void>, arg: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlTextReaderSetup(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null, input: interop.Pointer | interop.Reference<xmlParserInputBuffer> | ArrayBufferLike | ArrayBufferView | null, URL: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function xmlTextReaderStandalone(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextReaderValue(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlTextReaderXmlLang(reader: interop.Pointer | interop.Reference<xmlTextReader> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

interface xmlTextWriter {
}
declare var xmlTextWriter: interop.StructType<xmlTextWriter>;

declare function xmlTextWriterEndAttribute(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterEndCDATA(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterEndComment(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterEndDTD(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterEndDTDAttlist(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterEndDTDElement(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterEndDTDEntity(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterEndDocument(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterEndElement(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterEndPI(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterFlush(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterFullEndElement(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterSetIndent(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, indent: number): number;

declare function xmlTextWriterSetIndentString(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterSetQuoteChar(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, quotechar: number): number;

declare function xmlTextWriterStartAttribute(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterStartAttributeNS(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, namespaceURI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterStartCDATA(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterStartComment(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterStartDTD(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pubid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sysid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterStartDTDAttlist(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterStartDTDElement(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterStartDTDEntity(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, pe: number, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterStartDocument(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, version: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, encoding: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, standalone: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterStartElement(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterStartElementNS(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, namespaceURI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterStartPI(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, target: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteAttribute(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteAttributeNS(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, namespaceURI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteBase64(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, data: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, start: number, len: number): number;

declare function xmlTextWriterWriteBinHex(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, data: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, start: number, len: number): number;

declare function xmlTextWriterWriteCDATA(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteComment(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteDTD(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pubid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sysid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, subset: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteDTDAttlist(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteDTDElement(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteDTDEntity(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, pe: number, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pubid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sysid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ndataid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteDTDExternalEntity(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, pe: number, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pubid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sysid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ndataid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteDTDExternalEntityContents(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, pubid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sysid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ndataid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteDTDInternalEntity(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, pe: number, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteDTDNotation(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pubid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sysid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteElement(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteElementNS(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, namespaceURI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteFormatAttribute(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function xmlTextWriterWriteFormatAttributeNS(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, namespaceURI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function xmlTextWriterWriteFormatCDATA(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function xmlTextWriterWriteFormatComment(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function xmlTextWriterWriteFormatDTD(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pubid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sysid: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function xmlTextWriterWriteFormatDTDAttlist(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function xmlTextWriterWriteFormatDTDElement(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function xmlTextWriterWriteFormatDTDInternalEntity(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, pe: number, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function xmlTextWriterWriteFormatElement(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function xmlTextWriterWriteFormatElementNS(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, namespaceURI: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function xmlTextWriterWriteFormatPI(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, target: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function xmlTextWriterWriteFormatRaw(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function xmlTextWriterWriteFormatString(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): number;

declare function xmlTextWriterWritePI(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, target: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteRaw(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlTextWriterWriteRawLen(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlTextWriterWriteString(writer: interop.Pointer | interop.Reference<xmlTextWriter> | ArrayBufferLike | ArrayBufferView | null, content: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlThrDefBufferAllocScheme(v: xmlBufferAllocationScheme): xmlBufferAllocationScheme;

declare function xmlThrDefDefaultBufferSize(v: number): number;

declare function xmlThrDefDeregisterNodeDefault(func: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlNode> | null) => void>): interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlNode> | null) => void>;

declare function xmlThrDefDoValidityCheckingDefaultValue(v: number): number;

declare function xmlThrDefGetWarningsDefaultValue(v: number): number;

declare function xmlThrDefIndentTreeOutput(v: number): number;

declare function xmlThrDefKeepBlanksDefaultValue(v: number): number;

declare function xmlThrDefLineNumbersDefaultValue(v: number): number;

declare function xmlThrDefLoadExtDtdDefaultValue(v: number): number;

declare function xmlThrDefOutputBufferCreateFilenameDefault(func: interop.FunctionReference<(p1: string | null, p2: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | null, p3: number) => interop.Pointer | interop.Reference<xmlOutputBuffer> | null>): interop.FunctionReference<(p1: string | null, p2: interop.Pointer | interop.Reference<xmlCharEncodingHandler> | null, p3: number) => interop.Pointer | interop.Reference<xmlOutputBuffer> | null>;

declare function xmlThrDefParserDebugEntities(v: number): number;

declare function xmlThrDefParserInputBufferCreateFilenameDefault(func: interop.FunctionReference<(p1: string | null, p2: xmlCharEncoding) => interop.Pointer | interop.Reference<xmlParserInputBuffer> | null>): interop.FunctionReference<(p1: string | null, p2: xmlCharEncoding) => interop.Pointer | interop.Reference<xmlParserInputBuffer> | null>;

declare function xmlThrDefPedanticParserDefaultValue(v: number): number;

declare function xmlThrDefRegisterNodeDefault(func: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlNode> | null) => void>): interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlNode> | null) => void>;

declare function xmlThrDefSaveNoEmptyTags(v: number): number;

declare function xmlThrDefSetGenericErrorFunc(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, handler: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>): void;

declare function xmlThrDefSetStructuredErrorFunc(ctx: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, handler: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlError> | null) => void>): void;

declare function xmlThrDefSubstituteEntitiesDefaultValue(v: number): number;

declare function xmlThrDefTreeIndentString(v: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlUCSIsAegeanNumbers(code: number): number;

declare function xmlUCSIsAlphabeticPresentationForms(code: number): number;

declare function xmlUCSIsArabic(code: number): number;

declare function xmlUCSIsArabicPresentationFormsA(code: number): number;

declare function xmlUCSIsArabicPresentationFormsB(code: number): number;

declare function xmlUCSIsArmenian(code: number): number;

declare function xmlUCSIsArrows(code: number): number;

declare function xmlUCSIsBasicLatin(code: number): number;

declare function xmlUCSIsBengali(code: number): number;

declare function xmlUCSIsBlock(code: number, block: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlUCSIsBlockElements(code: number): number;

declare function xmlUCSIsBopomofo(code: number): number;

declare function xmlUCSIsBopomofoExtended(code: number): number;

declare function xmlUCSIsBoxDrawing(code: number): number;

declare function xmlUCSIsBraillePatterns(code: number): number;

declare function xmlUCSIsBuhid(code: number): number;

declare function xmlUCSIsByzantineMusicalSymbols(code: number): number;

declare function xmlUCSIsCJKCompatibility(code: number): number;

declare function xmlUCSIsCJKCompatibilityForms(code: number): number;

declare function xmlUCSIsCJKCompatibilityIdeographs(code: number): number;

declare function xmlUCSIsCJKCompatibilityIdeographsSupplement(code: number): number;

declare function xmlUCSIsCJKRadicalsSupplement(code: number): number;

declare function xmlUCSIsCJKSymbolsandPunctuation(code: number): number;

declare function xmlUCSIsCJKUnifiedIdeographs(code: number): number;

declare function xmlUCSIsCJKUnifiedIdeographsExtensionA(code: number): number;

declare function xmlUCSIsCJKUnifiedIdeographsExtensionB(code: number): number;

declare function xmlUCSIsCat(code: number, cat: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlUCSIsCatC(code: number): number;

declare function xmlUCSIsCatCc(code: number): number;

declare function xmlUCSIsCatCf(code: number): number;

declare function xmlUCSIsCatCo(code: number): number;

declare function xmlUCSIsCatCs(code: number): number;

declare function xmlUCSIsCatL(code: number): number;

declare function xmlUCSIsCatLl(code: number): number;

declare function xmlUCSIsCatLm(code: number): number;

declare function xmlUCSIsCatLo(code: number): number;

declare function xmlUCSIsCatLt(code: number): number;

declare function xmlUCSIsCatLu(code: number): number;

declare function xmlUCSIsCatM(code: number): number;

declare function xmlUCSIsCatMc(code: number): number;

declare function xmlUCSIsCatMe(code: number): number;

declare function xmlUCSIsCatMn(code: number): number;

declare function xmlUCSIsCatN(code: number): number;

declare function xmlUCSIsCatNd(code: number): number;

declare function xmlUCSIsCatNl(code: number): number;

declare function xmlUCSIsCatNo(code: number): number;

declare function xmlUCSIsCatP(code: number): number;

declare function xmlUCSIsCatPc(code: number): number;

declare function xmlUCSIsCatPd(code: number): number;

declare function xmlUCSIsCatPe(code: number): number;

declare function xmlUCSIsCatPf(code: number): number;

declare function xmlUCSIsCatPi(code: number): number;

declare function xmlUCSIsCatPo(code: number): number;

declare function xmlUCSIsCatPs(code: number): number;

declare function xmlUCSIsCatS(code: number): number;

declare function xmlUCSIsCatSc(code: number): number;

declare function xmlUCSIsCatSk(code: number): number;

declare function xmlUCSIsCatSm(code: number): number;

declare function xmlUCSIsCatSo(code: number): number;

declare function xmlUCSIsCatZ(code: number): number;

declare function xmlUCSIsCatZl(code: number): number;

declare function xmlUCSIsCatZp(code: number): number;

declare function xmlUCSIsCatZs(code: number): number;

declare function xmlUCSIsCherokee(code: number): number;

declare function xmlUCSIsCombiningDiacriticalMarks(code: number): number;

declare function xmlUCSIsCombiningDiacriticalMarksforSymbols(code: number): number;

declare function xmlUCSIsCombiningHalfMarks(code: number): number;

declare function xmlUCSIsCombiningMarksforSymbols(code: number): number;

declare function xmlUCSIsControlPictures(code: number): number;

declare function xmlUCSIsCurrencySymbols(code: number): number;

declare function xmlUCSIsCypriotSyllabary(code: number): number;

declare function xmlUCSIsCyrillic(code: number): number;

declare function xmlUCSIsCyrillicSupplement(code: number): number;

declare function xmlUCSIsDeseret(code: number): number;

declare function xmlUCSIsDevanagari(code: number): number;

declare function xmlUCSIsDingbats(code: number): number;

declare function xmlUCSIsEnclosedAlphanumerics(code: number): number;

declare function xmlUCSIsEnclosedCJKLettersandMonths(code: number): number;

declare function xmlUCSIsEthiopic(code: number): number;

declare function xmlUCSIsGeneralPunctuation(code: number): number;

declare function xmlUCSIsGeometricShapes(code: number): number;

declare function xmlUCSIsGeorgian(code: number): number;

declare function xmlUCSIsGothic(code: number): number;

declare function xmlUCSIsGreek(code: number): number;

declare function xmlUCSIsGreekExtended(code: number): number;

declare function xmlUCSIsGreekandCoptic(code: number): number;

declare function xmlUCSIsGujarati(code: number): number;

declare function xmlUCSIsGurmukhi(code: number): number;

declare function xmlUCSIsHalfwidthandFullwidthForms(code: number): number;

declare function xmlUCSIsHangulCompatibilityJamo(code: number): number;

declare function xmlUCSIsHangulJamo(code: number): number;

declare function xmlUCSIsHangulSyllables(code: number): number;

declare function xmlUCSIsHanunoo(code: number): number;

declare function xmlUCSIsHebrew(code: number): number;

declare function xmlUCSIsHighPrivateUseSurrogates(code: number): number;

declare function xmlUCSIsHighSurrogates(code: number): number;

declare function xmlUCSIsHiragana(code: number): number;

declare function xmlUCSIsIPAExtensions(code: number): number;

declare function xmlUCSIsIdeographicDescriptionCharacters(code: number): number;

declare function xmlUCSIsKanbun(code: number): number;

declare function xmlUCSIsKangxiRadicals(code: number): number;

declare function xmlUCSIsKannada(code: number): number;

declare function xmlUCSIsKatakana(code: number): number;

declare function xmlUCSIsKatakanaPhoneticExtensions(code: number): number;

declare function xmlUCSIsKhmer(code: number): number;

declare function xmlUCSIsKhmerSymbols(code: number): number;

declare function xmlUCSIsLao(code: number): number;

declare function xmlUCSIsLatin1Supplement(code: number): number;

declare function xmlUCSIsLatinExtendedA(code: number): number;

declare function xmlUCSIsLatinExtendedAdditional(code: number): number;

declare function xmlUCSIsLatinExtendedB(code: number): number;

declare function xmlUCSIsLetterlikeSymbols(code: number): number;

declare function xmlUCSIsLimbu(code: number): number;

declare function xmlUCSIsLinearBIdeograms(code: number): number;

declare function xmlUCSIsLinearBSyllabary(code: number): number;

declare function xmlUCSIsLowSurrogates(code: number): number;

declare function xmlUCSIsMalayalam(code: number): number;

declare function xmlUCSIsMathematicalAlphanumericSymbols(code: number): number;

declare function xmlUCSIsMathematicalOperators(code: number): number;

declare function xmlUCSIsMiscellaneousMathematicalSymbolsA(code: number): number;

declare function xmlUCSIsMiscellaneousMathematicalSymbolsB(code: number): number;

declare function xmlUCSIsMiscellaneousSymbols(code: number): number;

declare function xmlUCSIsMiscellaneousSymbolsandArrows(code: number): number;

declare function xmlUCSIsMiscellaneousTechnical(code: number): number;

declare function xmlUCSIsMongolian(code: number): number;

declare function xmlUCSIsMusicalSymbols(code: number): number;

declare function xmlUCSIsMyanmar(code: number): number;

declare function xmlUCSIsNumberForms(code: number): number;

declare function xmlUCSIsOgham(code: number): number;

declare function xmlUCSIsOldItalic(code: number): number;

declare function xmlUCSIsOpticalCharacterRecognition(code: number): number;

declare function xmlUCSIsOriya(code: number): number;

declare function xmlUCSIsOsmanya(code: number): number;

declare function xmlUCSIsPhoneticExtensions(code: number): number;

declare function xmlUCSIsPrivateUse(code: number): number;

declare function xmlUCSIsPrivateUseArea(code: number): number;

declare function xmlUCSIsRunic(code: number): number;

declare function xmlUCSIsShavian(code: number): number;

declare function xmlUCSIsSinhala(code: number): number;

declare function xmlUCSIsSmallFormVariants(code: number): number;

declare function xmlUCSIsSpacingModifierLetters(code: number): number;

declare function xmlUCSIsSpecials(code: number): number;

declare function xmlUCSIsSuperscriptsandSubscripts(code: number): number;

declare function xmlUCSIsSupplementalArrowsA(code: number): number;

declare function xmlUCSIsSupplementalArrowsB(code: number): number;

declare function xmlUCSIsSupplementalMathematicalOperators(code: number): number;

declare function xmlUCSIsSupplementaryPrivateUseAreaA(code: number): number;

declare function xmlUCSIsSupplementaryPrivateUseAreaB(code: number): number;

declare function xmlUCSIsSyriac(code: number): number;

declare function xmlUCSIsTagalog(code: number): number;

declare function xmlUCSIsTagbanwa(code: number): number;

declare function xmlUCSIsTags(code: number): number;

declare function xmlUCSIsTaiLe(code: number): number;

declare function xmlUCSIsTaiXuanJingSymbols(code: number): number;

declare function xmlUCSIsTamil(code: number): number;

declare function xmlUCSIsTelugu(code: number): number;

declare function xmlUCSIsThaana(code: number): number;

declare function xmlUCSIsThai(code: number): number;

declare function xmlUCSIsTibetan(code: number): number;

declare function xmlUCSIsUgaritic(code: number): number;

declare function xmlUCSIsUnifiedCanadianAboriginalSyllabics(code: number): number;

declare function xmlUCSIsVariationSelectors(code: number): number;

declare function xmlUCSIsVariationSelectorsSupplement(code: number): number;

declare function xmlUCSIsYiRadicals(code: number): number;

declare function xmlUCSIsYiSyllables(code: number): number;

declare function xmlUCSIsYijingHexagramSymbols(code: number): number;

interface xmlURI {
	scheme: interop.Pointer | interop.Reference<any> | null;
	opaque: interop.Pointer | interop.Reference<any> | null;
	authority: interop.Pointer | interop.Reference<any> | null;
	server: interop.Pointer | interop.Reference<any> | null;
	user: interop.Pointer | interop.Reference<any> | null;
	port: number;
	path: interop.Pointer | interop.Reference<any> | null;
	query: interop.Pointer | interop.Reference<any> | null;
	fragment: interop.Pointer | interop.Reference<any> | null;
	cleanup: number;
	query_raw: interop.Pointer | interop.Reference<any> | null;
}
declare var xmlURI: interop.StructType<xmlURI>;

/** Struct tag of {@link xmlURI}. */
type _xmlURI = xmlURI;
declare var _xmlURI: typeof xmlURI;

declare function xmlURIEscape(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlURIEscapeStr(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, list: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlURIUnescapeString(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number, target: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlUTF8Charcmp(utf1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, utf2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlUTF8Size(utf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlUTF8Strlen(utf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlUTF8Strloc(utf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, utfchar: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlUTF8Strndup(utf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlUTF8Strpos(utf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pos: number): string | null;

declare function xmlUTF8Strsize(utf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlUTF8Strsub(utf: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, start: number, len: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlUnlinkNode(cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlUnlockLibrary(): void;

declare function xmlUnsetNsProp(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlUnsetProp(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidBuildContentModel(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlElement> | ArrayBufferLike | ArrayBufferView | null): number;

interface xmlValidCtxt {
	userData: interop.Pointer | interop.Reference<any> | null;
	error: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	warning: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null) => void>;
	node: interop.Pointer | interop.Reference<xmlNode> | null;
	nodeNr: number;
	nodeMax: number;
	nodeTab: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlNode> | null> | null;
	finishDtd: number;
	doc: interop.Pointer | interop.Reference<xmlDoc> | null;
	valid: number;
	vstate: interop.Pointer | interop.Reference<xmlValidState> | null;
	vstateNr: number;
	vstateMax: number;
	vstateTab: interop.Pointer | interop.Reference<xmlValidState> | null;
	am: interop.Pointer | interop.Reference<xmlAutomata> | null;
	state: interop.Pointer | interop.Reference<xmlAutomataState> | null;
}
declare var xmlValidCtxt: interop.StructType<xmlValidCtxt>;

/** Struct tag of {@link xmlValidCtxt}. */
type _xmlValidCtxt = xmlValidCtxt;
declare var _xmlValidCtxt: typeof xmlValidCtxt;

declare function xmlValidCtxtNormalizeAttributeValue(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlValidGetPotentialChildren(ctree: interop.Pointer | interop.Reference<xmlElementContent> | ArrayBufferLike | ArrayBufferView | null, names: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null, len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, max: number): number;

declare function xmlValidGetValidElements(prev: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, next: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, names: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null, max: number): number;

declare function xmlValidNormalizeAttributeValue(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

interface xmlValidState {
}
declare var xmlValidState: interop.StructType<xmlValidState>;

declare function xmlValidateAttributeDecl(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, attr: interop.Pointer | interop.Reference<xmlAttribute> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateAttributeValue(type: xmlAttributeType, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateDocument(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateDocumentFinal(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateDtd(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, dtd: interop.Pointer | interop.Reference<xmlDtd> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateDtdFinal(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateElement(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateElementDecl(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlElement> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateNCName(value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, space: number): number;

declare function xmlValidateNMToken(value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, space: number): number;

declare function xmlValidateName(value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, space: number): number;

declare function xmlValidateNameValue(value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateNamesValue(value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateNmtokenValue(value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateNmtokensValue(value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateNotationDecl(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, nota: interop.Pointer | interop.Reference<xmlNotation> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateNotationUse(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, notationName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateOneAttribute(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, attr: interop.Pointer | interop.Reference<xmlAttr> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateOneElement(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateOneNamespace(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null, value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidatePopElement(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, qname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidatePushCData(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, data: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function xmlValidatePushElement(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, elem: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, qname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlValidateQName(value: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, space: number): number;

declare function xmlValidateRoot(ctxt: interop.Pointer | interop.Reference<xmlValidCtxt> | ArrayBufferLike | ArrayBufferView | null, doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

interface xmlXIncludeCtxt {
}
declare var xmlXIncludeCtxt: interop.StructType<xmlXIncludeCtxt>;

declare function xmlXIncludeFreeContext(ctxt: interop.Pointer | interop.Reference<xmlXIncludeCtxt> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXIncludeNewContext(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXIncludeCtxt> | null;

declare function xmlXIncludeProcess(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXIncludeProcessFlags(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, flags: number): number;

declare function xmlXIncludeProcessFlagsData(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, flags: number, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXIncludeProcessNode(ctxt: interop.Pointer | interop.Reference<xmlXIncludeCtxt> | ArrayBufferLike | ArrayBufferView | null, tree: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXIncludeProcessTree(tree: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXIncludeProcessTreeFlags(tree: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, flags: number): number;

declare function xmlXIncludeProcessTreeFlagsData(tree: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, flags: number, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXIncludeSetFlags(ctxt: interop.Pointer | interop.Reference<xmlXIncludeCtxt> | ArrayBufferLike | ArrayBufferView | null, flags: number): number;

declare function xmlXPathAddValues(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): void;

interface xmlXPathAxis {
	name: string | null;
	func: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlXPathParserContext> | null, p2: interop.Pointer | interop.Reference<xmlXPathObject> | null) => interop.Pointer | interop.Reference<xmlXPathObject> | null>;
}
declare var xmlXPathAxis: interop.StructType<xmlXPathAxis>;

/** Struct tag of {@link xmlXPathAxis}. */
type _xmlXPathAxis = xmlXPathAxis;
declare var _xmlXPathAxis: typeof xmlXPathAxis;

declare function xmlXPathBooleanFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathCastBooleanToNumber(val: number): number;

declare function xmlXPathCastBooleanToString(val: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlXPathCastNodeSetToBoolean(ns: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathCastNodeSetToNumber(ns: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathCastNodeSetToString(ns: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlXPathCastNodeToNumber(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathCastNodeToString(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlXPathCastNumberToBoolean(val: number): number;

declare function xmlXPathCastNumberToString(val: number): interop.Pointer | interop.Reference<any> | null;

declare function xmlXPathCastStringToBoolean(val: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathCastStringToNumber(val: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathCastToBoolean(val: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathCastToNumber(val: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathCastToString(val: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlXPathCeilingFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathCmpNodes(node1: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, node2: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

interface xmlXPathCompExpr {
}
declare var xmlXPathCompExpr: interop.StructType<xmlXPathCompExpr>;

declare function xmlXPathCompareValues(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, inf: number, strict: number): number;

declare function xmlXPathCompile(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathCompExpr> | null;

declare function xmlXPathCompiledEval(comp: interop.Pointer | interop.Reference<xmlXPathCompExpr> | ArrayBufferLike | ArrayBufferView | null, ctx: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathCompiledEvalToBoolean(comp: interop.Pointer | interop.Reference<xmlXPathCompExpr> | ArrayBufferLike | ArrayBufferView | null, ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathConcatFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathContainsFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

interface xmlXPathContext {
	doc: interop.Pointer | interop.Reference<xmlDoc> | null;
	node: interop.Pointer | interop.Reference<xmlNode> | null;
	nb_variables_unused: number;
	max_variables_unused: number;
	varHash: interop.Pointer | interop.Reference<xmlHashTable> | null;
	nb_types: number;
	max_types: number;
	types: interop.Pointer | interop.Reference<xmlXPathType> | null;
	nb_funcs_unused: number;
	max_funcs_unused: number;
	funcHash: interop.Pointer | interop.Reference<xmlHashTable> | null;
	nb_axis: number;
	max_axis: number;
	axis: interop.Pointer | interop.Reference<xmlXPathAxis> | null;
	namespaces: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlNs> | null> | null;
	nsNr: number;
	user: interop.Pointer | interop.Reference<any> | null;
	contextSize: number;
	proximityPosition: number;
	xptr: number;
	here: interop.Pointer | interop.Reference<xmlNode> | null;
	origin: interop.Pointer | interop.Reference<xmlNode> | null;
	nsHash: interop.Pointer | interop.Reference<xmlHashTable> | null;
	varLookupFunc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null) => interop.Pointer | interop.Reference<xmlXPathObject> | null>;
	varLookupData: interop.Pointer | interop.Reference<any> | null;
	extra: interop.Pointer | interop.Reference<any> | null;
	function: string | null;
	functionURI: string | null;
	funcLookupFunc: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null) => interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlXPathParserContext> | null, p2: number) => void>>;
	funcLookupData: interop.Pointer | interop.Reference<any> | null;
	tmpNsList: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlNs> | null> | null;
	tmpNsNr: number;
	userData: interop.Pointer | interop.Reference<any> | null;
	error: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<xmlError> | null) => void>;
	lastError: xmlError;
	debugNode: interop.Pointer | interop.Reference<xmlNode> | null;
	dict: interop.Pointer | interop.Reference<xmlDict> | null;
	flags: number;
	cache: interop.Pointer | interop.Reference<any> | null;
	opLimit: number;
	opCount: number;
	depth: number;
}
declare var xmlXPathContext: interop.StructType<xmlXPathContext>;

/** Struct tag of {@link xmlXPathContext}. */
type _xmlXPathContext = xmlXPathContext;
declare var _xmlXPathContext: typeof xmlXPathContext;

declare function xmlXPathContextSetCache(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, active: number, value: number, options: number): number;

declare function xmlXPathConvertBoolean(val: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathConvertNumber(val: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathConvertString(val: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathCountFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathCtxtCompile(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathCompExpr> | null;

declare function xmlXPathDebugDumpCompExpr(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, comp: interop.Pointer | interop.Reference<xmlXPathCompExpr> | ArrayBufferLike | ArrayBufferView | null, depth: number): void;

declare function xmlXPathDebugDumpObject(output: interop.Pointer | interop.Reference<FILE> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null, depth: number): void;

declare function xmlXPathDifference(nodes1: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, nodes2: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathDistinct(nodes: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathDistinctSorted(nodes: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathDivValues(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathEqualValues(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathErr(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, error: number): void;

declare const enum xmlXPathError {

	XPATH_EXPRESSION_OK = 0,

	XPATH_NUMBER_ERROR = 1,

	XPATH_UNFINISHED_LITERAL_ERROR = 2,

	XPATH_START_LITERAL_ERROR = 3,

	XPATH_VARIABLE_REF_ERROR = 4,

	XPATH_UNDEF_VARIABLE_ERROR = 5,

	XPATH_INVALID_PREDICATE_ERROR = 6,

	XPATH_EXPR_ERROR = 7,

	XPATH_UNCLOSED_ERROR = 8,

	XPATH_UNKNOWN_FUNC_ERROR = 9,

	XPATH_INVALID_OPERAND = 10,

	XPATH_INVALID_TYPE = 11,

	XPATH_INVALID_ARITY = 12,

	XPATH_INVALID_CTXT_SIZE = 13,

	XPATH_INVALID_CTXT_POSITION = 14,

	XPATH_MEMORY_ERROR = 15,

	XPTR_SYNTAX_ERROR = 16,

	XPTR_RESOURCE_ERROR = 17,

	XPTR_SUB_RESOURCE_ERROR = 18,

	XPATH_UNDEF_PREFIX_ERROR = 19,

	XPATH_ENCODING_ERROR = 20,

	XPATH_INVALID_CHAR_ERROR = 21,

	XPATH_INVALID_CTXT = 22,

	XPATH_STACK_ERROR = 23,

	XPATH_FORBID_VARIABLE_ERROR = 24,

	XPATH_OP_LIMIT_EXCEEDED = 25,

	XPATH_RECURSION_LIMIT_EXCEEDED = 26
}

declare function xmlXPathEval(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ctx: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathEvalExpr(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathEvalExpression(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathEvalPredicate(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, res: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathEvaluatePredicateResult(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, res: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathFalseFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathFloorFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathFreeCompExpr(comp: interop.Pointer | interop.Reference<xmlXPathCompExpr> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathFreeContext(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathFreeNodeSet(obj: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathFreeNodeSetList(obj: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathFreeObject(obj: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathFreeParserContext(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): void;

interface xmlXPathFunct {
	name: string | null;
	func: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlXPathParserContext> | null, p2: number) => void>;
}
declare var xmlXPathFunct: interop.StructType<xmlXPathFunct>;

/** Struct tag of {@link xmlXPathFunct}. */
type _xmlXPathFunct = xmlXPathFunct;
declare var _xmlXPathFunct: typeof xmlXPathFunct;

declare function xmlXPathFunctionLookup(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlXPathParserContext> | null, p2: number) => void>;

declare function xmlXPathFunctionLookupNS(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ns_uri: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlXPathParserContext> | null, p2: number) => void>;

declare function xmlXPathHasSameNodes(nodes1: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, nodes2: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathIdFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathInit(): void;

declare function xmlXPathIntersection(nodes1: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, nodes2: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathIsInf(val: number): number;

declare function xmlXPathIsNaN(val: number): number;

declare function xmlXPathIsNodeType(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathLangFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathLastFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathLeading(nodes1: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, nodes2: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathLeadingSorted(nodes1: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, nodes2: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathLocalNameFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathModValues(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathMultValues(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): void;

declare var xmlXPathNAN: number;

declare var xmlXPathNINF: number;

declare function xmlXPathNamespaceURIFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathNewBoolean(val: number): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathNewCString(val: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathNewContext(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathContext> | null;

declare function xmlXPathNewFloat(val: number): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathNewNodeSet(val: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathNewNodeSetList(val: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathNewParserContext(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathParserContext> | null;

declare function xmlXPathNewString(val: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathNewValueTree(val: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathNextAncestor(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlXPathNextAncestorOrSelf(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlXPathNextAttribute(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlXPathNextChild(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlXPathNextDescendant(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlXPathNextDescendantOrSelf(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlXPathNextFollowing(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlXPathNextFollowingSibling(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlXPathNextNamespace(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlXPathNextParent(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlXPathNextPreceding(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlXPathNextPrecedingSibling(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlXPathNextSelf(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, cur: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlXPathNodeEval(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ctx: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathNodeLeading(nodes: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathNodeLeadingSorted(nodes: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathNodeSetAdd(cur: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, val: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathNodeSetAddNs(cur: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathNodeSetAddUnique(cur: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, val: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathNodeSetContains(cur: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, val: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathNodeSetCreate(val: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathNodeSetDel(cur: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, val: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathNodeSetFreeNs(ns: interop.Pointer | interop.Reference<xmlNs> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathNodeSetMerge(val1: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, val2: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathNodeSetRemove(cur: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, val: number): void;

declare function xmlXPathNodeSetSort(set: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathNodeTrailing(nodes: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathNodeTrailingSorted(nodes: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathNormalizeFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathNotEqualValues(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathNotFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathNsLookup(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function xmlXPathNumberFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

interface xmlXPathObject {
	type: xmlXPathObjectType;
	nodesetval: interop.Pointer | interop.Reference<xmlNodeSet> | null;
	boolval: number;
	floatval: number;
	stringval: interop.Pointer | interop.Reference<any> | null;
	user: interop.Pointer | interop.Reference<any> | null;
	index: number;
	user2: interop.Pointer | interop.Reference<any> | null;
	index2: number;
}
declare var xmlXPathObject: interop.StructType<xmlXPathObject>;

/** Struct tag of {@link xmlXPathObject}. */
type _xmlXPathObject = xmlXPathObject;
declare var _xmlXPathObject: typeof xmlXPathObject;

declare function xmlXPathObjectCopy(val: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare const enum xmlXPathObjectType {

	UNDEFINED = 0,

	NODESET = 1,

	BOOLEAN = 2,

	NUMBER = 3,

	STRING = 4,

	POINT = 5,

	RANGE = 6,

	LOCATIONSET = 7,

	USERS = 8,

	XSLT_TREE = 9
}

declare function xmlXPathOrderDocElems(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null): number;

declare var xmlXPathPINF: number;

declare function xmlXPathParseNCName(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlXPathParseName(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

interface xmlXPathParserContext {
	cur: string | null;
	base: string | null;
	error: number;
	context: interop.Pointer | interop.Reference<xmlXPathContext> | null;
	value: interop.Pointer | interop.Reference<xmlXPathObject> | null;
	valueNr: number;
	valueMax: number;
	valueTab: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<xmlXPathObject> | null> | null;
	comp: interop.Pointer | interop.Reference<xmlXPathCompExpr> | null;
	xptr: number;
	ancestor: interop.Pointer | interop.Reference<xmlNode> | null;
	valueFrame: number;
}
declare var xmlXPathParserContext: interop.StructType<xmlXPathParserContext>;

/** Struct tag of {@link xmlXPathParserContext}. */
type _xmlXPathParserContext = xmlXPathParserContext;
declare var _xmlXPathParserContext: typeof xmlXPathParserContext;

declare function xmlXPathPopBoolean(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathPopExternal(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlXPathPopNodeSet(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathPopNumber(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathPopString(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function xmlXPathPositionFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathRegisterAllFunctions(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathRegisterFunc(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlXPathParserContext> | null, p2: number) => void>): number;

declare function xmlXPathRegisterFuncLookup(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null) => interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlXPathParserContext> | null, p2: number) => void>>, funcCtxt: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathRegisterFuncNS(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ns_uri: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlXPathParserContext> | null, p2: number) => void>): number;

declare function xmlXPathRegisterNs(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, prefix: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ns_uri: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathRegisterVariable(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathRegisterVariableLookup(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, f: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: string | null) => interop.Pointer | interop.Reference<xmlXPathObject> | null>, data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathRegisterVariableNS(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ns_uri: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathRegisteredFuncsCleanup(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathRegisteredNsCleanup(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathRegisteredVariablesCleanup(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathRoot(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathRoundFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathSetContextNode(node: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, ctx: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathStartsWithFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathStringEvalNumber(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function xmlXPathStringFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathStringLengthFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathSubValues(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPathSubstringAfterFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathSubstringBeforeFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathSubstringFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathSumFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathTrailing(nodes1: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, nodes2: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathTrailingSorted(nodes1: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null, nodes2: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNodeSet> | null;

declare function xmlXPathTranslateFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPathTrueFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

interface xmlXPathType {
	name: string | null;
	func: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<xmlXPathObject> | null, p2: number) => number>;
}
declare var xmlXPathType: interop.StructType<xmlXPathType>;

/** Struct tag of {@link xmlXPathType}. */
type _xmlXPathType = xmlXPathType;
declare var _xmlXPathType: typeof xmlXPathType;

declare function xmlXPathValueFlipSign(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): void;

interface xmlXPathVariable {
	name: string | null;
	value: interop.Pointer | interop.Reference<xmlXPathObject> | null;
}
declare var xmlXPathVariable: interop.StructType<xmlXPathVariable>;

/** Struct tag of {@link xmlXPathVariable}. */
type _xmlXPathVariable = xmlXPathVariable;
declare var _xmlXPathVariable: typeof xmlXPathVariable;

declare function xmlXPathVariableLookup(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathVariableLookupNS(ctxt: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ns_uri: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathWrapCString(val: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathWrapExternal(val: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathWrapNodeSet(val: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPathWrapString(val: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPatherror(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, line: number, no: number): void;

declare function xmlXPtrBuildNodeList(obj: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlNode> | null;

declare function xmlXPtrEval(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ctx: interop.Pointer | interop.Reference<xmlXPathContext> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPtrEvalRangePredicate(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPtrFreeLocationSet(obj: interop.Pointer | interop.Reference<xmlLocationSet> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPtrLocationSetAdd(cur: interop.Pointer | interop.Reference<xmlLocationSet> | ArrayBufferLike | ArrayBufferView | null, val: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPtrLocationSetCreate(val: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlLocationSet> | null;

declare function xmlXPtrLocationSetDel(cur: interop.Pointer | interop.Reference<xmlLocationSet> | ArrayBufferLike | ArrayBufferView | null, val: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): void;

declare function xmlXPtrLocationSetMerge(val1: interop.Pointer | interop.Reference<xmlLocationSet> | ArrayBufferLike | ArrayBufferView | null, val2: interop.Pointer | interop.Reference<xmlLocationSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlLocationSet> | null;

declare function xmlXPtrLocationSetRemove(cur: interop.Pointer | interop.Reference<xmlLocationSet> | ArrayBufferLike | ArrayBufferView | null, val: number): void;

declare function xmlXPtrNewCollapsedRange(start: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPtrNewContext(doc: interop.Pointer | interop.Reference<xmlDoc> | ArrayBufferLike | ArrayBufferView | null, here: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, origin: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathContext> | null;

declare function xmlXPtrNewLocationSetNodeSet(set: interop.Pointer | interop.Reference<xmlNodeSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPtrNewLocationSetNodes(start: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, end: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPtrNewRange(start: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, startindex: number, end: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, endindex: number): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPtrNewRangeNodeObject(start: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, end: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPtrNewRangeNodePoint(start: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, end: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPtrNewRangeNodes(start: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null, end: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPtrNewRangePointNode(start: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null, end: interop.Pointer | interop.Reference<xmlNode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPtrNewRangePoints(start: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null, end: interop.Pointer | interop.Reference<xmlXPathObject> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;

declare function xmlXPtrRangeToFunction(ctxt: interop.Pointer | interop.Reference<xmlXPathParserContext> | ArrayBufferLike | ArrayBufferView | null, nargs: number): void;

declare function xmlXPtrWrapLocationSet(val: interop.Pointer | interop.Reference<xmlLocationSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<xmlXPathObject> | null;
