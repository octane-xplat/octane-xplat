
declare const U16_MAX_LENGTH: number;

declare const U16_SURROGATE_OFFSET: number;

declare const U8_LEAD3_T1_BITS: string;

declare const U8_LEAD4_T1_BITS: string;

declare const U8_MAX_LENGTH: number;

declare const enum UBidiPairedBracketType {

	NONE = 0,

	OPEN = 1,

	CLOSE = 2,

	COUNT = 3
}

declare const enum UBlockCode {

	NO_BLOCK = 0,

	BASIC_LATIN = 1,

	LATIN_1_SUPPLEMENT = 2,

	LATIN_EXTENDED_A = 3,

	LATIN_EXTENDED_B = 4,

	IPA_EXTENSIONS = 5,

	SPACING_MODIFIER_LETTERS = 6,

	COMBINING_DIACRITICAL_MARKS = 7,

	GREEK = 8,

	CYRILLIC = 9,

	ARMENIAN = 10,

	HEBREW = 11,

	ARABIC = 12,

	SYRIAC = 13,

	THAANA = 14,

	DEVANAGARI = 15,

	BENGALI = 16,

	GURMUKHI = 17,

	GUJARATI = 18,

	ORIYA = 19,

	TAMIL = 20,

	TELUGU = 21,

	KANNADA = 22,

	MALAYALAM = 23,

	SINHALA = 24,

	THAI = 25,

	LAO = 26,

	TIBETAN = 27,

	MYANMAR = 28,

	GEORGIAN = 29,

	HANGUL_JAMO = 30,

	ETHIOPIC = 31,

	CHEROKEE = 32,

	UNIFIED_CANADIAN_ABORIGINAL_SYLLABICS = 33,

	OGHAM = 34,

	RUNIC = 35,

	KHMER = 36,

	MONGOLIAN = 37,

	LATIN_EXTENDED_ADDITIONAL = 38,

	GREEK_EXTENDED = 39,

	GENERAL_PUNCTUATION = 40,

	SUPERSCRIPTS_AND_SUBSCRIPTS = 41,

	CURRENCY_SYMBOLS = 42,

	COMBINING_MARKS_FOR_SYMBOLS = 43,

	LETTERLIKE_SYMBOLS = 44,

	NUMBER_FORMS = 45,

	ARROWS = 46,

	MATHEMATICAL_OPERATORS = 47,

	MISCELLANEOUS_TECHNICAL = 48,

	CONTROL_PICTURES = 49,

	OPTICAL_CHARACTER_RECOGNITION = 50,

	ENCLOSED_ALPHANUMERICS = 51,

	BOX_DRAWING = 52,

	BLOCK_ELEMENTS = 53,

	GEOMETRIC_SHAPES = 54,

	MISCELLANEOUS_SYMBOLS = 55,

	DINGBATS = 56,

	BRAILLE_PATTERNS = 57,

	CJK_RADICALS_SUPPLEMENT = 58,

	KANGXI_RADICALS = 59,

	IDEOGRAPHIC_DESCRIPTION_CHARACTERS = 60,

	CJK_SYMBOLS_AND_PUNCTUATION = 61,

	HIRAGANA = 62,

	KATAKANA = 63,

	BOPOMOFO = 64,

	HANGUL_COMPATIBILITY_JAMO = 65,

	KANBUN = 66,

	BOPOMOFO_EXTENDED = 67,

	ENCLOSED_CJK_LETTERS_AND_MONTHS = 68,

	CJK_COMPATIBILITY = 69,

	CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A = 70,

	CJK_UNIFIED_IDEOGRAPHS = 71,

	YI_SYLLABLES = 72,

	YI_RADICALS = 73,

	HANGUL_SYLLABLES = 74,

	HIGH_SURROGATES = 75,

	HIGH_PRIVATE_USE_SURROGATES = 76,

	LOW_SURROGATES = 77,

	PRIVATE_USE_AREA = 78,

	PRIVATE_USE = 78,

	CJK_COMPATIBILITY_IDEOGRAPHS = 79,

	ALPHABETIC_PRESENTATION_FORMS = 80,

	ARABIC_PRESENTATION_FORMS_A = 81,

	COMBINING_HALF_MARKS = 82,

	CJK_COMPATIBILITY_FORMS = 83,

	SMALL_FORM_VARIANTS = 84,

	ARABIC_PRESENTATION_FORMS_B = 85,

	SPECIALS = 86,

	HALFWIDTH_AND_FULLWIDTH_FORMS = 87,

	OLD_ITALIC = 88,

	GOTHIC = 89,

	DESERET = 90,

	BYZANTINE_MUSICAL_SYMBOLS = 91,

	MUSICAL_SYMBOLS = 92,

	MATHEMATICAL_ALPHANUMERIC_SYMBOLS = 93,

	CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B = 94,

	CJK_COMPATIBILITY_IDEOGRAPHS_SUPPLEMENT = 95,

	TAGS = 96,

	CYRILLIC_SUPPLEMENT = 97,

	CYRILLIC_SUPPLEMENTARY = 97,

	TAGALOG = 98,

	HANUNOO = 99,

	BUHID = 100,

	TAGBANWA = 101,

	MISCELLANEOUS_MATHEMATICAL_SYMBOLS_A = 102,

	SUPPLEMENTAL_ARROWS_A = 103,

	SUPPLEMENTAL_ARROWS_B = 104,

	MISCELLANEOUS_MATHEMATICAL_SYMBOLS_B = 105,

	SUPPLEMENTAL_MATHEMATICAL_OPERATORS = 106,

	KATAKANA_PHONETIC_EXTENSIONS = 107,

	VARIATION_SELECTORS = 108,

	SUPPLEMENTARY_PRIVATE_USE_AREA_A = 109,

	SUPPLEMENTARY_PRIVATE_USE_AREA_B = 110,

	LIMBU = 111,

	TAI_LE = 112,

	KHMER_SYMBOLS = 113,

	PHONETIC_EXTENSIONS = 114,

	MISCELLANEOUS_SYMBOLS_AND_ARROWS = 115,

	YIJING_HEXAGRAM_SYMBOLS = 116,

	LINEAR_B_SYLLABARY = 117,

	LINEAR_B_IDEOGRAMS = 118,

	AEGEAN_NUMBERS = 119,

	UGARITIC = 120,

	SHAVIAN = 121,

	OSMANYA = 122,

	CYPRIOT_SYLLABARY = 123,

	TAI_XUAN_JING_SYMBOLS = 124,

	VARIATION_SELECTORS_SUPPLEMENT = 125,

	ANCIENT_GREEK_MUSICAL_NOTATION = 126,

	ANCIENT_GREEK_NUMBERS = 127,

	ARABIC_SUPPLEMENT = 128,

	BUGINESE = 129,

	CJK_STROKES = 130,

	COMBINING_DIACRITICAL_MARKS_SUPPLEMENT = 131,

	COPTIC = 132,

	ETHIOPIC_EXTENDED = 133,

	ETHIOPIC_SUPPLEMENT = 134,

	GEORGIAN_SUPPLEMENT = 135,

	GLAGOLITIC = 136,

	KHAROSHTHI = 137,

	MODIFIER_TONE_LETTERS = 138,

	NEW_TAI_LUE = 139,

	OLD_PERSIAN = 140,

	PHONETIC_EXTENSIONS_SUPPLEMENT = 141,

	SUPPLEMENTAL_PUNCTUATION = 142,

	SYLOTI_NAGRI = 143,

	TIFINAGH = 144,

	VERTICAL_FORMS = 145,

	NKO = 146,

	BALINESE = 147,

	LATIN_EXTENDED_C = 148,

	LATIN_EXTENDED_D = 149,

	PHAGS_PA = 150,

	PHOENICIAN = 151,

	CUNEIFORM = 152,

	CUNEIFORM_NUMBERS_AND_PUNCTUATION = 153,

	COUNTING_ROD_NUMERALS = 154,

	SUNDANESE = 155,

	LEPCHA = 156,

	OL_CHIKI = 157,

	CYRILLIC_EXTENDED_A = 158,

	VAI = 159,

	CYRILLIC_EXTENDED_B = 160,

	SAURASHTRA = 161,

	KAYAH_LI = 162,

	REJANG = 163,

	CHAM = 164,

	ANCIENT_SYMBOLS = 165,

	PHAISTOS_DISC = 166,

	LYCIAN = 167,

	CARIAN = 168,

	LYDIAN = 169,

	MAHJONG_TILES = 170,

	DOMINO_TILES = 171,

	SAMARITAN = 172,

	UNIFIED_CANADIAN_ABORIGINAL_SYLLABICS_EXTENDED = 173,

	TAI_THAM = 174,

	VEDIC_EXTENSIONS = 175,

	LISU = 176,

	BAMUM = 177,

	COMMON_INDIC_NUMBER_FORMS = 178,

	DEVANAGARI_EXTENDED = 179,

	HANGUL_JAMO_EXTENDED_A = 180,

	JAVANESE = 181,

	MYANMAR_EXTENDED_A = 182,

	TAI_VIET = 183,

	MEETEI_MAYEK = 184,

	HANGUL_JAMO_EXTENDED_B = 185,

	IMPERIAL_ARAMAIC = 186,

	OLD_SOUTH_ARABIAN = 187,

	AVESTAN = 188,

	INSCRIPTIONAL_PARTHIAN = 189,

	INSCRIPTIONAL_PAHLAVI = 190,

	OLD_TURKIC = 191,

	RUMI_NUMERAL_SYMBOLS = 192,

	KAITHI = 193,

	EGYPTIAN_HIEROGLYPHS = 194,

	ENCLOSED_ALPHANUMERIC_SUPPLEMENT = 195,

	ENCLOSED_IDEOGRAPHIC_SUPPLEMENT = 196,

	CJK_UNIFIED_IDEOGRAPHS_EXTENSION_C = 197,

	MANDAIC = 198,

	BATAK = 199,

	ETHIOPIC_EXTENDED_A = 200,

	BRAHMI = 201,

	BAMUM_SUPPLEMENT = 202,

	KANA_SUPPLEMENT = 203,

	PLAYING_CARDS = 204,

	MISCELLANEOUS_SYMBOLS_AND_PICTOGRAPHS = 205,

	EMOTICONS = 206,

	TRANSPORT_AND_MAP_SYMBOLS = 207,

	ALCHEMICAL_SYMBOLS = 208,

	CJK_UNIFIED_IDEOGRAPHS_EXTENSION_D = 209,

	ARABIC_EXTENDED_A = 210,

	ARABIC_MATHEMATICAL_ALPHABETIC_SYMBOLS = 211,

	CHAKMA = 212,

	MEETEI_MAYEK_EXTENSIONS = 213,

	MEROITIC_CURSIVE = 214,

	MEROITIC_HIEROGLYPHS = 215,

	MIAO = 216,

	SHARADA = 217,

	SORA_SOMPENG = 218,

	SUNDANESE_SUPPLEMENT = 219,

	TAKRI = 220,

	BASSA_VAH = 221,

	CAUCASIAN_ALBANIAN = 222,

	COPTIC_EPACT_NUMBERS = 223,

	COMBINING_DIACRITICAL_MARKS_EXTENDED = 224,

	DUPLOYAN = 225,

	ELBASAN = 226,

	GEOMETRIC_SHAPES_EXTENDED = 227,

	GRANTHA = 228,

	KHOJKI = 229,

	KHUDAWADI = 230,

	LATIN_EXTENDED_E = 231,

	LINEAR_A = 232,

	MAHAJANI = 233,

	MANICHAEAN = 234,

	MENDE_KIKAKUI = 235,

	MODI = 236,

	MRO = 237,

	MYANMAR_EXTENDED_B = 238,

	NABATAEAN = 239,

	OLD_NORTH_ARABIAN = 240,

	OLD_PERMIC = 241,

	ORNAMENTAL_DINGBATS = 242,

	PAHAWH_HMONG = 243,

	PALMYRENE = 244,

	PAU_CIN_HAU = 245,

	PSALTER_PAHLAVI = 246,

	SHORTHAND_FORMAT_CONTROLS = 247,

	SIDDHAM = 248,

	SINHALA_ARCHAIC_NUMBERS = 249,

	SUPPLEMENTAL_ARROWS_C = 250,

	TIRHUTA = 251,

	WARANG_CITI = 252,

	AHOM = 253,

	ANATOLIAN_HIEROGLYPHS = 254,

	CHEROKEE_SUPPLEMENT = 255,

	CJK_UNIFIED_IDEOGRAPHS_EXTENSION_E = 256,

	EARLY_DYNASTIC_CUNEIFORM = 257,

	HATRAN = 258,

	MULTANI = 259,

	OLD_HUNGARIAN = 260,

	SUPPLEMENTAL_SYMBOLS_AND_PICTOGRAPHS = 261,

	SUTTON_SIGNWRITING = 262,

	ADLAM = 263,

	BHAIKSUKI = 264,

	CYRILLIC_EXTENDED_C = 265,

	GLAGOLITIC_SUPPLEMENT = 266,

	IDEOGRAPHIC_SYMBOLS_AND_PUNCTUATION = 267,

	MARCHEN = 268,

	MONGOLIAN_SUPPLEMENT = 269,

	NEWA = 270,

	OSAGE = 271,

	TANGUT = 272,

	TANGUT_COMPONENTS = 273,

	CJK_UNIFIED_IDEOGRAPHS_EXTENSION_F = 274,

	KANA_EXTENDED_A = 275,

	MASARAM_GONDI = 276,

	NUSHU = 277,

	SOYOMBO = 278,

	SYRIAC_SUPPLEMENT = 279,

	ZANABAZAR_SQUARE = 280,

	CHESS_SYMBOLS = 281,

	DOGRA = 282,

	GEORGIAN_EXTENDED = 283,

	GUNJALA_GONDI = 284,

	HANIFI_ROHINGYA = 285,

	INDIC_SIYAQ_NUMBERS = 286,

	MAKASAR = 287,

	MAYAN_NUMERALS = 288,

	MEDEFAIDRIN = 289,

	OLD_SOGDIAN = 290,

	SOGDIAN = 291,

	EGYPTIAN_HIEROGLYPH_FORMAT_CONTROLS = 292,

	ELYMAIC = 293,

	NANDINAGARI = 294,

	NYIAKENG_PUACHUE_HMONG = 295,

	OTTOMAN_SIYAQ_NUMBERS = 296,

	SMALL_KANA_EXTENSION = 297,

	SYMBOLS_AND_PICTOGRAPHS_EXTENDED_A = 298,

	TAMIL_SUPPLEMENT = 299,

	WANCHO = 300,

	CHORASMIAN = 301,

	CJK_UNIFIED_IDEOGRAPHS_EXTENSION_G = 302,

	DIVES_AKURU = 303,

	KHITAN_SMALL_SCRIPT = 304,

	LISU_SUPPLEMENT = 305,

	SYMBOLS_FOR_LEGACY_COMPUTING = 306,

	TANGUT_SUPPLEMENT = 307,

	YEZIDI = 308,

	ARABIC_EXTENDED_B = 309,

	CYPRO_MINOAN = 310,

	ETHIOPIC_EXTENDED_B = 311,

	KANA_EXTENDED_B = 312,

	LATIN_EXTENDED_F = 313,

	LATIN_EXTENDED_G = 314,

	OLD_UYGHUR = 315,

	TANGSA = 316,

	TOTO = 317,

	UNIFIED_CANADIAN_ABORIGINAL_SYLLABICS_EXTENDED_A = 318,

	VITHKUQI = 319,

	ZNAMENNY_MUSICAL_NOTATION = 320,

	ARABIC_EXTENDED_C = 321,

	CJK_UNIFIED_IDEOGRAPHS_EXTENSION_H = 322,

	CYRILLIC_EXTENDED_D = 323,

	DEVANAGARI_EXTENDED_A = 324,

	KAKTOVIK_NUMERALS = 325,

	KAWI = 326,

	NAG_MUNDARI = 327,

	CJK_UNIFIED_IDEOGRAPHS_EXTENSION_I = 328,

	COUNT = 329,

	INVALID_CODE = -1
}

interface UBreakIterator {
}
declare var UBreakIterator: interop.StructType<UBreakIterator>;

declare const UCHAR_MAX_VALUE: number;

declare const UCHAR_MIN_VALUE: number;

declare const UCLN_NO_AUTO_CLEANUP: number;

declare const UCNV_ESCAPE_C: string;

declare const UCNV_ESCAPE_CSS2: string;

declare const UCNV_ESCAPE_JAVA: string;

declare const UCNV_ESCAPE_UNICODE: string;

declare const UCNV_ESCAPE_XML_DEC: string;

declare const UCNV_ESCAPE_XML_HEX: string;

declare function UCNV_FROM_U_CALLBACK_ESCAPE_74(context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, fromUArgs: interop.Pointer | interop.Reference<UConverterFromUnicodeArgs> | ArrayBufferLike | ArrayBufferView | null, codeUnits: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number, codePoint: number, reason: UConverterCallbackReason, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function UCNV_FROM_U_CALLBACK_SKIP_74(context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, fromUArgs: interop.Pointer | interop.Reference<UConverterFromUnicodeArgs> | ArrayBufferLike | ArrayBufferView | null, codeUnits: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number, codePoint: number, reason: UConverterCallbackReason, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function UCNV_FROM_U_CALLBACK_STOP_74(context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, fromUArgs: interop.Pointer | interop.Reference<UConverterFromUnicodeArgs> | ArrayBufferLike | ArrayBufferView | null, codeUnits: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number, codePoint: number, reason: UConverterCallbackReason, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function UCNV_FROM_U_CALLBACK_SUBSTITUTE_74(context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, fromUArgs: interop.Pointer | interop.Reference<UConverterFromUnicodeArgs> | ArrayBufferLike | ArrayBufferView | null, codeUnits: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number, codePoint: number, reason: UConverterCallbackReason, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare const UCNV_LOCALE_OPTION_STRING: string;

declare const UCNV_MAX_CONVERTER_NAME_LENGTH: number;

declare const UCNV_MAX_FULL_FILE_NAME_LENGTH: number;

declare const UCNV_OPTION_SEP_CHAR: number;

declare const UCNV_OPTION_SEP_STRING: string;

declare const UCNV_SI: number;

declare const UCNV_SKIP_STOP_ON_ILLEGAL: string;

declare const UCNV_SO: number;

declare const UCNV_SUB_STOP_ON_ILLEGAL: string;

declare const UCNV_SWAP_LFNL_OPTION_STRING: string;

declare function UCNV_TO_U_CALLBACK_ESCAPE_74(context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, toUArgs: interop.Pointer | interop.Reference<UConverterToUnicodeArgs> | ArrayBufferLike | ArrayBufferView | null, codeUnits: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, length: number, reason: UConverterCallbackReason, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function UCNV_TO_U_CALLBACK_SKIP_74(context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, toUArgs: interop.Pointer | interop.Reference<UConverterToUnicodeArgs> | ArrayBufferLike | ArrayBufferView | null, codeUnits: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, length: number, reason: UConverterCallbackReason, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function UCNV_TO_U_CALLBACK_STOP_74(context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, toUArgs: interop.Pointer | interop.Reference<UConverterToUnicodeArgs> | ArrayBufferLike | ArrayBufferView | null, codeUnits: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, length: number, reason: UConverterCallbackReason, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function UCNV_TO_U_CALLBACK_SUBSTITUTE_74(context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, toUArgs: interop.Pointer | interop.Reference<UConverterToUnicodeArgs> | ArrayBufferLike | ArrayBufferView | null, codeUnits: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, length: number, reason: UConverterCallbackReason, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare const UCNV_VALUE_SEP_CHAR: number;

declare const UCNV_VALUE_SEP_STRING: string;

declare const UCNV_VERSION_OPTION_STRING: string;

declare const UCOL_BUILDER_VERSION: number;

declare const UCOL_RUNTIME_VERSION: number;

declare const UCOL_TAILORINGS_VERSION: number;

declare const UCONFIG_ENABLE_PLUGINS: number;

declare const UCONFIG_HAVE_PARSEALLINPUT: number;

declare const UCONFIG_NO_BREAK_ITERATION: number;

declare const UCONFIG_NO_COLLATION: number;

declare const UCONFIG_NO_CONVERSION: number;

declare const UCONFIG_NO_FILE_IO: number;

declare const UCONFIG_NO_FILTERED_BREAK_ITERATION: number;

declare const UCONFIG_NO_FORMATTING: number;

declare const UCONFIG_NO_IDNA: number;

declare const UCONFIG_NO_LEGACY_CONVERSION: number;

declare const UCONFIG_NO_NORMALIZATION: number;

declare const UCONFIG_NO_REGULAR_EXPRESSIONS: number;

declare const UCONFIG_NO_SERVICE: number;

declare const UCONFIG_NO_TRANSLITERATION: number;

declare const UCONFIG_ONLY_COLLATION: number;

declare const UCONFIG_ONLY_HTML_CONVERSION: number;

declare const UCONFIG_USE_ML_PHRASE_BREAKING: number;

declare const UCONFIG_USE_WINDOWS_LCID_MAPPING_API: number;

interface UCPMap {
}
declare var UCPMap: interop.StructType<UCPMap>;

declare const enum UCPMapRangeOption {

	NORMAL = 0,

	FIXED_LEAD_SURROGATES = 1,

	FIXED_ALL_SURROGATES = 2
}

declare const enum UCharCategory {

	UNASSIGNED = 0,

	GENERAL_OTHER_TYPES = 0,

	UPPERCASE_LETTER = 1,

	LOWERCASE_LETTER = 2,

	TITLECASE_LETTER = 3,

	MODIFIER_LETTER = 4,

	OTHER_LETTER = 5,

	NON_SPACING_MARK = 6,

	ENCLOSING_MARK = 7,

	COMBINING_SPACING_MARK = 8,

	DECIMAL_DIGIT_NUMBER = 9,

	LETTER_NUMBER = 10,

	OTHER_NUMBER = 11,

	SPACE_SEPARATOR = 12,

	LINE_SEPARATOR = 13,

	PARAGRAPH_SEPARATOR = 14,

	CONTROL_CHAR = 15,

	FORMAT_CHAR = 16,

	PRIVATE_USE_CHAR = 17,

	SURROGATE = 18,

	DASH_PUNCTUATION = 19,

	START_PUNCTUATION = 20,

	END_PUNCTUATION = 21,

	CONNECTOR_PUNCTUATION = 22,

	OTHER_PUNCTUATION = 23,

	MATH_SYMBOL = 24,

	CURRENCY_SYMBOL = 25,

	MODIFIER_SYMBOL = 26,

	OTHER_SYMBOL = 27,

	INITIAL_PUNCTUATION = 28,

	FINAL_PUNCTUATION = 29,

	CHAR_CATEGORY_COUNT = 30
}

declare const enum UCharDirection {

	LEFT_TO_RIGHT = 0,

	RIGHT_TO_LEFT = 1,

	EUROPEAN_NUMBER = 2,

	EUROPEAN_NUMBER_SEPARATOR = 3,

	EUROPEAN_NUMBER_TERMINATOR = 4,

	ARABIC_NUMBER = 5,

	COMMON_NUMBER_SEPARATOR = 6,

	BLOCK_SEPARATOR = 7,

	SEGMENT_SEPARATOR = 8,

	WHITE_SPACE_NEUTRAL = 9,

	OTHER_NEUTRAL = 10,

	LEFT_TO_RIGHT_EMBEDDING = 11,

	LEFT_TO_RIGHT_OVERRIDE = 12,

	RIGHT_TO_LEFT_ARABIC = 13,

	RIGHT_TO_LEFT_EMBEDDING = 14,

	RIGHT_TO_LEFT_OVERRIDE = 15,

	POP_DIRECTIONAL_FORMAT = 16,

	DIR_NON_SPACING_MARK = 17,

	BOUNDARY_NEUTRAL = 18,

	FIRST_STRONG_ISOLATE = 19,

	LEFT_TO_RIGHT_ISOLATE = 20,

	RIGHT_TO_LEFT_ISOLATE = 21,

	POP_DIRECTIONAL_ISOLATE = 22,

	CHAR_DIRECTION_COUNT = 23
}

interface UCharIterator {
	context: interop.Pointer | interop.Reference<any> | null;
	length: number;
	start: number;
	index: number;
	limit: number;
	reservedField: number;
	getIndex: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UCharIterator> | null, p2: UCharIteratorOrigin) => number>> | null;
	move: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UCharIterator> | null, p2: number, p3: UCharIteratorOrigin) => number>> | null;
	hasNext: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UCharIterator> | null) => number>> | null;
	hasPrevious: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UCharIterator> | null) => number>> | null;
	current: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UCharIterator> | null) => number>> | null;
	next: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UCharIterator> | null) => number>> | null;
	previous: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UCharIterator> | null) => number>> | null;
	reservedFn: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UCharIterator> | null, p2: number) => number>> | null;
	getState: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UCharIterator> | null) => number>> | null;
	setState: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UCharIterator> | null, p2: number, p3: interop.Pointer | interop.Reference<UErrorCode> | null) => void>> | null;
}
declare var UCharIterator: interop.StructType<UCharIterator>;

declare const enum UCharIteratorOrigin {

	START = 0,

	CURRENT = 1,

	LIMIT = 2,

	ZERO = 3,

	LENGTH = 4
}

declare const enum UCharNameChoice {

	UNICODE_CHAR_NAME = 0,

	UNICODE_10_CHAR_NAME = 1,

	EXTENDED_CHAR_NAME = 2,

	CHAR_NAME_ALIAS = 3,

	CHAR_NAME_CHOICE_COUNT = 4
}

interface UConverter {
}
declare var UConverter: interop.StructType<UConverter>;

declare const enum UConverterCallbackReason {

	UNASSIGNED = 0,

	ILLEGAL = 1,

	IRREGULAR = 2,

	RESET = 3,

	CLOSE = 4,

	CLONE = 5
}

interface UConverterFromUnicodeArgs {
	size: number;
	flush: number;
	converter: interop.Pointer | interop.Reference<UConverter> | null;
	source: interop.Pointer | interop.Reference<number> | null;
	sourceLimit: interop.Pointer | interop.Reference<number> | null;
	target: interop.Pointer | interop.Reference<any> | null;
	targetLimit: string | null;
	offsets: interop.Pointer | interop.Reference<number> | null;
}
declare var UConverterFromUnicodeArgs: interop.StructType<UConverterFromUnicodeArgs>;

declare const enum UConverterPlatform {

	UNKNOWN = -1,

	IBM = 0
}

interface UConverterToUnicodeArgs {
	size: number;
	flush: number;
	converter: interop.Pointer | interop.Reference<UConverter> | null;
	source: string | null;
	sourceLimit: string | null;
	target: interop.Pointer | interop.Reference<number> | null;
	targetLimit: interop.Pointer | interop.Reference<number> | null;
	offsets: interop.Pointer | interop.Reference<number> | null;
}
declare var UConverterToUnicodeArgs: interop.StructType<UConverterToUnicodeArgs>;

declare const enum UConverterType {

	UNSUPPORTED_CONVERTER = -1,

	SBCS = 0,

	DBCS = 1,

	MBCS = 2,

	LATIN_1 = 3,

	UTF8 = 4,

	UTF16_BigEndian = 5,

	UTF16_LittleEndian = 6,

	UTF32_BigEndian = 7,

	UTF32_LittleEndian = 8,

	EBCDIC_STATEFUL = 9,

	ISO_2022 = 10,

	LMBCS_1 = 11,

	LMBCS_2 = 12,

	LMBCS_3 = 13,

	LMBCS_4 = 14,

	LMBCS_5 = 15,

	LMBCS_6 = 16,

	LMBCS_8 = 17,

	LMBCS_11 = 18,

	LMBCS_16 = 19,

	LMBCS_17 = 20,

	LMBCS_18 = 21,

	LMBCS_19 = 22,

	LMBCS_LAST = 22,

	HZ = 23,

	SCSU = 24,

	ISCII = 25,

	US_ASCII = 26,

	UTF7 = 27,

	BOCU1 = 28,

	UTF16 = 29,

	UTF32 = 30,

	CESU8 = 31,

	IMAP_MAILBOX = 32,

	COMPOUND_TEXT = 33,

	NUMBER_OF_SUPPORTED_CONVERTER_TYPES = 34
}

declare const enum UConverterUnicodeSet {

	ROUNDTRIP_SET = 0,

	ROUNDTRIP_AND_FALLBACK_SET = 1,

	SET_COUNT = 2
}

declare const enum UDecompositionType {

	NONE = 0,

	CANONICAL = 1,

	COMPAT = 2,

	CIRCLE = 3,

	FINAL = 4,

	FONT = 5,

	FRACTION = 6,

	INITIAL = 7,

	ISOLATED = 8,

	MEDIAL = 9,

	NARROW = 10,

	NOBREAK = 11,

	SMALL = 12,

	SQUARE = 13,

	SUB = 14,

	SUPER = 15,

	VERTICAL = 16,

	WIDE = 17,

	COUNT = 18
}

declare const enum UEastAsianWidth {

	NEUTRAL = 0,

	AMBIGUOUS = 1,

	HALFWIDTH = 2,

	FULLWIDTH = 3,

	NARROW = 4,

	WIDE = 5,

	COUNT = 6
}

interface UEnumeration {
}
declare var UEnumeration: interop.StructType<UEnumeration>;

declare const enum UErrorCode {

	USING_FALLBACK_WARNING = -128,

	ERROR_WARNING_START = -128,

	USING_DEFAULT_WARNING = -127,

	SAFECLONE_ALLOCATED_WARNING = -126,

	STATE_OLD_WARNING = -125,

	STRING_NOT_TERMINATED_WARNING = -124,

	SORT_KEY_TOO_SHORT_WARNING = -123,

	AMBIGUOUS_ALIAS_WARNING = -122,

	DIFFERENT_UCA_VERSION = -121,

	PLUGIN_CHANGED_LEVEL_WARNING = -120,

	ERROR_WARNING_LIMIT = -119,

	ZERO_ERROR = 0,

	ILLEGAL_ARGUMENT_ERROR = 1,

	MISSING_RESOURCE_ERROR = 2,

	INVALID_FORMAT_ERROR = 3,

	FILE_ACCESS_ERROR = 4,

	INTERNAL_PROGRAM_ERROR = 5,

	MESSAGE_PARSE_ERROR = 6,

	MEMORY_ALLOCATION_ERROR = 7,

	INDEX_OUTOFBOUNDS_ERROR = 8,

	PARSE_ERROR = 9,

	INVALID_CHAR_FOUND = 10,

	TRUNCATED_CHAR_FOUND = 11,

	ILLEGAL_CHAR_FOUND = 12,

	INVALID_TABLE_FORMAT = 13,

	INVALID_TABLE_FILE = 14,

	BUFFER_OVERFLOW_ERROR = 15,

	UNSUPPORTED_ERROR = 16,

	RESOURCE_TYPE_MISMATCH = 17,

	ILLEGAL_ESCAPE_SEQUENCE = 18,

	UNSUPPORTED_ESCAPE_SEQUENCE = 19,

	NO_SPACE_AVAILABLE = 20,

	CE_NOT_FOUND_ERROR = 21,

	PRIMARY_TOO_LONG_ERROR = 22,

	STATE_TOO_OLD_ERROR = 23,

	TOO_MANY_ALIASES_ERROR = 24,

	ENUM_OUT_OF_SYNC_ERROR = 25,

	INVARIANT_CONVERSION_ERROR = 26,

	INVALID_STATE_ERROR = 27,

	COLLATOR_VERSION_MISMATCH = 28,

	USELESS_COLLATOR_ERROR = 29,

	NO_WRITE_PERMISSION = 30,

	INPUT_TOO_LONG_ERROR = 31,

	STANDARD_ERROR_LIMIT = 32,

	BAD_VARIABLE_DEFINITION = 65536,

	PARSE_ERROR_START = 65536,

	MALFORMED_RULE = 65537,

	MALFORMED_SET = 65538,

	MALFORMED_SYMBOL_REFERENCE = 65539,

	MALFORMED_UNICODE_ESCAPE = 65540,

	MALFORMED_VARIABLE_DEFINITION = 65541,

	MALFORMED_VARIABLE_REFERENCE = 65542,

	MISMATCHED_SEGMENT_DELIMITERS = 65543,

	MISPLACED_ANCHOR_START = 65544,

	MISPLACED_CURSOR_OFFSET = 65545,

	MISPLACED_QUANTIFIER = 65546,

	MISSING_OPERATOR = 65547,

	MISSING_SEGMENT_CLOSE = 65548,

	MULTIPLE_ANTE_CONTEXTS = 65549,

	MULTIPLE_CURSORS = 65550,

	MULTIPLE_POST_CONTEXTS = 65551,

	TRAILING_BACKSLASH = 65552,

	UNDEFINED_SEGMENT_REFERENCE = 65553,

	UNDEFINED_VARIABLE = 65554,

	UNQUOTED_SPECIAL = 65555,

	UNTERMINATED_QUOTE = 65556,

	RULE_MASK_ERROR = 65557,

	MISPLACED_COMPOUND_FILTER = 65558,

	MULTIPLE_COMPOUND_FILTERS = 65559,

	INVALID_RBT_SYNTAX = 65560,

	INVALID_PROPERTY_PATTERN = 65561,

	MALFORMED_PRAGMA = 65562,

	UNCLOSED_SEGMENT = 65563,

	ILLEGAL_CHAR_IN_SEGMENT = 65564,

	VARIABLE_RANGE_EXHAUSTED = 65565,

	VARIABLE_RANGE_OVERLAP = 65566,

	ILLEGAL_CHARACTER = 65567,

	INTERNAL_TRANSLITERATOR_ERROR = 65568,

	INVALID_ID = 65569,

	INVALID_FUNCTION = 65570,

	PARSE_ERROR_LIMIT = 65571,

	UNEXPECTED_TOKEN = 65792,

	FMT_PARSE_ERROR_START = 65792,

	MULTIPLE_DECIMAL_SEPARATORS = 65793,

	MULTIPLE_DECIMAL_SEPERATORS = 65793,

	MULTIPLE_EXPONENTIAL_SYMBOLS = 65794,

	MALFORMED_EXPONENTIAL_PATTERN = 65795,

	MULTIPLE_PERCENT_SYMBOLS = 65796,

	MULTIPLE_PERMILL_SYMBOLS = 65797,

	MULTIPLE_PAD_SPECIFIERS = 65798,

	PATTERN_SYNTAX_ERROR = 65799,

	ILLEGAL_PAD_POSITION = 65800,

	UNMATCHED_BRACES = 65801,

	UNSUPPORTED_PROPERTY = 65802,

	UNSUPPORTED_ATTRIBUTE = 65803,

	ARGUMENT_TYPE_MISMATCH = 65804,

	DUPLICATE_KEYWORD = 65805,

	UNDEFINED_KEYWORD = 65806,

	DEFAULT_KEYWORD_MISSING = 65807,

	DECIMAL_NUMBER_SYNTAX_ERROR = 65808,

	FORMAT_INEXACT_ERROR = 65809,

	NUMBER_ARG_OUTOFBOUNDS_ERROR = 65810,

	NUMBER_SKELETON_SYNTAX_ERROR = 65811,

	FMT_PARSE_ERROR_LIMIT = 65812,

	BRK_INTERNAL_ERROR = 66048,

	BRK_ERROR_START = 66048,

	BRK_HEX_DIGITS_EXPECTED = 66049,

	BRK_SEMICOLON_EXPECTED = 66050,

	BRK_RULE_SYNTAX = 66051,

	BRK_UNCLOSED_SET = 66052,

	BRK_ASSIGN_ERROR = 66053,

	BRK_VARIABLE_REDFINITION = 66054,

	BRK_MISMATCHED_PAREN = 66055,

	BRK_NEW_LINE_IN_QUOTED_STRING = 66056,

	BRK_UNDEFINED_VARIABLE = 66057,

	BRK_INIT_ERROR = 66058,

	BRK_RULE_EMPTY_SET = 66059,

	BRK_UNRECOGNIZED_OPTION = 66060,

	BRK_MALFORMED_RULE_TAG = 66061,

	BRK_ERROR_LIMIT = 66062,

	REGEX_INTERNAL_ERROR = 66304,

	REGEX_ERROR_START = 66304,

	REGEX_RULE_SYNTAX = 66305,

	REGEX_INVALID_STATE = 66306,

	REGEX_BAD_ESCAPE_SEQUENCE = 66307,

	REGEX_PROPERTY_SYNTAX = 66308,

	REGEX_UNIMPLEMENTED = 66309,

	REGEX_MISMATCHED_PAREN = 66310,

	REGEX_NUMBER_TOO_BIG = 66311,

	REGEX_BAD_INTERVAL = 66312,

	REGEX_MAX_LT_MIN = 66313,

	REGEX_INVALID_BACK_REF = 66314,

	REGEX_INVALID_FLAG = 66315,

	REGEX_LOOK_BEHIND_LIMIT = 66316,

	REGEX_SET_CONTAINS_STRING = 66317,

	REGEX_OCTAL_TOO_BIG = 66318,

	REGEX_MISSING_CLOSE_BRACKET = 66319,

	REGEX_INVALID_RANGE = 66320,

	REGEX_STACK_OVERFLOW = 66321,

	REGEX_TIME_OUT = 66322,

	REGEX_STOPPED_BY_CALLER = 66323,

	REGEX_PATTERN_TOO_BIG = 66324,

	REGEX_INVALID_CAPTURE_GROUP_NAME = 66325,

	REGEX_ERROR_LIMIT = 66326,

	IDNA_PROHIBITED_ERROR = 66560,

	IDNA_ERROR_START = 66560,

	IDNA_UNASSIGNED_ERROR = 66561,

	IDNA_CHECK_BIDI_ERROR = 66562,

	IDNA_STD3_ASCII_RULES_ERROR = 66563,

	IDNA_ACE_PREFIX_ERROR = 66564,

	IDNA_VERIFICATION_ERROR = 66565,

	IDNA_LABEL_TOO_LONG_ERROR = 66566,

	IDNA_ZERO_LENGTH_LABEL_ERROR = 66567,

	IDNA_DOMAIN_NAME_TOO_LONG_ERROR = 66568,

	IDNA_ERROR_LIMIT = 66569,

	STRINGPREP_PROHIBITED_ERROR = 66560,

	STRINGPREP_UNASSIGNED_ERROR = 66561,

	STRINGPREP_CHECK_BIDI_ERROR = 66562,

	PLUGIN_ERROR_START = 66816,

	PLUGIN_TOO_HIGH = 66816,

	PLUGIN_DIDNT_SET_LEVEL = 66817,

	PLUGIN_ERROR_LIMIT = 66818,

	ERROR_LIMIT = 66818
}

declare const enum UGraphemeClusterBreak {

	OTHER = 0,

	CONTROL = 1,

	CR = 2,

	EXTEND = 3,

	L = 4,

	LF = 5,

	LV = 6,

	LVT = 7,

	T = 8,

	V = 9,

	SPACING_MARK = 10,

	PREPEND = 11,

	REGIONAL_INDICATOR = 12,

	E_BASE = 13,

	E_BASE_GAZ = 14,

	E_MODIFIER = 15,

	GLUE_AFTER_ZWJ = 16,

	ZWJ = 17,

	COUNT = 18
}

declare const enum UHangulSyllableType {

	NOT_APPLICABLE = 0,

	LEADING_JAMO = 1,

	VOWEL_JAMO = 2,

	TRAILING_JAMO = 3,

	LV_SYLLABLE = 4,

	LVT_SYLLABLE = 5,

	COUNT = 6
}

declare const UITER_NO_STATE: number;

declare const UITER_UNKNOWN_INDEX: number;

declare const enum UIndicPositionalCategory {

	NA = 0,

	BOTTOM = 1,

	BOTTOM_AND_LEFT = 2,

	BOTTOM_AND_RIGHT = 3,

	LEFT = 4,

	LEFT_AND_RIGHT = 5,

	OVERSTRUCK = 6,

	RIGHT = 7,

	TOP = 8,

	TOP_AND_BOTTOM = 9,

	TOP_AND_BOTTOM_AND_RIGHT = 10,

	TOP_AND_LEFT = 11,

	TOP_AND_LEFT_AND_RIGHT = 12,

	TOP_AND_RIGHT = 13,

	VISUAL_ORDER_LEFT = 14,

	TOP_AND_BOTTOM_AND_LEFT = 15
}

declare const enum UIndicSyllabicCategory {

	OTHER = 0,

	AVAGRAHA = 1,

	BINDU = 2,

	BRAHMI_JOINING_NUMBER = 3,

	CANTILLATION_MARK = 4,

	CONSONANT = 5,

	CONSONANT_DEAD = 6,

	CONSONANT_FINAL = 7,

	CONSONANT_HEAD_LETTER = 8,

	CONSONANT_INITIAL_POSTFIXED = 9,

	CONSONANT_KILLER = 10,

	CONSONANT_MEDIAL = 11,

	CONSONANT_PLACEHOLDER = 12,

	CONSONANT_PRECEDING_REPHA = 13,

	CONSONANT_PREFIXED = 14,

	CONSONANT_SUBJOINED = 15,

	CONSONANT_SUCCEEDING_REPHA = 16,

	CONSONANT_WITH_STACKER = 17,

	GEMINATION_MARK = 18,

	INVISIBLE_STACKER = 19,

	JOINER = 20,

	MODIFYING_LETTER = 21,

	NON_JOINER = 22,

	NUKTA = 23,

	NUMBER = 24,

	NUMBER_JOINER = 25,

	PURE_KILLER = 26,

	REGISTER_SHIFTER = 27,

	SYLLABLE_MODIFIER = 28,

	TONE_LETTER = 29,

	TONE_MARK = 30,

	VIRAMA = 31,

	VISARGA = 32,

	VOWEL = 33,

	VOWEL_DEPENDENT = 34,

	VOWEL_INDEPENDENT = 35
}

declare const enum UJoiningGroup {

	NO_JOINING_GROUP = 0,

	AIN = 1,

	ALAPH = 2,

	ALEF = 3,

	BEH = 4,

	BETH = 5,

	DAL = 6,

	DALATH_RISH = 7,

	E = 8,

	FEH = 9,

	FINAL_SEMKATH = 10,

	GAF = 11,

	GAMAL = 12,

	HAH = 13,

	TEH_MARBUTA_GOAL = 14,

	HAMZA_ON_HEH_GOAL = 14,

	HE = 15,

	HEH = 16,

	HEH_GOAL = 17,

	HETH = 18,

	KAF = 19,

	KAPH = 20,

	KNOTTED_HEH = 21,

	LAM = 22,

	LAMADH = 23,

	MEEM = 24,

	MIM = 25,

	NOON = 26,

	NUN = 27,

	PE = 28,

	QAF = 29,

	QAPH = 30,

	REH = 31,

	REVERSED_PE = 32,

	SAD = 33,

	SADHE = 34,

	SEEN = 35,

	SEMKATH = 36,

	SHIN = 37,

	SWASH_KAF = 38,

	SYRIAC_WAW = 39,

	TAH = 40,

	TAW = 41,

	TEH_MARBUTA = 42,

	TETH = 43,

	WAW = 44,

	YEH = 45,

	YEH_BARREE = 46,

	YEH_WITH_TAIL = 47,

	YUDH = 48,

	YUDH_HE = 49,

	ZAIN = 50,

	FE = 51,

	KHAPH = 52,

	ZHAIN = 53,

	BURUSHASKI_YEH_BARREE = 54,

	FARSI_YEH = 55,

	NYA = 56,

	ROHINGYA_YEH = 57,

	MANICHAEAN_ALEPH = 58,

	MANICHAEAN_AYIN = 59,

	MANICHAEAN_BETH = 60,

	MANICHAEAN_DALETH = 61,

	MANICHAEAN_DHAMEDH = 62,

	MANICHAEAN_FIVE = 63,

	MANICHAEAN_GIMEL = 64,

	MANICHAEAN_HETH = 65,

	MANICHAEAN_HUNDRED = 66,

	MANICHAEAN_KAPH = 67,

	MANICHAEAN_LAMEDH = 68,

	MANICHAEAN_MEM = 69,

	MANICHAEAN_NUN = 70,

	MANICHAEAN_ONE = 71,

	MANICHAEAN_PE = 72,

	MANICHAEAN_QOPH = 73,

	MANICHAEAN_RESH = 74,

	MANICHAEAN_SADHE = 75,

	MANICHAEAN_SAMEKH = 76,

	MANICHAEAN_TAW = 77,

	MANICHAEAN_TEN = 78,

	MANICHAEAN_TETH = 79,

	MANICHAEAN_THAMEDH = 80,

	MANICHAEAN_TWENTY = 81,

	MANICHAEAN_WAW = 82,

	MANICHAEAN_YODH = 83,

	MANICHAEAN_ZAYIN = 84,

	STRAIGHT_WAW = 85,

	AFRICAN_FEH = 86,

	AFRICAN_NOON = 87,

	AFRICAN_QAF = 88,

	MALAYALAM_BHA = 89,

	MALAYALAM_JA = 90,

	MALAYALAM_LLA = 91,

	MALAYALAM_LLLA = 92,

	MALAYALAM_NGA = 93,

	MALAYALAM_NNA = 94,

	MALAYALAM_NNNA = 95,

	MALAYALAM_NYA = 96,

	MALAYALAM_RA = 97,

	MALAYALAM_SSA = 98,

	MALAYALAM_TTA = 99,

	HANIFI_ROHINGYA_KINNA_YA = 100,

	HANIFI_ROHINGYA_PA = 101,

	THIN_YEH = 102,

	VERTICAL_TAIL = 103,

	COUNT = 104
}

declare const enum UJoiningType {

	NON_JOINING = 0,

	JOIN_CAUSING = 1,

	DUAL_JOINING = 2,

	LEFT_JOINING = 3,

	RIGHT_JOINING = 4,

	TRANSPARENT = 5,

	COUNT = 6
}

declare const enum ULineBreak {

	UNKNOWN = 0,

	AMBIGUOUS = 1,

	ALPHABETIC = 2,

	BREAK_BOTH = 3,

	BREAK_AFTER = 4,

	BREAK_BEFORE = 5,

	MANDATORY_BREAK = 6,

	CONTINGENT_BREAK = 7,

	CLOSE_PUNCTUATION = 8,

	COMBINING_MARK = 9,

	CARRIAGE_RETURN = 10,

	EXCLAMATION = 11,

	GLUE = 12,

	HYPHEN = 13,

	IDEOGRAPHIC = 14,

	INSEPARABLE = 15,

	INSEPERABLE = 15,

	INFIX_NUMERIC = 16,

	LINE_FEED = 17,

	NONSTARTER = 18,

	NUMERIC = 19,

	OPEN_PUNCTUATION = 20,

	POSTFIX_NUMERIC = 21,

	PREFIX_NUMERIC = 22,

	QUOTATION = 23,

	COMPLEX_CONTEXT = 24,

	SURROGATE = 25,

	SPACE = 26,

	BREAK_SYMBOLS = 27,

	ZWSPACE = 28,

	NEXT_LINE = 29,

	WORD_JOINER = 30,

	H2 = 31,

	H3 = 32,

	JL = 33,

	JT = 34,

	JV = 35,

	CLOSE_PARENTHESIS = 36,

	CONDITIONAL_JAPANESE_STARTER = 37,

	HEBREW_LETTER = 38,

	REGIONAL_INDICATOR = 39,

	E_BASE = 40,

	E_MODIFIER = 41,

	ZWJ = 42,

	AKSARA = 43,

	AKSARA_PREBASE = 44,

	AKSARA_START = 45,

	VIRAMA_FINAL = 46,

	VIRAMA = 47,

	COUNT = 48
}

declare const UNORM_INPUT_IS_FCD: number;

declare const enum UNumericType {

	NONE = 0,

	DECIMAL = 1,

	DIGIT = 2,

	NUMERIC = 3,

	COUNT = 4
}

interface UParseError {
	line: number;
	offset: number;
	preContext: interop.Reference<number>;
	postContext: interop.Reference<number>;
}
declare var UParseError: interop.StructType<UParseError>;

declare const enum UProperty {

	ALPHABETIC = 0,

	BINARY_START = 0,

	ASCII_HEX_DIGIT = 1,

	BIDI_CONTROL = 2,

	BIDI_MIRRORED = 3,

	DASH = 4,

	DEFAULT_IGNORABLE_CODE_POINT = 5,

	DEPRECATED = 6,

	DIACRITIC = 7,

	EXTENDER = 8,

	FULL_COMPOSITION_EXCLUSION = 9,

	GRAPHEME_BASE = 10,

	GRAPHEME_EXTEND = 11,

	GRAPHEME_LINK = 12,

	HEX_DIGIT = 13,

	HYPHEN = 14,

	ID_CONTINUE = 15,

	ID_START = 16,

	IDEOGRAPHIC = 17,

	IDS_BINARY_OPERATOR = 18,

	IDS_TRINARY_OPERATOR = 19,

	JOIN_CONTROL = 20,

	LOGICAL_ORDER_EXCEPTION = 21,

	LOWERCASE = 22,

	MATH = 23,

	NONCHARACTER_CODE_POINT = 24,

	QUOTATION_MARK = 25,

	RADICAL = 26,

	SOFT_DOTTED = 27,

	TERMINAL_PUNCTUATION = 28,

	UNIFIED_IDEOGRAPH = 29,

	UPPERCASE = 30,

	WHITE_SPACE = 31,

	XID_CONTINUE = 32,

	XID_START = 33,

	CASE_SENSITIVE = 34,

	S_TERM = 35,

	VARIATION_SELECTOR = 36,

	NFD_INERT = 37,

	NFKD_INERT = 38,

	NFC_INERT = 39,

	NFKC_INERT = 40,

	SEGMENT_STARTER = 41,

	PATTERN_SYNTAX = 42,

	PATTERN_WHITE_SPACE = 43,

	POSIX_ALNUM = 44,

	POSIX_BLANK = 45,

	POSIX_GRAPH = 46,

	POSIX_PRINT = 47,

	POSIX_XDIGIT = 48,

	CASED = 49,

	CASE_IGNORABLE = 50,

	CHANGES_WHEN_LOWERCASED = 51,

	CHANGES_WHEN_UPPERCASED = 52,

	CHANGES_WHEN_TITLECASED = 53,

	CHANGES_WHEN_CASEFOLDED = 54,

	CHANGES_WHEN_CASEMAPPED = 55,

	CHANGES_WHEN_NFKC_CASEFOLDED = 56,

	EMOJI = 57,

	EMOJI_PRESENTATION = 58,

	EMOJI_MODIFIER = 59,

	EMOJI_MODIFIER_BASE = 60,

	EMOJI_COMPONENT = 61,

	REGIONAL_INDICATOR = 62,

	PREPENDED_CONCATENATION_MARK = 63,

	EXTENDED_PICTOGRAPHIC = 64,

	BASIC_EMOJI = 65,

	EMOJI_KEYCAP_SEQUENCE = 66,

	RGI_EMOJI_MODIFIER_SEQUENCE = 67,

	RGI_EMOJI_FLAG_SEQUENCE = 68,

	RGI_EMOJI_TAG_SEQUENCE = 69,

	RGI_EMOJI_ZWJ_SEQUENCE = 70,

	RGI_EMOJI = 71,

	IDS_UNARY_OPERATOR = 72,

	ID_COMPAT_MATH_START = 73,

	ID_COMPAT_MATH_CONTINUE = 74,

	BINARY_LIMIT = 75,

	BIDI_CLASS = 4096,

	INT_START = 4096,

	BLOCK = 4097,

	CANONICAL_COMBINING_CLASS = 4098,

	DECOMPOSITION_TYPE = 4099,

	EAST_ASIAN_WIDTH = 4100,

	GENERAL_CATEGORY = 4101,

	JOINING_GROUP = 4102,

	JOINING_TYPE = 4103,

	LINE_BREAK = 4104,

	NUMERIC_TYPE = 4105,

	SCRIPT = 4106,

	HANGUL_SYLLABLE_TYPE = 4107,

	NFD_QUICK_CHECK = 4108,

	NFKD_QUICK_CHECK = 4109,

	NFC_QUICK_CHECK = 4110,

	NFKC_QUICK_CHECK = 4111,

	LEAD_CANONICAL_COMBINING_CLASS = 4112,

	TRAIL_CANONICAL_COMBINING_CLASS = 4113,

	GRAPHEME_CLUSTER_BREAK = 4114,

	SENTENCE_BREAK = 4115,

	WORD_BREAK = 4116,

	BIDI_PAIRED_BRACKET_TYPE = 4117,

	INDIC_POSITIONAL_CATEGORY = 4118,

	INDIC_SYLLABIC_CATEGORY = 4119,

	VERTICAL_ORIENTATION = 4120,

	INT_LIMIT = 4121,

	GENERAL_CATEGORY_MASK = 8192,

	MASK_START = 8192,

	MASK_LIMIT = 8193,

	NUMERIC_VALUE = 12288,

	DOUBLE_START = 12288,

	DOUBLE_LIMIT = 12289,

	AGE = 16384,

	STRING_START = 16384,

	BIDI_MIRRORING_GLYPH = 16385,

	CASE_FOLDING = 16386,

	ISO_COMMENT = 16387,

	LOWERCASE_MAPPING = 16388,

	NAME = 16389,

	SIMPLE_CASE_FOLDING = 16390,

	SIMPLE_LOWERCASE_MAPPING = 16391,

	SIMPLE_TITLECASE_MAPPING = 16392,

	SIMPLE_UPPERCASE_MAPPING = 16393,

	TITLECASE_MAPPING = 16394,

	UNICODE_1_NAME = 16395,

	UPPERCASE_MAPPING = 16396,

	BIDI_PAIRED_BRACKET = 16397,

	STRING_LIMIT = 16398,

	SCRIPT_EXTENSIONS = 28672,

	OTHER_PROPERTY_START = 28672,

	OTHER_PROPERTY_LIMIT = 28673,

	INVALID_CODE = -1
}

declare const enum UPropertyNameChoice {

	SHORT_PROPERTY_NAME = 0,

	LONG_PROPERTY_NAME = 1,

	PROPERTY_NAME_CHOICE_COUNT = 2
}

declare const enum URegexpFlag {

	CANON_EQ = 128,

	CASE_INSENSITIVE = 2,

	COMMENTS = 4,

	DOTALL = 32,

	LITERAL = 16,

	MULTILINE = 8,

	UNIX_LINES = 1,

	UWORD = 256,

	ERROR_ON_UNKNOWN_ESCAPES = 512
}

interface URegularExpression {
}
declare var URegularExpression: interop.StructType<URegularExpression>;

declare const enum USentenceBreak {

	OTHER = 0,

	ATERM = 1,

	CLOSE = 2,

	FORMAT = 3,

	LOWER = 4,

	NUMERIC = 5,

	OLETTER = 6,

	SEP = 7,

	SP = 8,

	STERM = 9,

	UPPER = 10,

	CR = 11,

	EXTEND = 12,

	LF = 13,

	SCONTINUE = 14,

	COUNT = 15
}

interface USet {
}
declare var USet: interop.StructType<USet>;

declare const UTEXT_MAGIC: number;

declare const UTEXT_PROVIDER_HAS_META_DATA: number;

declare const UTEXT_PROVIDER_LENGTH_IS_EXPENSIVE: number;

declare const UTEXT_PROVIDER_OWNS_TEXT: number;

declare const UTEXT_PROVIDER_STABLE_CHUNKS: number;

declare const UTEXT_PROVIDER_WRITABLE: number;

declare const UTF16_MAX_CHAR_LENGTH: number;

declare const UTF32_MAX_CHAR_LENGTH: number;

declare const UTF8_ERROR_VALUE_1: number;

declare const UTF8_ERROR_VALUE_2: number;

declare const UTF8_MAX_CHAR_LENGTH: number;

declare const UTF_ERROR_VALUE: number;

declare const UTF_MAX_CHAR_LENGTH: number;

declare const UTF_SIZE: number;

declare const UTF_SURROGATE_OFFSET: number;

interface UText {
	magic: number;
	flags: number;
	providerProperties: number;
	sizeOfStruct: number;
	chunkNativeLimit: number;
	extraSize: number;
	nativeIndexingLimit: number;
	chunkNativeStart: number;
	chunkOffset: number;
	chunkLength: number;
	chunkContents: interop.Pointer | interop.Reference<number> | null;
	pFuncs: interop.Pointer | interop.Reference<UTextFuncs> | null;
	pExtra: interop.Pointer | interop.Reference<any> | null;
	context: interop.Pointer | interop.Reference<any> | null;
	p: interop.Pointer | interop.Reference<any> | null;
	q: interop.Pointer | interop.Reference<any> | null;
	r: interop.Pointer | interop.Reference<any> | null;
	privP: interop.Pointer | interop.Reference<any> | null;
	a: number;
	b: number;
	c: number;
	privA: number;
	privB: number;
	privC: number;
}
declare var UText: interop.StructType<UText>;

interface UTextFuncs {
	tableSize: number;
	reserved1: number;
	reserved2: number;
	reserved3: number;
	clone: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UText> | null, p2: interop.Pointer | interop.Reference<UText> | null, p3: number, p4: interop.Pointer | interop.Reference<UErrorCode> | null) => interop.Pointer | interop.Reference<UText> | null>> | null;
	nativeLength: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UText> | null) => number>> | null;
	access: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UText> | null, p2: number, p3: number) => number>> | null;
	extract: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UText> | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<number> | null, p5: number, p6: interop.Pointer | interop.Reference<UErrorCode> | null) => number>> | null;
	replace: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UText> | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<number> | null, p5: number, p6: interop.Pointer | interop.Reference<UErrorCode> | null) => number>> | null;
	copy: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UText> | null, p2: number, p3: number, p4: number, p5: number, p6: interop.Pointer | interop.Reference<UErrorCode> | null) => void>> | null;
	mapOffsetToNative: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UText> | null) => number>> | null;
	mapNativeIndexToUTF16: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UText> | null, p2: number) => number>> | null;
	close: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UText> | null) => void>> | null;
	spare1: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UText> | null) => void>> | null;
	spare2: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UText> | null) => void>> | null;
	spare3: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<UText> | null) => void>> | null;
}
declare var UTextFuncs: interop.StructType<UTextFuncs>;

declare const enum UVerticalOrientation {

	ROTATED = 0,

	TRANSFORMED_ROTATED = 1,

	TRANSFORMED_UPRIGHT = 2,

	UPRIGHT = 3
}

declare const enum UWordBreakValues {

	OTHER = 0,

	ALETTER = 1,

	FORMAT = 2,

	KATAKANA = 3,

	MIDLETTER = 4,

	MIDNUM = 5,

	NUMERIC = 6,

	EXTENDNUMLET = 7,

	CR = 8,

	EXTEND = 9,

	LF = 10,

	MIDNUMLET = 11,

	NEWLINE = 12,

	REGIONAL_INDICATOR = 13,

	HEBREW_LETTER = 14,

	SINGLE_QUOTE = 15,

	DOUBLE_QUOTE = 16,

	E_BASE = 17,

	E_BASE_GAZ = 18,

	E_MODIFIER = 19,

	GLUE_AFTER_ZWJ = 20,

	ZWJ = 21,

	WSEGSPACE = 22,

	COUNT = 23
}

declare const U_ASCII_FAMILY: number;

declare const U_CHAR16_IS_TYPEDEF: number;

declare const U_CHARSET_FAMILY: number;

declare const U_CHARSET_IS_UTF8: number;

declare const U_CHECK_DYLOAD: number;

declare const U_CNV_SAFECLONE_BUFFERSIZE: number;

declare const U_COMPARE_CODE_POINT_ORDER: number;

declare const U_COMPARE_IGNORE_CASE: number;

declare const U_COPYRIGHT_STRING: string;

declare const U_COPYRIGHT_STRING_LENGTH: number;

declare const U_CPLUSPLUS_VERSION: number;

declare const U_DATE_MAX: number;

declare const U_DATE_MIN: number;

declare const U_DEBUG: number;

declare const U_DEFAULT_SHOW_DRAFT: number;

declare const U_DEFINE_FALSE_AND_TRUE: number;

declare const U_DISABLE_RENAMING: number;

declare const U_DISABLE_VERSION_SUFFIX: number;

declare const U_EBCDIC_FAMILY: number;

declare const U_EDITS_NO_RESET: number;

declare const U_ENABLE_DYLOAD: number;

declare const U_ENABLE_TRACING: number;

declare const U_FILE_ALT_SEP_CHAR: number;

declare const U_FILE_ALT_SEP_STRING: string;

declare const U_FILE_SEP_CHAR: number;

declare const U_FILE_SEP_STRING: string;

declare const U_FOLD_CASE_DEFAULT: number;

declare const U_FOLD_CASE_EXCLUDE_SPECIAL_I: number;

declare const U_GCC_MAJOR_MINOR: number;

declare const U_GC_CC_MASK: number;

declare const U_GC_CF_MASK: number;

declare const U_GC_CN_MASK: number;

declare const U_GC_CO_MASK: number;

declare const U_GC_CS_MASK: number;

declare const U_GC_C_MASK: number;

declare const U_GC_LC_MASK: number;

declare const U_GC_LL_MASK: number;

declare const U_GC_LM_MASK: number;

declare const U_GC_LO_MASK: number;

declare const U_GC_LT_MASK: number;

declare const U_GC_LU_MASK: number;

declare const U_GC_L_MASK: number;

declare const U_GC_MC_MASK: number;

declare const U_GC_ME_MASK: number;

declare const U_GC_MN_MASK: number;

declare const U_GC_M_MASK: number;

declare const U_GC_ND_MASK: number;

declare const U_GC_NL_MASK: number;

declare const U_GC_NO_MASK: number;

declare const U_GC_N_MASK: number;

declare const U_GC_PC_MASK: number;

declare const U_GC_PD_MASK: number;

declare const U_GC_PE_MASK: number;

declare const U_GC_PF_MASK: number;

declare const U_GC_PI_MASK: number;

declare const U_GC_PO_MASK: number;

declare const U_GC_PS_MASK: number;

declare const U_GC_P_MASK: number;

declare const U_GC_SC_MASK: number;

declare const U_GC_SK_MASK: number;

declare const U_GC_SM_MASK: number;

declare const U_GC_SO_MASK: number;

declare const U_GC_S_MASK: number;

declare const U_GC_ZL_MASK: number;

declare const U_GC_ZP_MASK: number;

declare const U_GC_ZS_MASK: number;

declare const U_GC_Z_MASK: number;

declare const U_HAVE_CHAR16_T: number;

declare const U_HAVE_DEBUG_LOCATION_NEW: number;

declare const U_HAVE_INTTYPES_H: number;

declare const U_HAVE_PLACEMENT_NEW: number;

declare const U_HAVE_STDINT_H: number;

declare const U_HAVE_WCHAR_H: number;

declare const U_HAVE_WCSCPY: number;

declare const U_HIDE_OBSOLETE_UTF_OLD_H: number;

declare const U_ICUDATA_NAME: string;

declare const U_ICUDATA_TYPE_LETTER: string;

declare const U_ICU_DATA_VERSION: string;

declare const U_ICU_VERSION: string;

declare const U_ICU_VERSION_BUILDLEVEL_NUM: number;

declare const U_ICU_VERSION_MAJOR_NUM: number;

declare const U_ICU_VERSION_MINOR_NUM: number;

declare const U_ICU_VERSION_PATCHLEVEL_NUM: number;

declare const U_ICU_VERSION_SHORT: string;

declare const U_INT64_MAX: bigint;

declare const U_INT64_MIN: bigint;

declare const U_IS_BIG_ENDIAN: number;

declare const U_LIB_SUFFIX_C_NAME_STRING: string;

declare const U_MAX_VERSION_LENGTH: number;

declare const U_MAX_VERSION_STRING_LENGTH: number;

declare const U_MILLIS_PER_DAY: number;

declare const U_MILLIS_PER_HOUR: number;

declare const U_MILLIS_PER_MINUTE: number;

declare const U_MILLIS_PER_SECOND: number;

declare const U_NO_DEFAULT_INCLUDE_UTF_HEADERS: number;

declare const U_NO_NUMERIC_VALUE: number;

declare const U_OMIT_UNCHANGED_TEXT: number;

declare const U_OVERRIDE_CXX_ALLOCATION: number;

declare const U_PARSE_CONTEXT_LEN: number;

declare const U_PATH_SEP_CHAR: number;

declare const U_PATH_SEP_STRING: string;

declare const U_PF_AIX: number;

declare const U_PF_ANDROID: number;

declare const U_PF_BROWSER_NATIVE_CLIENT: number;

declare const U_PF_BSD: number;

declare const U_PF_CYGWIN: number;

declare const U_PF_DARWIN: number;

declare const U_PF_EMSCRIPTEN: number;

declare const U_PF_FUCHSIA: number;

declare const U_PF_HPUX: number;

declare const U_PF_IPHONE: number;

declare const U_PF_IRIX: number;

declare const U_PF_LINUX: number;

declare const U_PF_MINGW: number;

declare const U_PF_OS390: number;

declare const U_PF_OS400: number;

declare const U_PF_QNX: number;

declare const U_PF_SOLARIS: number;

declare const U_PF_UNKNOWN: number;

declare const U_PF_WINDOWS: number;

declare const U_PLATFORM: number;

declare const U_PLATFORM_HAS_WIN32_API: number;

declare const U_PLATFORM_HAS_WINUWP_API: number;

declare const U_PLATFORM_IMPLEMENTS_POSIX: number;

declare const U_PLATFORM_IS_DARWIN_BASED: number;

declare const U_PLATFORM_IS_LINUX_BASED: number;

declare const U_PLATFORM_USES_ONLY_WIN32_API: number;

declare const U_SENTINEL: number;

declare const U_SHOW_CPLUSPLUS_API: number;

declare const U_SIZEOF_UCHAR: number;

declare const U_SIZEOF_WCHAR_T: number;

declare const U_TITLECASE_ADJUST_TO_CASED: number;

declare const U_TITLECASE_NO_BREAK_ADJUSTMENT: number;

declare const U_TITLECASE_NO_LOWERCASE: number;

declare const U_TITLECASE_SENTENCES: number;

declare const U_TITLECASE_WHOLE_STRING: number;

declare const U_UINT64_MAX: bigint;

declare const U_UNICODE_VERSION: string;

declare const U_USE_USRDATA: number;

declare const U_USRDATA_NAME: string;

declare const U_VERSION_DELIMITER: number;

declare function u_UCharsToChars_74(us: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, cs: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, length: number): void;

declare function u_austrcpy_74(dst: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function u_austrncpy_74(dst: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, n: number): interop.Pointer | interop.Reference<any> | null;

declare function u_charAge_74(c: number, versionArray: interop.Reference<number>): void;

declare function u_charDigitValue_74(c: number): number;

declare function u_charDirection_74(c: number): UCharDirection;

declare function u_charFromName_74(nameChoice: UCharNameChoice, name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_charMirror_74(c: number): number;

declare function u_charName_74(code: number, nameChoice: UCharNameChoice, buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, bufferLength: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_charType_74(c: number): number;

declare function u_charsToUChars_74(cs: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, us: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number): void;

declare function u_countChar32_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number): number;

declare function u_digit_74(ch: number, radix: number): number;

declare function u_enumCharNames_74(start: number, limit: number, fn: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: number, p3: UCharNameChoice, p4: string | null, p5: number) => number>> | ArrayBufferLike | ArrayBufferView | null, context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, nameChoice: UCharNameChoice, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function u_enumCharTypes_74(enumRange: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: number, p3: number, p4: UCharCategory) => number>> | ArrayBufferLike | ArrayBufferView | null, context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function u_errorName_74(code: UErrorCode): string | null;

declare function u_foldCase_74(c: number, options: number): number;

declare function u_forDigit_74(digit: number, radix: number): number;

declare function u_getBidiPairedBracket_74(c: number): number;

declare function u_getBinaryPropertySet_74(property: UProperty, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<USet> | null;

declare function u_getCombiningClass_74(c: number): number;

declare function u_getDataDirectory_74(): string | null;

declare function u_getFC_NFKC_Closure_74(c: number, dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_getISOComment_74(c: number, dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_getIntPropertyMap_74(property: UProperty, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UCPMap> | null;

declare function u_getIntPropertyMaxValue_74(which: UProperty): number;

declare function u_getIntPropertyMinValue_74(which: UProperty): number;

declare function u_getIntPropertyValue_74(c: number, which: UProperty): number;

declare function u_getNumericValue_74(c: number): number;

declare function u_getPropertyEnum_74(alias: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): UProperty;

declare function u_getPropertyName_74(property: UProperty, nameChoice: UPropertyNameChoice): string | null;

declare function u_getPropertyValueEnum_74(property: UProperty, alias: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_getPropertyValueName_74(property: UProperty, value: number, nameChoice: UPropertyNameChoice): string | null;

declare function u_getTimeZoneFilesDirectory_74(status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function u_getUnicodeVersion_74(versionArray: interop.Reference<number>): void;

declare function u_getVersion_74(versionArray: interop.Reference<number>): void;

declare function u_hasBinaryProperty_74(c: number, which: UProperty): number;

declare function u_isIDIgnorable_74(c: number): number;

declare function u_isIDPart_74(c: number): number;

declare function u_isIDStart_74(c: number): number;

declare function u_isISOControl_74(c: number): number;

declare function u_isJavaIDPart_74(c: number): number;

declare function u_isJavaIDStart_74(c: number): number;

declare function u_isJavaSpaceChar_74(c: number): number;

declare function u_isMirrored_74(c: number): number;

declare function u_isUAlphabetic_74(c: number): number;

declare function u_isULowercase_74(c: number): number;

declare function u_isUUppercase_74(c: number): number;

declare function u_isUWhiteSpace_74(c: number): number;

declare function u_isWhitespace_74(c: number): number;

declare function u_isalnum_74(c: number): number;

declare function u_isalpha_74(c: number): number;

declare function u_isbase_74(c: number): number;

declare function u_isblank_74(c: number): number;

declare function u_iscntrl_74(c: number): number;

declare function u_isdefined_74(c: number): number;

declare function u_isdigit_74(c: number): number;

declare function u_isgraph_74(c: number): number;

declare function u_islower_74(c: number): number;

declare function u_isprint_74(c: number): number;

declare function u_ispunct_74(c: number): number;

declare function u_isspace_74(c: number): number;

declare function u_istitle_74(c: number): number;

declare function u_isupper_74(c: number): number;

declare function u_isxdigit_74(c: number): number;

declare function u_memcasecmp_74(s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number, options: number): number;

declare function u_memchr32_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, c: number, count: number): interop.Pointer | interop.Reference<number> | null;

declare function u_memchr_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, c: number, count: number): interop.Pointer | interop.Reference<number> | null;

declare function u_memcmpCodePointOrder_74(s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, count: number): number;

declare function u_memcmp_74(buf1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, buf2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, count: number): number;

declare function u_memcpy_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, count: number): interop.Pointer | interop.Reference<number> | null;

declare function u_memmove_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, count: number): interop.Pointer | interop.Reference<number> | null;

declare function u_memrchr32_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, c: number, count: number): interop.Pointer | interop.Reference<number> | null;

declare function u_memrchr_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, c: number, count: number): interop.Pointer | interop.Reference<number> | null;

declare function u_memset_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, c: number, count: number): interop.Pointer | interop.Reference<number> | null;

declare function u_setDataDirectory_74(directory: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function u_setTimeZoneFilesDirectory_74(path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function u_strCaseCompare_74(s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length1: number, s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length2: number, options: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_strCompareIter_74(iter1: interop.Pointer | interop.Reference<UCharIterator> | ArrayBufferLike | ArrayBufferView | null, iter2: interop.Pointer | interop.Reference<UCharIterator> | ArrayBufferLike | ArrayBufferView | null, codePointOrder: number): number;

declare function u_strCompare_74(s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length1: number, s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length2: number, codePointOrder: number): number;

declare function u_strFindFirst_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number, substring: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, subLength: number): interop.Pointer | interop.Reference<number> | null;

declare function u_strFindLast_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number, substring: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, subLength: number): interop.Pointer | interop.Reference<number> | null;

declare function u_strFoldCase_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, options: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_strFromJavaModifiedUTF8WithSub_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pDestLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, subchar: number, pNumSubstitutions: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strFromUTF32WithSub_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pDestLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, subchar: number, pNumSubstitutions: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strFromUTF32_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pDestLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strFromUTF8Lenient_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pDestLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strFromUTF8WithSub_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pDestLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, subchar: number, pNumSubstitutions: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strFromUTF8_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pDestLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strFromWCS_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pDestLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strHasMoreChar32Than_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number, number: number): number;

declare function u_strToJavaModifiedUTF8_74(dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pDestLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function u_strToLower_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, locale: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_strToTitle_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, titleIter: interop.Pointer | interop.Reference<UBreakIterator> | ArrayBufferLike | ArrayBufferView | null, locale: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_strToUTF32WithSub_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pDestLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, subchar: number, pNumSubstitutions: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strToUTF32_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pDestLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strToUTF8WithSub_74(dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pDestLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, subchar: number, pNumSubstitutions: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function u_strToUTF8_74(dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pDestLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function u_strToUpper_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, locale: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_strToWCS_74(dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, pDestLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strcasecmp_74(s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, options: number): number;

declare function u_strcat_74(dst: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strchr32_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, c: number): interop.Pointer | interop.Reference<number> | null;

declare function u_strchr_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, c: number): interop.Pointer | interop.Reference<number> | null;

declare function u_strcmpCodePointOrder_74(s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_strcmp_74(s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_strcpy_74(dst: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strcspn_74(string: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, matchSet: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_stringHasBinaryProperty_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number, which: UProperty): number;

declare function u_strlen_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_strncasecmp_74(s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, n: number, options: number): number;

declare function u_strncat_74(dst: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, n: number): interop.Pointer | interop.Reference<number> | null;

declare function u_strncmpCodePointOrder_74(s1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, s2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, n: number): number;

declare function u_strncmp_74(ucs1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, ucs2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, n: number): number;

declare function u_strncpy_74(dst: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, n: number): interop.Pointer | interop.Reference<number> | null;

declare function u_strpbrk_74(string: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, matchSet: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strrchr32_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, c: number): interop.Pointer | interop.Reference<number> | null;

declare function u_strrchr_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, c: number): interop.Pointer | interop.Reference<number> | null;

declare function u_strrstr_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, substring: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strspn_74(string: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, matchSet: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_strstr_74(s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, substring: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_strtok_r_74(src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, delim: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, saveState: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_tolower_74(c: number): number;

declare function u_totitle_74(c: number): number;

declare function u_toupper_74(c: number): number;

declare function u_uastrcpy_74(dst: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function u_uastrncpy_74(dst: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, n: number): interop.Pointer | interop.Reference<number> | null;

declare function u_unescapeAt_74(charAt: interop.FunctionReference<(p1: number, p2: interop.Pointer | interop.Reference<any> | null) => number>, offset: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number, context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function u_unescape_74(src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number): number;

declare function u_versionFromString_74(versionArray: interop.Reference<number>, versionString: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function u_versionFromUString_74(versionArray: interop.Reference<number>, versionString: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function u_versionToString_74(versionArray: interop.Reference<number>, versionString: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ublock_getCode_74(c: number): UBlockCode;

declare function ucnv_clone_74(cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UConverter> | null;

declare function ucnv_close_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_compareNames_74(name1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, name2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_convertEx_74(targetCnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, sourceCnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, target: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, targetLimit: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, source: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null, sourceLimit: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pivotStart: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, pivotSource: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, pivotTarget: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, pivotLimit: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, reset: number, flush: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_convert_74(toConverterName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, fromConverterName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, target: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, targetCapacity: number, source: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sourceLength: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_countAliases_74(alias: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_countAvailable_74(): number;

declare function ucnv_countStandards_74(): number;

declare function ucnv_detectUnicodeSignature_74(source: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sourceLength: number, signatureLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function ucnv_fixFileSeparator_74(cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, source: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, sourceLen: number): void;

declare function ucnv_flushCache_74(): number;

declare function ucnv_fromAlgorithmic_74(cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, algorithmicType: UConverterType, target: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, targetCapacity: number, source: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sourceLength: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_fromUChars_74(cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, dest: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, src: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_fromUCountPending_74(cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_fromUnicode_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, target: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, targetLimit: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, source: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, sourceLimit: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, offsets: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, flush: number, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_getAlias_74(alias: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, n: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function ucnv_getAliases_74(alias: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, aliases: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_getAvailableName_74(n: number): string | null;

declare function ucnv_getCCSID_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_getCanonicalName_74(alias: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, standard: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function ucnv_getDefaultName_74(): string | null;

declare function ucnv_getDisplayName_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, displayLocale: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, displayName: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, displayNameCapacity: number, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_getFromUCallBack_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, action: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<UConverterFromUnicodeArgs> | null, p3: interop.Pointer | interop.Reference<number> | null, p4: number, p5: number, p6: UConverterCallbackReason, p7: interop.Pointer | interop.Reference<UErrorCode> | null) => void>> | ArrayBufferLike | ArrayBufferView | null, context: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_getInvalidChars_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, errBytes: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_getInvalidUChars_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, errUChars: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_getMaxCharSize_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_getMinCharSize_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_getName_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function ucnv_getNextUChar_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, source: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null, sourceLimit: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_getPlatform_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): UConverterPlatform;

declare function ucnv_getStandardName_74(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, standard: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function ucnv_getStandard_74(n: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function ucnv_getStarters_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, starters: interop.Reference<number>, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_getSubstChars_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, subChars: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_getToUCallBack_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, action: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<UConverterToUnicodeArgs> | null, p3: string | null, p4: number, p5: UConverterCallbackReason, p6: interop.Pointer | interop.Reference<UErrorCode> | null) => void>> | ArrayBufferLike | ArrayBufferView | null, context: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_getType_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null): UConverterType;

declare function ucnv_getUnicodeSet_74(cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, setFillIn: interop.Pointer | interop.Reference<USet> | ArrayBufferLike | ArrayBufferView | null, whichSet: UConverterUnicodeSet, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_isAmbiguous_74(cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_isFixedWidth_74(cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_openAllNames_74(pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UEnumeration> | null;

declare function ucnv_openCCSID_74(codepage: number, platform: UConverterPlatform, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UConverter> | null;

declare function ucnv_openPackage_74(packageName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, converterName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UConverter> | null;

declare function ucnv_openStandardNames_74(convName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, standard: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UEnumeration> | null;

declare function ucnv_openU_74(name: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UConverter> | null;

declare function ucnv_open_74(converterName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UConverter> | null;

declare function ucnv_resetFromUnicode_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_resetToUnicode_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_reset_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_safeClone_74(cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, stackBuffer: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pBufferSize: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UConverter> | null;

declare function ucnv_setDefaultName_74(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_setFallback_74(cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, usesFallback: number): void;

declare function ucnv_setFromUCallBack_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, newAction: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<UConverterFromUnicodeArgs> | null, p3: interop.Pointer | interop.Reference<number> | null, p4: number, p5: number, p6: UConverterCallbackReason, p7: interop.Pointer | interop.Reference<UErrorCode> | null) => void>, newContext: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, oldAction: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<UConverterFromUnicodeArgs> | null, p3: interop.Pointer | interop.Reference<number> | null, p4: number, p5: number, p6: UConverterCallbackReason, p7: interop.Pointer | interop.Reference<UErrorCode> | null) => void>> | ArrayBufferLike | ArrayBufferView | null, oldContext: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_setSubstChars_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, subChars: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_setSubstString_74(cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_setToUCallBack_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, newAction: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<UConverterToUnicodeArgs> | null, p3: string | null, p4: number, p5: UConverterCallbackReason, p6: interop.Pointer | interop.Reference<UErrorCode> | null) => void>, newContext: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, oldAction: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<UConverterToUnicodeArgs> | null, p3: string | null, p4: number, p5: UConverterCallbackReason, p6: interop.Pointer | interop.Reference<UErrorCode> | null) => void>> | ArrayBufferLike | ArrayBufferView | null, oldContext: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_toAlgorithmic_74(algorithmicType: UConverterType, cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, target: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, targetCapacity: number, source: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, sourceLength: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_toUChars_74(cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, src: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, srcLength: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_toUCountPending_74(cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucnv_toUnicode_74(converter: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null, target: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, targetLimit: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, source: interop.Pointer | interop.Reference<string | null> | ArrayBufferLike | ArrayBufferView | null, sourceLimit: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, offsets: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, flush: number, err: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function ucnv_usesFallback_74(cnv: interop.Pointer | interop.Reference<UConverter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucpmap_getRange_74(map: interop.Pointer | interop.Reference<UCPMap> | ArrayBufferLike | ArrayBufferView | null, start: number, option: UCPMapRangeOption, surrogateValue: number, filter: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: number) => number>> | ArrayBufferLike | ArrayBufferView | null, context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pValue: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ucpmap_get_74(map: interop.Pointer | interop.Reference<UCPMap> | ArrayBufferLike | ArrayBufferView | null, c: number): number;

declare function uenum_close_74(en: interop.Pointer | interop.Reference<UEnumeration> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uenum_count_74(en: interop.Pointer | interop.Reference<UEnumeration> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uenum_next_74(en: interop.Pointer | interop.Reference<UEnumeration> | ArrayBufferLike | ArrayBufferView | null, resultLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function uenum_openCharStringsEnumeration_74(strings: interop.Reference<string | null>, count: number, ec: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UEnumeration> | null;

declare function uenum_openUCharStringsEnumeration_74(strings: interop.Reference<interop.Pointer | interop.Reference<number> | null>, count: number, ec: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UEnumeration> | null;

declare function uenum_reset_74(en: interop.Pointer | interop.Reference<UEnumeration> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uenum_unext_74(en: interop.Pointer | interop.Reference<UEnumeration> | ArrayBufferLike | ArrayBufferView | null, resultLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function uiter_current32_74(iter: interop.Pointer | interop.Reference<UCharIterator> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uiter_getState_74(iter: interop.Pointer | interop.Reference<UCharIterator> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uiter_next32_74(iter: interop.Pointer | interop.Reference<UCharIterator> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uiter_previous32_74(iter: interop.Pointer | interop.Reference<UCharIterator> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uiter_setState_74(iter: interop.Pointer | interop.Reference<UCharIterator> | ArrayBufferLike | ArrayBufferView | null, state: number, pErrorCode: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uiter_setString_74(iter: interop.Pointer | interop.Reference<UCharIterator> | ArrayBufferLike | ArrayBufferView | null, s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number): void;

declare function uiter_setUTF16BE_74(iter: interop.Pointer | interop.Reference<UCharIterator> | ArrayBufferLike | ArrayBufferView | null, s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, length: number): void;

declare function uiter_setUTF8_74(iter: interop.Pointer | interop.Reference<UCharIterator> | ArrayBufferLike | ArrayBufferView | null, s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, length: number): void;

declare function uregex_appendReplacementUText_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, replacementText: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, dest: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_appendReplacement_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, replacementText: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, replacementLength: number, destBuf: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, destCapacity: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_appendTailUText_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, dest: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UText> | null;

declare function uregex_appendTail_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, destBuf: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, destCapacity: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_clone_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<URegularExpression> | null;

declare function uregex_close_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_end64_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, groupNum: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_end_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, groupNum: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_find64_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, startIndex: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_findNext_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_find_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, startIndex: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_flags_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_getFindProgressCallback_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, callback: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: number) => number>> | null> | ArrayBufferLike | ArrayBufferView | null, context: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_getMatchCallback_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, callback: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: number) => number>> | null> | ArrayBufferLike | ArrayBufferView | null, context: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_getStackLimit_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_getText_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, textLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function uregex_getTimeLimit_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_getUText_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, dest: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UText> | null;

declare function uregex_groupCount_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_groupNumberFromCName_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, groupName: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, nameLength: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_groupNumberFromName_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, groupName: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, nameLength: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_groupUText_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, groupNum: number, dest: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, groupLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UText> | null;

declare function uregex_group_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, groupNum: number, dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_hasAnchoringBounds_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_hasTransparentBounds_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_hitEnd_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_lookingAt64_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, startIndex: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_lookingAt_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, startIndex: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_matches64_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, startIndex: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_matches_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, startIndex: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_openC_74(pattern: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, flags: number, pe: interop.Pointer | interop.Reference<UParseError> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<URegularExpression> | null;

declare function uregex_openUText_74(pattern: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, flags: number, pe: interop.Pointer | interop.Reference<UParseError> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<URegularExpression> | null;

declare function uregex_open_74(pattern: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, patternLength: number, flags: number, pe: interop.Pointer | interop.Reference<UParseError> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<URegularExpression> | null;

declare function uregex_patternUText_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UText> | null;

declare function uregex_pattern_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, patLength: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function uregex_refreshUText_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, text: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_regionEnd64_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_regionEnd_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_regionStart64_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_regionStart_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_replaceAllUText_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, replacement: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, dest: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UText> | null;

declare function uregex_replaceAll_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, replacementText: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, replacementLength: number, destBuf: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_replaceFirstUText_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, replacement: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, dest: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UText> | null;

declare function uregex_replaceFirst_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, replacementText: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, replacementLength: number, destBuf: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_requireEnd_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_reset64_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, index: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_reset_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, index: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_setFindProgressCallback_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, callback: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: number) => number>> | ArrayBufferLike | ArrayBufferView | null, context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_setMatchCallback_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, callback: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: number) => number>> | ArrayBufferLike | ArrayBufferView | null, context: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_setRegion64_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, regionStart: number, regionLimit: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_setRegionAndStart_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, regionStart: number, regionLimit: number, startIndex: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_setRegion_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, regionStart: number, regionLimit: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_setStackLimit_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, limit: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_setText_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, text: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, textLength: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_setTimeLimit_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, limit: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_setUText_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, text: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_splitUText_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, destFields: interop.Reference<interop.Pointer | interop.Reference<UText> | null>, destFieldsCapacity: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_split_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, destBuf: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, requiredCapacity: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destFields: interop.Reference<interop.Pointer | interop.Reference<number> | null>, destFieldsCapacity: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_start64_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, groupNum: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_start_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, groupNum: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function uregex_useAnchoringBounds_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, b: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function uregex_useTransparentBounds_74(regexp: interop.Pointer | interop.Reference<URegularExpression> | ArrayBufferLike | ArrayBufferView | null, b: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function utext_char32At_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, nativeIndex: number): number;

declare function utext_clone_74(dest: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, src: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, deep: number, readOnly: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UText> | null;

declare function utext_close_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UText> | null;

declare function utext_copy_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, nativeStart: number, nativeLimit: number, destIndex: number, move: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): void;

declare function utext_current32_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null): number;

declare function utext_equals_74(a: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, b: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null): number;

declare function utext_extract_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, nativeStart: number, nativeLimit: number, dest: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, destCapacity: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function utext_freeze_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null): void;

declare function utext_getNativeIndex_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null): number;

declare function utext_getPreviousNativeIndex_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null): number;

declare function utext_hasMetaData_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null): number;

declare function utext_isLengthExpensive_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null): number;

declare function utext_isWritable_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null): number;

declare function utext_moveIndex32_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, delta: number): number;

declare function utext_nativeLength_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null): number;

declare function utext_next32From_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, nativeIndex: number): number;

declare function utext_next32_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null): number;

declare function utext_openUChars_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, s: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UText> | null;

declare function utext_openUTF8_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, length: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UText> | null;

declare function utext_previous32From_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, nativeIndex: number): number;

declare function utext_previous32_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null): number;

declare function utext_replace_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, nativeStart: number, nativeLimit: number, replacementText: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, replacementLength: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): number;

declare function utext_setNativeIndex_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, nativeIndex: number): void;

declare function utext_setup_74(ut: interop.Pointer | interop.Reference<UText> | ArrayBufferLike | ArrayBufferView | null, extraSpace: number, status: interop.Pointer | interop.Reference<UErrorCode> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<UText> | null;

declare function utf8_appendCharSafeBody_74(s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, i: number, length: number, c: number, pIsError: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function utf8_back1SafeBody_74(s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, start: number, i: number): number;

declare var utf8_countTrailBytes_74: interop.Reference<number>;

declare function utf8_nextCharSafeBody_74(s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, pi: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, length: number, c: number, strict: number): number;

declare function utf8_prevCharSafeBody_74(s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, start: number, pi: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, c: number, strict: number): number;
