
declare const ACCESSPERMS: number;

declare const ADDRB: number;

declare const AF_ALG: number;

declare const AF_APPLETALK: number;

declare const AF_ASH: number;

declare const AF_ATMPVC: number;

declare const AF_ATMSVC: number;

declare const AF_AX25: number;

declare const AF_BLUETOOTH: number;

declare const AF_BRIDGE: number;

declare const AF_CAIF: number;

declare const AF_CAN: number;

declare const AF_DECnet: number;

declare const AF_ECONET: number;

declare const AF_FILE: number;

declare const AF_IB: number;

declare const AF_IEEE802154: number;

declare const AF_INET: number;

declare const AF_INET6: number;

declare const AF_IPX: number;

declare const AF_IRDA: number;

declare const AF_ISDN: number;

declare const AF_IUCV: number;

declare const AF_KCM: number;

declare const AF_KEY: number;

declare const AF_LLC: number;

declare const AF_LOCAL: number;

declare const AF_MAX: number;

declare const AF_MCTP: number;

declare const AF_MPLS: number;

declare const AF_NETBEUI: number;

declare const AF_NETLINK: number;

declare const AF_NETROM: number;

declare const AF_NFC: number;

declare const AF_PACKET: number;

declare const AF_PHONET: number;

declare const AF_PPPOX: number;

declare const AF_QIPCRTR: number;

declare const AF_RDS: number;

declare const AF_ROSE: number;

declare const AF_ROUTE: number;

declare const AF_RXRPC: number;

declare const AF_SECURITY: number;

declare const AF_SMC: number;

declare const AF_SNA: number;

declare const AF_TIPC: number;

declare const AF_UNIX: number;

declare const AF_UNSPEC: number;

declare const AF_VSOCK: number;

declare const AF_WANPIPE: number;

declare const AF_X25: number;

declare const AF_XDP: number;

declare const AIO_PRIO_DELTA_MAX: number;

declare const ALLPERMS: number;

declare const B0: number;

declare const B1000000: number;

declare const B110: number;

declare const B115200: number;

declare const B1152000: number;

declare const B1200: number;

declare const B134: number;

declare const B150: number;

declare const B1500000: number;

declare const B1800: number;

declare const B19200: number;

declare const B200: number;

declare const B2000000: number;

declare const B230400: number;

declare const B2400: number;

declare const B2500000: number;

declare const B300: number;

declare const B3000000: number;

declare const B3500000: number;

declare const B38400: number;

declare const B4000000: number;

declare const B460800: number;

declare const B4800: number;

declare const B50: number;

declare const B500000: number;

declare const B57600: number;

declare const B576000: number;

declare const B600: number;

declare const B75: number;

declare const B921600: number;

declare const B9600: number;

declare const BC_BASE_MAX: number;

declare const BC_DIM_MAX: number;

declare const BC_SCALE_MAX: number;

declare const BC_STRING_MAX: number;

declare const BLOCK_SIZE: number;

declare const BLOCK_SIZE_BITS: number;

declare const BOOT_TIME: number;

declare const BRKINT: number;

declare const BS0: number;

declare const BS1: number;

declare const BSDLY: number;

declare const BUS_ADRALN: number;

declare const BUS_ADRERR: number;

declare const BUS_MCEERR_AO: number;

declare const BUS_MCEERR_AR: number;

declare const BUS_OBJERR: number;

declare const CANBSIZ: number;

declare const CBAUD: number;

declare const CBAUDEX: number;

declare const CBRK: number;

declare const CDISCARD: number;

declare const CDSUSP: number;

declare const CEOF: number;

declare const CEOL: number;

declare const CEOT: number;

declare const CERASE: number;

declare const CFLUSH: number;

declare const CHARCLASS_NAME_MAX: number;

declare const CIBAUD: number;

declare const CINTR: number;

declare const CKILL: number;

declare const CLD_CONTINUED: number;

declare const CLD_DUMPED: number;

declare const CLD_EXITED: number;

declare const CLD_KILLED: number;

declare const CLD_STOPPED: number;

declare const CLD_TRAPPED: number;

declare const CLNEXT: number;

declare const CLOCAL: number;

declare const CLOCKS_PER_SEC: number;

declare const CLOCK_BOOTTIME: number;

declare const CLOCK_BOOTTIME_ALARM: number;

declare const CLOCK_MONOTONIC: number;

declare const CLOCK_MONOTONIC_COARSE: number;

declare const CLOCK_MONOTONIC_RAW: number;

declare const CLOCK_PROCESS_CPUTIME_ID: number;

declare const CLOCK_REALTIME: number;

declare const CLOCK_REALTIME_ALARM: number;

declare const CLOCK_REALTIME_COARSE: number;

declare const CLOCK_TAI: number;

declare const CLOCK_THREAD_CPUTIME_ID: number;

declare const CMIN: number;

declare const CMSPAR: number;

declare const COLL_WEIGHTS_MAX: number;

declare const CQUIT: number;

declare const CR0: number;

declare const CR1: number;

declare const CR2: number;

declare const CR3: number;

declare const CRDLY: number;

declare const CREAD: number;

declare const CREPRINT: number;

declare const CRPRNT: number;

declare const CRTSCTS: number;

declare const CS5: number;

declare const CS6: number;

declare const CS7: number;

declare const CS8: number;

declare const CSIZE: number;

declare const CSTART: number;

declare const CSTATUS: number;

declare const CSTOP: number;

declare const CSTOPB: number;

declare const CSUSP: number;

declare const CTIME: number;

declare const CWERASE: number;

declare const DEAD_PROCESS: number;

declare const DEFFILEMODE: number;

declare const DELAYTIMER_MAX: number;

declare const DEV_BSIZE: number;

declare const ECHO: number;

declare const ECHOCTL: number;

declare const ECHOE: number;

declare const ECHOK: number;

declare const ECHOKE: number;

declare const ECHONL: number;

declare const ECHOPRT: number;

declare const EMPTY: number;

declare const ENOTSUP: number;

declare const EXPR_NEST_MAX: number;

declare const EXTA: number;

declare const EXTB: number;

declare const EXTPROC: number;

declare const FAPPEND: number;

declare const FASYNC: number;

declare const FD_CLOEXEC: number;

declare const FD_SETSIZE: number;

declare const FE_ALL_EXCEPT: number;

declare const FE_DIVBYZERO: number;

declare const FE_DOWNWARD: number;

declare const FE_INEXACT: number;

declare const FE_INVALID: number;

declare const FE_OVERFLOW: number;

declare const FE_TONEAREST: number;

declare const FE_TOWARDZERO: number;

declare const FE_UNDERFLOW: number;

declare const FE_UPWARD: number;

declare const FF0: number;

declare const FF1: number;

declare const FFDLY: number;

declare const FFSYNC: number;

interface FILE {
	_flags: number;
	_IO_read_ptr: interop.Pointer | interop.Reference<any> | null;
	_IO_read_end: interop.Pointer | interop.Reference<any> | null;
	_IO_read_base: interop.Pointer | interop.Reference<any> | null;
	_IO_write_base: interop.Pointer | interop.Reference<any> | null;
	_IO_write_ptr: interop.Pointer | interop.Reference<any> | null;
	_IO_write_end: interop.Pointer | interop.Reference<any> | null;
	_IO_buf_base: interop.Pointer | interop.Reference<any> | null;
	_IO_buf_end: interop.Pointer | interop.Reference<any> | null;
	_IO_save_base: interop.Pointer | interop.Reference<any> | null;
	_IO_backup_base: interop.Pointer | interop.Reference<any> | null;
	_IO_save_end: interop.Pointer | interop.Reference<any> | null;
	_markers: interop.Pointer | interop.Reference<_IO_marker> | null;
	_chain: interop.Pointer | interop.Reference<FILE> | null;
	_fileno: number;
	_flags2: number;
	_old_offset: number;
	_cur_column: number;
	_vtable_offset: number;
	_shortbuf: interop.Reference<number>;
	_lock: interop.Pointer | interop.Reference<any> | null;
	_offset: number;
	_codecvt: interop.Pointer | interop.Reference<_IO_codecvt> | null;
	_wide_data: interop.Pointer | interop.Reference<_IO_wide_data> | null;
	_freeres_list: interop.Pointer | interop.Reference<FILE> | null;
	_freeres_buf: interop.Pointer | interop.Reference<any> | null;
	__pad5: number;
	_mode: number;
	_unused2: interop.Reference<number>;
}
declare var FILE: interop.StructType<FILE>;

/** Struct tag of {@link FILE}. */
type _IO_FILE = FILE;
declare var _IO_FILE: typeof FILE;

declare const FILENAME_MAX: number;

declare const FLUSHO: number;

declare const FNDELAY: number;

declare const FNONBLOCK: number;

declare const FPE_CONDTRAP: number;

declare const FPE_FLTDIV: number;

declare const FPE_FLTINV: number;

declare const FPE_FLTOVF: number;

declare const FPE_FLTRES: number;

declare const FPE_FLTSUB: number;

declare const FPE_FLTUND: number;

declare const FPE_FLTUNK: number;

declare const FPE_INTDIV: number;

declare const FPE_INTOVF: number;

declare const FP_XSTATE_MAGIC1: number;

declare const FP_XSTATE_MAGIC2: number;

declare const FP_XSTATE_MAGIC2_SIZE: number;

declare const FSMOUNT_CLOEXEC: number;

declare const FSOPEN_CLOEXEC: number;

declare const FSPICK_CLOEXEC: number;

declare const FSPICK_EMPTY_PATH: number;

declare const FSPICK_NO_AUTOMOUNT: number;

declare const FSPICK_SYMLINK_NOFOLLOW: number;

declare const F_DUPFD: number;

declare const F_DUPFD_CLOEXEC: number;

declare const F_EXLCK: number;

declare const F_GETFD: number;

declare const F_GETFL: number;

declare const F_GETLK: number;

declare const F_GETLK64: number;

declare const F_GETOWN: number;

declare const F_RDLCK: number;

declare const F_SETFD: number;

declare const F_SETFL: number;

declare const F_SETLK: number;

declare const F_SETLK64: number;

declare const F_SETLKW: number;

declare const F_SETLKW64: number;

declare const F_SETOWN: number;

declare const F_SHLCK: number;

declare const F_UNLCK: number;

declare const F_WRLCK: number;

declare const GETALL: number;

declare const GETNCNT: number;

declare const GETPID: number;

declare const GETVAL: number;

declare const GETZCNT: number;

declare const HOST_NAME_MAX: number;

declare const HUPCL: number;

declare const ICANON: number;

declare const ICRNL: number;

declare const IEXTEN: number;

declare const IGNBRK: number;

declare const IGNCR: number;

declare const IGNPAR: number;

declare const ILL_BADIADDR: number;

declare const ILL_BADSTK: number;

declare const ILL_COPROC: number;

declare const ILL_ILLADR: number;

declare const ILL_ILLOPC: number;

declare const ILL_ILLOPN: number;

declare const ILL_ILLTRP: number;

declare const ILL_PRVOPC: number;

declare const ILL_PRVREG: number;

declare const IMAXBEL: number;

declare const INIT_PROCESS: number;

declare const INLCR: number;

declare const INPCK: number;

declare const IPC_CREAT: number;

declare const IPC_EXCL: number;

declare const IPC_NOWAIT: number;

declare const IPC_PRIVATE: number;

declare const IPC_RMID: number;

declare const IPC_SET: number;

declare const IPC_STAT: number;

declare const IPV6_2292DSTOPTS: number;

declare const IPV6_2292HOPLIMIT: number;

declare const IPV6_2292HOPOPTS: number;

declare const IPV6_2292PKTINFO: number;

declare const IPV6_2292PKTOPTIONS: number;

declare const IPV6_2292RTHDR: number;

declare const IPV6_ADDRFORM: number;

declare const IPV6_ADDR_PREFERENCES: number;

declare const IPV6_ADD_MEMBERSHIP: number;

declare const IPV6_AUTHHDR: number;

declare const IPV6_AUTOFLOWLABEL: number;

declare const IPV6_CHECKSUM: number;

declare const IPV6_DONTFRAG: number;

declare const IPV6_DROP_MEMBERSHIP: number;

declare const IPV6_DSTOPTS: number;

declare const IPV6_FREEBIND: number;

declare const IPV6_HDRINCL: number;

declare const IPV6_HOPLIMIT: number;

declare const IPV6_HOPOPTS: number;

declare const IPV6_IPSEC_POLICY: number;

declare const IPV6_JOIN_ANYCAST: number;

declare const IPV6_JOIN_GROUP: number;

declare const IPV6_LEAVE_ANYCAST: number;

declare const IPV6_LEAVE_GROUP: number;

declare const IPV6_MINHOPCOUNT: number;

declare const IPV6_MTU: number;

declare const IPV6_MTU_DISCOVER: number;

declare const IPV6_MULTICAST_ALL: number;

declare const IPV6_MULTICAST_HOPS: number;

declare const IPV6_MULTICAST_IF: number;

declare const IPV6_MULTICAST_LOOP: number;

declare const IPV6_NEXTHOP: number;

declare const IPV6_ORIGDSTADDR: number;

declare const IPV6_PATHMTU: number;

declare const IPV6_PKTINFO: number;

declare const IPV6_PMTUDISC_DO: number;

declare const IPV6_PMTUDISC_DONT: number;

declare const IPV6_PMTUDISC_INTERFACE: number;

declare const IPV6_PMTUDISC_OMIT: number;

declare const IPV6_PMTUDISC_PROBE: number;

declare const IPV6_PMTUDISC_WANT: number;

declare const IPV6_RECVDSTOPTS: number;

declare const IPV6_RECVERR: number;

declare const IPV6_RECVERR_RFC4884: number;

declare const IPV6_RECVFRAGSIZE: number;

declare const IPV6_RECVHOPLIMIT: number;

declare const IPV6_RECVHOPOPTS: number;

declare const IPV6_RECVORIGDSTADDR: number;

declare const IPV6_RECVPATHMTU: number;

declare const IPV6_RECVPKTINFO: number;

declare const IPV6_RECVRTHDR: number;

declare const IPV6_RECVTCLASS: number;

declare const IPV6_ROUTER_ALERT: number;

declare const IPV6_ROUTER_ALERT_ISOLATE: number;

declare const IPV6_RTHDR: number;

declare const IPV6_RTHDRDSTOPTS: number;

declare const IPV6_RTHDR_LOOSE: number;

declare const IPV6_RTHDR_STRICT: number;

declare const IPV6_RTHDR_TYPE_0: number;

declare const IPV6_RXDSTOPTS: number;

declare const IPV6_RXHOPOPTS: number;

declare const IPV6_TCLASS: number;

declare const IPV6_TRANSPARENT: number;

declare const IPV6_UNICAST_HOPS: number;

declare const IPV6_UNICAST_IF: number;

declare const IPV6_V6ONLY: number;

declare const IPV6_XFRM_POLICY: number;

declare const IP_ADD_MEMBERSHIP: number;

declare const IP_ADD_SOURCE_MEMBERSHIP: number;

declare const IP_BIND_ADDRESS_NO_PORT: number;

declare const IP_BLOCK_SOURCE: number;

declare const IP_CHECKSUM: number;

declare const IP_DEFAULT_MULTICAST_LOOP: number;

declare const IP_DEFAULT_MULTICAST_TTL: number;

declare const IP_DROP_MEMBERSHIP: number;

declare const IP_DROP_SOURCE_MEMBERSHIP: number;

declare const IP_FREEBIND: number;

declare const IP_HDRINCL: number;

declare const IP_IPSEC_POLICY: number;

declare const IP_LOCAL_PORT_RANGE: number;

declare const IP_MAX_MEMBERSHIPS: number;

declare const IP_MINTTL: number;

declare const IP_MSFILTER: number;

declare const IP_MTU: number;

declare const IP_MTU_DISCOVER: number;

declare const IP_MULTICAST_ALL: number;

declare const IP_MULTICAST_IF: number;

declare const IP_MULTICAST_LOOP: number;

declare const IP_MULTICAST_TTL: number;

declare const IP_NODEFRAG: number;

declare const IP_OPTIONS: number;

declare const IP_ORIGDSTADDR: number;

declare const IP_PASSSEC: number;

declare const IP_PKTINFO: number;

declare const IP_PKTOPTIONS: number;

declare const IP_PMTUDISC: number;

declare const IP_PMTUDISC_DO: number;

declare const IP_PMTUDISC_DONT: number;

declare const IP_PMTUDISC_INTERFACE: number;

declare const IP_PMTUDISC_OMIT: number;

declare const IP_PMTUDISC_PROBE: number;

declare const IP_PMTUDISC_WANT: number;

declare const IP_PROTOCOL: number;

declare const IP_RECVERR: number;

declare const IP_RECVERR_RFC4884: number;

declare const IP_RECVFRAGSIZE: number;

declare const IP_RECVOPTS: number;

declare const IP_RECVORIGDSTADDR: number;

declare const IP_RECVRETOPTS: number;

declare const IP_RECVTOS: number;

declare const IP_RECVTTL: number;

declare const IP_RETOPTS: number;

declare const IP_ROUTER_ALERT: number;

declare const IP_TOS: number;

declare const IP_TRANSPARENT: number;

declare const IP_TTL: number;

declare const IP_UNBLOCK_SOURCE: number;

declare const IP_UNICAST_IF: number;

declare const IP_XFRM_POLICY: number;

declare const ISIG: number;

declare const ISTRIP: number;

declare const IUCLC: number;

declare const IUTF8: number;

declare const IXANY: number;

declare const IXOFF: number;

declare const IXON: number;

declare const LINE_MAX: number;

declare const LOCK_EX: number;

declare const LOCK_NB: number;

declare const LOCK_SH: number;

declare const LOCK_UN: number;

declare const LOGIN_NAME_MAX: number;

declare const LOGIN_PROCESS: number;

declare const LOG_ALERT: number;

declare const LOG_AUTH: number;

declare const LOG_AUTHPRIV: number;

declare const LOG_CONS: number;

declare const LOG_CRIT: number;

declare const LOG_CRON: number;

declare const LOG_DAEMON: number;

declare const LOG_DEBUG: number;

declare const LOG_EMERG: number;

declare const LOG_ERR: number;

declare const LOG_FACMASK: number;

declare const LOG_FTP: number;

declare const LOG_INFO: number;

declare const LOG_KERN: number;

declare const LOG_LOCAL0: number;

declare const LOG_LOCAL1: number;

declare const LOG_LOCAL2: number;

declare const LOG_LOCAL3: number;

declare const LOG_LOCAL4: number;

declare const LOG_LOCAL5: number;

declare const LOG_LOCAL6: number;

declare const LOG_LOCAL7: number;

declare const LOG_LPR: number;

declare const LOG_MAIL: number;

declare const LOG_NDELAY: number;

declare const LOG_NEWS: number;

declare const LOG_NFACILITIES: number;

declare const LOG_NOTICE: number;

declare const LOG_NOWAIT: number;

declare const LOG_ODELAY: number;

declare const LOG_PERROR: number;

declare const LOG_PID: number;

declare const LOG_PRIMASK: number;

declare const LOG_SYSLOG: number;

declare const LOG_USER: number;

declare const LOG_UUCP: number;

declare const LOG_WARNING: number;

declare const MADV_COLD: number;

declare const MADV_COLLAPSE: number;

declare const MADV_DODUMP: number;

declare const MADV_DOFORK: number;

declare const MADV_DONTDUMP: number;

declare const MADV_DONTFORK: number;

declare const MADV_DONTNEED: number;

declare const MADV_DONTNEED_LOCKED: number;

declare const MADV_FREE: number;

declare const MADV_HUGEPAGE: number;

declare const MADV_HWPOISON: number;

declare const MADV_KEEPONFORK: number;

declare const MADV_MERGEABLE: number;

declare const MADV_NOHUGEPAGE: number;

declare const MADV_NORMAL: number;

declare const MADV_PAGEOUT: number;

declare const MADV_POPULATE_READ: number;

declare const MADV_POPULATE_WRITE: number;

declare const MADV_RANDOM: number;

declare const MADV_REMOVE: number;

declare const MADV_SEQUENTIAL: number;

declare const MADV_UNMERGEABLE: number;

declare const MADV_WILLNEED: number;

declare const MADV_WIPEONFORK: number;

declare const MAP_32BIT: number;

declare const MAP_ABOVE4G: number;

declare const MAP_ANON: number;

declare const MAP_ANONYMOUS: number;

declare const MAP_DENYWRITE: number;

declare const MAP_EXECUTABLE: number;

declare const MAP_FILE: number;

declare const MAP_FIXED: number;

declare const MAP_FIXED_NOREPLACE: number;

declare const MAP_GROWSDOWN: number;

declare const MAP_HUGETLB: number;

declare const MAP_HUGE_MASK: number;

declare const MAP_HUGE_SHIFT: number;

declare const MAP_LOCKED: number;

declare const MAP_NONBLOCK: number;

declare const MAP_NORESERVE: number;

declare const MAP_POPULATE: number;

declare const MAP_PRIVATE: number;

declare const MAP_SHARED: number;

declare const MAP_SHARED_VALIDATE: number;

declare const MAP_STACK: number;

declare const MAP_SYNC: number;

declare const MAP_TYPE: number;

declare const MAXPATHLEN: number;

declare const MAXSYMLINKS: number;

declare const MAX_DQ_TIME: number;

declare const MAX_IQ_TIME: number;

declare const MCAST_BLOCK_SOURCE: number;

declare const MCAST_EXCLUDE: number;

declare const MCAST_INCLUDE: number;

declare const MCAST_JOIN_GROUP: number;

declare const MCAST_JOIN_SOURCE_GROUP: number;

declare const MCAST_LEAVE_GROUP: number;

declare const MCAST_LEAVE_SOURCE_GROUP: number;

declare const MCAST_MSFILTER: number;

declare const MCAST_UNBLOCK_SOURCE: number;

declare const MCL_CURRENT: number;

declare const MCL_FUTURE: number;

declare const MCL_ONFAULT: number;

declare const MINSIGSTKSZ: number;

declare const MNT_DETACH: number;

declare const MNT_EXPIRE: number;

declare const MNT_FORCE: number;

declare const MOUNT_ATTR_IDMAP: number;

declare const MOUNT_ATTR_NOATIME: number;

declare const MOUNT_ATTR_NODEV: number;

declare const MOUNT_ATTR_NODIRATIME: number;

declare const MOUNT_ATTR_NOEXEC: number;

declare const MOUNT_ATTR_NOSUID: number;

declare const MOUNT_ATTR_NOSYMFOLLOW: number;

declare const MOUNT_ATTR_RDONLY: number;

declare const MOUNT_ATTR_RELATIME: number;

declare const MOUNT_ATTR_SIZE_VER0: number;

declare const MOUNT_ATTR_STRICTATIME: number;

declare const MOUNT_ATTR__ATIME: number;

declare const MOVE_MOUNT_BENEATH: number;

declare const MOVE_MOUNT_F_AUTOMOUNTS: number;

declare const MOVE_MOUNT_F_EMPTY_PATH: number;

declare const MOVE_MOUNT_F_SYMLINKS: number;

declare const MOVE_MOUNT_SET_GROUP: number;

declare const MOVE_MOUNT_T_AUTOMOUNTS: number;

declare const MOVE_MOUNT_T_EMPTY_PATH: number;

declare const MOVE_MOUNT_T_SYMLINKS: number;

declare const MQ_PRIO_MAX: number;

declare const MSG_BATCH: number;

declare const MSG_CMSG_CLOEXEC: number;

declare const MSG_CONFIRM: number;

declare const MSG_CTRUNC: number;

declare const MSG_DONTROUTE: number;

declare const MSG_DONTWAIT: number;

declare const MSG_EOR: number;

declare const MSG_ERRQUEUE: number;

declare const MSG_FASTOPEN: number;

declare const MSG_FIN: number;

declare const MSG_INFO: number;

declare const MSG_MORE: number;

declare const MSG_NOERROR: number;

declare const MSG_NOSIGNAL: number;

declare const MSG_OOB: number;

declare const MSG_PEEK: number;

declare const MSG_PROXY: number;

declare const MSG_RST: number;

declare const MSG_STAT: number;

declare const MSG_STAT_ANY: number;

declare const MSG_SYN: number;

declare const MSG_TRUNC: number;

declare const MSG_WAITALL: number;

declare const MSG_WAITFORONE: number;

declare const MSG_ZEROCOPY: number;

declare const MS_ACTIVE: number;

declare const MS_ASYNC: number;

declare const MS_BIND: number;

declare const MS_DIRSYNC: number;

declare const MS_INVALIDATE: number;

declare const MS_I_VERSION: number;

declare const MS_KERNMOUNT: number;

declare const MS_LAZYTIME: number;

declare const MS_MANDLOCK: number;

declare const MS_MGC_MSK: number;

declare const MS_MGC_VAL: number;

declare const MS_MOVE: number;

declare const MS_NOATIME: number;

declare const MS_NODEV: number;

declare const MS_NODIRATIME: number;

declare const MS_NOEXEC: number;

declare const MS_NOSUID: number;

declare const MS_NOSYMFOLLOW: number;

declare const MS_NOUSER: number;

declare const MS_POSIXACL: number;

declare const MS_PRIVATE: number;

declare const MS_RDONLY: number;

declare const MS_REC: number;

declare const MS_RELATIME: number;

declare const MS_REMOUNT: number;

declare const MS_RMT_MASK: number;

declare const MS_SHARED: number;

declare const MS_SILENT: number;

declare const MS_SLAVE: number;

declare const MS_STRICTATIME: number;

declare const MS_SYNC: number;

declare const MS_SYNCHRONOUS: number;

declare const MS_UNBINDABLE: number;

declare const NBBY: number;

declare const NCARGS: number;

declare const NCC: number;

declare const NCCS: number;

declare const NEW_TIME: number;

declare const NFDBITS: number;

declare const NGREG: number;

declare const NGROUPS: number;

declare const NL0: number;

declare const NL1: number;

declare const NLDLY: number;

declare const NODEV: bigint;

declare const NOFILE: number;

declare const NOFLSH: number;

declare const NR_DQHASH: number;

declare const NR_DQUOTS: number;

declare const N_6PACK: number;

declare const N_AX25: number;

declare const N_HCI: number;

declare const N_HDLC: number;

declare const N_IRDA: number;

declare const N_MASC: number;

declare const N_MOUSE: number;

declare const N_PPP: number;

declare const N_PROFIBUS_FDL: number;

declare const N_R3964: number;

declare const N_SLIP: number;

declare const N_SMSBLOCK: number;

declare const N_STRIP: number;

declare const N_SYNC_PPP: number;

declare const N_TTY: number;

declare const N_X25: number;

declare const OCRNL: number;

declare const OFDEL: number;

declare const OFILL: number;

declare const OLCUC: number;

declare const OLD_TIME: number;

declare const ONLCR: number;

declare const ONLRET: number;

declare const ONOCR: number;

declare const OPEN_TREE_CLOEXEC: number;

declare const OPEN_TREE_CLONE: number;

declare const OPOST: number;

declare const O_ACCMODE: number;

declare const O_APPEND: number;

declare const O_ASYNC: number;

declare const O_CLOEXEC: number;

declare const O_CREAT: number;

declare const O_DIRECTORY: number;

declare const O_DSYNC: number;

declare const O_EXCL: number;

declare const O_FSYNC: number;

declare const O_NDELAY: number;

declare const O_NOCTTY: number;

declare const O_NOFOLLOW: number;

declare const O_NONBLOCK: number;

declare const O_RDONLY: number;

declare const O_RDWR: number;

declare const O_RSYNC: number;

declare const O_SYNC: number;

declare const O_TRUNC: number;

declare const O_WRONLY: number;

declare const PARENB: number;

declare const PARMRK: number;

declare const PARODD: number;

declare const PENDIN: number;

declare const PF_ALG: number;

declare const PF_APPLETALK: number;

declare const PF_ASH: number;

declare const PF_ATMPVC: number;

declare const PF_ATMSVC: number;

declare const PF_AX25: number;

declare const PF_BLUETOOTH: number;

declare const PF_BRIDGE: number;

declare const PF_CAIF: number;

declare const PF_CAN: number;

declare const PF_DECnet: number;

declare const PF_ECONET: number;

declare const PF_FILE: number;

declare const PF_IB: number;

declare const PF_IEEE802154: number;

declare const PF_INET: number;

declare const PF_INET6: number;

declare const PF_IPX: number;

declare const PF_IRDA: number;

declare const PF_ISDN: number;

declare const PF_IUCV: number;

declare const PF_KCM: number;

declare const PF_KEY: number;

declare const PF_LLC: number;

declare const PF_LOCAL: number;

declare const PF_MAX: number;

declare const PF_MCTP: number;

declare const PF_MPLS: number;

declare const PF_NETBEUI: number;

declare const PF_NETLINK: number;

declare const PF_NETROM: number;

declare const PF_NFC: number;

declare const PF_PACKET: number;

declare const PF_PHONET: number;

declare const PF_PPPOX: number;

declare const PF_QIPCRTR: number;

declare const PF_RDS: number;

declare const PF_ROSE: number;

declare const PF_ROUTE: number;

declare const PF_RXRPC: number;

declare const PF_SECURITY: number;

declare const PF_SMC: number;

declare const PF_SNA: number;

declare const PF_TIPC: number;

declare const PF_UNIX: number;

declare const PF_UNSPEC: number;

declare const PF_VSOCK: number;

declare const PF_WANPIPE: number;

declare const PF_X25: number;

declare const PF_XDP: number;

declare const POLLERR: number;

declare const POLLHUP: number;

declare const POLLIN: number;

declare const POLLNVAL: number;

declare const POLLOUT: number;

declare const POLLPRI: number;

declare const POLLRDBAND: number;

declare const POLLRDNORM: number;

declare const POLLWRBAND: number;

declare const POLLWRNORM: number;

declare const POLL_ERR: number;

declare const POLL_HUP: number;

declare const POLL_IN: number;

declare const POLL_MSG: number;

declare const POLL_OUT: number;

declare const POLL_PRI: number;

declare const POSIX_FADV_DONTNEED: number;

declare const POSIX_FADV_NOREUSE: number;

declare const POSIX_FADV_NORMAL: number;

declare const POSIX_FADV_RANDOM: number;

declare const POSIX_FADV_SEQUENTIAL: number;

declare const POSIX_FADV_WILLNEED: number;

declare const POSIX_MADV_DONTNEED: number;

declare const POSIX_MADV_NORMAL: number;

declare const POSIX_MADV_RANDOM: number;

declare const POSIX_MADV_SEQUENTIAL: number;

declare const POSIX_MADV_WILLNEED: number;

declare const PRIO_MAX: number;

declare const PRIO_MIN: number;

declare const PROT_EXEC: number;

declare const PROT_GROWSDOWN: number;

declare const PROT_GROWSUP: number;

declare const PROT_NONE: number;

declare const PROT_READ: number;

declare const PROT_WRITE: number;

declare const PTHREAD_DESTRUCTOR_ITERATIONS: number;

declare const PTHREAD_KEYS_MAX: number;

declare const PTHREAD_STACK_MIN: number;

declare const QUOTAFILENAME: string;

declare const QUOTAGROUP: string;

declare const RE_DUP_MAX: number;

declare const RLIMIT_LOCKS: number;

declare const RLIMIT_MEMLOCK: number;

declare const RLIMIT_MSGQUEUE: number;

declare const RLIMIT_NICE: number;

declare const RLIMIT_NLIMITS: number;

declare const RLIMIT_NPROC: number;

declare const RLIMIT_OFILE: number;

declare const RLIMIT_RSS: number;

declare const RLIMIT_RTPRIO: number;

declare const RLIMIT_RTTIME: number;

declare const RLIMIT_SIGPENDING: number;

declare const RLIM_INFINITY: bigint;

declare const RLIM_NLIMITS: number;

declare const RLIM_SAVED_CUR: bigint;

declare const RLIM_SAVED_MAX: bigint;

declare const RTLD_BINDING_MASK: number;

declare const RTLD_DEEPBIND: number;

declare const RTLD_GLOBAL: number;

declare const RTLD_LAZY: number;

declare const RTLD_LOCAL: number;

declare const RTLD_NODELETE: number;

declare const RTLD_NOLOAD: number;

declare const RTLD_NOW: number;

declare const SA_INTERRUPT: number;

declare const SA_NOCLDSTOP: number;

declare const SA_NOCLDWAIT: number;

declare const SA_NODEFER: number;

declare const SA_NOMASK: number;

declare const SA_ONESHOT: number;

declare const SA_ONSTACK: number;

declare const SA_RESETHAND: number;

declare const SA_RESTART: number;

declare const SA_SIGINFO: number;

declare const SA_STACK: number;

declare const SCHED_FIFO: number;

declare const SCHED_OTHER: number;

declare const SCHED_RR: number;

declare const SCM_RIGHTS: number;

declare const SEGV_ACCADI: number;

declare const SEGV_ACCERR: number;

declare const SEGV_ADIDERR: number;

declare const SEGV_ADIPERR: number;

declare const SEGV_BNDERR: number;

declare const SEGV_CPERR: number;

declare const SEGV_MAPERR: number;

declare const SEGV_MTEAERR: number;

declare const SEGV_MTESERR: number;

declare const SEGV_PKUERR: number;

declare const SEM_INFO: number;

declare const SEM_STAT: number;

declare const SEM_STAT_ANY: number;

declare const SEM_UNDO: number;

declare const SEM_VALUE_MAX: number;

declare const SETALL: number;

declare const SETVAL: number;

declare const SHADOW_STACK_SET_TOKEN: number;

declare const SHM_DEST: number;

declare const SHM_EXEC: number;

declare const SHM_HUGETLB: number;

declare const SHM_INFO: number;

declare const SHM_LOCK: number;

declare const SHM_LOCKED: number;

declare const SHM_NORESERVE: number;

declare const SHM_R: number;

declare const SHM_RDONLY: number;

declare const SHM_REMAP: number;

declare const SHM_RND: number;

declare const SHM_STAT: number;

declare const SHM_STAT_ANY: number;

declare const SHM_UNLOCK: number;

declare const SHM_W: number;

declare const SHUT_RD: number;

declare const SHUT_RDWR: number;

declare const SHUT_WR: number;

declare const SIGABRT: number;

declare const SIGALRM: number;

declare const SIGBUS: number;

declare const SIGCHLD: number;

declare const SIGCLD: number;

declare const SIGCONT: number;

declare const SIGEV_NONE: number;

declare const SIGEV_SIGNAL: number;

declare const SIGEV_THREAD: number;

declare const SIGEV_THREAD_ID: number;

declare const SIGFPE: number;

declare const SIGHUP: number;

declare const SIGILL: number;

declare const SIGINT: number;

declare const SIGIO: number;

declare const SIGIOT: number;

declare const SIGKILL: number;

declare const SIGPIPE: number;

declare const SIGPOLL: number;

declare const SIGPROF: number;

declare const SIGPWR: number;

declare const SIGQUIT: number;

declare const SIGSEGV: number;

declare const SIGSTKFLT: number;

declare const SIGSTKSZ: number;

declare const SIGSTOP: number;

declare const SIGSYS: number;

declare const SIGTERM: number;

declare const SIGTRAP: number;

declare const SIGTSTP: number;

declare const SIGTTIN: number;

declare const SIGTTOU: number;

declare const SIGURG: number;

declare const SIGUSR1: number;

declare const SIGUSR2: number;

declare const SIGVTALRM: number;

declare const SIGWINCH: number;

declare const SIGXCPU: number;

declare const SIGXFSZ: number;

declare const SIG_BLOCK: number;

declare const SIG_SETMASK: number;

declare const SIG_UNBLOCK: number;

declare const SIOCADDDLCI: number;

declare const SIOCADDMULTI: number;

declare const SIOCADDRT: number;

declare const SIOCDARP: number;

declare const SIOCDELDLCI: number;

declare const SIOCDELMULTI: number;

declare const SIOCDELRT: number;

declare const SIOCDEVPRIVATE: number;

declare const SIOCDIFADDR: number;

declare const SIOCDRARP: number;

declare const SIOCGARP: number;

declare const SIOCGIFADDR: number;

declare const SIOCGIFBR: number;

declare const SIOCGIFBRDADDR: number;

declare const SIOCGIFCONF: number;

declare const SIOCGIFCOUNT: number;

declare const SIOCGIFDSTADDR: number;

declare const SIOCGIFENCAP: number;

declare const SIOCGIFFLAGS: number;

declare const SIOCGIFHWADDR: number;

declare const SIOCGIFINDEX: number;

declare const SIOCGIFMAP: number;

declare const SIOCGIFMEM: number;

declare const SIOCGIFMETRIC: number;

declare const SIOCGIFMTU: number;

declare const SIOCGIFNAME: number;

declare const SIOCGIFNETMASK: number;

declare const SIOCGIFPFLAGS: number;

declare const SIOCGIFSLAVE: number;

declare const SIOCGIFTXQLEN: number;

declare const SIOCGRARP: number;

declare const SIOCPROTOPRIVATE: number;

declare const SIOCRTMSG: number;

declare const SIOCSARP: number;

declare const SIOCSIFADDR: number;

declare const SIOCSIFBR: number;

declare const SIOCSIFBRDADDR: number;

declare const SIOCSIFDSTADDR: number;

declare const SIOCSIFENCAP: number;

declare const SIOCSIFFLAGS: number;

declare const SIOCSIFHWADDR: number;

declare const SIOCSIFHWBROADCAST: number;

declare const SIOCSIFLINK: number;

declare const SIOCSIFMAP: number;

declare const SIOCSIFMEM: number;

declare const SIOCSIFMETRIC: number;

declare const SIOCSIFMTU: number;

declare const SIOCSIFNAME: number;

declare const SIOCSIFNETMASK: number;

declare const SIOCSIFPFLAGS: number;

declare const SIOCSIFSLAVE: number;

declare const SIOCSIFTXQLEN: number;

declare const SIOCSRARP: number;

declare const SIOGIFINDEX: number;

declare const SI_ASYNCIO: number;

declare const SI_ASYNCNL: number;

declare const SI_DETHREAD: number;

declare const SI_KERNEL: number;

declare const SI_MESGQ: number;

declare const SI_QUEUE: number;

declare const SI_SIGIO: number;

declare const SI_TIMER: number;

declare const SI_TKILL: number;

declare const SI_USER: number;

declare const SOL_AAL: number;

declare const SOL_ALG: number;

declare const SOL_ATM: number;

declare const SOL_BLUETOOTH: number;

declare const SOL_CAIF: number;

declare const SOL_DCCP: number;

declare const SOL_DECNET: number;

declare const SOL_ICMPV6: number;

declare const SOL_IP: number;

declare const SOL_IPV6: number;

declare const SOL_IRDA: number;

declare const SOL_IUCV: number;

declare const SOL_KCM: number;

declare const SOL_LLC: number;

declare const SOL_MCTP: number;

declare const SOL_MPTCP: number;

declare const SOL_NETBEUI: number;

declare const SOL_NETLINK: number;

declare const SOL_NFC: number;

declare const SOL_PACKET: number;

declare const SOL_PNPIPE: number;

declare const SOL_PPPOL2TP: number;

declare const SOL_RAW: number;

declare const SOL_RDS: number;

declare const SOL_RXRPC: number;

declare const SOL_SMC: number;

declare const SOL_TIPC: number;

declare const SOL_TLS: number;

declare const SOL_X25: number;

declare const SOL_XDP: number;

declare const SOMAXCONN: number;

declare const SSIZE_MAX: bigint;

declare const SS_DISABLE: number;

declare const SS_ONSTACK: number;

declare const ST_NOSUID: number;

declare const ST_RDONLY: number;

declare const SYS_NMLN: number;

declare const SYS__sysctl: number;

declare const SYS_accept: number;

declare const SYS_accept4: number;

declare const SYS_access: number;

declare const SYS_acct: number;

declare const SYS_add_key: number;

declare const SYS_adjtimex: number;

declare const SYS_afs_syscall: number;

declare const SYS_alarm: number;

declare const SYS_arch_prctl: number;

declare const SYS_bind: number;

declare const SYS_bpf: number;

declare const SYS_brk: number;

declare const SYS_cachestat: number;

declare const SYS_capget: number;

declare const SYS_capset: number;

declare const SYS_chdir: number;

declare const SYS_chmod: number;

declare const SYS_chown: number;

declare const SYS_chroot: number;

declare const SYS_clock_adjtime: number;

declare const SYS_clock_getres: number;

declare const SYS_clock_gettime: number;

declare const SYS_clock_nanosleep: number;

declare const SYS_clock_settime: number;

declare const SYS_clone: number;

declare const SYS_clone3: number;

declare const SYS_close: number;

declare const SYS_close_range: number;

declare const SYS_connect: number;

declare const SYS_copy_file_range: number;

declare const SYS_creat: number;

declare const SYS_create_module: number;

declare const SYS_delete_module: number;

declare const SYS_dup: number;

declare const SYS_dup2: number;

declare const SYS_dup3: number;

declare const SYS_epoll_create: number;

declare const SYS_epoll_create1: number;

declare const SYS_epoll_ctl: number;

declare const SYS_epoll_ctl_old: number;

declare const SYS_epoll_pwait: number;

declare const SYS_epoll_pwait2: number;

declare const SYS_epoll_wait: number;

declare const SYS_epoll_wait_old: number;

declare const SYS_eventfd: number;

declare const SYS_eventfd2: number;

declare const SYS_execve: number;

declare const SYS_execveat: number;

declare const SYS_exit: number;

declare const SYS_exit_group: number;

declare const SYS_faccessat: number;

declare const SYS_faccessat2: number;

declare const SYS_fadvise64: number;

declare const SYS_fallocate: number;

declare const SYS_fanotify_init: number;

declare const SYS_fanotify_mark: number;

declare const SYS_fchdir: number;

declare const SYS_fchmod: number;

declare const SYS_fchmodat: number;

declare const SYS_fchmodat2: number;

declare const SYS_fchown: number;

declare const SYS_fchownat: number;

declare const SYS_fcntl: number;

declare const SYS_fdatasync: number;

declare const SYS_fgetxattr: number;

declare const SYS_finit_module: number;

declare const SYS_flistxattr: number;

declare const SYS_flock: number;

declare const SYS_fork: number;

declare const SYS_fremovexattr: number;

declare const SYS_fsconfig: number;

declare const SYS_fsetxattr: number;

declare const SYS_fsmount: number;

declare const SYS_fsopen: number;

declare const SYS_fspick: number;

declare const SYS_fstat: number;

declare const SYS_fstatfs: number;

declare const SYS_fsync: number;

declare const SYS_ftruncate: number;

declare const SYS_futex: number;

declare const SYS_futex_requeue: number;

declare const SYS_futex_wait: number;

declare const SYS_futex_waitv: number;

declare const SYS_futex_wake: number;

declare const SYS_futimesat: number;

declare const SYS_get_kernel_syms: number;

declare const SYS_get_mempolicy: number;

declare const SYS_get_robust_list: number;

declare const SYS_get_thread_area: number;

declare const SYS_getcpu: number;

declare const SYS_getcwd: number;

declare const SYS_getdents: number;

declare const SYS_getdents64: number;

declare const SYS_getegid: number;

declare const SYS_geteuid: number;

declare const SYS_getgid: number;

declare const SYS_getgroups: number;

declare const SYS_getitimer: number;

declare const SYS_getpeername: number;

declare const SYS_getpgid: number;

declare const SYS_getpgrp: number;

declare const SYS_getpid: number;

declare const SYS_getpmsg: number;

declare const SYS_getppid: number;

declare const SYS_getpriority: number;

declare const SYS_getrandom: number;

declare const SYS_getresgid: number;

declare const SYS_getresuid: number;

declare const SYS_getrlimit: number;

declare const SYS_getrusage: number;

declare const SYS_getsid: number;

declare const SYS_getsockname: number;

declare const SYS_getsockopt: number;

declare const SYS_gettid: number;

declare const SYS_gettimeofday: number;

declare const SYS_getuid: number;

declare const SYS_getxattr: number;

declare const SYS_init_module: number;

declare const SYS_inotify_add_watch: number;

declare const SYS_inotify_init: number;

declare const SYS_inotify_init1: number;

declare const SYS_inotify_rm_watch: number;

declare const SYS_io_cancel: number;

declare const SYS_io_destroy: number;

declare const SYS_io_getevents: number;

declare const SYS_io_pgetevents: number;

declare const SYS_io_setup: number;

declare const SYS_io_submit: number;

declare const SYS_io_uring_enter: number;

declare const SYS_io_uring_register: number;

declare const SYS_io_uring_setup: number;

declare const SYS_ioctl: number;

declare const SYS_ioperm: number;

declare const SYS_iopl: number;

declare const SYS_ioprio_get: number;

declare const SYS_ioprio_set: number;

declare const SYS_kcmp: number;

declare const SYS_kexec_file_load: number;

declare const SYS_kexec_load: number;

declare const SYS_keyctl: number;

declare const SYS_kill: number;

declare const SYS_landlock_add_rule: number;

declare const SYS_landlock_create_ruleset: number;

declare const SYS_landlock_restrict_self: number;

declare const SYS_lchown: number;

declare const SYS_lgetxattr: number;

declare const SYS_link: number;

declare const SYS_linkat: number;

declare const SYS_listen: number;

declare const SYS_listxattr: number;

declare const SYS_llistxattr: number;

declare const SYS_lookup_dcookie: number;

declare const SYS_lremovexattr: number;

declare const SYS_lseek: number;

declare const SYS_lsetxattr: number;

declare const SYS_lstat: number;

declare const SYS_madvise: number;

declare const SYS_map_shadow_stack: number;

declare const SYS_mbind: number;

declare const SYS_membarrier: number;

declare const SYS_memfd_create: number;

declare const SYS_memfd_secret: number;

declare const SYS_migrate_pages: number;

declare const SYS_mincore: number;

declare const SYS_mkdir: number;

declare const SYS_mkdirat: number;

declare const SYS_mknod: number;

declare const SYS_mknodat: number;

declare const SYS_mlock: number;

declare const SYS_mlock2: number;

declare const SYS_mlockall: number;

declare const SYS_mmap: number;

declare const SYS_modify_ldt: number;

declare const SYS_mount: number;

declare const SYS_mount_setattr: number;

declare const SYS_move_mount: number;

declare const SYS_move_pages: number;

declare const SYS_mprotect: number;

declare const SYS_mq_getsetattr: number;

declare const SYS_mq_notify: number;

declare const SYS_mq_open: number;

declare const SYS_mq_timedreceive: number;

declare const SYS_mq_timedsend: number;

declare const SYS_mq_unlink: number;

declare const SYS_mremap: number;

declare const SYS_msgctl: number;

declare const SYS_msgget: number;

declare const SYS_msgrcv: number;

declare const SYS_msgsnd: number;

declare const SYS_msync: number;

declare const SYS_munlock: number;

declare const SYS_munlockall: number;

declare const SYS_munmap: number;

declare const SYS_name_to_handle_at: number;

declare const SYS_nanosleep: number;

declare const SYS_newfstatat: number;

declare const SYS_nfsservctl: number;

declare const SYS_open: number;

declare const SYS_open_by_handle_at: number;

declare const SYS_open_tree: number;

declare const SYS_openat: number;

declare const SYS_openat2: number;

declare const SYS_pause: number;

declare const SYS_perf_event_open: number;

declare const SYS_personality: number;

declare const SYS_pidfd_getfd: number;

declare const SYS_pidfd_open: number;

declare const SYS_pidfd_send_signal: number;

declare const SYS_pipe: number;

declare const SYS_pipe2: number;

declare const SYS_pivot_root: number;

declare const SYS_pkey_alloc: number;

declare const SYS_pkey_free: number;

declare const SYS_pkey_mprotect: number;

declare const SYS_poll: number;

declare const SYS_ppoll: number;

declare const SYS_prctl: number;

declare const SYS_pread64: number;

declare const SYS_preadv: number;

declare const SYS_preadv2: number;

declare const SYS_prlimit64: number;

declare const SYS_process_madvise: number;

declare const SYS_process_mrelease: number;

declare const SYS_process_vm_readv: number;

declare const SYS_process_vm_writev: number;

declare const SYS_pselect6: number;

declare const SYS_ptrace: number;

declare const SYS_putpmsg: number;

declare const SYS_pwrite64: number;

declare const SYS_pwritev: number;

declare const SYS_pwritev2: number;

declare const SYS_query_module: number;

declare const SYS_quotactl: number;

declare const SYS_quotactl_fd: number;

declare const SYS_read: number;

declare const SYS_readahead: number;

declare const SYS_readlink: number;

declare const SYS_readlinkat: number;

declare const SYS_readv: number;

declare const SYS_reboot: number;

declare const SYS_recvfrom: number;

declare const SYS_recvmmsg: number;

declare const SYS_recvmsg: number;

declare const SYS_remap_file_pages: number;

declare const SYS_removexattr: number;

declare const SYS_rename: number;

declare const SYS_renameat: number;

declare const SYS_renameat2: number;

declare const SYS_request_key: number;

declare const SYS_restart_syscall: number;

declare const SYS_rmdir: number;

declare const SYS_rseq: number;

declare const SYS_rt_sigaction: number;

declare const SYS_rt_sigpending: number;

declare const SYS_rt_sigprocmask: number;

declare const SYS_rt_sigqueueinfo: number;

declare const SYS_rt_sigreturn: number;

declare const SYS_rt_sigsuspend: number;

declare const SYS_rt_sigtimedwait: number;

declare const SYS_rt_tgsigqueueinfo: number;

declare const SYS_sched_get_priority_max: number;

declare const SYS_sched_get_priority_min: number;

declare const SYS_sched_getaffinity: number;

declare const SYS_sched_getattr: number;

declare const SYS_sched_getparam: number;

declare const SYS_sched_getscheduler: number;

declare const SYS_sched_rr_get_interval: number;

declare const SYS_sched_setaffinity: number;

declare const SYS_sched_setattr: number;

declare const SYS_sched_setparam: number;

declare const SYS_sched_setscheduler: number;

declare const SYS_sched_yield: number;

declare const SYS_seccomp: number;

declare const SYS_security: number;

declare const SYS_select: number;

declare const SYS_semctl: number;

declare const SYS_semget: number;

declare const SYS_semop: number;

declare const SYS_semtimedop: number;

declare const SYS_sendfile: number;

declare const SYS_sendmmsg: number;

declare const SYS_sendmsg: number;

declare const SYS_sendto: number;

declare const SYS_set_mempolicy: number;

declare const SYS_set_mempolicy_home_node: number;

declare const SYS_set_robust_list: number;

declare const SYS_set_thread_area: number;

declare const SYS_set_tid_address: number;

declare const SYS_setdomainname: number;

declare const SYS_setfsgid: number;

declare const SYS_setfsuid: number;

declare const SYS_setgid: number;

declare const SYS_setgroups: number;

declare const SYS_sethostname: number;

declare const SYS_setitimer: number;

declare const SYS_setns: number;

declare const SYS_setpgid: number;

declare const SYS_setpriority: number;

declare const SYS_setregid: number;

declare const SYS_setresgid: number;

declare const SYS_setresuid: number;

declare const SYS_setreuid: number;

declare const SYS_setrlimit: number;

declare const SYS_setsid: number;

declare const SYS_setsockopt: number;

declare const SYS_settimeofday: number;

declare const SYS_setuid: number;

declare const SYS_setxattr: number;

declare const SYS_shmat: number;

declare const SYS_shmctl: number;

declare const SYS_shmdt: number;

declare const SYS_shmget: number;

declare const SYS_shutdown: number;

declare const SYS_sigaltstack: number;

declare const SYS_signalfd: number;

declare const SYS_signalfd4: number;

declare const SYS_socket: number;

declare const SYS_socketpair: number;

declare const SYS_splice: number;

declare const SYS_stat: number;

declare const SYS_statfs: number;

declare const SYS_statx: number;

declare const SYS_swapoff: number;

declare const SYS_swapon: number;

declare const SYS_symlink: number;

declare const SYS_symlinkat: number;

declare const SYS_sync: number;

declare const SYS_sync_file_range: number;

declare const SYS_syncfs: number;

declare const SYS_sysfs: number;

declare const SYS_sysinfo: number;

declare const SYS_syslog: number;

declare const SYS_tee: number;

declare const SYS_tgkill: number;

declare const SYS_time: number;

declare const SYS_timer_create: number;

declare const SYS_timer_delete: number;

declare const SYS_timer_getoverrun: number;

declare const SYS_timer_gettime: number;

declare const SYS_timer_settime: number;

declare const SYS_timerfd_create: number;

declare const SYS_timerfd_gettime: number;

declare const SYS_timerfd_settime: number;

declare const SYS_times: number;

declare const SYS_tkill: number;

declare const SYS_truncate: number;

declare const SYS_tuxcall: number;

declare const SYS_umask: number;

declare const SYS_umount2: number;

declare const SYS_uname: number;

declare const SYS_unlink: number;

declare const SYS_unlinkat: number;

declare const SYS_unshare: number;

declare const SYS_uselib: number;

declare const SYS_userfaultfd: number;

declare const SYS_ustat: number;

declare const SYS_utime: number;

declare const SYS_utimensat: number;

declare const SYS_utimes: number;

declare const SYS_vfork: number;

declare const SYS_vhangup: number;

declare const SYS_vmsplice: number;

declare const SYS_vserver: number;

declare const SYS_wait4: number;

declare const SYS_waitid: number;

declare const SYS_write: number;

declare const SYS_writev: number;

declare const S_BLKSIZE: number;

declare const S_IEXEC: number;

declare const S_IFBLK: number;

declare const S_IFCHR: number;

declare const S_IFDIR: number;

declare const S_IFIFO: number;

declare const S_IFLNK: number;

declare const S_IFMT: number;

declare const S_IFREG: number;

declare const S_IFSOCK: number;

declare const S_IREAD: number;

declare const S_IRGRP: number;

declare const S_IROTH: number;

declare const S_IRUSR: number;

declare const S_IRWXG: number;

declare const S_IRWXO: number;

declare const S_IRWXU: number;

declare const S_ISGID: number;

declare const S_ISUID: number;

declare const S_ISVTX: number;

declare const S_IWGRP: number;

declare const S_IWOTH: number;

declare const S_IWRITE: number;

declare const S_IWUSR: number;

declare const S_IXGRP: number;

declare const S_IXOTH: number;

declare const S_IXUSR: number;

declare const TAB0: number;

declare const TAB1: number;

declare const TAB2: number;

declare const TAB3: number;

declare const TABDLY: number;

declare const TCIFLUSH: number;

declare const TCIOFF: number;

declare const TCIOFLUSH: number;

declare const TCION: number;

declare const TCOFLUSH: number;

declare const TCOOFF: number;

declare const TCOON: number;

declare const TCSADRAIN: number;

declare const TCSAFLUSH: number;

declare const TCSANOW: number;

declare const TIMER_ABSTIME: number;

declare const TIOCM_CAR: number;

declare const TIOCM_CD: number;

declare const TIOCM_CTS: number;

declare const TIOCM_DSR: number;

declare const TIOCM_DTR: number;

declare const TIOCM_LE: number;

declare const TIOCM_RI: number;

declare const TIOCM_RNG: number;

declare const TIOCM_RTS: number;

declare const TIOCM_SR: number;

declare const TIOCM_ST: number;

declare const TIOCSER_TEMT: number;

declare const TOSTOP: number;

declare const TTYDEF_CFLAG: number;

declare const TTYDEF_IFLAG: number;

declare const TTYDEF_LFLAG: number;

declare const TTYDEF_OFLAG: number;

declare const TTYDEF_SPEED: number;

declare const TTY_NAME_MAX: number;

declare const UIO_MAXIOV: number;

declare const UMOUNT_NOFOLLOW: number;

declare const USER_PROCESS: number;

declare const UTIME_NOW: number;

declare const UTIME_OMIT: number;

declare const VDISCARD: number;

declare const VEOF: number;

declare const VEOL: number;

declare const VEOL2: number;

declare const VERASE: number;

declare const VINTR: number;

declare const VKILL: number;

declare const VLNEXT: number;

declare const VMIN: number;

declare const VQUIT: number;

declare const VREPRINT: number;

declare const VSTART: number;

declare const VSTOP: number;

declare const VSUSP: number;

declare const VSWTC: number;

declare const VT0: number;

declare const VT1: number;

declare const VTDLY: number;

declare const VTIME: number;

declare const VWERASE: number;

declare const WAIT_ANY: number;

declare const WAIT_MYPGRP: number;

declare const WCONTINUED: number;

declare const WCOREFLAG: number;

declare const WEXITED: number;

declare const WNOHANG: number;

declare const WNOWAIT: number;

declare const WSTOPPED: number;

declare const WUNTRACED: number;

declare const XATTR_CREATE: number;

declare const XATTR_REPLACE: number;

declare const XCASE: number;

declare const XTABS: number;

declare const _BITS_BYTESWAP_H: number;

declare const _BITS_CPU_SET_H: number;

declare const _BITS_ENDIANNESS_H: number;

declare const _BITS_ENDIAN_H: number;

declare const _BITS_ERRNO_H: number;

declare const _BITS_IPCTYPES_H: number;

declare const _BITS_LIBM_SIMD_DECL_STUBS_H: number;

declare const _BITS_LOCALE_H: number;

declare const _BITS_POSIX1_LIM_H: number;

declare const _BITS_POSIX2_LIM_H: number;

declare const _BITS_POSIX_OPT_H: number;

declare const _BITS_PTHREADTYPES_ARCH_H: number;

declare const _BITS_PTHREADTYPES_COMMON_H: number;

declare const _BITS_SCHED_H: number;

declare const _BITS_SETJMP_H: number;

declare const _BITS_SIGACTION_H: number;

declare const _BITS_SIGCONTEXT_H: number;

declare const _BITS_SIGEVENT_CONSTS_H: number;

declare const _BITS_SIGINFO_ARCH_H: number;

declare const _BITS_SIGINFO_CONSTS_H: number;

declare const _BITS_SIGNUM_ARCH_H: number;

declare const _BITS_SIGNUM_GENERIC_H: number;

declare const _BITS_SIGSTACK_H: number;

declare const _BITS_SIGTHREAD_H: number;

declare const _BITS_SOCKADDR_H: number;

declare const _BITS_SS_FLAGS_H: number;

declare const _BITS_STAT_H: number;

declare const _BITS_STDINT_INTN_H: number;

declare const _BITS_STDINT_LEAST_H: number;

declare const _BITS_STDINT_UINTN_H: number;

declare const _BITS_STDIO_LIM_H: number;

declare const _BITS_STRUCT_STAT_H: number;

declare const _BITS_SYSLOG_PATH_H: number;

declare const _BITS_TIME64_H: number;

declare const _BITS_TIME_H: number;

declare const _BITS_TYPESIZES_H: number;

declare const _BITS_TYPES_H: number;

declare const _BITS_TYPES_LOCALE_T_H: number;

declare const _BITS_TYPES_STRUCT_SCHED_PARAM: number;

declare const _BITS_TYPES___LOCALE_T_H: number;

declare const _BITS_UINTN_IDENTITY_H: number;

declare const _BITS_UIO_LIM_H: number;

declare const _BITS_WCHAR_H: number;

declare const _BITS_WCTYPE_WCHAR_H: number;

declare const _CS_GNU_LIBC_VERSION: number;

declare const _CS_GNU_LIBPTHREAD_VERSION: number;

declare const _CS_LFS64_CFLAGS: number;

declare const _CS_LFS64_LDFLAGS: number;

declare const _CS_LFS64_LIBS: number;

declare const _CS_LFS64_LINTFLAGS: number;

declare const _CS_LFS_CFLAGS: number;

declare const _CS_LFS_LDFLAGS: number;

declare const _CS_LFS_LIBS: number;

declare const _CS_LFS_LINTFLAGS: number;

declare const _CS_PATH: number;

declare const _CS_POSIX_V5_WIDTH_RESTRICTED_ENVS: number;

declare const _CS_POSIX_V6_ILP32_OFF32_CFLAGS: number;

declare const _CS_POSIX_V6_ILP32_OFF32_LDFLAGS: number;

declare const _CS_POSIX_V6_ILP32_OFF32_LIBS: number;

declare const _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS: number;

declare const _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS: number;

declare const _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS: number;

declare const _CS_POSIX_V6_ILP32_OFFBIG_LIBS: number;

declare const _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS: number;

declare const _CS_POSIX_V6_LP64_OFF64_CFLAGS: number;

declare const _CS_POSIX_V6_LP64_OFF64_LDFLAGS: number;

declare const _CS_POSIX_V6_LP64_OFF64_LIBS: number;

declare const _CS_POSIX_V6_LP64_OFF64_LINTFLAGS: number;

declare const _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS: number;

declare const _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS: number;

declare const _CS_POSIX_V6_LPBIG_OFFBIG_LIBS: number;

declare const _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS: number;

declare const _CS_POSIX_V6_WIDTH_RESTRICTED_ENVS: number;

declare const _CS_POSIX_V7_ILP32_OFF32_CFLAGS: number;

declare const _CS_POSIX_V7_ILP32_OFF32_LDFLAGS: number;

declare const _CS_POSIX_V7_ILP32_OFF32_LIBS: number;

declare const _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS: number;

declare const _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS: number;

declare const _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS: number;

declare const _CS_POSIX_V7_ILP32_OFFBIG_LIBS: number;

declare const _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS: number;

declare const _CS_POSIX_V7_LP64_OFF64_CFLAGS: number;

declare const _CS_POSIX_V7_LP64_OFF64_LDFLAGS: number;

declare const _CS_POSIX_V7_LP64_OFF64_LIBS: number;

declare const _CS_POSIX_V7_LP64_OFF64_LINTFLAGS: number;

declare const _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS: number;

declare const _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS: number;

declare const _CS_POSIX_V7_LPBIG_OFFBIG_LIBS: number;

declare const _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS: number;

declare const _CS_POSIX_V7_WIDTH_RESTRICTED_ENVS: number;

declare const _CS_V5_WIDTH_RESTRICTED_ENVS: number;

declare const _CS_V6_ENV: number;

declare const _CS_V6_WIDTH_RESTRICTED_ENVS: number;

declare const _CS_V7_ENV: number;

declare const _CS_V7_WIDTH_RESTRICTED_ENVS: number;

declare const _CS_XBS5_ILP32_OFF32_CFLAGS: number;

declare const _CS_XBS5_ILP32_OFF32_LDFLAGS: number;

declare const _CS_XBS5_ILP32_OFF32_LIBS: number;

declare const _CS_XBS5_ILP32_OFF32_LINTFLAGS: number;

declare const _CS_XBS5_ILP32_OFFBIG_CFLAGS: number;

declare const _CS_XBS5_ILP32_OFFBIG_LDFLAGS: number;

declare const _CS_XBS5_ILP32_OFFBIG_LIBS: number;

declare const _CS_XBS5_ILP32_OFFBIG_LINTFLAGS: number;

declare const _CS_XBS5_LP64_OFF64_CFLAGS: number;

declare const _CS_XBS5_LP64_OFF64_LDFLAGS: number;

declare const _CS_XBS5_LP64_OFF64_LIBS: number;

declare const _CS_XBS5_LP64_OFF64_LINTFLAGS: number;

declare const _CS_XBS5_LPBIG_OFFBIG_CFLAGS: number;

declare const _CS_XBS5_LPBIG_OFFBIG_LDFLAGS: number;

declare const _CS_XBS5_LPBIG_OFFBIG_LIBS: number;

declare const _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS: number;

declare const _DIRENT_MATCHES_DIRENT64: number;

declare const _GETOPT_CORE_H: number;

declare const _GETOPT_EXT_H: number;

declare const _GETOPT_POSIX_H: number;

declare const _HAVE_STRUCT_TERMIOS_C_ISPEED: number;

declare const _HAVE_STRUCT_TERMIOS_C_OSPEED: number;

declare const _IO_EOF_SEEN: number;

declare const _IO_ERR_SEEN: number;

declare const _IO_USER_LOCK: number;

interface _IO_codecvt {
}
declare var _IO_codecvt: interop.StructType<_IO_codecvt>;

interface _IO_marker {
}
declare var _IO_marker: interop.StructType<_IO_marker>;

interface _IO_wide_data {
}
declare var _IO_wide_data: interop.StructType<_IO_wide_data>;

declare const _ISwalnum: number;

declare const _ISwalpha: number;

declare const _ISwblank: number;

declare const _ISwcntrl: number;

declare const _ISwdigit: number;

declare const _ISwgraph: number;

declare const _ISwlower: number;

declare const _ISwprint: number;

declare const _ISwpunct: number;

declare const _ISwspace: number;

declare const _ISwupper: number;

declare const _ISwxdigit: number;

declare const _LFS64_ASYNCHRONOUS_IO: number;

declare const _LFS64_LARGEFILE: number;

declare const _LFS64_STDIO: number;

declare const _LFS_ASYNCHRONOUS_IO: number;

declare const _LFS_LARGEFILE: number;

declare const _NSIG: number;

declare const _PATH_LOG: string;

declare const _PC_2_SYMLINKS: number;

declare const _PC_ALLOC_SIZE_MIN: number;

declare const _PC_ASYNC_IO: number;

declare const _PC_CHOWN_RESTRICTED: number;

declare const _PC_FILESIZEBITS: number;

declare const _PC_LINK_MAX: number;

declare const _PC_MAX_CANON: number;

declare const _PC_MAX_INPUT: number;

declare const _PC_NAME_MAX: number;

declare const _PC_NO_TRUNC: number;

declare const _PC_PATH_MAX: number;

declare const _PC_PIPE_BUF: number;

declare const _PC_PRIO_IO: number;

declare const _PC_REC_INCR_XFER_SIZE: number;

declare const _PC_REC_MAX_XFER_SIZE: number;

declare const _PC_REC_MIN_XFER_SIZE: number;

declare const _PC_REC_XFER_ALIGN: number;

declare const _PC_SOCK_MAXBUF: number;

declare const _PC_SYMLINK_MAX: number;

declare const _PC_SYNC_IO: number;

declare const _PC_VDISABLE: number;

declare const _POSIX2_BC_BASE_MAX: number;

declare const _POSIX2_BC_DIM_MAX: number;

declare const _POSIX2_BC_SCALE_MAX: number;

declare const _POSIX2_BC_STRING_MAX: number;

declare const _POSIX2_CHARCLASS_NAME_MAX: number;

declare const _POSIX2_CHAR_TERM: number;

declare const _POSIX2_COLL_WEIGHTS_MAX: number;

declare const _POSIX2_EXPR_NEST_MAX: number;

declare const _POSIX2_LINE_MAX: number;

declare const _POSIX2_RE_DUP_MAX: number;

declare const _POSIX_ADVISORY_INFO: number;

declare const _POSIX_AIO_LISTIO_MAX: number;

declare const _POSIX_AIO_MAX: number;

declare const _POSIX_ARG_MAX: number;

declare const _POSIX_ASYNCHRONOUS_IO: number;

declare const _POSIX_ASYNC_IO: number;

declare const _POSIX_BARRIERS: number;

declare const _POSIX_CHILD_MAX: number;

declare const _POSIX_CHOWN_RESTRICTED: number;

declare const _POSIX_CLOCKRES_MIN: number;

declare const _POSIX_CLOCK_SELECTION: number;

declare const _POSIX_CPUTIME: number;

declare const _POSIX_DELAYTIMER_MAX: number;

declare const _POSIX_FSYNC: number;

declare const _POSIX_HOST_NAME_MAX: number;

declare const _POSIX_IPV6: number;

declare const _POSIX_JOB_CONTROL: number;

declare const _POSIX_LINK_MAX: number;

declare const _POSIX_LOGIN_NAME_MAX: number;

declare const _POSIX_MAPPED_FILES: number;

declare const _POSIX_MAX_CANON: number;

declare const _POSIX_MAX_INPUT: number;

declare const _POSIX_MEMLOCK: number;

declare const _POSIX_MEMLOCK_RANGE: number;

declare const _POSIX_MEMORY_PROTECTION: number;

declare const _POSIX_MESSAGE_PASSING: number;

declare const _POSIX_MONOTONIC_CLOCK: number;

declare const _POSIX_MQ_OPEN_MAX: number;

declare const _POSIX_MQ_PRIO_MAX: number;

declare const _POSIX_NAME_MAX: number;

declare const _POSIX_NGROUPS_MAX: number;

declare const _POSIX_NO_TRUNC: number;

declare const _POSIX_OPEN_MAX: number;

declare const _POSIX_PATH_MAX: number;

declare const _POSIX_PIPE_BUF: number;

declare const _POSIX_PRIORITIZED_IO: number;

declare const _POSIX_PRIORITY_SCHEDULING: number;

declare const _POSIX_RAW_SOCKETS: number;

declare const _POSIX_READER_WRITER_LOCKS: number;

declare const _POSIX_REALTIME_SIGNALS: number;

declare const _POSIX_REENTRANT_FUNCTIONS: number;

declare const _POSIX_REGEXP: number;

declare const _POSIX_RE_DUP_MAX: number;

declare const _POSIX_RTSIG_MAX: number;

declare const _POSIX_SAVED_IDS: number;

declare const _POSIX_SEMAPHORES: number;

declare const _POSIX_SEM_NSEMS_MAX: number;

declare const _POSIX_SEM_VALUE_MAX: number;

declare const _POSIX_SHARED_MEMORY_OBJECTS: number;

declare const _POSIX_SHELL: number;

declare const _POSIX_SIGQUEUE_MAX: number;

declare const _POSIX_SPAWN: number;

declare const _POSIX_SPIN_LOCKS: number;

declare const _POSIX_SPORADIC_SERVER: number;

declare const _POSIX_SSIZE_MAX: number;

declare const _POSIX_STREAM_MAX: number;

declare const _POSIX_SYMLINK_MAX: number;

declare const _POSIX_SYMLOOP_MAX: number;

declare const _POSIX_SYNCHRONIZED_IO: number;

declare const _POSIX_THREADS: number;

declare const _POSIX_THREAD_ATTR_STACKADDR: number;

declare const _POSIX_THREAD_ATTR_STACKSIZE: number;

declare const _POSIX_THREAD_CPUTIME: number;

declare const _POSIX_THREAD_DESTRUCTOR_ITERATIONS: number;

declare const _POSIX_THREAD_KEYS_MAX: number;

declare const _POSIX_THREAD_PRIORITY_SCHEDULING: number;

declare const _POSIX_THREAD_PRIO_INHERIT: number;

declare const _POSIX_THREAD_PRIO_PROTECT: number;

declare const _POSIX_THREAD_PROCESS_SHARED: number;

declare const _POSIX_THREAD_ROBUST_PRIO_INHERIT: number;

declare const _POSIX_THREAD_ROBUST_PRIO_PROTECT: number;

declare const _POSIX_THREAD_SAFE_FUNCTIONS: number;

declare const _POSIX_THREAD_SPORADIC_SERVER: number;

declare const _POSIX_THREAD_THREADS_MAX: number;

declare const _POSIX_TIMEOUTS: number;

declare const _POSIX_TIMERS: number;

declare const _POSIX_TIMER_MAX: number;

declare const _POSIX_TRACE: number;

declare const _POSIX_TRACE_EVENT_FILTER: number;

declare const _POSIX_TRACE_INHERIT: number;

declare const _POSIX_TRACE_LOG: number;

declare const _POSIX_TTY_NAME_MAX: number;

declare const _POSIX_TYPED_MEMORY_OBJECTS: number;

declare const _POSIX_TZNAME_MAX: number;

declare const _POSIX_V6_LP64_OFF64: number;

declare const _POSIX_V6_LPBIG_OFFBIG: number;

declare const _POSIX_V7_LP64_OFF64: number;

declare const _POSIX_V7_LPBIG_OFFBIG: number;

declare const _POSIX_VDISABLE: number;

declare const _SC_2_CHAR_TERM: number;

declare const _SC_2_C_BIND: number;

declare const _SC_2_C_DEV: number;

declare const _SC_2_C_VERSION: number;

declare const _SC_2_FORT_DEV: number;

declare const _SC_2_FORT_RUN: number;

declare const _SC_2_LOCALEDEF: number;

declare const _SC_2_PBS: number;

declare const _SC_2_PBS_ACCOUNTING: number;

declare const _SC_2_PBS_CHECKPOINT: number;

declare const _SC_2_PBS_LOCATE: number;

declare const _SC_2_PBS_MESSAGE: number;

declare const _SC_2_PBS_TRACK: number;

declare const _SC_2_SW_DEV: number;

declare const _SC_2_UPE: number;

declare const _SC_2_VERSION: number;

declare const _SC_ADVISORY_INFO: number;

declare const _SC_AIO_LISTIO_MAX: number;

declare const _SC_AIO_MAX: number;

declare const _SC_AIO_PRIO_DELTA_MAX: number;

declare const _SC_ARG_MAX: number;

declare const _SC_ASYNCHRONOUS_IO: number;

declare const _SC_ATEXIT_MAX: number;

declare const _SC_AVPHYS_PAGES: number;

declare const _SC_BARRIERS: number;

declare const _SC_BASE: number;

declare const _SC_BC_BASE_MAX: number;

declare const _SC_BC_DIM_MAX: number;

declare const _SC_BC_SCALE_MAX: number;

declare const _SC_BC_STRING_MAX: number;

declare const _SC_CHARCLASS_NAME_MAX: number;

declare const _SC_CHAR_BIT: number;

declare const _SC_CHAR_MAX: number;

declare const _SC_CHAR_MIN: number;

declare const _SC_CHILD_MAX: number;

declare const _SC_CLK_TCK: number;

declare const _SC_CLOCK_SELECTION: number;

declare const _SC_COLL_WEIGHTS_MAX: number;

declare const _SC_CPUTIME: number;

declare const _SC_C_LANG_SUPPORT: number;

declare const _SC_C_LANG_SUPPORT_R: number;

declare const _SC_DELAYTIMER_MAX: number;

declare const _SC_DEVICE_IO: number;

declare const _SC_DEVICE_SPECIFIC: number;

declare const _SC_DEVICE_SPECIFIC_R: number;

declare const _SC_EQUIV_CLASS_MAX: number;

declare const _SC_EXPR_NEST_MAX: number;

declare const _SC_FD_MGMT: number;

declare const _SC_FIFO: number;

declare const _SC_FILE_ATTRIBUTES: number;

declare const _SC_FILE_LOCKING: number;

declare const _SC_FILE_SYSTEM: number;

declare const _SC_FSYNC: number;

declare const _SC_GETGR_R_SIZE_MAX: number;

declare const _SC_GETPW_R_SIZE_MAX: number;

declare const _SC_HOST_NAME_MAX: number;

declare const _SC_INT_MAX: number;

declare const _SC_INT_MIN: number;

declare const _SC_IOV_MAX: number;

declare const _SC_IPV6: number;

declare const _SC_JOB_CONTROL: number;

declare const _SC_LEVEL1_DCACHE_ASSOC: number;

declare const _SC_LEVEL1_DCACHE_LINESIZE: number;

declare const _SC_LEVEL1_DCACHE_SIZE: number;

declare const _SC_LEVEL1_ICACHE_ASSOC: number;

declare const _SC_LEVEL1_ICACHE_LINESIZE: number;

declare const _SC_LEVEL1_ICACHE_SIZE: number;

declare const _SC_LEVEL2_CACHE_ASSOC: number;

declare const _SC_LEVEL2_CACHE_LINESIZE: number;

declare const _SC_LEVEL2_CACHE_SIZE: number;

declare const _SC_LEVEL3_CACHE_ASSOC: number;

declare const _SC_LEVEL3_CACHE_LINESIZE: number;

declare const _SC_LEVEL3_CACHE_SIZE: number;

declare const _SC_LEVEL4_CACHE_ASSOC: number;

declare const _SC_LEVEL4_CACHE_LINESIZE: number;

declare const _SC_LEVEL4_CACHE_SIZE: number;

declare const _SC_LINE_MAX: number;

declare const _SC_LOGIN_NAME_MAX: number;

declare const _SC_LONG_BIT: number;

declare const _SC_MAPPED_FILES: number;

declare const _SC_MB_LEN_MAX: number;

declare const _SC_MEMLOCK: number;

declare const _SC_MEMLOCK_RANGE: number;

declare const _SC_MEMORY_PROTECTION: number;

declare const _SC_MESSAGE_PASSING: number;

declare const _SC_MINSIGSTKSZ: number;

declare const _SC_MONOTONIC_CLOCK: number;

declare const _SC_MQ_OPEN_MAX: number;

declare const _SC_MQ_PRIO_MAX: number;

declare const _SC_MULTI_PROCESS: number;

declare const _SC_NETWORKING: number;

declare const _SC_NGROUPS_MAX: number;

declare const _SC_NL_ARGMAX: number;

declare const _SC_NL_LANGMAX: number;

declare const _SC_NL_MSGMAX: number;

declare const _SC_NL_NMAX: number;

declare const _SC_NL_SETMAX: number;

declare const _SC_NL_TEXTMAX: number;

declare const _SC_NPROCESSORS_CONF: number;

declare const _SC_NPROCESSORS_ONLN: number;

declare const _SC_NZERO: number;

declare const _SC_OPEN_MAX: number;

declare const _SC_PAGESIZE: number;

declare const _SC_PAGE_SIZE: number;

declare const _SC_PASS_MAX: number;

declare const _SC_PHYS_PAGES: number;

declare const _SC_PII: number;

declare const _SC_PII_INTERNET: number;

declare const _SC_PII_INTERNET_DGRAM: number;

declare const _SC_PII_INTERNET_STREAM: number;

declare const _SC_PII_OSI: number;

declare const _SC_PII_OSI_CLTS: number;

declare const _SC_PII_OSI_COTS: number;

declare const _SC_PII_OSI_M: number;

declare const _SC_PII_SOCKET: number;

declare const _SC_PII_XTI: number;

declare const _SC_PIPE: number;

declare const _SC_POLL: number;

declare const _SC_PRIORITIZED_IO: number;

declare const _SC_PRIORITY_SCHEDULING: number;

declare const _SC_RAW_SOCKETS: number;

declare const _SC_READER_WRITER_LOCKS: number;

declare const _SC_REALTIME_SIGNALS: number;

declare const _SC_REGEXP: number;

declare const _SC_REGEX_VERSION: number;

declare const _SC_RE_DUP_MAX: number;

declare const _SC_RTSIG_MAX: number;

declare const _SC_SAVED_IDS: number;

declare const _SC_SCHAR_MAX: number;

declare const _SC_SCHAR_MIN: number;

declare const _SC_SELECT: number;

declare const _SC_SEMAPHORES: number;

declare const _SC_SEM_NSEMS_MAX: number;

declare const _SC_SEM_VALUE_MAX: number;

declare const _SC_SHARED_MEMORY_OBJECTS: number;

declare const _SC_SHELL: number;

declare const _SC_SHRT_MAX: number;

declare const _SC_SHRT_MIN: number;

declare const _SC_SIGNALS: number;

declare const _SC_SIGQUEUE_MAX: number;

declare const _SC_SIGSTKSZ: number;

declare const _SC_SINGLE_PROCESS: number;

declare const _SC_SPAWN: number;

declare const _SC_SPIN_LOCKS: number;

declare const _SC_SPORADIC_SERVER: number;

declare const _SC_SSIZE_MAX: number;

declare const _SC_SS_REPL_MAX: number;

declare const _SC_STREAMS: number;

declare const _SC_STREAM_MAX: number;

declare const _SC_SYMLOOP_MAX: number;

declare const _SC_SYNCHRONIZED_IO: number;

declare const _SC_SYSTEM_DATABASE: number;

declare const _SC_SYSTEM_DATABASE_R: number;

declare const _SC_THREADS: number;

declare const _SC_THREAD_ATTR_STACKADDR: number;

declare const _SC_THREAD_ATTR_STACKSIZE: number;

declare const _SC_THREAD_CPUTIME: number;

declare const _SC_THREAD_DESTRUCTOR_ITERATIONS: number;

declare const _SC_THREAD_KEYS_MAX: number;

declare const _SC_THREAD_PRIORITY_SCHEDULING: number;

declare const _SC_THREAD_PRIO_INHERIT: number;

declare const _SC_THREAD_PRIO_PROTECT: number;

declare const _SC_THREAD_PROCESS_SHARED: number;

declare const _SC_THREAD_ROBUST_PRIO_INHERIT: number;

declare const _SC_THREAD_ROBUST_PRIO_PROTECT: number;

declare const _SC_THREAD_SAFE_FUNCTIONS: number;

declare const _SC_THREAD_SPORADIC_SERVER: number;

declare const _SC_THREAD_STACK_MIN: number;

declare const _SC_THREAD_THREADS_MAX: number;

declare const _SC_TIMEOUTS: number;

declare const _SC_TIMERS: number;

declare const _SC_TIMER_MAX: number;

declare const _SC_TRACE: number;

declare const _SC_TRACE_EVENT_FILTER: number;

declare const _SC_TRACE_EVENT_NAME_MAX: number;

declare const _SC_TRACE_INHERIT: number;

declare const _SC_TRACE_LOG: number;

declare const _SC_TRACE_NAME_MAX: number;

declare const _SC_TRACE_SYS_MAX: number;

declare const _SC_TRACE_USER_EVENT_MAX: number;

declare const _SC_TTY_NAME_MAX: number;

declare const _SC_TYPED_MEMORY_OBJECTS: number;

declare const _SC_TZNAME_MAX: number;

declare const _SC_T_IOV_MAX: number;

declare const _SC_UCHAR_MAX: number;

declare const _SC_UINT_MAX: number;

declare const _SC_UIO_MAXIOV: number;

declare const _SC_ULONG_MAX: number;

declare const _SC_USER_GROUPS: number;

declare const _SC_USER_GROUPS_R: number;

declare const _SC_USHRT_MAX: number;

declare const _SC_V6_ILP32_OFF32: number;

declare const _SC_V6_ILP32_OFFBIG: number;

declare const _SC_V6_LP64_OFF64: number;

declare const _SC_V6_LPBIG_OFFBIG: number;

declare const _SC_V7_ILP32_OFF32: number;

declare const _SC_V7_ILP32_OFFBIG: number;

declare const _SC_V7_LP64_OFF64: number;

declare const _SC_V7_LPBIG_OFFBIG: number;

declare const _SC_VERSION: number;

declare const _SC_WORD_BIT: number;

declare const _SC_XBS5_ILP32_OFF32: number;

declare const _SC_XBS5_ILP32_OFFBIG: number;

declare const _SC_XBS5_LP64_OFF64: number;

declare const _SC_XBS5_LPBIG_OFFBIG: number;

declare const _SC_XOPEN_CRYPT: number;

declare const _SC_XOPEN_ENH_I18N: number;

declare const _SC_XOPEN_LEGACY: number;

declare const _SC_XOPEN_REALTIME: number;

declare const _SC_XOPEN_REALTIME_THREADS: number;

declare const _SC_XOPEN_SHM: number;

declare const _SC_XOPEN_STREAMS: number;

declare const _SC_XOPEN_UNIX: number;

declare const _SC_XOPEN_VERSION: number;

declare const _SC_XOPEN_XCU_VERSION: number;

declare const _SC_XOPEN_XPG2: number;

declare const _SC_XOPEN_XPG3: number;

declare const _SC_XOPEN_XPG4: number;

declare const _SEM_SEMUN_UNDEFINED: number;

declare const _SIGSET_NWORDS: number;

declare const _SS_PADSIZE: number;

declare const _SS_SIZE: number;

declare const _STRUCT_TIMESPEC: number;

declare const _SYSCALL_H: number;

declare const _SYS_CDEFS_H: number;

declare const _SYS_FILE_H: number;

declare const _SYS_IOCTL_H: number;

declare const _SYS_IPC_H: number;

declare const _SYS_MMAN_H: number;

declare const _SYS_MOUNT_H: number;

declare const _SYS_PARAM_H: number;

declare const _SYS_POLL_H: number;

declare const _SYS_QUOTA_H: number;

declare const _SYS_RESOURCE_H: number;

declare const _SYS_SELECT_H: number;

declare const _SYS_SEM_H: number;

declare const _SYS_SHM_H: number;

declare const _SYS_SOCKET_H: number;

declare const _SYS_STATVFS_H: number;

declare const _SYS_STAT_H: number;

declare const _SYS_SYSLOG_H: number;

declare const _SYS_TIMEB_H: number;

declare const _SYS_TIMES_H: number;

declare const _SYS_TIME_H: number;

declare const _SYS_TYPES_H: number;

declare const _SYS_UCONTEXT_H: number;

declare const _SYS_UIO_H: number;

declare const _SYS_UN_H: number;

declare const _SYS_UTSNAME_H: number;

declare const _SYS_WAIT_H: number;

declare const _SYS_XATTR_H: number;

declare const _THREAD_MUTEX_INTERNAL_H: number;

declare const _THREAD_SHARED_TYPES_H: number;

declare const _UTSNAME_DOMAIN_LENGTH: number;

declare const _UTSNAME_LENGTH: number;

declare const _UTSNAME_MACHINE_LENGTH: number;

declare const _UTSNAME_NODENAME_LENGTH: number;

declare const _UTSNAME_RELEASE_LENGTH: number;

declare const _UTSNAME_SYSNAME_LENGTH: number;

declare const _UTSNAME_VERSION_LENGTH: number;

declare const _WINT_T: number;

declare const _XBS5_LP64_OFF64: number;

declare const _XBS5_LPBIG_OFFBIG: number;

declare const _XOPEN_REALTIME: number;

declare const _XOPEN_REALTIME_THREADS: number;

declare const _XOPEN_SHM: number;

declare const __FE_DENORM: number;

declare const __ISwalnum: number;

declare const __ISwalpha: number;

declare const __ISwblank: number;

declare const __ISwcntrl: number;

declare const __ISwdigit: number;

declare const __ISwgraph: number;

declare const __ISwlower: number;

declare const __ISwprint: number;

declare const __ISwpunct: number;

declare const __ISwspace: number;

declare const __ISwupper: number;

declare const __ISwxdigit: number;

declare function __acos(__x: number): number;

declare function __acosf(__x: number): number;

declare function __acosh(__x: number): number;

declare function __acoshf(__x: number): number;

declare function __acoshl(__x: number): number;

declare function __acosl(__x: number): number;

declare function __asin(__x: number): number;

declare function __asinf(__x: number): number;

declare function __asinh(__x: number): number;

declare function __asinhf(__x: number): number;

declare function __asinhl(__x: number): number;

declare function __asinl(__x: number): number;

declare function __atan(__x: number): number;

declare function __atan2(__y: number, __x: number): number;

declare function __atan2f(__y: number, __x: number): number;

declare function __atan2l(__y: number, __x: number): number;

declare function __atanf(__x: number): number;

declare function __atanh(__x: number): number;

declare function __atanhf(__x: number): number;

declare function __atanhl(__x: number): number;

declare function __atanl(__x: number): number;

interface __atomic_wide_counter {
	__value64: number;
	__value32: { __low: number; __high: number; };
}


declare function __cbrt(__x: number): number;

declare function __cbrtf(__x: number): number;

declare function __cbrtl(__x: number): number;

declare function __ceil(__x: number): number;

declare function __ceilf(__x: number): number;

declare function __ceill(__x: number): number;

declare function __cmsg_nxthdr(__mhdr: interop.Pointer | interop.Reference<msghdr> | ArrayBufferLike | ArrayBufferView | null, __cmsg: interop.Pointer | interop.Reference<cmsghdr> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<cmsghdr> | null;

declare function __copysign(__x: number, __y: number): number;

declare function __copysignf(__x: number, __y: number): number;

declare function __copysignl(__x: number, __y: number): number;

declare function __cos(__x: number): number;

declare function __cosf(__x: number): number;

declare function __cosh(__x: number): number;

declare function __coshf(__x: number): number;

declare function __coshl(__x: number): number;

declare function __cosl(__x: number): number;

declare function __drem(__x: number, __y: number): number;

declare function __dremf(__x: number, __y: number): number;

declare function __dreml(__x: number, __y: number): number;

declare function __erf(p1: number): number;

declare function __erfc(p1: number): number;

declare function __erfcf(p1: number): number;

declare function __erfcl(p1: number): number;

declare function __erff(p1: number): number;

declare function __erfl(p1: number): number;

interface __exit_status {
	__e_termination: number;
	__e_exit: number;
}
declare var __exit_status: interop.StructType<__exit_status>;

declare function __exp(__x: number): number;

declare function __exp2(__x: number): number;

declare function __exp2f(__x: number): number;

declare function __exp2l(__x: number): number;

declare function __expf(__x: number): number;

declare function __expl(__x: number): number;

declare function __expm1(__x: number): number;

declare function __expm1f(__x: number): number;

declare function __expm1l(__x: number): number;

declare function __fabs(__x: number): number;

declare function __fabsf(__x: number): number;

declare function __fabsl(__x: number): number;

declare function __fdim(__x: number, __y: number): number;

declare function __fdimf(__x: number, __y: number): number;

declare function __fdiml(__x: number, __y: number): number;

declare function __finite(__value: number): number;

declare function __finitef(__value: number): number;

declare function __finitel(__value: number): number;

declare function __floor(__x: number): number;

declare function __floorf(__x: number): number;

declare function __floorl(__x: number): number;

declare function __fma(__x: number, __y: number, __z: number): number;

declare function __fmaf(__x: number, __y: number, __z: number): number;

declare function __fmal(__x: number, __y: number, __z: number): number;

declare function __fmax(__x: number, __y: number): number;

declare function __fmaxf(__x: number, __y: number): number;

declare function __fmaxl(__x: number, __y: number): number;

declare function __fmin(__x: number, __y: number): number;

declare function __fminf(__x: number, __y: number): number;

declare function __fminl(__x: number, __y: number): number;

declare function __fmod(__x: number, __y: number): number;

declare function __fmodf(__x: number, __y: number): number;

declare function __fmodl(__x: number, __y: number): number;

declare function __fpclassify(__value: number): number;

declare function __fpclassifyf(__value: number): number;

declare function __fpclassifyl(__value: number): number;

interface __fpos64_t {
	__pos: number;
	__state: __mbstate_t;
}
declare var __fpos64_t: interop.StructType<__fpos64_t>;

interface __fpos_t {
	__pos: number;
	__state: __mbstate_t;
}
declare var __fpos_t: interop.StructType<__fpos_t>;

declare function __frexp(__x: number, __exponent: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __frexpf(__x: number, __exponent: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __frexpl(__x: number, __exponent: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

interface __fsid_t {
	__val: interop.Reference<number>;
}
declare var __fsid_t: interop.StructType<__fsid_t>;

declare function __gamma(p1: number): number;

declare function __gammaf(p1: number): number;

declare function __gammal(p1: number): number;

declare function __getpagesize(): number;

declare function __hypot(__x: number, __y: number): number;

declare function __hypotf(__x: number, __y: number): number;

declare function __hypotl(__x: number, __y: number): number;

declare function __ilogb(__x: number): number;

declare function __ilogbf(__x: number): number;

declare function __ilogbl(__x: number): number;

declare function __iseqsig(__x: number, __y: number): number;

declare function __iseqsigf(__x: number, __y: number): number;

declare function __iseqsigl(__x: number, __y: number): number;

declare function __isinf(__value: number): number;

declare function __isinff(__value: number): number;

declare function __isinfl(__value: number): number;

declare function __isnan(__value: number): number;

declare function __isnanf(__value: number): number;

declare function __isnanl(__value: number): number;

declare function __issignaling(__value: number): number;

declare function __issignalingf(__value: number): number;

declare function __issignalingl(__value: number): number;

declare const enum __itimer_which {

	REAL = 0,

	VIRTUAL = 1,

	PROF = 2
}

declare function __j0(p1: number): number;

declare function __j0f(p1: number): number;

declare function __j0l(p1: number): number;

declare function __j1(p1: number): number;

declare function __j1f(p1: number): number;

declare function __j1l(p1: number): number;

interface __jmp_buf_tag {
	__jmpbuf: interop.Reference<number>;
	__mask_was_saved: number;
	__saved_mask: __sigset_t;
}
declare var __jmp_buf_tag: interop.StructType<__jmp_buf_tag>;

declare function __jn(p1: number, p2: number): number;

declare function __jnf(p1: number, p2: number): number;

declare function __jnl(p1: number, p2: number): number;

declare function __ldexp(__x: number, __exponent: number): number;

declare function __ldexpf(__x: number, __exponent: number): number;

declare function __ldexpl(__x: number, __exponent: number): number;

declare function __lgamma(p1: number): number;

declare function __lgamma_r(p1: number, __signgamp: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __lgammaf(p1: number): number;

declare function __lgammaf_r(p1: number, __signgamp: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __lgammal(p1: number): number;

declare function __lgammal_r(p1: number, __signgamp: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __llrint(__x: number): number;

declare function __llrintf(__x: number): number;

declare function __llrintl(__x: number): number;

declare function __llround(__x: number): number;

declare function __llroundf(__x: number): number;

declare function __llroundl(__x: number): number;

interface __locale_data {
}
declare var __locale_data: interop.StructType<__locale_data>;

interface __locale_struct {
	__locales: interop.Reference<interop.Pointer | interop.Reference<__locale_data> | null>;
	__ctype_b: interop.Pointer | interop.Reference<number> | null;
	__ctype_tolower: interop.Pointer | interop.Reference<number> | null;
	__ctype_toupper: interop.Pointer | interop.Reference<number> | null;
	__names: interop.Reference<string | null>;
}
declare var __locale_struct: interop.StructType<__locale_struct>;

declare function __log(__x: number): number;

declare function __log10(__x: number): number;

declare function __log10f(__x: number): number;

declare function __log10l(__x: number): number;

declare function __log1p(__x: number): number;

declare function __log1pf(__x: number): number;

declare function __log1pl(__x: number): number;

declare function __log2(__x: number): number;

declare function __log2f(__x: number): number;

declare function __log2l(__x: number): number;

declare function __logb(__x: number): number;

declare function __logbf(__x: number): number;

declare function __logbl(__x: number): number;

declare function __logf(__x: number): number;

declare function __logl(__x: number): number;

declare function __lrint(__x: number): number;

declare function __lrintf(__x: number): number;

declare function __lrintl(__x: number): number;

declare function __lround(__x: number): number;

declare function __lroundf(__x: number): number;

declare function __lroundl(__x: number): number;

interface __mbstate_t {
	__count: number;
	__value: { __wch: number; __wchb: interop.Reference<number>; };
}
declare var __mbstate_t: interop.StructType<__mbstate_t>;

declare function __modf(__x: number, __iptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __modff(__x: number, __iptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __modfl(__x: number, __iptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __nan(__tagb: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __nanf(__tagb: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __nanl(__tagb: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __nearbyint(__x: number): number;

declare function __nearbyintf(__x: number): number;

declare function __nearbyintl(__x: number): number;

declare function __nextafter(__x: number, __y: number): number;

declare function __nextafterf(__x: number, __y: number): number;

declare function __nextafterl(__x: number, __y: number): number;

declare function __nexttoward(__x: number, __y: number): number;

declare function __nexttowardf(__x: number, __y: number): number;

declare function __nexttowardl(__x: number, __y: number): number;

interface __once_flag {
	__data: number;
}
declare var __once_flag: interop.StructType<__once_flag>;

declare function __pow(__x: number, __y: number): number;

declare function __powf(__x: number, __y: number): number;

declare function __powl(__x: number, __y: number): number;

declare const enum __priority_which {

	PROCESS = 0,

	PGRP = 1,

	USER = 2
}

interface __pthread_cond_s {
	__wseq: __atomic_wide_counter;
	__g1_start: __atomic_wide_counter;
	__g_refs: interop.Reference<number>;
	__g_size: interop.Reference<number>;
	__g1_orig_size: number;
	__wrefs: number;
	__g_signals: interop.Reference<number>;
}
declare var __pthread_cond_s: interop.StructType<__pthread_cond_s>;

interface __pthread_list_t {
	__prev: interop.Pointer | interop.Reference<__pthread_list_t> | null;
	__next: interop.Pointer | interop.Reference<__pthread_list_t> | null;
}
declare var __pthread_list_t: interop.StructType<__pthread_list_t>;

interface __pthread_mutex_s {
	__lock: number;
	__count: number;
	__owner: number;
	__nusers: number;
	__kind: number;
	__spins: number;
	__elision: number;
	__list: __pthread_list_t;
}
declare var __pthread_mutex_s: interop.StructType<__pthread_mutex_s>;

interface __pthread_rwlock_arch_t {
	__readers: number;
	__writers: number;
	__wrphase_futex: number;
	__writers_futex: number;
	__pad3: number;
	__pad4: number;
	__cur_writer: number;
	__shared: number;
	__rwelision: number;
	__pad1: interop.Reference<number>;
	__pad2: number;
	__flags: number;
}
declare var __pthread_rwlock_arch_t: interop.StructType<__pthread_rwlock_arch_t>;

interface __pthread_slist_t {
	__next: interop.Pointer | interop.Reference<__pthread_slist_t> | null;
}
declare var __pthread_slist_t: interop.StructType<__pthread_slist_t>;

declare function __remainder(__x: number, __y: number): number;

declare function __remainderf(__x: number, __y: number): number;

declare function __remainderl(__x: number, __y: number): number;

declare function __remquo(__x: number, __y: number, __quo: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __remquof(__x: number, __y: number, __quo: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __remquol(__x: number, __y: number, __quo: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __rint(__x: number): number;

declare function __rintf(__x: number): number;

declare function __rintl(__x: number): number;

declare const enum __rlimit_resource {

	RLIMIT_CPU = 0,

	RLIMIT_FSIZE = 1,

	RLIMIT_DATA = 2,

	RLIMIT_STACK = 3,

	RLIMIT_CORE = 4,

	__RLIMIT_RSS = 5,

	RLIMIT_NOFILE = 7,

	__RLIMIT_OFILE = 7,

	RLIMIT_AS = 9,

	__RLIMIT_NPROC = 6,

	__RLIMIT_MEMLOCK = 8,

	__RLIMIT_LOCKS = 10,

	__RLIMIT_SIGPENDING = 11,

	__RLIMIT_MSGQUEUE = 12,

	__RLIMIT_NICE = 13,

	__RLIMIT_RTPRIO = 14,

	__RLIMIT_RTTIME = 15,

	__RLIMIT_NLIMITS = 16,

	__RLIM_NLIMITS = 16
}

declare function __round(__x: number): number;

declare function __roundf(__x: number): number;

declare function __roundl(__x: number): number;

declare const enum __rusage_who {

	SELF = 0,

	CHILDREN = -1
}

declare function __scalb(__x: number, __n: number): number;

declare function __scalbf(__x: number, __n: number): number;

declare function __scalbl(__x: number, __n: number): number;

declare function __scalbln(__x: number, __n: number): number;

declare function __scalblnf(__x: number, __n: number): number;

declare function __scalblnl(__x: number, __n: number): number;

declare function __scalbn(__x: number, __n: number): number;

declare function __scalbnf(__x: number, __n: number): number;

declare function __scalbnl(__x: number, __n: number): number;

declare function __sched_cpualloc(__count: number): interop.Pointer | interop.Reference<cpu_set_t> | null;

declare function __sched_cpucount(__setsize: number, __setp: interop.Pointer | interop.Reference<cpu_set_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function __sched_cpufree(__set: interop.Pointer | interop.Reference<cpu_set_t> | ArrayBufferLike | ArrayBufferView | null): void;

declare function __signbit(__value: number): number;

declare function __signbitf(__value: number): number;

declare function __signbitl(__value: number): number;

declare function __significand(__x: number): number;

declare function __significandf(__x: number): number;

declare function __significandl(__x: number): number;

interface __sigset_t {
	__val: interop.Reference<number>;
}
declare var __sigset_t: interop.StructType<__sigset_t>;

interface __sigval_t {
	sival_int: number;
	sival_ptr: interop.Pointer | interop.Reference<any> | null;
}
type sigval = __sigval_t;


declare function __sin(__x: number): number;

declare function __sinf(__x: number): number;

declare function __sinh(__x: number): number;

declare function __sinhf(__x: number): number;

declare function __sinhl(__x: number): number;

declare function __sinl(__x: number): number;

declare const enum __socket_type {

	STREAM = 1,

	DGRAM = 2,

	RAW = 3,

	RDM = 4,

	SEQPACKET = 5,

	DCCP = 6,

	PACKET = 10,

	CLOEXEC = 524288,

	NONBLOCK = 2048
}

declare function __sqrt(__x: number): number;

declare function __sqrtf(__x: number): number;

declare function __sqrtl(__x: number): number;

declare function __tan(__x: number): number;

declare function __tanf(__x: number): number;

declare function __tanh(__x: number): number;

declare function __tanhf(__x: number): number;

declare function __tanhl(__x: number): number;

declare function __tanl(__x: number): number;

declare function __tgamma(p1: number): number;

declare function __tgammaf(p1: number): number;

declare function __tgammal(p1: number): number;

declare function __trunc(__x: number): number;

declare function __truncf(__x: number): number;

declare function __truncl(__x: number): number;

declare function __y0(p1: number): number;

declare function __y0f(p1: number): number;

declare function __y0l(p1: number): number;

declare function __y1(p1: number): number;

declare function __y1f(p1: number): number;

declare function __y1l(p1: number): number;

declare function __yn(p1: number, p2: number): number;

declare function __ynf(p1: number, p2: number): number;

declare function __ynl(p1: number, p2: number): number;

interface _fpreg {
	significand: interop.Reference<number>;
	exponent: number;
}
declare var _fpreg: interop.StructType<_fpreg>;

interface _fpstate {
	cwd: number;
	swd: number;
	ftw: number;
	fop: number;
	rip: number;
	rdp: number;
	mxcsr: number;
	mxcr_mask: number;
	_st: interop.Reference<_fpxreg>;
	_xmm: interop.Reference<_xmmreg>;
	__glibc_reserved1: interop.Reference<number>;
}
declare var _fpstate: interop.StructType<_fpstate>;

interface _fpx_sw_bytes {
	magic1: number;
	extended_size: number;
	xstate_bv: number;
	xstate_size: number;
	__glibc_reserved1: interop.Reference<number>;
}
declare var _fpx_sw_bytes: interop.StructType<_fpx_sw_bytes>;

interface _fpxreg {
	significand: interop.Reference<number>;
	exponent: number;
	__glibc_reserved1: interop.Reference<number>;
}
declare var _fpxreg: interop.StructType<_fpxreg>;

interface _libc_fpstate {
	cwd: number;
	swd: number;
	ftw: number;
	fop: number;
	rip: number;
	rdp: number;
	mxcsr: number;
	mxcr_mask: number;
	_st: interop.Reference<_libc_fpxreg>;
	_xmm: interop.Reference<_libc_xmmreg>;
	__glibc_reserved1: interop.Reference<number>;
}
declare var _libc_fpstate: interop.StructType<_libc_fpstate>;

interface _libc_fpxreg {
	significand: interop.Reference<number>;
	exponent: number;
	__glibc_reserved1: interop.Reference<number>;
}
declare var _libc_fpxreg: interop.StructType<_libc_fpxreg>;

interface _libc_xmmreg {
	element: interop.Reference<number>;
}
declare var _libc_xmmreg: interop.StructType<_libc_xmmreg>;

interface _xmmreg {
	element: interop.Reference<number>;
}
declare var _xmmreg: interop.StructType<_xmmreg>;

interface _xsave_hdr {
	xstate_bv: number;
	__glibc_reserved1: interop.Reference<number>;
	__glibc_reserved2: interop.Reference<number>;
}
declare var _xsave_hdr: interop.StructType<_xsave_hdr>;

interface _xstate {
	fpstate: _fpstate;
	xstate_hdr: _xsave_hdr;
	ymmh: _ymmh_state;
}
declare var _xstate: interop.StructType<_xstate>;

interface _ymmh_state {
	ymmh_space: interop.Reference<number>;
}
declare var _ymmh_state: interop.StructType<_ymmh_state>;

declare function accept(__fd: number, __addr: interop.Pointer | interop.Reference<sockaddr> | ArrayBufferLike | ArrayBufferView | null, __addr_len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function acos(__x: number): number;

declare function acosf(__x: number): number;

declare function acosh(__x: number): number;

declare function acoshf(__x: number): number;

declare function acoshl(__x: number): number;

declare function acosl(__x: number): number;

declare function adjtime(__delta: interop.Pointer | interop.Reference<timeval> | ArrayBufferLike | ArrayBufferView | null, __olddelta: interop.Pointer | interop.Reference<timeval> | ArrayBufferLike | ArrayBufferView | null): number;

declare function asin(__x: number): number;

declare function asinf(__x: number): number;

declare function asinh(__x: number): number;

declare function asinhf(__x: number): number;

declare function asinhl(__x: number): number;

declare function asinl(__x: number): number;

declare function atan(__x: number): number;

declare function atan2(__y: number, __x: number): number;

declare function atan2f(__y: number, __x: number): number;

declare function atan2l(__y: number, __x: number): number;

declare function atanf(__x: number): number;

declare function atanh(__x: number): number;

declare function atanhf(__x: number): number;

declare function atanhl(__x: number): number;

declare function atanl(__x: number): number;

declare function bind(__fd: number, __addr: interop.Pointer | interop.Reference<sockaddr> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function cbrt(__x: number): number;

declare function cbrtf(__x: number): number;

declare function cbrtl(__x: number): number;

declare function ceil(__x: number): number;

declare function ceilf(__x: number): number;

declare function ceill(__x: number): number;

declare function chmod(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __mode: number): number;

declare function closelog(): void;

interface cmsghdr {
	cmsg_len: number;
	cmsg_level: number;
	cmsg_type: number;
	__cmsg_data: interop.Reference<number>;
}
declare var cmsghdr: interop.StructType<cmsghdr>;

declare function connect(__fd: number, __addr: interop.Pointer | interop.Reference<sockaddr> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

interface cookie_io_functions_t {
	read: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number) => number>> | null;
	write: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: string | null, p3: number) => number>> | null;
	seek: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null, p2: interop.Pointer | interop.Reference<number> | null, p3: number) => number>> | null;
	close: interop.Pointer | interop.Reference<interop.FunctionReference<(p1: interop.Pointer | interop.Reference<any> | null) => number>> | null;
}
declare var cookie_io_functions_t: interop.StructType<cookie_io_functions_t>;

declare function copysign(__x: number, __y: number): number;

declare function copysignf(__x: number, __y: number): number;

declare function copysignl(__x: number, __y: number): number;

declare function cos(__x: number): number;

declare function cosf(__x: number): number;

declare function cosh(__x: number): number;

declare function coshf(__x: number): number;

declare function coshl(__x: number): number;

declare function cosl(__x: number): number;

interface cpu_set_t {
	__bits: interop.Reference<number>;
}
declare var cpu_set_t: interop.StructType<cpu_set_t>;

interface dirent {
	d_ino: number;
	d_off: number;
	d_reclen: number;
	d_type: number;
	d_name: interop.Reference<number>;
}
declare var dirent: interop.StructType<dirent>;

interface dqblk {
	dqb_bhardlimit: number;
	dqb_bsoftlimit: number;
	dqb_curspace: number;
	dqb_ihardlimit: number;
	dqb_isoftlimit: number;
	dqb_curinodes: number;
	dqb_btime: number;
	dqb_itime: number;
	dqb_valid: number;
}
declare var dqblk: interop.StructType<dqblk>;

interface dqinfo {
	dqi_bgrace: number;
	dqi_igrace: number;
	dqi_flags: number;
	dqi_valid: number;
}
declare var dqinfo: interop.StructType<dqinfo>;

declare function drem(__x: number, __y: number): number;

declare function dremf(__x: number, __y: number): number;

declare function dreml(__x: number, __y: number): number;

declare function erf(p1: number): number;

declare function erfc(p1: number): number;

declare function erfcf(p1: number): number;

declare function erfcl(p1: number): number;

declare function erff(p1: number): number;

declare function erfl(p1: number): number;

declare function exp(__x: number): number;

declare function exp2(__x: number): number;

declare function exp2f(__x: number): number;

declare function exp2l(__x: number): number;

declare function expf(__x: number): number;

declare function expl(__x: number): number;

declare function expm1(__x: number): number;

declare function expm1f(__x: number): number;

declare function expm1l(__x: number): number;

declare function fabs(__x: number): number;

declare function fabsf(__x: number): number;

declare function fabsl(__x: number): number;

declare function fchmod(__fd: number, __mode: number): number;

declare function fchmodat(__fd: number, __file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __mode: number, __flag: number): number;

interface fd_set {
	__fds_bits: interop.Reference<number>;
}
declare var fd_set: interop.StructType<fd_set>;

declare function fdim(__x: number, __y: number): number;

declare function fdimf(__x: number, __y: number): number;

declare function fdiml(__x: number, __y: number): number;

interface fenv_t {
	__control_word: number;
	__glibc_reserved1: number;
	__status_word: number;
	__glibc_reserved2: number;
	__tags: number;
	__glibc_reserved3: number;
	__eip: number;
	__cs_selector: number;
	__opcode: number;
	__glibc_reserved4: number;
	__data_offset: number;
	__data_selector: number;
	__glibc_reserved5: number;
	__mxcsr: number;
}
declare var fenv_t: interop.StructType<fenv_t>;

declare function fgetxattr(__fd: number, __name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __value: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number): number;

declare function finite(__value: number): number;

declare function finitef(__value: number): number;

declare function finitel(__value: number): number;

declare function flistxattr(__fd: number, __list: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number): number;

declare function flock(__fd: number, __operation: number): number;

interface flockStruct {
	l_type: number;
	l_whence: number;
	l_start: number;
	l_len: number;
	l_pid: number;
}
declare var flockStruct: interop.StructType<flockStruct>;

declare function floor(__x: number): number;

declare function floorf(__x: number): number;

declare function floorl(__x: number): number;

declare function fma(__x: number, __y: number, __z: number): number;

declare function fmaf(__x: number, __y: number, __z: number): number;

declare function fmal(__x: number, __y: number, __z: number): number;

declare function fmax(__x: number, __y: number): number;

declare function fmaxf(__x: number, __y: number): number;

declare function fmaxl(__x: number, __y: number): number;

declare function fmin(__x: number, __y: number): number;

declare function fminf(__x: number, __y: number): number;

declare function fminl(__x: number, __y: number): number;

declare function fmod(__x: number, __y: number): number;

declare function fmodf(__x: number, __y: number): number;

declare function fmodl(__x: number, __y: number): number;

declare function fremovexattr(__fd: number, __name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function frexp(__x: number, __exponent: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function frexpf(__x: number, __exponent: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function frexpl(__x: number, __exponent: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fsconfig(__fd: number, __cmd: number, __key: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __value: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __aux: number): number;

declare function fsetxattr(__fd: number, __name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __value: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number, __flags: number): number;

declare function fsmount(__fd: number, __flags: number, __ms_flags: number): number;

declare function fsopen(__fs_name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __flags: number): number;

declare function fspick(__dfd: number, __path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __flags: number): number;

declare function fstat(__fd: number, __buf: interop.Pointer | interop.Reference<statStruct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function fstatat(__fd: number, __file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buf: interop.Pointer | interop.Reference<statStruct> | ArrayBufferLike | ArrayBufferView | null, __flag: number): number;

declare function fstatvfs(__fildes: number, __buf: interop.Pointer | interop.Reference<statvfsStruct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ftime(__timebuf: interop.Pointer | interop.Reference<timeb> | ArrayBufferLike | ArrayBufferView | null): number;

declare function ftok(__pathname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __proj_id: number): number;

declare function futimens(__fd: number, __times: interop.Reference<timespec>): number;

declare function futimes(__fd: number, __tvp: interop.Reference<timeval>): number;

declare function gamma(p1: number): number;

declare function gammaf(p1: number): number;

declare function gammal(p1: number): number;

declare function getitimer(__which: number, __value: interop.Pointer | interop.Reference<itimerval> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getopt(___argc: number, ___argv: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __shortopts: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getopt_long(___argc: number, ___argv: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __shortopts: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __longopts: interop.Pointer | interop.Reference<option> | ArrayBufferLike | ArrayBufferView | null, __longind: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getopt_long_only(___argc: number, ___argv: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, __shortopts: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __longopts: interop.Pointer | interop.Reference<option> | ArrayBufferLike | ArrayBufferView | null, __longind: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getpeername(__fd: number, __addr: interop.Pointer | interop.Reference<sockaddr> | ArrayBufferLike | ArrayBufferView | null, __len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getpriority(__which: number, __who: number): number;

declare function getrlimit(__resource: number, __rlimits: interop.Pointer | interop.Reference<rlimit> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getrusage(__who: number, __usage: interop.Pointer | interop.Reference<rusage> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getsockname(__fd: number, __addr: interop.Pointer | interop.Reference<sockaddr> | ArrayBufferLike | ArrayBufferView | null, __len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getsockopt(__fd: number, __level: number, __optname: number, __optval: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __optlen: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function gettimeofday(__tv: interop.Pointer | interop.Reference<timeval> | ArrayBufferLike | ArrayBufferView | null, __tz: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function getxattr(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __value: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number): number;

declare function hypot(__x: number, __y: number): number;

declare function hypotf(__x: number, __y: number): number;

declare function hypotl(__x: number, __y: number): number;

declare const enum idtype_t {

	ALL = 0,

	PID = 1,

	PGID = 2,

	PIDFD = 3
}

declare function ilogb(__x: number): number;

declare function ilogbf(__x: number): number;

declare function ilogbl(__x: number): number;

interface in_pktinfo {
	ipi_ifindex: number;
	ipi_spec_dst: in_addr;
	ipi_addr: in_addr;
}
declare var in_pktinfo: interop.StructType<in_pktinfo>;

declare function ioctl(__fd: number, __request: number, ...args: any[]): number;

interface iovec {
	iov_base: interop.Pointer | interop.Reference<any> | null;
	iov_len: number;
}
declare var iovec: interop.StructType<iovec>;

interface ip_opts {
	ip_dst: in_addr;
	ip_opts: interop.Reference<number>;
}
declare var ip_opts: interop.StructType<ip_opts>;

interface ipc_perm {
	__key: number;
	uid: number;
	gid: number;
	cuid: number;
	cgid: number;
	mode: number;
	__seq: number;
	__pad2: number;
	__glibc_reserved1: number;
	__glibc_reserved2: number;
}
declare var ipc_perm: interop.StructType<ipc_perm>;

declare function isfdtype(__fd: number, __fdtype: number): number;

declare function isinf(__value: number): number;

declare function isinff(__value: number): number;

declare function isinfl(__value: number): number;

declare function isnan(__value: number): number;

declare function isnanf(__value: number): number;

declare function isnanl(__value: number): number;

declare function iswalnum(__wc: number): number;

declare function iswalpha(__wc: number): number;

declare function iswblank(__wc: number): number;

declare function iswcntrl(__wc: number): number;

declare function iswctype(__wc: number, __desc: number): number;

declare function iswdigit(__wc: number): number;

declare function iswgraph(__wc: number): number;

declare function iswlower(__wc: number): number;

declare function iswprint(__wc: number): number;

declare function iswpunct(__wc: number): number;

declare function iswspace(__wc: number): number;

declare function iswupper(__wc: number): number;

declare function iswxdigit(__wc: number): number;

interface itimerspec {
	it_interval: timespec;
	it_value: timespec;
}
declare var itimerspec: interop.StructType<itimerspec>;

interface itimerval {
	it_interval: timeval;
	it_value: timeval;
}
declare var itimerval: interop.StructType<itimerval>;

declare function j0(p1: number): number;

declare function j0f(p1: number): number;

declare function j0l(p1: number): number;

declare function j1(p1: number): number;

declare function j1f(p1: number): number;

declare function j1l(p1: number): number;

declare function jn(p1: number, p2: number): number;

declare function jnf(p1: number, p2: number): number;

declare function jnl(p1: number, p2: number): number;

declare function lchmod(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __mode: number): number;

declare function ldexp(__x: number, __exponent: number): number;

declare function ldexpf(__x: number, __exponent: number): number;

declare function ldexpl(__x: number, __exponent: number): number;

declare function lgamma(p1: number): number;

declare function lgamma_r(p1: number, __signgamp: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function lgammaf(p1: number): number;

declare function lgammaf_r(p1: number, __signgamp: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function lgammal(p1: number): number;

declare function lgammal_r(p1: number, __signgamp: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function lgetxattr(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __value: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number): number;

interface linger {
	l_onoff: number;
	l_linger: number;
}
declare var linger: interop.StructType<linger>;

declare function listen(__fd: number, __n: number): number;

declare function listxattr(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __list: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number): number;

declare function llistxattr(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __list: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number): number;

declare function llrint(__x: number): number;

declare function llrintf(__x: number): number;

declare function llrintl(__x: number): number;

declare function llround(__x: number): number;

declare function llroundf(__x: number): number;

declare function llroundl(__x: number): number;

declare function log(__x: number): number;

declare function log10(__x: number): number;

declare function log10f(__x: number): number;

declare function log10l(__x: number): number;

declare function log1p(__x: number): number;

declare function log1pf(__x: number): number;

declare function log1pl(__x: number): number;

declare function log2(__x: number): number;

declare function log2f(__x: number): number;

declare function log2l(__x: number): number;

declare function logb(__x: number): number;

declare function logbf(__x: number): number;

declare function logbl(__x: number): number;

declare function logf(__x: number): number;

declare function logl(__x: number): number;

declare function lremovexattr(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function lrint(__x: number): number;

declare function lrintf(__x: number): number;

declare function lrintl(__x: number): number;

declare function lround(__x: number): number;

declare function lroundf(__x: number): number;

declare function lroundl(__x: number): number;

declare function lsetxattr(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __value: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number, __flags: number): number;

declare function lstat(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buf: interop.Pointer | interop.Reference<statStruct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function lutimes(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __tvp: interop.Reference<timeval>): number;

declare function madvise(__addr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number, __advice: number): number;

interface mcontext_t {
	gregs: interop.Reference<number>;
	fpregs: interop.Pointer | interop.Reference<_libc_fpstate> | null;
	__reserved1: interop.Reference<number>;
}
declare var mcontext_t: interop.StructType<mcontext_t>;

declare function mincore(__start: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number, __vec: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function mkdir(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __mode: number): number;

declare function mkdirat(__fd: number, __path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __mode: number): number;

declare function mkfifo(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __mode: number): number;

declare function mkfifoat(__fd: number, __path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __mode: number): number;

declare function mknod(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __mode: number, __dev: number): number;

declare function mknodat(__fd: number, __path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __mode: number, __dev: number): number;

declare function mlock(__addr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function mlockall(__flags: number): number;

declare function mmap(__addr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number, __prot: number, __flags: number, __fd: number, __offset: number): interop.Pointer | interop.Reference<any> | null;

declare function modf(__x: number, __iptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function modff(__x: number, __iptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function modfl(__x: number, __iptr: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function mount(__special_file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __dir: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __fstype: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __rwflag: number, __data: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function mount_setattr(__dfd: number, __path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __flags: number, __uattr: interop.Pointer | interop.Reference<mount_attr> | ArrayBufferLike | ArrayBufferView | null, __usize: number): number;

declare function move_mount(__from_dfd: number, __from_pathname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __to_dfd: number, __to_pathname: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, flags: number): number;

declare function mprotect(__addr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number, __prot: number): number;

declare function msgctl(__msqid: number, __cmd: number, __buf: interop.Pointer | interop.Reference<msqid_ds> | ArrayBufferLike | ArrayBufferView | null): number;

declare function msgget(__key: number, __msgflg: number): number;

interface msghdr {
	msg_name: interop.Pointer | interop.Reference<any> | null;
	msg_namelen: number;
	msg_iov: interop.Pointer | interop.Reference<iovec> | null;
	msg_iovlen: number;
	msg_control: interop.Pointer | interop.Reference<any> | null;
	msg_controllen: number;
	msg_flags: number;
}
declare var msghdr: interop.StructType<msghdr>;

interface msginfo {
	msgpool: number;
	msgmap: number;
	msgmax: number;
	msgmnb: number;
	msgmni: number;
	msgssz: number;
	msgtql: number;
	msgseg: number;
}
declare var msginfo: interop.StructType<msginfo>;

declare function msgrcv(__msqid: number, __msgp: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __msgsz: number, __msgtyp: number, __msgflg: number): number;

declare function msgsnd(__msqid: number, __msgp: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __msgsz: number, __msgflg: number): number;

interface msqid_ds {
	msg_perm: ipc_perm;
	msg_stime: number;
	msg_rtime: number;
	msg_ctime: number;
	__msg_cbytes: number;
	msg_qnum: number;
	msg_qbytes: number;
	msg_lspid: number;
	msg_lrpid: number;
	__glibc_reserved4: number;
	__glibc_reserved5: number;
}
declare var msqid_ds: interop.StructType<msqid_ds>;

declare function msync(__addr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number, __flags: number): number;

declare function munlock(__addr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function munlockall(): number;

declare function munmap(__addr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number): number;

declare function nan(__tagb: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function nanf(__tagb: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function nanl(__tagb: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function nearbyint(__x: number): number;

declare function nearbyintf(__x: number): number;

declare function nearbyintl(__x: number): number;

interface netent {
	n_name: interop.Pointer | interop.Reference<any> | null;
	n_aliases: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;
	n_addrtype: number;
	n_net: number;
}
declare var netent: interop.StructType<netent>;

declare function nextafter(__x: number, __y: number): number;

declare function nextafterf(__x: number, __y: number): number;

declare function nextafterl(__x: number, __y: number): number;

declare function nexttoward(__x: number, __y: number): number;

declare function nexttowardf(__x: number, __y: number): number;

declare function nexttowardl(__x: number, __y: number): number;

declare const no_argument: number;

declare function open_tree(__dfd: number, __filename: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __flags: number): number;

declare function openlog(__ident: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __option: number, __facility: number): void;

declare var optarg: interop.Pointer | interop.Reference<any> | null;

declare var opterr: number;

declare var optind: number;

interface option {
	name: string | null;
	has_arg: number;
	flag: interop.Pointer | interop.Reference<number> | null;
	val: number;
}
declare var option: interop.StructType<option>;

declare const optional_argument: number;

declare var optopt: number;

interface osockaddr {
	sa_family: number;
	sa_data: interop.Reference<number>;
}
declare var osockaddr: interop.StructType<osockaddr>;

declare function pidfd_spawn(__pidfd: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __facts: interop.Pointer | interop.Reference<posix_spawn_file_actions_t> | ArrayBufferLike | ArrayBufferView | null, __attrp: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __argv: interop.Reference<interop.Pointer | interop.Reference<any> | null>, __envp: interop.Reference<interop.Pointer | interop.Reference<any> | null>): number;

declare function pidfd_spawnp(__pidfd: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __facts: interop.Pointer | interop.Reference<posix_spawn_file_actions_t> | ArrayBufferLike | ArrayBufferView | null, __attrp: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __argv: interop.Reference<interop.Pointer | interop.Reference<any> | null>, __envp: interop.Reference<interop.Pointer | interop.Reference<any> | null>): number;

declare function poll(__fds: interop.Pointer | interop.Reference<pollfd> | ArrayBufferLike | ArrayBufferView | null, __nfds: number, __timeout: number): number;

interface pollfd {
	fd: number;
	events: number;
	revents: number;
}
declare var pollfd: interop.StructType<pollfd>;

declare function posix_madvise(__addr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __len: number, __advice: number): number;

declare function posix_spawnattr_getcgroup_np(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __cgroup: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function posix_spawnattr_setcgroup_np(__attr: interop.Pointer | interop.Reference<posix_spawnattr_t> | ArrayBufferLike | ArrayBufferView | null, __cgroup: number): number;

declare function pow(__x: number, __y: number): number;

declare function powf(__x: number, __y: number): number;

declare function powl(__x: number, __y: number): number;

declare function preadv(__fd: number, __iovec: interop.Pointer | interop.Reference<iovec> | ArrayBufferLike | ArrayBufferView | null, __count: number, __offset: number): number;

declare function pselect(__nfds: number, __readfds: interop.Pointer | interop.Reference<fd_set> | ArrayBufferLike | ArrayBufferView | null, __writefds: interop.Pointer | interop.Reference<fd_set> | ArrayBufferLike | ArrayBufferView | null, __exceptfds: interop.Pointer | interop.Reference<fd_set> | ArrayBufferLike | ArrayBufferView | null, __timeout: interop.Pointer | interop.Reference<timespec> | ArrayBufferLike | ArrayBufferView | null, __sigmask: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null): number;

interface pthread_attr_t {
	__size: interop.Reference<number>;
	__align: number;
}


interface pthread_barrier_t {
	__size: interop.Reference<number>;
	__align: number;
}


interface pthread_barrierattr_t {
	__size: interop.Reference<number>;
	__align: number;
}


interface pthread_cond_t {
	__data: __pthread_cond_s;
	__size: interop.Reference<number>;
	__align: number;
}


interface pthread_condattr_t {
	__size: interop.Reference<number>;
	__align: number;
}


declare function pthread_kill(__threadid: number, __signo: number): number;

interface pthread_mutex_t {
	__data: __pthread_mutex_s;
	__size: interop.Reference<number>;
	__align: number;
}


interface pthread_mutexattr_t {
	__size: interop.Reference<number>;
	__align: number;
}


interface pthread_rwlock_t {
	__data: __pthread_rwlock_arch_t;
	__size: interop.Reference<number>;
	__align: number;
}


interface pthread_rwlockattr_t {
	__size: interop.Reference<number>;
	__align: number;
}


declare function pthread_sigmask(__how: number, __newmask: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null, __oldmask: interop.Pointer | interop.Reference<__sigset_t> | ArrayBufferLike | ArrayBufferView | null): number;

declare function pwritev(__fd: number, __iovec: interop.Pointer | interop.Reference<iovec> | ArrayBufferLike | ArrayBufferView | null, __count: number, __offset: number): number;

declare function quotactl(__cmd: number, __special: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __id: number, __addr: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function readv(__fd: number, __iovec: interop.Pointer | interop.Reference<iovec> | ArrayBufferLike | ArrayBufferView | null, __count: number): number;

declare function recv(__fd: number, __buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number, __flags: number): number;

declare function recvfrom(__fd: number, __buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number, __flags: number, __addr: interop.Pointer | interop.Reference<sockaddr> | ArrayBufferLike | ArrayBufferView | null, __addr_len: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function recvmsg(__fd: number, __message: interop.Pointer | interop.Reference<msghdr> | ArrayBufferLike | ArrayBufferView | null, __flags: number): number;

declare function remainder(__x: number, __y: number): number;

declare function remainderf(__x: number, __y: number): number;

declare function remainderl(__x: number, __y: number): number;

declare function removexattr(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function remquo(__x: number, __y: number, __quo: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function remquof(__x: number, __y: number, __quo: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function remquol(__x: number, __y: number, __quo: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare const required_argument: number;

declare function rint(__x: number): number;

declare function rintf(__x: number): number;

declare function rintl(__x: number): number;

interface rlimit {
	rlim_cur: number;
	rlim_max: number;
}
declare var rlimit: interop.StructType<rlimit>;

declare function round(__x: number): number;

declare function roundf(__x: number): number;

declare function roundl(__x: number): number;

interface rusage {
	ru_utime: timeval;
	ru_stime: timeval;
}
declare var rusage: interop.StructType<rusage>;

declare function scalb(__x: number, __n: number): number;

declare function scalbf(__x: number, __n: number): number;

declare function scalbl(__x: number, __n: number): number;

declare function scalbln(__x: number, __n: number): number;

declare function scalblnf(__x: number, __n: number): number;

declare function scalblnl(__x: number, __n: number): number;

declare function scalbn(__x: number, __n: number): number;

declare function scalbnf(__x: number, __n: number): number;

declare function scalbnl(__x: number, __n: number): number;

interface sched_param {
	sched_priority: number;
}
declare var sched_param: interop.StructType<sched_param>;

declare function select(__nfds: number, __readfds: interop.Pointer | interop.Reference<fd_set> | ArrayBufferLike | ArrayBufferView | null, __writefds: interop.Pointer | interop.Reference<fd_set> | ArrayBufferLike | ArrayBufferView | null, __exceptfds: interop.Pointer | interop.Reference<fd_set> | ArrayBufferLike | ArrayBufferView | null, __timeout: interop.Pointer | interop.Reference<timeval> | ArrayBufferLike | ArrayBufferView | null): number;

interface sem_t {
	__size: interop.Reference<number>;
	__align: number;
}


interface sembuf {
	sem_num: number;
	sem_op: number;
	sem_flg: number;
}
declare var sembuf: interop.StructType<sembuf>;

declare function semctl(__semid: number, __semnum: number, __cmd: number, ...args: any[]): number;

declare function semget(__key: number, __nsems: number, __semflg: number): number;

interface semid_ds {
	sem_perm: ipc_perm;
	sem_otime: number;
	__sem_otime_high: number;
	sem_ctime: number;
	__sem_ctime_high: number;
	sem_nsems: number;
	__glibc_reserved3: number;
	__glibc_reserved4: number;
}
declare var semid_ds: interop.StructType<semid_ds>;

interface seminfo {
	semmap: number;
	semmni: number;
	semmns: number;
	semmnu: number;
	semmsl: number;
	semopm: number;
	semume: number;
	semusz: number;
	semvmx: number;
	semaem: number;
}
declare var seminfo: interop.StructType<seminfo>;

declare function semop(__semid: number, __sops: interop.Pointer | interop.Reference<sembuf> | ArrayBufferLike | ArrayBufferView | null, __nsops: number): number;

declare function send(__fd: number, __buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number, __flags: number): number;

declare function sendmsg(__fd: number, __message: interop.Pointer | interop.Reference<msghdr> | ArrayBufferLike | ArrayBufferView | null, __flags: number): number;

declare function sendto(__fd: number, __buf: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __n: number, __flags: number, __addr: interop.Pointer | interop.Reference<sockaddr> | ArrayBufferLike | ArrayBufferView | null, __addr_len: number): number;

declare function setitimer(__which: number, __new: interop.Pointer | interop.Reference<itimerval> | ArrayBufferLike | ArrayBufferView | null, __old: interop.Pointer | interop.Reference<itimerval> | ArrayBufferLike | ArrayBufferView | null): number;

declare function setlogmask(__mask: number): number;

declare function setpriority(__which: number, __who: number, __prio: number): number;

declare function setrlimit(__resource: number, __rlimits: interop.Pointer | interop.Reference<rlimit> | ArrayBufferLike | ArrayBufferView | null): number;

declare function setsockopt(__fd: number, __level: number, __optname: number, __optval: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __optlen: number): number;

declare function settimeofday(__tv: interop.Pointer | interop.Reference<timeval> | ArrayBufferLike | ArrayBufferView | null, __tz: interop.Pointer | interop.Reference<timezone> | ArrayBufferLike | ArrayBufferView | null): number;

declare function setxattr(__path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __value: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __size: number, __flags: number): number;

interface shm_info {
	used_ids: number;
	shm_tot: number;
	shm_rss: number;
	shm_swp: number;
	swap_attempts: number;
	swap_successes: number;
}
declare var shm_info: interop.StructType<shm_info>;

declare function shm_open(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __oflag: number, __mode: number): number;

declare function shm_unlink(__name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function shmat(__shmid: number, __shmaddr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __shmflg: number): interop.Pointer | interop.Reference<any> | null;

declare function shmctl(__shmid: number, __cmd: number, __buf: interop.Pointer | interop.Reference<shmid_ds> | ArrayBufferLike | ArrayBufferView | null): number;

declare function shmdt(__shmaddr: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function shmget(__key: number, __size: number, __shmflg: number): number;

interface shmid_ds {
	shm_perm: ipc_perm;
	shm_segsz: number;
	shm_atime: number;
	shm_dtime: number;
	shm_ctime: number;
	shm_cpid: number;
	shm_lpid: number;
	shm_nattch: number;
	__glibc_reserved5: number;
	__glibc_reserved6: number;
}
declare var shmid_ds: interop.StructType<shmid_ds>;

interface shminfo {
	shmmax: number;
	shmmin: number;
	shmmni: number;
	shmseg: number;
	shmall: number;
	__glibc_reserved1: number;
	__glibc_reserved2: number;
	__glibc_reserved3: number;
	__glibc_reserved4: number;
}
declare var shminfo: interop.StructType<shminfo>;

declare function shutdown(__fd: number, __how: number): number;

interface sigaction {
	__sigaction_handler: { sa_handler: interop.FunctionReference<(p1: number) => void>; sa_sigaction: interop.FunctionReference<(p1: number, p2: interop.Pointer | interop.Reference<siginfo_t> | null, p3: interop.Pointer | interop.Reference<any> | null) => void>; };
	sa_mask: __sigset_t;
	sa_flags: number;
	sa_restorer: interop.FunctionReference<() => void>;
}
declare var sigaction: interop.StructType<sigaction>;

interface sigcontext {
	r8: number;
	r9: number;
	r10: number;
	r11: number;
	r12: number;
	r13: number;
	r14: number;
	r15: number;
	rdi: number;
	rsi: number;
	rbp: number;
	rbx: number;
	rdx: number;
	rax: number;
	rcx: number;
	rsp: number;
	rip: number;
	eflags: number;
	cs: number;
	gs: number;
	fs: number;
	__pad0: number;
	err: number;
	trapno: number;
	oldmask: number;
	cr2: number;
	__reserved1: interop.Reference<number>;
}
declare var sigcontext: interop.StructType<sigcontext>;

interface sigevent_t {
	sigev_value: __sigval_t;
	sigev_signo: number;
	sigev_notify: number;
	_sigev_un: { _pad: interop.Reference<number>; _tid: number; _sigev_thread: { _function: interop.FunctionReference<(p1: __sigval_t) => void>; _attribute: interop.Pointer | interop.Reference<pthread_attr_t> | null; }; };
}
declare var sigevent_t: interop.StructType<sigevent_t>;

interface siginfo_t {
	si_signo: number;
	si_errno: number;
	si_code: number;
	__pad0: number;
	_sifields: { _pad: interop.Reference<number>; _kill: { si_pid: number; si_uid: number; }; _timer: { si_tid: number; si_overrun: number; si_sigval: __sigval_t; }; _rt: { si_pid: number; si_uid: number; si_sigval: __sigval_t; }; _sigchld: { si_pid: number; si_uid: number; si_status: number; si_utime: number; si_stime: number; }; _sigfault: { si_addr: interop.Pointer | interop.Reference<any> | null; si_addr_lsb: number; _bounds: { _addr_bnd: { _lower: interop.Pointer | interop.Reference<any> | null; _upper: interop.Pointer | interop.Reference<any> | null; }; _pkey: number; }; }; _sigpoll: { si_band: number; si_fd: number; }; _sigsys: { _call_addr: interop.Pointer | interop.Reference<any> | null; _syscall: number; _arch: number; }; };
}
declare var siginfo_t: interop.StructType<siginfo_t>;

declare function significand(__x: number): number;

declare function significandf(__x: number): number;

declare function significandl(__x: number): number;

interface sigstack {
	ss_sp: interop.Pointer | interop.Reference<any> | null;
	ss_onstack: number;
}
declare var sigstack: interop.StructType<sigstack>;

declare function sin(__x: number): number;

declare function sinf(__x: number): number;

declare function sinh(__x: number): number;

declare function sinhf(__x: number): number;

declare function sinhl(__x: number): number;

declare function sinl(__x: number): number;

interface sockaddr {
	sa_family: number;
	sa_data: interop.Reference<number>;
}
declare var sockaddr: interop.StructType<sockaddr>;

interface sockaddr_storage {
	ss_family: number;
	__ss_padding: interop.Reference<number>;
	__ss_align: number;
}
declare var sockaddr_storage: interop.StructType<sockaddr_storage>;

interface sockaddr_un {
	sun_family: number;
	sun_path: interop.Reference<number>;
}
declare var sockaddr_un: interop.StructType<sockaddr_un>;

declare function sockatmark(__fd: number): number;

declare function socket(__domain: number, __type: number, __protocol: number): number;

declare function socketpair(__domain: number, __type: number, __protocol: number, __fds: interop.Reference<number>): number;

declare function sqrt(__x: number): number;

declare function sqrtf(__x: number): number;

declare function sqrtl(__x: number): number;

interface stack_t {
	ss_sp: interop.Pointer | interop.Reference<any> | null;
	ss_flags: number;
	ss_size: number;
}
declare var stack_t: interop.StructType<stack_t>;

declare function stat(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buf: interop.Pointer | interop.Reference<statStruct> | ArrayBufferLike | ArrayBufferView | null): number;

interface statStruct {
	st_dev: number;
	st_ino: number;
	st_nlink: number;
	st_mode: number;
	st_uid: number;
	st_gid: number;
	__pad0: number;
	st_rdev: number;
	st_size: number;
	st_blksize: number;
	st_blocks: number;
	st_atim: timespec;
	st_mtim: timespec;
	st_ctim: timespec;
	__glibc_reserved: interop.Reference<number>;
}
declare var statStruct: interop.StructType<statStruct>;

declare function statvfs(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __buf: interop.Pointer | interop.Reference<statvfsStruct> | ArrayBufferLike | ArrayBufferView | null): number;

interface statvfsStruct {
	f_bsize: number;
	f_frsize: number;
	f_blocks: number;
	f_bfree: number;
	f_bavail: number;
	f_files: number;
	f_ffree: number;
	f_favail: number;
	f_fsid: number;
	f_flag: number;
	f_namemax: number;
	f_type: number;
	__f_spare: interop.Reference<number>;
}
declare var statvfsStruct: interop.StructType<statvfsStruct>;

declare function syslog(__pri: number, __fmt: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): void;

declare function tan(__x: number): number;

declare function tanf(__x: number): number;

declare function tanh(__x: number): number;

declare function tanhf(__x: number): number;

declare function tanhl(__x: number): number;

declare function tanl(__x: number): number;

interface termio {
	c_iflag: number;
	c_oflag: number;
	c_cflag: number;
	c_lflag: number;
	c_line: number;
	c_cc: interop.Reference<number>;
}
declare var termio: interop.StructType<termio>;

interface termios {
	c_iflag: number;
	c_oflag: number;
	c_cflag: number;
	c_lflag: number;
	c_line: number;
	c_cc: interop.Reference<number>;
	c_ispeed: number;
	c_ospeed: number;
}
declare var termios: interop.StructType<termios>;

declare function tgamma(p1: number): number;

declare function tgammaf(p1: number): number;

declare function tgammal(p1: number): number;

interface timeb {
	time: number;
	millitm: number;
	timezone: number;
	dstflag: number;
}
declare var timeb: interop.StructType<timeb>;

declare function times(__buffer: interop.Pointer | interop.Reference<tms> | ArrayBufferLike | ArrayBufferView | null): number;

interface timespec {
	tv_sec: number;
	tv_nsec: number;
}
declare var timespec: interop.StructType<timespec>;

interface timeval {
	tv_sec: number;
	tv_usec: number;
}
declare var timeval: interop.StructType<timeval>;

interface timezone {
	tz_minuteswest: number;
	tz_dsttime: number;
}
declare var timezone: interop.StructType<timezone>;

interface tm {
	tm_sec: number;
	tm_min: number;
	tm_hour: number;
	tm_mday: number;
	tm_mon: number;
	tm_year: number;
	tm_wday: number;
	tm_yday: number;
	tm_isdst: number;
	tm_gmtoff: number;
	tm_zone: string | null;
}
declare var tm: interop.StructType<tm>;

interface tms {
	tms_utime: number;
	tms_stime: number;
	tms_cutime: number;
	tms_cstime: number;
}
declare var tms: interop.StructType<tms>;

declare function towlower(__wc: number): number;

declare function towupper(__wc: number): number;

declare function trunc(__x: number): number;

declare function truncf(__x: number): number;

declare function truncl(__x: number): number;

interface ucontext_t {
	uc_flags: number;
	uc_link: interop.Pointer | interop.Reference<ucontext_t> | null;
	uc_stack: stack_t;
	uc_mcontext: mcontext_t;
	uc_sigmask: __sigset_t;
	__fpregs_mem: _libc_fpstate;
	__ssp: interop.Reference<number>;
}
declare var ucontext_t: interop.StructType<ucontext_t>;

declare function umask(__mask: number): number;

declare function umount(__special_file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function umount2(__special_file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __flags: number): number;

declare function uname(__name: interop.Pointer | interop.Reference<utsname> | ArrayBufferLike | ArrayBufferView | null): number;

declare function utimensat(__fd: number, __path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __times: interop.Reference<timespec>, __flags: number): number;

declare function utimes(__file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, __tvp: interop.Reference<timeval>): number;

interface utmpx {
	ut_type: number;
	ut_pid: number;
	ut_line: interop.Reference<number>;
	ut_id: interop.Reference<number>;
	ut_user: interop.Reference<number>;
	ut_host: interop.Reference<number>;
	ut_exit: __exit_status;
	ut_session: number;
	ut_tv: { tv_sec: number; tv_usec: number; };
	ut_addr_v6: interop.Reference<number>;
	__glibc_reserved: interop.Reference<number>;
}
declare var utmpx: interop.StructType<utmpx>;

interface utsname {
	sysname: interop.Reference<number>;
	nodename: interop.Reference<number>;
	release: interop.Reference<number>;
	version: interop.Reference<number>;
	machine: interop.Reference<number>;
	__domainname: interop.Reference<number>;
}
declare var utsname: interop.StructType<utsname>;

declare function wait(__stat_loc: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wait3(__stat_loc: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __options: number, __usage: interop.Pointer | interop.Reference<rusage> | ArrayBufferLike | ArrayBufferView | null): number;

declare function wait4(__pid: number, __stat_loc: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __options: number, __usage: interop.Pointer | interop.Reference<rusage> | ArrayBufferLike | ArrayBufferView | null): number;

declare function waitid(__idtype: idtype_t, __id: number, __infop: interop.Pointer | interop.Reference<siginfo_t> | ArrayBufferLike | ArrayBufferView | null, __options: number): number;

declare function waitpid(__pid: number, __stat_loc: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, __options: number): number;

declare function wctype(__property: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

interface winsize {
	ws_row: number;
	ws_col: number;
	ws_xpixel: number;
	ws_ypixel: number;
}
declare var winsize: interop.StructType<winsize>;

declare function writev(__fd: number, __iovec: interop.Pointer | interop.Reference<iovec> | ArrayBufferLike | ArrayBufferView | null, __count: number): number;

declare function y0(p1: number): number;

declare function y0f(p1: number): number;

declare function y0l(p1: number): number;

declare function y1(p1: number): number;

declare function y1f(p1: number): number;

declare function y1l(p1: number): number;

declare function yn(p1: number, p2: number): number;

declare function ynf(p1: number, p2: number): number;

declare function ynl(p1: number, p2: number): number;
