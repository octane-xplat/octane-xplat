
declare const FC_ANTIALIAS: string;

declare const FC_ASPECT: string;

declare const FC_AUTOHINT: string;

declare const FC_CACHE_SUFFIX: string;

declare const FC_CACHE_VERSION: string;

declare const FC_CACHE_VERSION_NUMBER: number;

declare const FC_CAPABILITY: string;

declare const FC_CHARCELL: number;

declare const FC_CHARSET: string;

declare const FC_CHARSET_DONE: number;

declare const FC_CHARSET_MAP_SIZE: number;

declare const FC_CHARWIDTH: string;

declare const FC_CHAR_HEIGHT: string;

declare const FC_CHAR_WIDTH: string;

declare const FC_COLOR: string;

declare const FC_DECORATIVE: string;

declare const FC_DESKTOP_NAME: string;

declare const FC_DIR_CACHE_FILE: string;

declare const FC_DPI: string;

declare const FC_DUAL: number;

declare const FC_EMBEDDED_BITMAP: string;

declare const FC_EMBOLDEN: string;

declare const FC_FAMILY: string;

declare const FC_FAMILYLANG: string;

declare const FC_FILE: string;

declare const FC_FONTFORMAT: string;

declare const FC_FONTVERSION: string;

declare const FC_FONT_FEATURES: string;

declare const FC_FONT_HAS_HINT: string;

declare const FC_FONT_VARIATIONS: string;

declare const FC_FONT_WRAPPER: string;

declare const FC_FOUNDRY: string;

declare const FC_FT_FACE: string;

declare const FC_FULLNAME: string;

declare const FC_FULLNAMELANG: string;

declare const FC_GLOBAL_ADVANCE: string;

declare const FC_HASH: string;

declare const FC_HINTING: string;

declare const FC_HINT_FULL: number;

declare const FC_HINT_MEDIUM: number;

declare const FC_HINT_NONE: number;

declare const FC_HINT_SLIGHT: number;

declare const FC_HINT_STYLE: string;

declare const FC_INDEX: string;

declare const FC_LANG: string;

declare const FC_LCD_DEFAULT: number;

declare const FC_LCD_FILTER: string;

declare const FC_LCD_LEGACY: number;

declare const FC_LCD_LIGHT: number;

declare const FC_LCD_NONE: number;

declare const FC_MAJOR: number;

declare const FC_MATRIX: string;

declare const FC_MINOR: number;

declare const FC_MINSPACE: string;

declare const FC_MONO: number;

declare const FC_NAMED_INSTANCE: string;

declare const FC_NAMELANG: string;

declare const FC_ORDER: string;

declare const FC_OUTLINE: string;

declare const FC_PIXEL_SIZE: string;

declare const FC_POSTSCRIPT_NAME: string;

declare const FC_PRGNAME: string;

declare const FC_PROPORTIONAL: number;

declare const FC_RASTERIZER: string;

declare const FC_REVISION: number;

declare const FC_RGBA: string;

declare const FC_RGBA_BGR: number;

declare const FC_RGBA_NONE: number;

declare const FC_RGBA_RGB: number;

declare const FC_RGBA_UNKNOWN: number;

declare const FC_RGBA_VBGR: number;

declare const FC_RGBA_VRGB: number;

declare const FC_SCALABLE: string;

declare const FC_SCALE: string;

declare const FC_SIZE: string;

declare const FC_SLANT: string;

declare const FC_SLANT_ITALIC: number;

declare const FC_SLANT_OBLIQUE: number;

declare const FC_SLANT_ROMAN: number;

declare const FC_SOURCE: string;

declare const FC_SPACING: string;

declare const FC_STYLE: string;

declare const FC_STYLELANG: string;

declare const FC_SYMBOL: string;

declare const FC_USER_CACHE_FILE: string;

declare const FC_UTF8_MAX_LEN: number;

declare const FC_VARIABLE: string;

declare const FC_VERSION: number;

declare const FC_VERTICAL_LAYOUT: string;

declare const FC_WEIGHT: string;

declare const FC_WEIGHT_BLACK: number;

declare const FC_WEIGHT_BOLD: number;

declare const FC_WEIGHT_BOOK: number;

declare const FC_WEIGHT_DEMIBOLD: number;

declare const FC_WEIGHT_DEMILIGHT: number;

declare const FC_WEIGHT_EXTRABLACK: number;

declare const FC_WEIGHT_EXTRABOLD: number;

declare const FC_WEIGHT_EXTRALIGHT: number;

declare const FC_WEIGHT_HEAVY: number;

declare const FC_WEIGHT_LIGHT: number;

declare const FC_WEIGHT_MEDIUM: number;

declare const FC_WEIGHT_NORMAL: number;

declare const FC_WEIGHT_REGULAR: number;

declare const FC_WEIGHT_SEMIBOLD: number;

declare const FC_WEIGHT_SEMILIGHT: number;

declare const FC_WEIGHT_THIN: number;

declare const FC_WEIGHT_ULTRABLACK: number;

declare const FC_WEIGHT_ULTRABOLD: number;

declare const FC_WEIGHT_ULTRALIGHT: number;

declare const FC_WIDTH: string;

declare const FC_WIDTH_CONDENSED: number;

declare const FC_WIDTH_EXPANDED: number;

declare const FC_WIDTH_EXTRACONDENSED: number;

declare const FC_WIDTH_EXTRAEXPANDED: number;

declare const FC_WIDTH_NORMAL: number;

declare const FC_WIDTH_SEMICONDENSED: number;

declare const FC_WIDTH_SEMIEXPANDED: number;

declare const FC_WIDTH_ULTRACONDENSED: number;

declare const FC_WIDTH_ULTRAEXPANDED: number;

interface FcAtomic {
}
declare var FcAtomic: interop.StructType<FcAtomic>;

declare function FcAtomicCreate(file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcAtomic> | null;

declare function FcAtomicDeleteNew(atomic: interop.Pointer | interop.Reference<FcAtomic> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcAtomicDestroy(atomic: interop.Pointer | interop.Reference<FcAtomic> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcAtomicLock(atomic: interop.Pointer | interop.Reference<FcAtomic> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcAtomicNewFile(atomic: interop.Pointer | interop.Reference<FcAtomic> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function FcAtomicOrigFile(atomic: interop.Pointer | interop.Reference<FcAtomic> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function FcAtomicReplaceOrig(atomic: interop.Pointer | interop.Reference<FcAtomic> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcAtomicUnlock(atomic: interop.Pointer | interop.Reference<FcAtomic> | ArrayBufferLike | ArrayBufferView | null): void;

interface FcBlanks {
}
declare var FcBlanks: interop.StructType<FcBlanks>;

declare function FcBlanksAdd(b: interop.Pointer | interop.Reference<FcBlanks> | ArrayBufferLike | ArrayBufferView | null, ucs4: number): number;

declare function FcBlanksCreate(): interop.Pointer | interop.Reference<FcBlanks> | null;

declare function FcBlanksDestroy(b: interop.Pointer | interop.Reference<FcBlanks> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcBlanksIsMember(b: interop.Pointer | interop.Reference<FcBlanks> | ArrayBufferLike | ArrayBufferView | null, ucs4: number): number;

interface FcCache {
}
declare var FcCache: interop.StructType<FcCache>;

declare function FcCacheCopySet(c: interop.Pointer | interop.Reference<FcCache> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcFontSet> | null;

declare function FcCacheCreateTagFile(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcCacheDir(c: interop.Pointer | interop.Reference<FcCache> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function FcCacheNumFont(c: interop.Pointer | interop.Reference<FcCache> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcCacheNumSubdir(c: interop.Pointer | interop.Reference<FcCache> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcCacheSubdir(c: interop.Pointer | interop.Reference<FcCache> | ArrayBufferLike | ArrayBufferView | null, i: number): string | null;

interface FcCharSet {
}
declare var FcCharSet: interop.StructType<FcCharSet>;

declare function FcCharSetAddChar(fcs: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, ucs4: number): number;

declare function FcCharSetCopy(src: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcCharSet> | null;

declare function FcCharSetCount(a: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcCharSetCoverage(a: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, page: number, result: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcCharSetCreate(): interop.Pointer | interop.Reference<FcCharSet> | null;

declare function FcCharSetDelChar(fcs: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, ucs4: number): number;

declare function FcCharSetDestroy(fcs: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcCharSetEqual(a: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, b: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcCharSetFirstPage(a: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, map: interop.Reference<number>, next: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcCharSetHasChar(fcs: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, ucs4: number): number;

declare function FcCharSetIntersect(a: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, b: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcCharSet> | null;

declare function FcCharSetIntersectCount(a: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, b: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcCharSetIsSubset(a: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, b: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcCharSetMerge(a: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, b: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, changed: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcCharSetNew(): interop.Pointer | interop.Reference<FcCharSet> | null;

declare function FcCharSetNextPage(a: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, map: interop.Reference<number>, next: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcCharSetSubtract(a: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, b: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcCharSet> | null;

declare function FcCharSetSubtractCount(a: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, b: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcCharSetUnion(a: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null, b: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcCharSet> | null;

interface FcConfig {
}
declare var FcConfig: interop.StructType<FcConfig>;

declare function FcConfigAppFontAddDir(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, dir: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcConfigAppFontAddFile(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcConfigAppFontClear(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcConfigBuildFonts(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcConfigCreate(): interop.Pointer | interop.Reference<FcConfig> | null;

declare function FcConfigDestroy(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcConfigEnableHome(enable: number): number;

interface FcConfigFileInfoIter {
	dummy1: interop.Pointer | interop.Reference<any> | null;
	dummy2: interop.Pointer | interop.Reference<any> | null;
	dummy3: interop.Pointer | interop.Reference<any> | null;
}
declare var FcConfigFileInfoIter: interop.StructType<FcConfigFileInfoIter>;

declare function FcConfigFileInfoIterGet(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, iter: interop.Pointer | interop.Reference<FcConfigFileInfoIter> | ArrayBufferLike | ArrayBufferView | null, name: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, description: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, enabled: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcConfigFileInfoIterInit(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, iter: interop.Pointer | interop.Reference<FcConfigFileInfoIter> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcConfigFileInfoIterNext(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, iter: interop.Pointer | interop.Reference<FcConfigFileInfoIter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcConfigFilename(url: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function FcConfigGetBlanks(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcBlanks> | null;

declare function FcConfigGetCache(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function FcConfigGetCacheDirs(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcStrList> | null;

declare function FcConfigGetConfigDirs(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcStrList> | null;

declare function FcConfigGetConfigFiles(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcStrList> | null;

declare function FcConfigGetCurrent(): interop.Pointer | interop.Reference<FcConfig> | null;

declare function FcConfigGetFilename(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, url: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function FcConfigGetFontDirs(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcStrList> | null;

declare function FcConfigGetFonts(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, set: FcSetName): interop.Pointer | interop.Reference<FcFontSet> | null;

declare function FcConfigGetRescanInterval(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcConfigGetSysRoot(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function FcConfigHome(): interop.Pointer | interop.Reference<any> | null;

declare function FcConfigParseAndLoad(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, complain: number): number;

declare function FcConfigParseAndLoadFromMemory(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, buffer: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, complain: number): number;

declare function FcConfigReference(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcConfig> | null;

declare function FcConfigSetCurrent(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcConfigSetRescanInterval(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, rescanInterval: number): number;

declare function FcConfigSetSysRoot(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, sysroot: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcConfigSubstitute(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, kind: FcMatchKind): number;

declare function FcConfigSubstituteWithPat(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, p_pat: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, kind: FcMatchKind): number;

declare function FcConfigUptoDate(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): number;

interface FcConstant {
	name: string | null;
	object: string | null;
	value: number;
}
declare var FcConstant: interop.StructType<FcConstant>;

declare function FcDefaultSubstitute(pattern: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcDirCacheClean(cache_dir: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, verbose: number): number;

declare function FcDirCacheCreateUUID(dir: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, force: number, config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcDirCacheDeleteUUID(dir: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcDirCacheLoad(dir: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, cache_file: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcCache> | null;

declare function FcDirCacheLoadFile(cache_file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, file_stat: interop.Pointer | interop.Reference<statStruct> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcCache> | null;

declare function FcDirCacheRead(dir: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, force: number, config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcCache> | null;

declare function FcDirCacheRescan(dir: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcCache> | null;

declare function FcDirCacheUnlink(dir: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcDirCacheUnload(cache: interop.Pointer | interop.Reference<FcCache> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcDirCacheValid(cache_file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcDirSave(set: interop.Pointer | interop.Reference<FcFontSet> | ArrayBufferLike | ArrayBufferView | null, dirs: interop.Pointer | interop.Reference<FcStrSet> | ArrayBufferLike | ArrayBufferView | null, dir: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcDirScan(set: interop.Pointer | interop.Reference<FcFontSet> | ArrayBufferLike | ArrayBufferView | null, dirs: interop.Pointer | interop.Reference<FcStrSet> | ArrayBufferLike | ArrayBufferView | null, cache: interop.Pointer | interop.Reference<FcFileCache> | ArrayBufferLike | ArrayBufferView | null, blanks: interop.Pointer | interop.Reference<FcBlanks> | ArrayBufferLike | ArrayBufferView | null, dir: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, force: number): number;

declare const FcDontCare: number;

declare const enum FcEndian {

	FcEndianBig = 0,

	FcEndianLittle = 1
}

declare const FcFalse: number;

interface FcFileCache {
}
declare var FcFileCache: interop.StructType<FcFileCache>;

declare function FcFileIsDir(file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcFileScan(set: interop.Pointer | interop.Reference<FcFontSet> | ArrayBufferLike | ArrayBufferView | null, dirs: interop.Pointer | interop.Reference<FcStrSet> | ArrayBufferLike | ArrayBufferView | null, cache: interop.Pointer | interop.Reference<FcFileCache> | ArrayBufferLike | ArrayBufferView | null, blanks: interop.Pointer | interop.Reference<FcBlanks> | ArrayBufferLike | ArrayBufferView | null, file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, force: number): number;

declare function FcFini(): void;

declare function FcFontList(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, os: interop.Pointer | interop.Reference<FcObjectSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcFontSet> | null;

declare function FcFontMatch(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, result: interop.Pointer | interop.Reference<FcResult> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcPattern> | null;

declare function FcFontRenderPrepare(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, pat: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, font: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcPattern> | null;

interface FcFontSet {
	nfont: number;
	sfont: number;
	fonts: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FcPattern> | null> | null;
}
declare var FcFontSet: interop.StructType<FcFontSet>;

declare function FcFontSetAdd(s: interop.Pointer | interop.Reference<FcFontSet> | ArrayBufferLike | ArrayBufferView | null, font: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcFontSetCreate(): interop.Pointer | interop.Reference<FcFontSet> | null;

declare function FcFontSetDestroy(s: interop.Pointer | interop.Reference<FcFontSet> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcFontSetList(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, sets: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FcFontSet> | null> | ArrayBufferLike | ArrayBufferView | null, nsets: number, p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, os: interop.Pointer | interop.Reference<FcObjectSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcFontSet> | null;

declare function FcFontSetMatch(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, sets: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FcFontSet> | null> | ArrayBufferLike | ArrayBufferView | null, nsets: number, p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, result: interop.Pointer | interop.Reference<FcResult> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcPattern> | null;

declare function FcFontSetPrint(s: interop.Pointer | interop.Reference<FcFontSet> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcFontSetSort(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, sets: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FcFontSet> | null> | ArrayBufferLike | ArrayBufferView | null, nsets: number, p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, trim: number, csp: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FcCharSet> | null> | ArrayBufferLike | ArrayBufferView | null, result: interop.Pointer | interop.Reference<FcResult> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcFontSet> | null;

declare function FcFontSetSortDestroy(fs: interop.Pointer | interop.Reference<FcFontSet> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcFontSort(config: interop.Pointer | interop.Reference<FcConfig> | ArrayBufferLike | ArrayBufferView | null, p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, trim: number, csp: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FcCharSet> | null> | ArrayBufferLike | ArrayBufferView | null, result: interop.Pointer | interop.Reference<FcResult> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcFontSet> | null;

declare function FcFreeTypeQuery(file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, id: number, blanks: interop.Pointer | interop.Reference<FcBlanks> | ArrayBufferLike | ArrayBufferView | null, count: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcPattern> | null;

declare function FcFreeTypeQueryAll(file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, id: number, blanks: interop.Pointer | interop.Reference<FcBlanks> | ArrayBufferLike | ArrayBufferView | null, count: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, set: interop.Pointer | interop.Reference<FcFontSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcGetDefaultLangs(): interop.Pointer | interop.Reference<FcStrSet> | null;

declare function FcGetLangs(): interop.Pointer | interop.Reference<FcStrSet> | null;

declare function FcGetVersion(): number;

declare function FcInit(): number;

declare function FcInitBringUptoDate(): number;

declare function FcInitLoadConfig(): interop.Pointer | interop.Reference<FcConfig> | null;

declare function FcInitLoadConfigAndFonts(): interop.Pointer | interop.Reference<FcConfig> | null;

declare function FcInitReinitialize(): number;

declare function FcLangGetCharSet(lang: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcCharSet> | null;

declare function FcLangNormalize(lang: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare const enum FcLangResult {

	FcLangEqual = 0,

	FcLangDifferentCountry = 1,

	FcLangDifferentTerritory = 1,

	FcLangDifferentLang = 2
}

interface FcLangSet {
}
declare var FcLangSet: interop.StructType<FcLangSet>;

declare function FcLangSetAdd(ls: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null, lang: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcLangSetCompare(lsa: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null, lsb: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null): FcLangResult;

declare function FcLangSetContains(lsa: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null, lsb: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcLangSetCopy(ls: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcLangSet> | null;

declare function FcLangSetCreate(): interop.Pointer | interop.Reference<FcLangSet> | null;

declare function FcLangSetDel(ls: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null, lang: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcLangSetDestroy(ls: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcLangSetEqual(lsa: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null, lsb: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcLangSetGetLangs(ls: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcStrSet> | null;

declare function FcLangSetHasLang(ls: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null, lang: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): FcLangResult;

declare function FcLangSetHash(ls: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcLangSetSubtract(a: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null, b: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcLangSet> | null;

declare function FcLangSetUnion(a: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null, b: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcLangSet> | null;

declare const enum FcMatchKind {

	FcMatchPattern = 0,

	FcMatchFont = 1,

	FcMatchScan = 2,

	FcMatchKindEnd = 3,

	FcMatchKindBegin = 0
}

interface FcMatrix {
	xx: number;
	xy: number;
	yx: number;
	yy: number;
}
declare var FcMatrix: interop.StructType<FcMatrix>;

declare function FcMatrixCopy(mat: interop.Pointer | interop.Reference<FcMatrix> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcMatrix> | null;

declare function FcMatrixEqual(mat1: interop.Pointer | interop.Reference<FcMatrix> | ArrayBufferLike | ArrayBufferView | null, mat2: interop.Pointer | interop.Reference<FcMatrix> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcMatrixMultiply(result: interop.Pointer | interop.Reference<FcMatrix> | ArrayBufferLike | ArrayBufferView | null, a: interop.Pointer | interop.Reference<FcMatrix> | ArrayBufferLike | ArrayBufferView | null, b: interop.Pointer | interop.Reference<FcMatrix> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcMatrixRotate(m: interop.Pointer | interop.Reference<FcMatrix> | ArrayBufferLike | ArrayBufferView | null, c: number, s: number): void;

declare function FcMatrixScale(m: interop.Pointer | interop.Reference<FcMatrix> | ArrayBufferLike | ArrayBufferView | null, sx: number, sy: number): void;

declare function FcMatrixShear(m: interop.Pointer | interop.Reference<FcMatrix> | ArrayBufferLike | ArrayBufferView | null, sh: number, sv: number): void;

declare function FcNameConstant(string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, result: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcNameGetConstant(string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcConstant> | null;

declare function FcNameGetConstantFor(string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcConstant> | null;

declare function FcNameGetObjectType(object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcObjectType> | null;

declare function FcNameParse(name: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcPattern> | null;

declare function FcNameRegisterConstants(consts: interop.Pointer | interop.Reference<FcConstant> | ArrayBufferLike | ArrayBufferView | null, nconsts: number): number;

declare function FcNameRegisterObjectTypes(types: interop.Pointer | interop.Reference<FcObjectType> | ArrayBufferLike | ArrayBufferView | null, ntype: number): number;

declare function FcNameUnparse(pat: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function FcNameUnregisterConstants(consts: interop.Pointer | interop.Reference<FcConstant> | ArrayBufferLike | ArrayBufferView | null, nconsts: number): number;

declare function FcNameUnregisterObjectTypes(types: interop.Pointer | interop.Reference<FcObjectType> | ArrayBufferLike | ArrayBufferView | null, ntype: number): number;

interface FcObjectSet {
	nobject: number;
	sobject: number;
	objects: interop.Pointer | interop.Reference<string | null> | null;
}
declare var FcObjectSet: interop.StructType<FcObjectSet>;

declare function FcObjectSetAdd(os: interop.Pointer | interop.Reference<FcObjectSet> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcObjectSetBuild(first: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): interop.Pointer | interop.Reference<FcObjectSet> | null;

declare function FcObjectSetCreate(): interop.Pointer | interop.Reference<FcObjectSet> | null;

declare function FcObjectSetDestroy(os: interop.Pointer | interop.Reference<FcObjectSet> | ArrayBufferLike | ArrayBufferView | null): void;

interface FcObjectType {
	object: interop.Pointer | interop.Reference<any> | null;
	type: FcType;
}
declare var FcObjectType: interop.StructType<FcObjectType>;

interface FcPattern {
}
declare var FcPattern: interop.StructType<FcPattern>;

declare function FcPatternAdd(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: FcValue, append: number): number;

declare function FcPatternAddBool(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, b: number): number;

declare function FcPatternAddCharSet(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, c: interop.Pointer | interop.Reference<FcCharSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcPatternAddDouble(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, d: number): number;

declare function FcPatternAddInteger(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, i: number): number;

declare function FcPatternAddLangSet(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ls: interop.Pointer | interop.Reference<FcLangSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcPatternAddMatrix(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, s: interop.Pointer | interop.Reference<FcMatrix> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcPatternAddRange(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, r: interop.Pointer | interop.Reference<FcRange> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcPatternAddString(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcPatternAddWeak(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, value: FcValue, append: number): number;

declare function FcPatternBuild(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): interop.Pointer | interop.Reference<FcPattern> | null;

declare function FcPatternCreate(): interop.Pointer | interop.Reference<FcPattern> | null;

declare function FcPatternDel(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcPatternDestroy(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcPatternDuplicate(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcPattern> | null;

declare function FcPatternEqual(pa: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, pb: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcPatternEqualSubset(pa: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, pb: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, os: interop.Pointer | interop.Reference<FcObjectSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcPatternFilter(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, os: interop.Pointer | interop.Reference<FcObjectSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcPattern> | null;

declare function FcPatternFindIter(pat: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, iter: interop.Pointer | interop.Reference<FcPatternIter> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcPatternFormat(pat: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, format: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function FcPatternGet(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, id: number, v: interop.Pointer | interop.Reference<FcValue> | ArrayBufferLike | ArrayBufferView | null): FcResult;

declare function FcPatternGetBool(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, n: number, b: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): FcResult;

declare function FcPatternGetCharSet(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, n: number, c: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FcCharSet> | null> | ArrayBufferLike | ArrayBufferView | null): FcResult;

declare function FcPatternGetDouble(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, n: number, d: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): FcResult;

declare function FcPatternGetInteger(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, n: number, i: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): FcResult;

declare function FcPatternGetLangSet(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, n: number, ls: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FcLangSet> | null> | ArrayBufferLike | ArrayBufferView | null): FcResult;

declare function FcPatternGetMatrix(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, n: number, s: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FcMatrix> | null> | ArrayBufferLike | ArrayBufferView | null): FcResult;

declare function FcPatternGetRange(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, id: number, r: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<FcRange> | null> | ArrayBufferLike | ArrayBufferView | null): FcResult;

declare function FcPatternGetString(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, n: number, s: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): FcResult;

declare function FcPatternGetWithBinding(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, id: number, v: interop.Pointer | interop.Reference<FcValue> | ArrayBufferLike | ArrayBufferView | null, b: interop.Pointer | interop.Reference<FcValueBinding> | ArrayBufferLike | ArrayBufferView | null): FcResult;

declare function FcPatternHash(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null): number;

interface FcPatternIter {
	dummy1: interop.Pointer | interop.Reference<any> | null;
	dummy2: interop.Pointer | interop.Reference<any> | null;
}
declare var FcPatternIter: interop.StructType<FcPatternIter>;

declare function FcPatternIterEqual(p1: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, i1: interop.Pointer | interop.Reference<FcPatternIter> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, i2: interop.Pointer | interop.Reference<FcPatternIter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcPatternIterGetObject(pat: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, iter: interop.Pointer | interop.Reference<FcPatternIter> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function FcPatternIterGetValue(pat: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, iter: interop.Pointer | interop.Reference<FcPatternIter> | ArrayBufferLike | ArrayBufferView | null, id: number, v: interop.Pointer | interop.Reference<FcValue> | ArrayBufferLike | ArrayBufferView | null, b: interop.Pointer | interop.Reference<FcValueBinding> | ArrayBufferLike | ArrayBufferView | null): FcResult;

declare function FcPatternIterIsValid(pat: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, iter: interop.Pointer | interop.Reference<FcPatternIter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcPatternIterNext(pat: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, iter: interop.Pointer | interop.Reference<FcPatternIter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcPatternIterStart(pat: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, iter: interop.Pointer | interop.Reference<FcPatternIter> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcPatternIterValueCount(pat: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, iter: interop.Pointer | interop.Reference<FcPatternIter> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcPatternObjectCount(pat: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcPatternPrint(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcPatternReference(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcPatternRemove(p: interop.Pointer | interop.Reference<FcPattern> | ArrayBufferLike | ArrayBufferView | null, object: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, id: number): number;

interface FcRange {
}
declare var FcRange: interop.StructType<FcRange>;

declare function FcRangeCopy(r: interop.Pointer | interop.Reference<FcRange> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcRange> | null;

declare function FcRangeCreateDouble(begin: number, end: number): interop.Pointer | interop.Reference<FcRange> | null;

declare function FcRangeCreateInteger(begin: number, end: number): interop.Pointer | interop.Reference<FcRange> | null;

declare function FcRangeDestroy(range: interop.Pointer | interop.Reference<FcRange> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcRangeGetDouble(range: interop.Pointer | interop.Reference<FcRange> | ArrayBufferLike | ArrayBufferView | null, begin: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, end: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare const enum FcResult {

	FcResultMatch = 0,

	FcResultNoMatch = 1,

	FcResultTypeMismatch = 2,

	FcResultNoId = 3,

	FcResultOutOfMemory = 4
}

declare const enum FcSetName {

	FcSetSystem = 0,

	FcSetApplication = 1
}

declare function FcStrBasename(file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function FcStrBuildFilename(path: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): interop.Pointer | interop.Reference<any> | null;

declare function FcStrCmp(s1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, s2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcStrCmpIgnoreCase(s1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, s2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcStrCopy(s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function FcStrCopyFilename(s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function FcStrDirname(file: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function FcStrDowncase(s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function FcStrFree(s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

interface FcStrList {
}
declare var FcStrList: interop.StructType<FcStrList>;

declare function FcStrListCreate(set: interop.Pointer | interop.Reference<FcStrSet> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<FcStrList> | null;

declare function FcStrListDone(list: interop.Pointer | interop.Reference<FcStrList> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcStrListFirst(list: interop.Pointer | interop.Reference<FcStrList> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcStrListNext(list: interop.Pointer | interop.Reference<FcStrList> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function FcStrPlus(s1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, s2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

interface FcStrSet {
}
declare var FcStrSet: interop.StructType<FcStrSet>;

declare function FcStrSetAdd(set: interop.Pointer | interop.Reference<FcStrSet> | ArrayBufferLike | ArrayBufferView | null, s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcStrSetAddFilename(set: interop.Pointer | interop.Reference<FcStrSet> | ArrayBufferLike | ArrayBufferView | null, s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcStrSetCreate(): interop.Pointer | interop.Reference<FcStrSet> | null;

declare function FcStrSetDel(set: interop.Pointer | interop.Reference<FcStrSet> | ArrayBufferLike | ArrayBufferView | null, s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcStrSetDestroy(set: interop.Pointer | interop.Reference<FcStrSet> | ArrayBufferLike | ArrayBufferView | null): void;

declare function FcStrSetEqual(sa: interop.Pointer | interop.Reference<FcStrSet> | ArrayBufferLike | ArrayBufferView | null, sb: interop.Pointer | interop.Reference<FcStrSet> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcStrSetMember(set: interop.Pointer | interop.Reference<FcStrSet> | ArrayBufferLike | ArrayBufferView | null, s: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcStrStr(s1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, s2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare function FcStrStrIgnoreCase(s1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, s2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): string | null;

declare const FcTrue: number;

declare const enum FcType {

	FcTypeUnknown = -1,

	FcTypeVoid = 0,

	FcTypeInteger = 1,

	FcTypeDouble = 2,

	FcTypeString = 3,

	FcTypeBool = 4,

	FcTypeMatrix = 5,

	FcTypeCharSet = 6,

	FcTypeFTFace = 7,

	FcTypeLangSet = 8,

	FcTypeRange = 9
}

declare function FcUcs4ToUtf8(ucs4: number, dest: interop.Reference<number>): number;

declare function FcUtf16Len(string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, endian: FcEndian, len: number, nchar: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, wchar: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcUtf16ToUcs4(src_orig: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, endian: FcEndian, dst: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function FcUtf8Len(string: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number, nchar: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, wchar: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function FcUtf8ToUcs4(src_orig: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, dst: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

interface FcValue {
	type: FcType;
	u: { s: string | null; i: number; b: number; d: number; m: interop.Pointer | interop.Reference<FcMatrix> | null; c: interop.Pointer | interop.Reference<FcCharSet> | null; f: interop.Pointer | interop.Reference<any> | null; l: interop.Pointer | interop.Reference<FcLangSet> | null; r: interop.Pointer | interop.Reference<FcRange> | null; };
}
declare var FcValue: interop.StructType<FcValue>;

declare const enum FcValueBinding {

	FcValueBindingWeak = 0,

	FcValueBindingStrong = 1,

	FcValueBindingSame = 2,

	FcValueBindingEnd = 2147483647
}

declare function FcValueDestroy(v: FcValue): void;

declare function FcValueEqual(va: FcValue, vb: FcValue): number;

declare function FcValuePrint(v: FcValue): void;

declare function FcValueSave(v: FcValue): FcValue;

declare function FcWeightFromOpenType(ot_weight: number): number;

declare function FcWeightFromOpenTypeDouble(ot_weight: number): number;

declare function FcWeightToOpenType(fc_weight: number): number;

declare function FcWeightToOpenTypeDouble(fc_weight: number): number;
