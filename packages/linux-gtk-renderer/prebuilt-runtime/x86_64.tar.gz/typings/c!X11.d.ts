
declare const Above: number;

declare const AllHints: number;

declare const AllPlanes: bigint;

declare const AllTemporary: number;

declare const AllValues: number;

declare const AllocAll: number;

declare const AllocNone: number;

declare const AllowExposures: number;

declare const AlreadyGrabbed: number;

declare const Always: number;

declare const AnyButton: number;

declare const AnyKey: number;

declare const AnyModifier: number;

declare const AnyPropertyType: number;

declare const ArcChord: number;

declare const ArcPieSlice: number;

declare const AsyncBoth: number;

declare const AsyncKeyboard: number;

declare const AsyncPointer: number;

declare const AutoRepeatModeDefault: number;

declare const AutoRepeatModeOff: number;

declare const AutoRepeatModeOn: number;

declare const BadAccess: number;

declare const BadAlloc: number;

declare const BadAtom: number;

declare const BadColor: number;

declare const BadCursor: number;

declare const BadDrawable: number;

declare const BadFont: number;

declare const BadGC: number;

declare const BadIDChoice: number;

declare const BadImplementation: number;

declare const BadLength: number;

declare const BadMatch: number;

declare const BadName: number;

declare const BadPixmap: number;

declare const BadRequest: number;

declare const BadValue: number;

declare const BadWindow: number;

declare const Below: number;

declare const BitmapFileInvalid: number;

declare const BitmapNoMemory: number;

declare const BitmapOpenFailed: number;

declare const BitmapSuccess: number;

declare const BottomIf: number;

declare const Button1: number;

declare const Button1Mask: number;

declare const Button1MotionMask: number;

declare const Button2: number;

declare const Button2Mask: number;

declare const Button2MotionMask: number;

declare const Button3: number;

declare const Button3Mask: number;

declare const Button3MotionMask: number;

declare const Button4: number;

declare const Button4Mask: number;

declare const Button4MotionMask: number;

declare const Button5: number;

declare const Button5Mask: number;

declare const Button5MotionMask: number;

declare const ButtonMotionMask: number;

declare const ButtonPress: number;

declare const ButtonPressMask: number;

declare const ButtonRelease: number;

declare const ButtonReleaseMask: number;

declare const CWBackPixel: number;

declare const CWBackPixmap: number;

declare const CWBackingPixel: number;

declare const CWBackingPlanes: number;

declare const CWBackingStore: number;

declare const CWBitGravity: number;

declare const CWBorderPixel: number;

declare const CWBorderPixmap: number;

declare const CWBorderWidth: number;

declare const CWColormap: number;

declare const CWCursor: number;

declare const CWDontPropagate: number;

declare const CWEventMask: number;

declare const CWHeight: number;

declare const CWOverrideRedirect: number;

declare const CWSaveUnder: number;

declare const CWSibling: number;

declare const CWStackMode: number;

declare const CWWidth: number;

declare const CWWinGravity: number;

declare const CWX: number;

declare const CWY: number;

declare const CapButt: number;

declare const CapNotLast: number;

declare const CapProjecting: number;

declare const CapRound: number;

declare const CenterGravity: number;

declare const CirculateNotify: number;

declare const CirculateRequest: number;

declare const ClientMessage: number;

declare const ClipByChildren: number;

declare const ColormapChangeMask: number;

declare const ColormapInstalled: number;

declare const ColormapNotify: number;

declare const ColormapUninstalled: number;

declare const Complex: number;

declare const ConfigureNotify: number;

declare const ConfigureRequest: number;

declare const ControlMapIndex: number;

declare const ControlMask: number;

declare const Convex: number;

declare const CoordModeOrigin: number;

declare const CoordModePrevious: number;

declare const CopyFromParent: number;

declare const CreateNotify: number;

declare const CurrentTime: number;

declare const CursorShape: number;

declare const DefaultBlanking: number;

declare const DefaultExposures: number;

interface Depth {
	depth: number;
	nvisuals: number;
	visuals: interop.Pointer | interop.Reference<Visual> | null;
}
declare var Depth: interop.StructType<Depth>;

declare const DestroyAll: number;

declare const DestroyNotify: number;

declare const DirectColor: number;

declare const DisableAccess: number;

declare const DisableScreenInterval: number;

declare const DisableScreenSaver: number;

interface Display {
}
declare var Display: interop.StructType<Display>;

/** Struct tag of {@link Display}. */
type _XDisplay = Display;
declare var _XDisplay: typeof Display;

declare const DoBlue: number;

declare const DoGreen: number;

declare const DoRed: number;

declare const DontAllowExposures: number;

declare const DontCareState: number;

declare const DontPreferBlanking: number;

declare const EastGravity: number;

declare const EnableAccess: number;

declare const EnterNotify: number;

declare const EnterWindowMask: number;

declare const EvenOddRule: number;

declare const Expose: number;

declare const ExposureMask: number;

declare const FUNCPROTO: number;

declare const False: number;

declare const FamilyChaos: number;

declare const FamilyDECnet: number;

declare const FamilyInternet: number;

declare const FamilyInternet6: number;

declare const FamilyServerInterpreted: number;

declare const FillOpaqueStippled: number;

declare const FillSolid: number;

declare const FillStippled: number;

declare const FillTiled: number;

declare const FirstExtensionError: number;

declare const FocusChangeMask: number;

declare const FocusIn: number;

declare const FocusOut: number;

declare const FontChange: number;

declare const FontLeftToRight: number;

declare const FontRightToLeft: number;

declare const ForgetGravity: number;

declare const GCArcMode: number;

declare const GCBackground: number;

declare const GCCapStyle: number;

declare const GCClipMask: number;

declare const GCClipXOrigin: number;

declare const GCClipYOrigin: number;

declare const GCDashList: number;

declare const GCDashOffset: number;

declare const GCFillRule: number;

declare const GCFillStyle: number;

declare const GCFont: number;

declare const GCForeground: number;

declare const GCFunction: number;

declare const GCGraphicsExposures: number;

declare const GCJoinStyle: number;

declare const GCLastBit: number;

declare const GCLineStyle: number;

declare const GCLineWidth: number;

declare const GCPlaneMask: number;

declare const GCStipple: number;

declare const GCSubwindowMode: number;

declare const GCTile: number;

declare const GCTileStipXOrigin: number;

declare const GCTileStipYOrigin: number;

declare const GXand: number;

declare const GXandInverted: number;

declare const GXandReverse: number;

declare const GXclear: number;

declare const GXcopy: number;

declare const GXcopyInverted: number;

declare const GXequiv: number;

declare const GXinvert: number;

declare const GXnand: number;

declare const GXnoop: number;

declare const GXnor: number;

declare const GXor: number;

declare const GXorInverted: number;

declare const GXorReverse: number;

declare const GXset: number;

declare const GXxor: number;

declare const GenericEvent: number;

declare const GrabFrozen: number;

declare const GrabInvalidTime: number;

declare const GrabModeAsync: number;

declare const GrabModeSync: number;

declare const GrabNotViewable: number;

declare const GrabSuccess: number;

declare const GraphicsExpose: number;

declare const GravityNotify: number;

declare const GrayScale: number;

declare const HeightValue: number;

declare const HostDelete: number;

declare const HostInsert: number;

declare const IconMaskHint: number;

declare const IconPixmapHint: number;

declare const IconPositionHint: number;

declare const IconWindowHint: number;

declare const IconicState: number;

declare const InactiveState: number;

declare const IncludeInferiors: number;

declare const InputFocus: number;

declare const InputHint: number;

declare const InputOnly: number;

declare const InputOutput: number;

declare const IsUnmapped: number;

declare const IsUnviewable: number;

declare const IsViewable: number;

declare const JoinBevel: number;

declare const JoinMiter: number;

declare const JoinRound: number;

declare const KBAutoRepeatMode: number;

declare const KBBellDuration: number;

declare const KBBellPercent: number;

declare const KBBellPitch: number;

declare const KBKey: number;

declare const KBKeyClickPercent: number;

declare const KBLed: number;

declare const KBLedMode: number;

declare const KeyPress: number;

declare const KeyPressMask: number;

declare const KeyRelease: number;

declare const KeyReleaseMask: number;

declare const KeymapNotify: number;

declare const KeymapStateMask: number;

declare const LASTEvent: number;

declare const LSBFirst: number;

declare const LastExtensionError: number;

declare const LeaveNotify: number;

declare const LeaveWindowMask: number;

declare const LedModeOff: number;

declare const LedModeOn: number;

declare const LineDoubleDash: number;

declare const LineOnOffDash: number;

declare const LineSolid: number;

declare const LockMapIndex: number;

declare const LockMask: number;

declare const LowerHighest: number;

declare const MSBFirst: number;

declare const MapNotify: number;

declare const MapRequest: number;

declare const MappingBusy: number;

declare const MappingFailed: number;

declare const MappingKeyboard: number;

declare const MappingModifier: number;

declare const MappingNotify: number;

declare const MappingPointer: number;

declare const MappingSuccess: number;

declare const Mod1MapIndex: number;

declare const Mod1Mask: number;

declare const Mod2MapIndex: number;

declare const Mod2Mask: number;

declare const Mod3MapIndex: number;

declare const Mod3Mask: number;

declare const Mod4MapIndex: number;

declare const Mod4Mask: number;

declare const Mod5MapIndex: number;

declare const Mod5Mask: number;

declare const MotionNotify: number;

declare const NeedFunctionPrototypes: number;

declare const NeedNestedPrototypes: number;

declare const NeedVarargsPrototypes: number;

declare const NeedWidePrototypes: number;

declare const NoEventMask: number;

declare const NoExpose: number;

declare const NoSymbol: number;

declare const NoValue: number;

declare const Nonconvex: number;

declare const None: number;

declare const NormalState: number;

declare const NorthEastGravity: number;

declare const NorthGravity: number;

declare const NorthWestGravity: number;

declare const NotUseful: number;

declare const NotifyAncestor: number;

declare const NotifyDetailNone: number;

declare const NotifyGrab: number;

declare const NotifyHint: number;

declare const NotifyInferior: number;

declare const NotifyNonlinear: number;

declare const NotifyNonlinearVirtual: number;

declare const NotifyNormal: number;

declare const NotifyPointer: number;

declare const NotifyPointerRoot: number;

declare const NotifyUngrab: number;

declare const NotifyVirtual: number;

declare const NotifyWhileGrabbed: number;

declare const Opposite: number;

declare const OwnerGrabButtonMask: number;

declare const PAllHints: number;

declare const PAspect: number;

declare const PBaseSize: number;

declare const PMaxSize: number;

declare const PMinSize: number;

declare const PPosition: number;

declare const PResizeInc: number;

declare const PSize: number;

declare const PWinGravity: number;

declare const ParentRelative: number;

declare const PlaceOnBottom: number;

declare const PlaceOnTop: number;

declare const PointerMotionHintMask: number;

declare const PointerMotionMask: number;

declare const PointerRoot: number;

declare const PointerWindow: number;

declare const PreferBlanking: number;

declare const PropModeAppend: number;

declare const PropModePrepend: number;

declare const PropModeReplace: number;

declare const PropertyChangeMask: number;

declare const PropertyDelete: number;

declare const PropertyNewValue: number;

declare const PropertyNotify: number;

declare const PseudoColor: number;

declare const QueuedAfterFlush: number;

declare const QueuedAfterReading: number;

declare const QueuedAlready: number;

declare const RaiseLowest: number;

declare const RectangleIn: number;

declare const RectangleOut: number;

declare const RectanglePart: number;

declare const ReleaseByFreeingColormap: number;

declare const ReparentNotify: number;

declare const ReplayKeyboard: number;

declare const ReplayPointer: number;

declare const ResizeRedirectMask: number;

declare const ResizeRequest: number;

declare const RetainPermanent: number;

declare const RetainTemporary: number;

declare const RevertToNone: number;

declare const RevertToParent: number;

declare const RevertToPointerRoot: number;

interface Screen {
	ext_data: interop.Pointer | interop.Reference<XExtData> | null;
	display: interop.Pointer | interop.Reference<Display> | null;
	root: number;
	width: number;
	height: number;
	mwidth: number;
	mheight: number;
	ndepths: number;
	depths: interop.Pointer | interop.Reference<Depth> | null;
	root_depth: number;
	root_visual: interop.Pointer | interop.Reference<Visual> | null;
	default_gc: interop.Pointer | interop.Reference<_XGC> | null;
	cmap: number;
	white_pixel: number;
	black_pixel: number;
	max_maps: number;
	min_maps: number;
	backing_store: number;
	save_unders: number;
	root_input_mask: number;
}
declare var Screen: interop.StructType<Screen>;

interface ScreenFormat {
	ext_data: interop.Pointer | interop.Reference<XExtData> | null;
	depth: number;
	bits_per_pixel: number;
	scanline_pad: number;
}
declare var ScreenFormat: interop.StructType<ScreenFormat>;

declare const ScreenSaverActive: number;

declare const ScreenSaverReset: number;

declare const SelectionClear: number;

declare const SelectionNotify: number;

declare const SelectionRequest: number;

declare const SetModeDelete: number;

declare const SetModeInsert: number;

declare const ShiftMapIndex: number;

declare const ShiftMask: number;

declare const SouthEastGravity: number;

declare const SouthGravity: number;

declare const SouthWestGravity: number;

declare const StateHint: number;

declare const StaticColor: number;

declare const StaticGravity: number;

declare const StaticGray: number;

declare const StippleShape: number;

declare const StructureNotifyMask: number;

declare const SubstructureNotifyMask: number;

declare const SubstructureRedirectMask: number;

declare const Success: number;

declare const SyncBoth: number;

declare const SyncKeyboard: number;

declare const SyncPointer: number;

declare const TileShape: number;

declare const TopIf: number;

declare const True: number;

declare const TrueColor: number;

declare const USPosition: number;

declare const USSize: number;

declare const UnmapGravity: number;

declare const UnmapNotify: number;

declare const Unsorted: number;

declare const VisibilityChangeMask: number;

declare const VisibilityFullyObscured: number;

declare const VisibilityNotify: number;

declare const VisibilityPartiallyObscured: number;

declare const VisibilityUnobscured: number;

interface Visual {
	ext_data: interop.Pointer | interop.Reference<XExtData> | null;
	visualid: number;
	class: number;
	red_mask: number;
	green_mask: number;
	blue_mask: number;
	bits_per_rgb: number;
	map_entries: number;
}
declare var Visual: interop.StructType<Visual>;

declare const VisualAllMask: number;

declare const VisualBitsPerRGBMask: number;

declare const VisualBlueMaskMask: number;

declare const VisualClassMask: number;

declare const VisualColormapSizeMask: number;

declare const VisualDepthMask: number;

declare const VisualGreenMaskMask: number;

declare const VisualIDMask: number;

declare const VisualNoMask: number;

declare const VisualRedMaskMask: number;

declare const VisualScreenMask: number;

declare const WestGravity: number;

declare const WhenMapped: number;

declare const WidthValue: number;

declare const WindingRule: number;

declare const WindowGroupHint: number;

declare const WithdrawnState: number;

declare const XATOM_H: number;

declare const XA_ARC: number;

declare const XA_ATOM: number;

declare const XA_BITMAP: number;

declare const XA_CAP_HEIGHT: number;

declare const XA_CARDINAL: number;

declare const XA_COLORMAP: number;

declare const XA_COPYRIGHT: number;

declare const XA_CURSOR: number;

declare const XA_CUT_BUFFER0: number;

declare const XA_CUT_BUFFER1: number;

declare const XA_CUT_BUFFER2: number;

declare const XA_CUT_BUFFER3: number;

declare const XA_CUT_BUFFER4: number;

declare const XA_CUT_BUFFER5: number;

declare const XA_CUT_BUFFER6: number;

declare const XA_CUT_BUFFER7: number;

declare const XA_DRAWABLE: number;

declare const XA_END_SPACE: number;

declare const XA_FAMILY_NAME: number;

declare const XA_FONT: number;

declare const XA_FONT_NAME: number;

declare const XA_FULL_NAME: number;

declare const XA_INTEGER: number;

declare const XA_ITALIC_ANGLE: number;

declare const XA_LAST_PREDEFINED: number;

declare const XA_MAX_SPACE: number;

declare const XA_MIN_SPACE: number;

declare const XA_NORM_SPACE: number;

declare const XA_NOTICE: number;

declare const XA_PIXMAP: number;

declare const XA_POINT: number;

declare const XA_POINT_SIZE: number;

declare const XA_PRIMARY: number;

declare const XA_QUAD_WIDTH: number;

declare const XA_RECTANGLE: number;

declare const XA_RESOLUTION: number;

declare const XA_RESOURCE_MANAGER: number;

declare const XA_RGB_BEST_MAP: number;

declare const XA_RGB_BLUE_MAP: number;

declare const XA_RGB_COLOR_MAP: number;

declare const XA_RGB_DEFAULT_MAP: number;

declare const XA_RGB_GRAY_MAP: number;

declare const XA_RGB_GREEN_MAP: number;

declare const XA_RGB_RED_MAP: number;

declare const XA_SECONDARY: number;

declare const XA_STRIKEOUT_ASCENT: number;

declare const XA_STRIKEOUT_DESCENT: number;

declare const XA_STRING: number;

declare const XA_SUBSCRIPT_X: number;

declare const XA_SUBSCRIPT_Y: number;

declare const XA_SUPERSCRIPT_X: number;

declare const XA_SUPERSCRIPT_Y: number;

declare const XA_UNDERLINE_POSITION: number;

declare const XA_UNDERLINE_THICKNESS: number;

declare const XA_VISUALID: number;

declare const XA_WEIGHT: number;

declare const XA_WINDOW: number;

declare const XA_WM_CLASS: number;

declare const XA_WM_CLIENT_MACHINE: number;

declare const XA_WM_COMMAND: number;

declare const XA_WM_HINTS: number;

declare const XA_WM_ICON_NAME: number;

declare const XA_WM_ICON_SIZE: number;

declare const XA_WM_NAME: number;

declare const XA_WM_NORMAL_HINTS: number;

declare const XA_WM_SIZE_HINTS: number;

declare const XA_WM_TRANSIENT_FOR: number;

declare const XA_WM_ZOOM_HINTS: number;

declare const XA_X_HEIGHT: number;

declare function XActivateScreenSaver(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XAddConnectionWatch(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number, p4: number, p5: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null) => void>, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XAddExtension(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<XExtCodes> | null;

declare function XAddHost(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XHostAddress> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XAddHosts(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XHostAddress> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XAddToExtensionList(p1: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<XExtData> | null> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XExtData> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XAddToSaveSet(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XAllPlanes(): number;

declare function XAllocClassHint(): interop.Pointer | interop.Reference<XClassHint> | null;

declare function XAllocColor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XAllocColorCells(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p7: number): number;

declare function XAllocColorPlanes(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: number, p7: number, p8: number, p9: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p10: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p11: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XAllocIconSize(): interop.Pointer | interop.Reference<XIconSize> | null;

declare function XAllocNamedColor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XAllocSizeHints(): interop.Pointer | interop.Reference<XSizeHints> | null;

declare function XAllocStandardColormap(): interop.Pointer | interop.Reference<XStandardColormap> | null;

declare function XAllocWMHints(): interop.Pointer | interop.Reference<XWMHints> | null;

declare function XAllowEvents(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

interface XAnyEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
}
declare var XAnyEvent: interop.StructType<XAnyEvent>;

interface XArc {
	x: number;
	y: number;
	width: number;
	height: number;
	angle1: number;
	angle2: number;
}
declare var XArc: interop.StructType<XArc>;

declare function XAutoRepeatOff(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XAutoRepeatOn(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XBaseFontNameListOfFontSet(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function XBell(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XBitmapBitOrder(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XBitmapPad(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XBitmapUnit(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XBlackPixel(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XBlackPixelOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

declare const XBufferOverflow: number;

interface XButtonEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
	root: number;
	subwindow: number;
	time: number;
	x: number;
	y: number;
	x_root: number;
	y_root: number;
	state: number;
	button: number;
	same_screen: number;
}
declare var XButtonEvent: interop.StructType<XButtonEvent>;

declare const XCNOENT: number;

declare const XCNOMEM: number;

declare const XCSUCCESS: number;

declare function XCellsOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XChangeActivePointerGrab(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number): number;

declare function XChangeGC(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<XGCValues> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XChangeKeyboardControl(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XKeyboardControl> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XChangeKeyboardMapping(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: number): number;

declare function XChangePointerControl(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number): number;

declare function XChangeProperty(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number, p7: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p8: number): number;

declare function XChangeSaveSet(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XChangeWindowAttributes(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<XSetWindowAttributes> | ArrayBufferLike | ArrayBufferView | null): number;

interface XChar2b {
	byte1: number;
	byte2: number;
}
declare var XChar2b: interop.StructType<XChar2b>;

interface XCharStruct {
	lbearing: number;
	rbearing: number;
	width: number;
	ascent: number;
	descent: number;
	attributes: number;
}
declare var XCharStruct: interop.StructType<XCharStruct>;

declare function XCheckIfEvent(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XEvent> | ArrayBufferLike | ArrayBufferView | null, p3: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null, p2: interop.Pointer | interop.Reference<XEvent> | null, p3: interop.Pointer | interop.Reference<any> | null) => number>, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XCheckMaskEvent(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XEvent> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XCheckTypedEvent(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XEvent> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XCheckTypedWindowEvent(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<XEvent> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XCheckWindowEvent(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<XEvent> | ArrayBufferLike | ArrayBufferView | null): number;

interface XCirculateEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	event: number;
	window: number;
	place: number;
}
declare var XCirculateEvent: interop.StructType<XCirculateEvent>;

interface XCirculateRequestEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	parent: number;
	window: number;
	place: number;
}
declare var XCirculateRequestEvent: interop.StructType<XCirculateRequestEvent>;

declare function XCirculateSubwindows(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XCirculateSubwindowsDown(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XCirculateSubwindowsUp(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

interface XClassHint {
	res_name: interop.Pointer | interop.Reference<any> | null;
	res_class: interop.Pointer | interop.Reference<any> | null;
}
declare var XClassHint: interop.StructType<XClassHint>;

declare function XClearArea(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number, p7: number): number;

declare function XClearWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

interface XClientMessageEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
	message_type: number;
	format: number;
	data: { b: interop.Reference<number>; s: interop.Reference<number>; l: interop.Reference<number>; };
}
declare var XClientMessageEvent: interop.StructType<XClientMessageEvent>;

declare function XClipBox(p1: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XCloseDisplay(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XCloseIM(p1: interop.Pointer | interop.Reference<_XIM> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XCloseOM(p1: interop.Pointer | interop.Reference<_XOM> | ArrayBufferLike | ArrayBufferView | null): number;

interface XColor {
	pixel: number;
	red: number;
	green: number;
	blue: number;
	flags: number;
	pad: number;
}
declare var XColor: interop.StructType<XColor>;

interface XColormapEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
	colormap: number;
	new: number;
	state: number;
}
declare var XColormapEvent: interop.StructType<XColormapEvent>;

interface XComposeStatus {
	compose_ptr: interop.Pointer | interop.Reference<any> | null;
	chars_matched: number;
}
declare var XComposeStatus: interop.StructType<XComposeStatus>;

interface XConfigureEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	event: number;
	window: number;
	x: number;
	y: number;
	width: number;
	height: number;
	border_width: number;
	above: number;
	override_redirect: number;
}
declare var XConfigureEvent: interop.StructType<XConfigureEvent>;

interface XConfigureRequestEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	parent: number;
	window: number;
	x: number;
	y: number;
	width: number;
	height: number;
	border_width: number;
	above: number;
	detail: number;
	value_mask: number;
}
declare var XConfigureRequestEvent: interop.StructType<XConfigureRequestEvent>;

declare function XConfigureWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<XWindowChanges> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XConnectionNumber(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XContextDependentDrawing(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XContextualDrawing(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XConvertCase(p1: number, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XConvertSelection(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number): number;

declare const XConverterNotFound: number;

declare function XCopyArea(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: number, p7: number, p8: number, p9: number, p10: number): number;

declare function XCopyColormapAndFree(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XCopyGC(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XCopyPlane(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: number, p7: number, p8: number, p9: number, p10: number, p11: number): number;

declare function XCreateBitmapFromData(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number): number;

declare function XCreateColormap(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<Visual> | ArrayBufferLike | ArrayBufferView | null, p4: number): number;

declare function XCreateFontCursor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XCreateFontSet(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<_XOC> | null;

declare function XCreateGC(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<XGCValues> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<_XGC> | null;

declare function XCreateGlyphCursor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null, p7: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XCreateIC(p1: interop.Pointer | interop.Reference<_XIM> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): interop.Pointer | interop.Reference<_XIC> | null;

declare function XCreateImage(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<Visual> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: number, p5: number, p6: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p7: number, p8: number, p9: number, p10: number): interop.Pointer | interop.Reference<XImage> | null;

declare function XCreateOC(p1: interop.Pointer | interop.Reference<_XOM> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): interop.Pointer | interop.Reference<_XOC> | null;

declare function XCreatePixmap(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number): number;

declare function XCreatePixmapCursor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null, p6: number, p7: number): number;

declare function XCreatePixmapFromBitmapData(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: number, p7: number, p8: number): number;

declare function XCreateRegion(): interop.Pointer | interop.Reference<_XRegion> | null;

declare function XCreateSimpleWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number, p7: number, p8: number, p9: number): number;

declare function XCreateWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number, p7: number, p8: number, p9: number, p10: interop.Pointer | interop.Reference<Visual> | ArrayBufferLike | ArrayBufferView | null, p11: number, p12: interop.Pointer | interop.Reference<XSetWindowAttributes> | ArrayBufferLike | ArrayBufferView | null): number;

interface XCreateWindowEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	parent: number;
	window: number;
	x: number;
	y: number;
	width: number;
	height: number;
	border_width: number;
	override_redirect: number;
}
declare var XCreateWindowEvent: interop.StructType<XCreateWindowEvent>;

interface XCrossingEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
	root: number;
	subwindow: number;
	time: number;
	x: number;
	y: number;
	x_root: number;
	y_root: number;
	mode: number;
	detail: number;
	same_screen: number;
	focus: number;
	state: number;
}
declare var XCrossingEvent: interop.StructType<XCrossingEvent>;

declare function XDefaultColormap(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XDefaultColormapOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XDefaultDepth(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XDefaultDepthOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XDefaultGC(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): interop.Pointer | interop.Reference<_XGC> | null;

declare function XDefaultGCOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<_XGC> | null;

declare function XDefaultRootWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XDefaultScreen(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XDefaultScreenOfDisplay(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<Screen> | null;

declare function XDefaultString(): string | null;

declare function XDefaultVisual(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): interop.Pointer | interop.Reference<Visual> | null;

declare function XDefaultVisualOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<Visual> | null;

declare function XDefineCursor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XDeleteContext(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XDeleteModifiermapEntry(p1: interop.Pointer | interop.Reference<XModifierKeymap> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): interop.Pointer | interop.Reference<XModifierKeymap> | null;

declare function XDeleteProperty(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XDestroyIC(p1: interop.Pointer | interop.Reference<_XIC> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XDestroyOC(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XDestroyRegion(p1: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XDestroySubwindows(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XDestroyWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

interface XDestroyWindowEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	event: number;
	window: number;
}
declare var XDestroyWindowEvent: interop.StructType<XDestroyWindowEvent>;

declare function XDirectionalDependentDrawing(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XDisableAccessControl(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XDisplayCells(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XDisplayHeight(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XDisplayHeightMM(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XDisplayKeycodes(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XDisplayMotionBufferSize(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XDisplayName(p1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function XDisplayOfIM(p1: interop.Pointer | interop.Reference<_XIM> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<Display> | null;

declare function XDisplayOfOM(p1: interop.Pointer | interop.Reference<_XOM> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<Display> | null;

declare function XDisplayOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<Display> | null;

declare function XDisplayPlanes(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XDisplayString(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function XDisplayWidth(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XDisplayWidthMM(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XDoesBackingStore(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XDoesSaveUnders(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XDrawArc(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: number, p7: number, p8: number, p9: number): number;

declare function XDrawArcs(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<XArc> | ArrayBufferLike | ArrayBufferView | null, p5: number): number;

declare function XDrawImageString(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p7: number): number;

declare function XDrawImageString16(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: interop.Pointer | interop.Reference<XChar2b> | ArrayBufferLike | ArrayBufferView | null, p7: number): number;

declare function XDrawLine(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: number, p7: number): number;

declare function XDrawLines(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<XPoint> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: number): number;

declare function XDrawPoint(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number): number;

declare function XDrawPoints(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<XPoint> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: number): number;

declare function XDrawRectangle(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: number, p7: number): number;

declare function XDrawRectangles(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p5: number): number;

declare function XDrawSegments(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<XSegment> | ArrayBufferLike | ArrayBufferView | null, p5: number): number;

declare function XDrawString(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p7: number): number;

declare function XDrawString16(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: interop.Pointer | interop.Reference<XChar2b> | ArrayBufferLike | ArrayBufferView | null, p7: number): number;

declare function XDrawText(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: interop.Pointer | interop.Reference<XTextItem> | ArrayBufferLike | ArrayBufferView | null, p7: number): number;

declare function XDrawText16(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: interop.Pointer | interop.Reference<XTextItem16> | ArrayBufferLike | ArrayBufferView | null, p7: number): number;

interface XEDataObject {
	display: interop.Pointer | interop.Reference<Display> | null;
	gc: interop.Pointer | interop.Reference<_XGC> | null;
	visual: interop.Pointer | interop.Reference<Visual> | null;
	screen: interop.Pointer | interop.Reference<Screen> | null;
	pixmap_format: interop.Pointer | interop.Reference<ScreenFormat> | null;
	font: interop.Pointer | interop.Reference<XFontStruct> | null;
}


declare function XEHeadOfExtensionList(p1: XEDataObject): interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<XExtData> | null> | null;

declare function XEmptyRegion(p1: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XEnableAccessControl(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XEqualRegion(p1: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null): number;

interface XErrorEvent {
	type: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	resourceid: number;
	serial: number;
	error_code: number;
	request_code: number;
	minor_code: number;
}
declare var XErrorEvent: interop.StructType<XErrorEvent>;

interface XEvent {
	type: number;
	xany: XAnyEvent;
	xkey: XKeyEvent;
	xbutton: XButtonEvent;
	xmotion: XMotionEvent;
	xcrossing: XCrossingEvent;
	xfocus: XFocusChangeEvent;
	xexpose: XExposeEvent;
	xgraphicsexpose: XGraphicsExposeEvent;
	xnoexpose: XNoExposeEvent;
	xvisibility: XVisibilityEvent;
	xcreatewindow: XCreateWindowEvent;
	xdestroywindow: XDestroyWindowEvent;
	xunmap: XUnmapEvent;
	xmap: XMapEvent;
	xmaprequest: XMapRequestEvent;
	xreparent: XReparentEvent;
	xconfigure: XConfigureEvent;
	xgravity: XGravityEvent;
	xresizerequest: XResizeRequestEvent;
	xconfigurerequest: XConfigureRequestEvent;
	xcirculate: XCirculateEvent;
	xcirculaterequest: XCirculateRequestEvent;
	xproperty: XPropertyEvent;
	xselectionclear: XSelectionClearEvent;
	xselectionrequest: XSelectionRequestEvent;
	xselection: XSelectionEvent;
	xcolormap: XColormapEvent;
	xclient: XClientMessageEvent;
	xmapping: XMappingEvent;
	xerror: XErrorEvent;
	xkeymap: XKeymapEvent;
	xgeneric: XGenericEvent;
	xcookie: XGenericEventCookie;
	pad: interop.Reference<number>;
}


declare function XEventMaskOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XEventsQueued(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

interface XExposeEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
	x: number;
	y: number;
	width: number;
	height: number;
	count: number;
}
declare var XExposeEvent: interop.StructType<XExposeEvent>;

interface XExtCodes {
	extension: number;
	major_opcode: number;
	first_event: number;
	first_error: number;
}
declare var XExtCodes: interop.StructType<XExtCodes>;

interface XExtData {
	number: number;
	next: interop.Pointer | interop.Reference<XExtData> | null;
	free_private: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<XExtData> | null) => number>;
	private_data: interop.Pointer | interop.Reference<any> | null;
}
declare var XExtData: interop.StructType<XExtData>;

declare function XExtendedMaxRequestSize(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XExtentsOfFontSet(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<XFontSetExtents> | null;

declare function XFetchBuffer(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p3: number): interop.Pointer | interop.Reference<any> | null;

declare function XFetchBytes(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function XFetchName(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XFillArc(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: number, p7: number, p8: number, p9: number): number;

declare function XFillArcs(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<XArc> | ArrayBufferLike | ArrayBufferView | null, p5: number): number;

declare function XFillPolygon(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<XPoint> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: number, p7: number): number;

declare function XFillRectangle(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: number, p7: number): number;

declare function XFillRectangles(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p5: number): number;

declare function XFilterEvent(p1: interop.Pointer | interop.Reference<XEvent> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XFindContext(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XFindOnExtensionList(p1: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<XExtData> | null> | ArrayBufferLike | ArrayBufferView | null, p2: number): interop.Pointer | interop.Reference<XExtData> | null;

declare function XFlush(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XFlushGC(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null): void;

interface XFocusChangeEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
	mode: number;
	detail: number;
}
declare var XFocusChangeEvent: interop.StructType<XFocusChangeEvent>;

interface XFontProp {
	name: number;
	card32: number;
}
declare var XFontProp: interop.StructType<XFontProp>;

interface XFontSetExtents {
	max_ink_extent: XRectangle;
	max_logical_extent: XRectangle;
}
declare var XFontSetExtents: interop.StructType<XFontSetExtents>;

interface XFontStruct {
	ext_data: interop.Pointer | interop.Reference<XExtData> | null;
	fid: number;
	direction: number;
	min_char_or_byte2: number;
	max_char_or_byte2: number;
	min_byte1: number;
	max_byte1: number;
	all_chars_exist: number;
	default_char: number;
	n_properties: number;
	properties: interop.Pointer | interop.Reference<XFontProp> | null;
	min_bounds: XCharStruct;
	max_bounds: XCharStruct;
	per_char: interop.Pointer | interop.Reference<XCharStruct> | null;
	ascent: number;
	descent: number;
}
declare var XFontStruct: interop.StructType<XFontStruct>;

declare function XFontsOfFontSet(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<XFontStruct> | null> | null> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XForceScreenSaver(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XFree(p1: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XFreeColormap(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XFreeColors(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number): number;

declare function XFreeCursor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XFreeEventData(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XGenericEventCookie> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XFreeExtensionList(p1: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XFreeFont(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XFontStruct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XFreeFontInfo(p1: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XFontStruct> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XFreeFontNames(p1: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XFreeFontPath(p1: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XFreeFontSet(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XFreeGC(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XFreeModifiermap(p1: interop.Pointer | interop.Reference<XModifierKeymap> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XFreePixmap(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XFreeStringList(p1: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XFreeThreads(): number;

interface XGCValues {
	function: number;
	plane_mask: number;
	foreground: number;
	background: number;
	line_width: number;
	line_style: number;
	cap_style: number;
	join_style: number;
	fill_style: number;
	fill_rule: number;
	arc_mode: number;
	tile: number;
	stipple: number;
	ts_x_origin: number;
	ts_y_origin: number;
	font: number;
	subwindow_mode: number;
	graphics_exposures: number;
	clip_x_origin: number;
	clip_y_origin: number;
	clip_mask: number;
	dash_offset: number;
	dashes: number;
}
declare var XGCValues: interop.StructType<XGCValues>;

declare function XGContextFromGC(p1: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null): number;

interface XGenericEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	extension: number;
	evtype: number;
}
declare var XGenericEvent: interop.StructType<XGenericEvent>;

interface XGenericEventCookie {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	extension: number;
	evtype: number;
	cookie: number;
	data: interop.Pointer | interop.Reference<any> | null;
}
declare var XGenericEventCookie: interop.StructType<XGenericEventCookie>;

declare function XGeometry(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: number, p7: number, p8: number, p9: number, p10: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p11: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p12: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p13: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetAtomName(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): interop.Pointer | interop.Reference<any> | null;

declare function XGetAtomNames(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetClassHint(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XClassHint> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetCommand(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetDefault(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function XGetErrorDatabaseText(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p5: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p6: number): number;

declare function XGetErrorText(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: number): number;

declare function XGetEventData(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XGenericEventCookie> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetFontPath(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;

declare function XGetFontProperty(p1: interop.Pointer | interop.Reference<XFontStruct> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetGCValues(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<XGCValues> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetGeometry(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p7: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p8: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p9: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetICValues(p1: interop.Pointer | interop.Reference<_XIC> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): interop.Pointer | interop.Reference<any> | null;

declare function XGetIMValues(p1: interop.Pointer | interop.Reference<_XIM> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): interop.Pointer | interop.Reference<any> | null;

declare function XGetIconName(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetIconSizes(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<XIconSize> | null> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetImage(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number, p7: number, p8: number): interop.Pointer | interop.Reference<XImage> | null;

declare function XGetInputFocus(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetKeyboardControl(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XKeyboardState> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetKeyboardMapping(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function XGetModifierMapping(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<XModifierKeymap> | null;

declare function XGetMotionEvents(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<XTimeCoord> | null;

declare function XGetNormalHints(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetOCValues(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): interop.Pointer | interop.Reference<any> | null;

declare function XGetOMValues(p1: interop.Pointer | interop.Reference<_XOM> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): interop.Pointer | interop.Reference<any> | null;

declare function XGetPointerControl(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetPointerMapping(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XGetRGBColormaps(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<XStandardColormap> | null> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: number): number;

declare function XGetScreenSaver(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetSelectionOwner(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XGetSizeHints(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null, p4: number): number;

declare function XGetStandardColormap(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XStandardColormap> | ArrayBufferLike | ArrayBufferView | null, p4: number): number;

declare function XGetSubImage(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number, p7: number, p8: number, p9: interop.Pointer | interop.Reference<XImage> | ArrayBufferLike | ArrayBufferView | null, p10: number, p11: number): interop.Pointer | interop.Reference<XImage> | null;

declare function XGetTextProperty(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null, p4: number): number;

declare function XGetTransientForHint(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetVisualInfo(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XVisualInfo> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<XVisualInfo> | null;

declare function XGetWMClientMachine(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetWMColormapWindows(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetWMHints(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): interop.Pointer | interop.Reference<XWMHints> | null;

declare function XGetWMIconName(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetWMName(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetWMNormalHints(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetWMProtocols(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetWMSizeHints(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: number): number;

declare function XGetWindowAttributes(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XWindowAttributes> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetWindowProperty(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number, p7: number, p8: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p9: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p10: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p11: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p12: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGetZoomHints(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XGrabButton(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number, p7: number, p8: number, p9: number, p10: number): number;

declare function XGrabKey(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number, p7: number): number;

declare function XGrabKeyboard(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number): number;

declare function XGrabPointer(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number, p7: number, p8: number, p9: number): number;

declare function XGrabServer(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

interface XGraphicsExposeEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	drawable: number;
	x: number;
	y: number;
	width: number;
	height: number;
	count: number;
	major_code: number;
	minor_code: number;
}
declare var XGraphicsExposeEvent: interop.StructType<XGraphicsExposeEvent>;

interface XGravityEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	event: number;
	window: number;
	x: number;
	y: number;
}
declare var XGravityEvent: interop.StructType<XGravityEvent>;

declare function XHeightMMOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XHeightOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

interface XHostAddress {
	family: number;
	length: number;
	address: interop.Pointer | interop.Reference<any> | null;
}
declare var XHostAddress: interop.StructType<XHostAddress>;

declare const enum XICCEncodingStyle {

	XStringStyle = 0,

	XCompoundTextStyle = 1,

	XTextStyle = 2,

	XStdICCTextStyle = 3,

	XUTF8StringStyle = 4
}

interface XICCallback {
	client_data: interop.Pointer | interop.Reference<any> | null;
	callback: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<_XIC> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: interop.Pointer | interop.Reference<any> | null) => number>;
}
declare var XICCallback: interop.StructType<XICCallback>;

interface XIMCallback {
	client_data: interop.Pointer | interop.Reference<any> | null;
	callback: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<_XIM> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: interop.Pointer | interop.Reference<any> | null) => void>;
}
declare var XIMCallback: interop.StructType<XIMCallback>;

declare const enum XIMCaretDirection {

	XIMForwardChar = 0,

	XIMBackwardChar = 1,

	XIMForwardWord = 2,

	XIMBackwardWord = 3,

	XIMCaretUp = 4,

	XIMCaretDown = 5,

	XIMNextLine = 6,

	XIMPreviousLine = 7,

	XIMLineStart = 8,

	XIMLineEnd = 9,

	XIMAbsolutePosition = 10,

	XIMDontChange = 11
}

declare const enum XIMCaretStyle {

	XIMIsInvisible = 0,

	XIMIsPrimary = 1,

	XIMIsSecondary = 2
}

declare const XIMHighlight: number;

declare const XIMHotKeyStateOFF: number;

declare const XIMHotKeyStateON: number;

interface XIMHotKeyTrigger {
	keysym: number;
	modifier: number;
	modifier_mask: number;
}
declare var XIMHotKeyTrigger: interop.StructType<XIMHotKeyTrigger>;

interface XIMHotKeyTriggers {
	num_hot_key: number;
	key: interop.Pointer | interop.Reference<XIMHotKeyTrigger> | null;
}
declare var XIMHotKeyTriggers: interop.StructType<XIMHotKeyTriggers>;

declare const XIMInitialState: number;

declare function XIMOfIC(p1: interop.Pointer | interop.Reference<_XIC> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<_XIM> | null;

declare const XIMPreeditArea: number;

declare const XIMPreeditCallbacks: number;

interface XIMPreeditCaretCallbackStruct {
	position: number;
	direction: XIMCaretDirection;
	style: XIMCaretStyle;
}
declare var XIMPreeditCaretCallbackStruct: interop.StructType<XIMPreeditCaretCallbackStruct>;

declare const XIMPreeditDisable: number;

interface XIMPreeditDrawCallbackStruct {
	caret: number;
	chg_first: number;
	chg_length: number;
	text: interop.Pointer | interop.Reference<XIMText> | null;
}
declare var XIMPreeditDrawCallbackStruct: interop.StructType<XIMPreeditDrawCallbackStruct>;

declare const XIMPreeditEnable: number;

declare const XIMPreeditNone: number;

declare const XIMPreeditNothing: number;

declare const XIMPreeditPosition: number;

interface XIMPreeditStateNotifyCallbackStruct {
	state: number;
}
declare var XIMPreeditStateNotifyCallbackStruct: interop.StructType<XIMPreeditStateNotifyCallbackStruct>;

declare const XIMPreeditUnKnown: number;

declare const XIMPreserveState: number;

declare const XIMPrimary: number;

declare const XIMReverse: number;

declare const XIMSecondary: number;

declare const XIMStatusArea: number;

declare const XIMStatusCallbacks: number;

declare const enum XIMStatusDataType {

	XIMTextType = 0,

	XIMBitmapType = 1
}

interface XIMStatusDrawCallbackStruct {
	type: XIMStatusDataType;
	data: { text: interop.Pointer | interop.Reference<XIMText> | null; bitmap: number; };
}
declare var XIMStatusDrawCallbackStruct: interop.StructType<XIMStatusDrawCallbackStruct>;

declare const XIMStatusNone: number;

declare const XIMStatusNothing: number;

declare const XIMStringConversionBottomEdge: number;

declare const XIMStringConversionBuffer: number;

interface XIMStringConversionCallbackStruct {
	position: number;
	direction: XIMCaretDirection;
	operation: number;
	factor: number;
	text: interop.Pointer | interop.Reference<XIMStringConversionText> | null;
}
declare var XIMStringConversionCallbackStruct: interop.StructType<XIMStringConversionCallbackStruct>;

declare const XIMStringConversionChar: number;

declare const XIMStringConversionConcealed: number;

declare const XIMStringConversionLeftEdge: number;

declare const XIMStringConversionLine: number;

declare const XIMStringConversionRetrieval: number;

declare const XIMStringConversionRightEdge: number;

declare const XIMStringConversionSubstitution: number;

interface XIMStringConversionText {
	length: number;
	feedback: interop.Pointer | interop.Reference<number> | null;
	encoding_is_wchar: number;
	string: { mbs: interop.Pointer | interop.Reference<any> | null; wcs: interop.Pointer | interop.Reference<number> | null; };
}
declare var XIMStringConversionText: interop.StructType<XIMStringConversionText>;

declare const XIMStringConversionTopEdge: number;

declare const XIMStringConversionWord: number;

declare const XIMStringConversionWrapped: number;

interface XIMStyles {
	count_styles: number;
	supported_styles: interop.Pointer | interop.Reference<number> | null;
}
declare var XIMStyles: interop.StructType<XIMStyles>;

declare const XIMTertiary: number;

interface XIMText {
	length: number;
	feedback: interop.Pointer | interop.Reference<number> | null;
	encoding_is_wchar: number;
	string: { multi_byte: interop.Pointer | interop.Reference<any> | null; wide_char: interop.Pointer | interop.Reference<number> | null; };
}
declare var XIMText: interop.StructType<XIMText>;

declare const XIMUnderline: number;

interface XIMValuesList {
	count_values: number;
	supported_values: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;
}
declare var XIMValuesList: interop.StructType<XIMValuesList>;

declare const XIMVisibleToBackword: number;

declare const XIMVisibleToCenter: number;

declare const XIMVisibleToForward: number;

interface XIconSize {
	min_width: number;
	min_height: number;
	max_width: number;
	max_height: number;
	width_inc: number;
	height_inc: number;
}
declare var XIconSize: interop.StructType<XIconSize>;

declare function XIconifyWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XIfEvent(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XEvent> | ArrayBufferLike | ArrayBufferView | null, p3: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null, p2: interop.Pointer | interop.Reference<XEvent> | null, p3: interop.Pointer | interop.Reference<any> | null) => number>, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

interface XImage {
	width: number;
	height: number;
	xoffset: number;
	format: number;
	data: interop.Pointer | interop.Reference<any> | null;
	byte_order: number;
	bitmap_unit: number;
	bitmap_bit_order: number;
	bitmap_pad: number;
	depth: number;
	bytes_per_line: number;
	bits_per_pixel: number;
	red_mask: number;
	green_mask: number;
	blue_mask: number;
	obdata: interop.Pointer | interop.Reference<any> | null;
	f: funcs;
}
declare var XImage: interop.StructType<XImage>;

declare function XImageByteOrder(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XInitExtension(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<XExtCodes> | null;

declare function XInitImage(p1: interop.Pointer | interop.Reference<XImage> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XInitThreads(): number;

declare function XInsertModifiermapEntry(p1: interop.Pointer | interop.Reference<XModifierKeymap> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): interop.Pointer | interop.Reference<XModifierKeymap> | null;

declare function XInstallColormap(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XInternAtom(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XInternAtoms(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: number, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XInternalConnectionNumbers(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XIntersectRegion(p1: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null): number;

declare const XK_0: number;

declare const XK_1: number;

declare const XK_2: number;

declare const XK_3: number;

declare const XK_4: number;

declare const XK_5: number;

declare const XK_6: number;

declare const XK_7: number;

declare const XK_8: number;

declare const XK_9: number;

declare const XK_A: number;

declare const XK_AE: number;

declare const XK_Aacute: number;

declare const XK_Abelowdot: number;

declare const XK_Abreve: number;

declare const XK_Abreveacute: number;

declare const XK_Abrevebelowdot: number;

declare const XK_Abrevegrave: number;

declare const XK_Abrevehook: number;

declare const XK_Abrevetilde: number;

declare const XK_AccessX_Enable: number;

declare const XK_AccessX_Feedback_Enable: number;

declare const XK_Acircumflex: number;

declare const XK_Acircumflexacute: number;

declare const XK_Acircumflexbelowdot: number;

declare const XK_Acircumflexgrave: number;

declare const XK_Acircumflexhook: number;

declare const XK_Acircumflextilde: number;

declare const XK_Adiaeresis: number;

declare const XK_Agrave: number;

declare const XK_Ahook: number;

declare const XK_Alt_L: number;

declare const XK_Alt_R: number;

declare const XK_Amacron: number;

declare const XK_Aogonek: number;

declare const XK_Arabic_0: number;

declare const XK_Arabic_1: number;

declare const XK_Arabic_2: number;

declare const XK_Arabic_3: number;

declare const XK_Arabic_4: number;

declare const XK_Arabic_5: number;

declare const XK_Arabic_6: number;

declare const XK_Arabic_7: number;

declare const XK_Arabic_8: number;

declare const XK_Arabic_9: number;

declare const XK_Arabic_ain: number;

declare const XK_Arabic_alef: number;

declare const XK_Arabic_alefmaksura: number;

declare const XK_Arabic_beh: number;

declare const XK_Arabic_comma: number;

declare const XK_Arabic_dad: number;

declare const XK_Arabic_dal: number;

declare const XK_Arabic_damma: number;

declare const XK_Arabic_dammatan: number;

declare const XK_Arabic_ddal: number;

declare const XK_Arabic_farsi_yeh: number;

declare const XK_Arabic_fatha: number;

declare const XK_Arabic_fathatan: number;

declare const XK_Arabic_feh: number;

declare const XK_Arabic_fullstop: number;

declare const XK_Arabic_gaf: number;

declare const XK_Arabic_ghain: number;

declare const XK_Arabic_ha: number;

declare const XK_Arabic_hah: number;

declare const XK_Arabic_hamza: number;

declare const XK_Arabic_hamza_above: number;

declare const XK_Arabic_hamza_below: number;

declare const XK_Arabic_hamzaonalef: number;

declare const XK_Arabic_hamzaonwaw: number;

declare const XK_Arabic_hamzaonyeh: number;

declare const XK_Arabic_hamzaunderalef: number;

declare const XK_Arabic_heh: number;

declare const XK_Arabic_heh_doachashmee: number;

declare const XK_Arabic_heh_goal: number;

declare const XK_Arabic_jeem: number;

declare const XK_Arabic_jeh: number;

declare const XK_Arabic_kaf: number;

declare const XK_Arabic_kasra: number;

declare const XK_Arabic_kasratan: number;

declare const XK_Arabic_keheh: number;

declare const XK_Arabic_khah: number;

declare const XK_Arabic_lam: number;

declare const XK_Arabic_madda_above: number;

declare const XK_Arabic_maddaonalef: number;

declare const XK_Arabic_meem: number;

declare const XK_Arabic_noon: number;

declare const XK_Arabic_noon_ghunna: number;

declare const XK_Arabic_peh: number;

declare const XK_Arabic_percent: number;

declare const XK_Arabic_qaf: number;

declare const XK_Arabic_question_mark: number;

declare const XK_Arabic_ra: number;

declare const XK_Arabic_rreh: number;

declare const XK_Arabic_sad: number;

declare const XK_Arabic_seen: number;

declare const XK_Arabic_semicolon: number;

declare const XK_Arabic_shadda: number;

declare const XK_Arabic_sheen: number;

declare const XK_Arabic_sukun: number;

declare const XK_Arabic_superscript_alef: number;

declare const XK_Arabic_switch: number;

declare const XK_Arabic_tah: number;

declare const XK_Arabic_tatweel: number;

declare const XK_Arabic_tcheh: number;

declare const XK_Arabic_teh: number;

declare const XK_Arabic_tehmarbuta: number;

declare const XK_Arabic_thal: number;

declare const XK_Arabic_theh: number;

declare const XK_Arabic_tteh: number;

declare const XK_Arabic_veh: number;

declare const XK_Arabic_waw: number;

declare const XK_Arabic_yeh: number;

declare const XK_Arabic_yeh_baree: number;

declare const XK_Arabic_zah: number;

declare const XK_Arabic_zain: number;

declare const XK_Aring: number;

declare const XK_Armenian_AT: number;

declare const XK_Armenian_AYB: number;

declare const XK_Armenian_BEN: number;

declare const XK_Armenian_CHA: number;

declare const XK_Armenian_DA: number;

declare const XK_Armenian_DZA: number;

declare const XK_Armenian_E: number;

declare const XK_Armenian_FE: number;

declare const XK_Armenian_GHAT: number;

declare const XK_Armenian_GIM: number;

declare const XK_Armenian_HI: number;

declare const XK_Armenian_HO: number;

declare const XK_Armenian_INI: number;

declare const XK_Armenian_JE: number;

declare const XK_Armenian_KE: number;

declare const XK_Armenian_KEN: number;

declare const XK_Armenian_KHE: number;

declare const XK_Armenian_LYUN: number;

declare const XK_Armenian_MEN: number;

declare const XK_Armenian_NU: number;

declare const XK_Armenian_O: number;

declare const XK_Armenian_PE: number;

declare const XK_Armenian_PYUR: number;

declare const XK_Armenian_RA: number;

declare const XK_Armenian_RE: number;

declare const XK_Armenian_SE: number;

declare const XK_Armenian_SHA: number;

declare const XK_Armenian_TCHE: number;

declare const XK_Armenian_TO: number;

declare const XK_Armenian_TSA: number;

declare const XK_Armenian_TSO: number;

declare const XK_Armenian_TYUN: number;

declare const XK_Armenian_VEV: number;

declare const XK_Armenian_VO: number;

declare const XK_Armenian_VYUN: number;

declare const XK_Armenian_YECH: number;

declare const XK_Armenian_ZA: number;

declare const XK_Armenian_ZHE: number;

declare const XK_Armenian_accent: number;

declare const XK_Armenian_amanak: number;

declare const XK_Armenian_apostrophe: number;

declare const XK_Armenian_at: number;

declare const XK_Armenian_ayb: number;

declare const XK_Armenian_ben: number;

declare const XK_Armenian_but: number;

declare const XK_Armenian_cha: number;

declare const XK_Armenian_da: number;

declare const XK_Armenian_dza: number;

declare const XK_Armenian_e: number;

declare const XK_Armenian_exclam: number;

declare const XK_Armenian_fe: number;

declare const XK_Armenian_full_stop: number;

declare const XK_Armenian_ghat: number;

declare const XK_Armenian_gim: number;

declare const XK_Armenian_hi: number;

declare const XK_Armenian_ho: number;

declare const XK_Armenian_hyphen: number;

declare const XK_Armenian_ini: number;

declare const XK_Armenian_je: number;

declare const XK_Armenian_ke: number;

declare const XK_Armenian_ken: number;

declare const XK_Armenian_khe: number;

declare const XK_Armenian_ligature_ew: number;

declare const XK_Armenian_lyun: number;

declare const XK_Armenian_men: number;

declare const XK_Armenian_nu: number;

declare const XK_Armenian_o: number;

declare const XK_Armenian_paruyk: number;

declare const XK_Armenian_pe: number;

declare const XK_Armenian_pyur: number;

declare const XK_Armenian_question: number;

declare const XK_Armenian_ra: number;

declare const XK_Armenian_re: number;

declare const XK_Armenian_se: number;

declare const XK_Armenian_separation_mark: number;

declare const XK_Armenian_sha: number;

declare const XK_Armenian_shesht: number;

declare const XK_Armenian_tche: number;

declare const XK_Armenian_to: number;

declare const XK_Armenian_tsa: number;

declare const XK_Armenian_tso: number;

declare const XK_Armenian_tyun: number;

declare const XK_Armenian_verjaket: number;

declare const XK_Armenian_vev: number;

declare const XK_Armenian_vo: number;

declare const XK_Armenian_vyun: number;

declare const XK_Armenian_yech: number;

declare const XK_Armenian_yentamna: number;

declare const XK_Armenian_za: number;

declare const XK_Armenian_zhe: number;

declare const XK_Atilde: number;

declare const XK_AudibleBell_Enable: number;

declare const XK_B: number;

declare const XK_Babovedot: number;

declare const XK_BackSpace: number;

declare const XK_Begin: number;

declare const XK_BounceKeys_Enable: number;

declare const XK_Break: number;

declare const XK_Byelorussian_SHORTU: number;

declare const XK_Byelorussian_shortu: number;

declare const XK_C: number;

declare const XK_CH: number;

declare const XK_C_H: number;

declare const XK_C_h: number;

declare const XK_Cabovedot: number;

declare const XK_Cacute: number;

declare const XK_Cancel: number;

declare const XK_Caps_Lock: number;

declare const XK_Ccaron: number;

declare const XK_Ccedilla: number;

declare const XK_Ccircumflex: number;

declare const XK_Ch: number;

declare const XK_Clear: number;

declare const XK_Codeinput: number;

declare const XK_ColonSign: number;

declare const XK_Control_L: number;

declare const XK_Control_R: number;

declare const XK_CruzeiroSign: number;

declare const XK_Cyrillic_A: number;

declare const XK_Cyrillic_BE: number;

declare const XK_Cyrillic_CHE: number;

declare const XK_Cyrillic_CHE_descender: number;

declare const XK_Cyrillic_CHE_vertstroke: number;

declare const XK_Cyrillic_DE: number;

declare const XK_Cyrillic_DZHE: number;

declare const XK_Cyrillic_E: number;

declare const XK_Cyrillic_EF: number;

declare const XK_Cyrillic_EL: number;

declare const XK_Cyrillic_EM: number;

declare const XK_Cyrillic_EN: number;

declare const XK_Cyrillic_EN_descender: number;

declare const XK_Cyrillic_ER: number;

declare const XK_Cyrillic_ES: number;

declare const XK_Cyrillic_GHE: number;

declare const XK_Cyrillic_GHE_bar: number;

declare const XK_Cyrillic_HA: number;

declare const XK_Cyrillic_HARDSIGN: number;

declare const XK_Cyrillic_HA_descender: number;

declare const XK_Cyrillic_I: number;

declare const XK_Cyrillic_IE: number;

declare const XK_Cyrillic_IO: number;

declare const XK_Cyrillic_I_macron: number;

declare const XK_Cyrillic_JE: number;

declare const XK_Cyrillic_KA: number;

declare const XK_Cyrillic_KA_descender: number;

declare const XK_Cyrillic_KA_vertstroke: number;

declare const XK_Cyrillic_LJE: number;

declare const XK_Cyrillic_NJE: number;

declare const XK_Cyrillic_O: number;

declare const XK_Cyrillic_O_bar: number;

declare const XK_Cyrillic_PE: number;

declare const XK_Cyrillic_SCHWA: number;

declare const XK_Cyrillic_SHA: number;

declare const XK_Cyrillic_SHCHA: number;

declare const XK_Cyrillic_SHHA: number;

declare const XK_Cyrillic_SHORTI: number;

declare const XK_Cyrillic_SOFTSIGN: number;

declare const XK_Cyrillic_TE: number;

declare const XK_Cyrillic_TSE: number;

declare const XK_Cyrillic_U: number;

declare const XK_Cyrillic_U_macron: number;

declare const XK_Cyrillic_U_straight: number;

declare const XK_Cyrillic_U_straight_bar: number;

declare const XK_Cyrillic_VE: number;

declare const XK_Cyrillic_YA: number;

declare const XK_Cyrillic_YERU: number;

declare const XK_Cyrillic_YU: number;

declare const XK_Cyrillic_ZE: number;

declare const XK_Cyrillic_ZHE: number;

declare const XK_Cyrillic_ZHE_descender: number;

declare const XK_Cyrillic_a: number;

declare const XK_Cyrillic_be: number;

declare const XK_Cyrillic_che: number;

declare const XK_Cyrillic_che_descender: number;

declare const XK_Cyrillic_che_vertstroke: number;

declare const XK_Cyrillic_de: number;

declare const XK_Cyrillic_dzhe: number;

declare const XK_Cyrillic_e: number;

declare const XK_Cyrillic_ef: number;

declare const XK_Cyrillic_el: number;

declare const XK_Cyrillic_em: number;

declare const XK_Cyrillic_en: number;

declare const XK_Cyrillic_en_descender: number;

declare const XK_Cyrillic_er: number;

declare const XK_Cyrillic_es: number;

declare const XK_Cyrillic_ghe: number;

declare const XK_Cyrillic_ghe_bar: number;

declare const XK_Cyrillic_ha: number;

declare const XK_Cyrillic_ha_descender: number;

declare const XK_Cyrillic_hardsign: number;

declare const XK_Cyrillic_i: number;

declare const XK_Cyrillic_i_macron: number;

declare const XK_Cyrillic_ie: number;

declare const XK_Cyrillic_io: number;

declare const XK_Cyrillic_je: number;

declare const XK_Cyrillic_ka: number;

declare const XK_Cyrillic_ka_descender: number;

declare const XK_Cyrillic_ka_vertstroke: number;

declare const XK_Cyrillic_lje: number;

declare const XK_Cyrillic_nje: number;

declare const XK_Cyrillic_o: number;

declare const XK_Cyrillic_o_bar: number;

declare const XK_Cyrillic_pe: number;

declare const XK_Cyrillic_schwa: number;

declare const XK_Cyrillic_sha: number;

declare const XK_Cyrillic_shcha: number;

declare const XK_Cyrillic_shha: number;

declare const XK_Cyrillic_shorti: number;

declare const XK_Cyrillic_softsign: number;

declare const XK_Cyrillic_te: number;

declare const XK_Cyrillic_tse: number;

declare const XK_Cyrillic_u: number;

declare const XK_Cyrillic_u_macron: number;

declare const XK_Cyrillic_u_straight: number;

declare const XK_Cyrillic_u_straight_bar: number;

declare const XK_Cyrillic_ve: number;

declare const XK_Cyrillic_ya: number;

declare const XK_Cyrillic_yeru: number;

declare const XK_Cyrillic_yu: number;

declare const XK_Cyrillic_ze: number;

declare const XK_Cyrillic_zhe: number;

declare const XK_Cyrillic_zhe_descender: number;

declare const XK_D: number;

declare const XK_Dabovedot: number;

declare const XK_Dcaron: number;

declare const XK_Delete: number;

declare const XK_DongSign: number;

declare const XK_Down: number;

declare const XK_Dstroke: number;

declare const XK_E: number;

declare const XK_ENG: number;

declare const XK_ETH: number;

declare const XK_EZH: number;

declare const XK_Eabovedot: number;

declare const XK_Eacute: number;

declare const XK_Ebelowdot: number;

declare const XK_Ecaron: number;

declare const XK_Ecircumflex: number;

declare const XK_Ecircumflexacute: number;

declare const XK_Ecircumflexbelowdot: number;

declare const XK_Ecircumflexgrave: number;

declare const XK_Ecircumflexhook: number;

declare const XK_Ecircumflextilde: number;

declare const XK_EcuSign: number;

declare const XK_Ediaeresis: number;

declare const XK_Egrave: number;

declare const XK_Ehook: number;

declare const XK_Eisu_Shift: number;

declare const XK_Eisu_toggle: number;

declare const XK_Emacron: number;

declare const XK_End: number;

declare const XK_Eogonek: number;

declare const XK_Escape: number;

declare const XK_Eth: number;

declare const XK_Etilde: number;

declare const XK_EuroSign: number;

declare const XK_Execute: number;

declare const XK_F: number;

declare const XK_F1: number;

declare const XK_F10: number;

declare const XK_F11: number;

declare const XK_F12: number;

declare const XK_F13: number;

declare const XK_F14: number;

declare const XK_F15: number;

declare const XK_F16: number;

declare const XK_F17: number;

declare const XK_F18: number;

declare const XK_F19: number;

declare const XK_F2: number;

declare const XK_F20: number;

declare const XK_F21: number;

declare const XK_F22: number;

declare const XK_F23: number;

declare const XK_F24: number;

declare const XK_F25: number;

declare const XK_F26: number;

declare const XK_F27: number;

declare const XK_F28: number;

declare const XK_F29: number;

declare const XK_F3: number;

declare const XK_F30: number;

declare const XK_F31: number;

declare const XK_F32: number;

declare const XK_F33: number;

declare const XK_F34: number;

declare const XK_F35: number;

declare const XK_F4: number;

declare const XK_F5: number;

declare const XK_F6: number;

declare const XK_F7: number;

declare const XK_F8: number;

declare const XK_F9: number;

declare const XK_FFrancSign: number;

declare const XK_Fabovedot: number;

declare const XK_Farsi_0: number;

declare const XK_Farsi_1: number;

declare const XK_Farsi_2: number;

declare const XK_Farsi_3: number;

declare const XK_Farsi_4: number;

declare const XK_Farsi_5: number;

declare const XK_Farsi_6: number;

declare const XK_Farsi_7: number;

declare const XK_Farsi_8: number;

declare const XK_Farsi_9: number;

declare const XK_Farsi_yeh: number;

declare const XK_Find: number;

declare const XK_First_Virtual_Screen: number;

declare const XK_G: number;

declare const XK_Gabovedot: number;

declare const XK_Gbreve: number;

declare const XK_Gcaron: number;

declare const XK_Gcedilla: number;

declare const XK_Gcircumflex: number;

declare const XK_Georgian_an: number;

declare const XK_Georgian_ban: number;

declare const XK_Georgian_can: number;

declare const XK_Georgian_char: number;

declare const XK_Georgian_chin: number;

declare const XK_Georgian_cil: number;

declare const XK_Georgian_don: number;

declare const XK_Georgian_en: number;

declare const XK_Georgian_fi: number;

declare const XK_Georgian_gan: number;

declare const XK_Georgian_ghan: number;

declare const XK_Georgian_hae: number;

declare const XK_Georgian_har: number;

declare const XK_Georgian_he: number;

declare const XK_Georgian_hie: number;

declare const XK_Georgian_hoe: number;

declare const XK_Georgian_in: number;

declare const XK_Georgian_jhan: number;

declare const XK_Georgian_jil: number;

declare const XK_Georgian_kan: number;

declare const XK_Georgian_khar: number;

declare const XK_Georgian_las: number;

declare const XK_Georgian_man: number;

declare const XK_Georgian_nar: number;

declare const XK_Georgian_on: number;

declare const XK_Georgian_par: number;

declare const XK_Georgian_phar: number;

declare const XK_Georgian_qar: number;

declare const XK_Georgian_rae: number;

declare const XK_Georgian_san: number;

declare const XK_Georgian_shin: number;

declare const XK_Georgian_tan: number;

declare const XK_Georgian_tar: number;

declare const XK_Georgian_un: number;

declare const XK_Georgian_vin: number;

declare const XK_Georgian_we: number;

declare const XK_Georgian_xan: number;

declare const XK_Georgian_zen: number;

declare const XK_Georgian_zhar: number;

declare const XK_Greek_ALPHA: number;

declare const XK_Greek_ALPHAaccent: number;

declare const XK_Greek_BETA: number;

declare const XK_Greek_CHI: number;

declare const XK_Greek_DELTA: number;

declare const XK_Greek_EPSILON: number;

declare const XK_Greek_EPSILONaccent: number;

declare const XK_Greek_ETA: number;

declare const XK_Greek_ETAaccent: number;

declare const XK_Greek_GAMMA: number;

declare const XK_Greek_IOTA: number;

declare const XK_Greek_IOTAaccent: number;

declare const XK_Greek_IOTAdiaeresis: number;

declare const XK_Greek_IOTAdieresis: number;

declare const XK_Greek_KAPPA: number;

declare const XK_Greek_LAMBDA: number;

declare const XK_Greek_LAMDA: number;

declare const XK_Greek_MU: number;

declare const XK_Greek_NU: number;

declare const XK_Greek_OMEGA: number;

declare const XK_Greek_OMEGAaccent: number;

declare const XK_Greek_OMICRON: number;

declare const XK_Greek_OMICRONaccent: number;

declare const XK_Greek_PHI: number;

declare const XK_Greek_PI: number;

declare const XK_Greek_PSI: number;

declare const XK_Greek_RHO: number;

declare const XK_Greek_SIGMA: number;

declare const XK_Greek_TAU: number;

declare const XK_Greek_THETA: number;

declare const XK_Greek_UPSILON: number;

declare const XK_Greek_UPSILONaccent: number;

declare const XK_Greek_UPSILONdieresis: number;

declare const XK_Greek_XI: number;

declare const XK_Greek_ZETA: number;

declare const XK_Greek_accentdieresis: number;

declare const XK_Greek_alpha: number;

declare const XK_Greek_alphaaccent: number;

declare const XK_Greek_beta: number;

declare const XK_Greek_chi: number;

declare const XK_Greek_delta: number;

declare const XK_Greek_epsilon: number;

declare const XK_Greek_epsilonaccent: number;

declare const XK_Greek_eta: number;

declare const XK_Greek_etaaccent: number;

declare const XK_Greek_finalsmallsigma: number;

declare const XK_Greek_gamma: number;

declare const XK_Greek_horizbar: number;

declare const XK_Greek_iota: number;

declare const XK_Greek_iotaaccent: number;

declare const XK_Greek_iotaaccentdieresis: number;

declare const XK_Greek_iotadieresis: number;

declare const XK_Greek_kappa: number;

declare const XK_Greek_lambda: number;

declare const XK_Greek_lamda: number;

declare const XK_Greek_mu: number;

declare const XK_Greek_nu: number;

declare const XK_Greek_omega: number;

declare const XK_Greek_omegaaccent: number;

declare const XK_Greek_omicron: number;

declare const XK_Greek_omicronaccent: number;

declare const XK_Greek_phi: number;

declare const XK_Greek_pi: number;

declare const XK_Greek_psi: number;

declare const XK_Greek_rho: number;

declare const XK_Greek_sigma: number;

declare const XK_Greek_switch: number;

declare const XK_Greek_tau: number;

declare const XK_Greek_theta: number;

declare const XK_Greek_upsilon: number;

declare const XK_Greek_upsilonaccent: number;

declare const XK_Greek_upsilonaccentdieresis: number;

declare const XK_Greek_upsilondieresis: number;

declare const XK_Greek_xi: number;

declare const XK_Greek_zeta: number;

declare const XK_H: number;

declare const XK_Hangul: number;

declare const XK_Hangul_A: number;

declare const XK_Hangul_AE: number;

declare const XK_Hangul_AraeA: number;

declare const XK_Hangul_AraeAE: number;

declare const XK_Hangul_Banja: number;

declare const XK_Hangul_Cieuc: number;

declare const XK_Hangul_Codeinput: number;

declare const XK_Hangul_Dikeud: number;

declare const XK_Hangul_E: number;

declare const XK_Hangul_EO: number;

declare const XK_Hangul_EU: number;

declare const XK_Hangul_End: number;

declare const XK_Hangul_Hanja: number;

declare const XK_Hangul_Hieuh: number;

declare const XK_Hangul_I: number;

declare const XK_Hangul_Ieung: number;

declare const XK_Hangul_J_Cieuc: number;

declare const XK_Hangul_J_Dikeud: number;

declare const XK_Hangul_J_Hieuh: number;

declare const XK_Hangul_J_Ieung: number;

declare const XK_Hangul_J_Jieuj: number;

declare const XK_Hangul_J_Khieuq: number;

declare const XK_Hangul_J_Kiyeog: number;

declare const XK_Hangul_J_KiyeogSios: number;

declare const XK_Hangul_J_KkogjiDalrinIeung: number;

declare const XK_Hangul_J_Mieum: number;

declare const XK_Hangul_J_Nieun: number;

declare const XK_Hangul_J_NieunHieuh: number;

declare const XK_Hangul_J_NieunJieuj: number;

declare const XK_Hangul_J_PanSios: number;

declare const XK_Hangul_J_Phieuf: number;

declare const XK_Hangul_J_Pieub: number;

declare const XK_Hangul_J_PieubSios: number;

declare const XK_Hangul_J_Rieul: number;

declare const XK_Hangul_J_RieulHieuh: number;

declare const XK_Hangul_J_RieulKiyeog: number;

declare const XK_Hangul_J_RieulMieum: number;

declare const XK_Hangul_J_RieulPhieuf: number;

declare const XK_Hangul_J_RieulPieub: number;

declare const XK_Hangul_J_RieulSios: number;

declare const XK_Hangul_J_RieulTieut: number;

declare const XK_Hangul_J_Sios: number;

declare const XK_Hangul_J_SsangKiyeog: number;

declare const XK_Hangul_J_SsangSios: number;

declare const XK_Hangul_J_Tieut: number;

declare const XK_Hangul_J_YeorinHieuh: number;

declare const XK_Hangul_Jamo: number;

declare const XK_Hangul_Jeonja: number;

declare const XK_Hangul_Jieuj: number;

declare const XK_Hangul_Khieuq: number;

declare const XK_Hangul_Kiyeog: number;

declare const XK_Hangul_KiyeogSios: number;

declare const XK_Hangul_KkogjiDalrinIeung: number;

declare const XK_Hangul_Mieum: number;

declare const XK_Hangul_MultipleCandidate: number;

declare const XK_Hangul_Nieun: number;

declare const XK_Hangul_NieunHieuh: number;

declare const XK_Hangul_NieunJieuj: number;

declare const XK_Hangul_O: number;

declare const XK_Hangul_OE: number;

declare const XK_Hangul_PanSios: number;

declare const XK_Hangul_Phieuf: number;

declare const XK_Hangul_Pieub: number;

declare const XK_Hangul_PieubSios: number;

declare const XK_Hangul_PostHanja: number;

declare const XK_Hangul_PreHanja: number;

declare const XK_Hangul_PreviousCandidate: number;

declare const XK_Hangul_Rieul: number;

declare const XK_Hangul_RieulHieuh: number;

declare const XK_Hangul_RieulKiyeog: number;

declare const XK_Hangul_RieulMieum: number;

declare const XK_Hangul_RieulPhieuf: number;

declare const XK_Hangul_RieulPieub: number;

declare const XK_Hangul_RieulSios: number;

declare const XK_Hangul_RieulTieut: number;

declare const XK_Hangul_RieulYeorinHieuh: number;

declare const XK_Hangul_Romaja: number;

declare const XK_Hangul_SingleCandidate: number;

declare const XK_Hangul_Sios: number;

declare const XK_Hangul_Special: number;

declare const XK_Hangul_SsangDikeud: number;

declare const XK_Hangul_SsangJieuj: number;

declare const XK_Hangul_SsangKiyeog: number;

declare const XK_Hangul_SsangPieub: number;

declare const XK_Hangul_SsangSios: number;

declare const XK_Hangul_Start: number;

declare const XK_Hangul_SunkyeongeumMieum: number;

declare const XK_Hangul_SunkyeongeumPhieuf: number;

declare const XK_Hangul_SunkyeongeumPieub: number;

declare const XK_Hangul_Tieut: number;

declare const XK_Hangul_U: number;

declare const XK_Hangul_WA: number;

declare const XK_Hangul_WAE: number;

declare const XK_Hangul_WE: number;

declare const XK_Hangul_WEO: number;

declare const XK_Hangul_WI: number;

declare const XK_Hangul_YA: number;

declare const XK_Hangul_YAE: number;

declare const XK_Hangul_YE: number;

declare const XK_Hangul_YEO: number;

declare const XK_Hangul_YI: number;

declare const XK_Hangul_YO: number;

declare const XK_Hangul_YU: number;

declare const XK_Hangul_YeorinHieuh: number;

declare const XK_Hangul_switch: number;

declare const XK_Hankaku: number;

declare const XK_Hcircumflex: number;

declare const XK_Hebrew_switch: number;

declare const XK_Help: number;

declare const XK_Henkan: number;

declare const XK_Henkan_Mode: number;

declare const XK_Hiragana: number;

declare const XK_Hiragana_Katakana: number;

declare const XK_Home: number;

declare const XK_Hstroke: number;

declare const XK_Hyper_L: number;

declare const XK_Hyper_R: number;

declare const XK_I: number;

declare const XK_ISO_Center_Object: number;

declare const XK_ISO_Continuous_Underline: number;

declare const XK_ISO_Discontinuous_Underline: number;

declare const XK_ISO_Emphasize: number;

declare const XK_ISO_Enter: number;

declare const XK_ISO_Fast_Cursor_Down: number;

declare const XK_ISO_Fast_Cursor_Left: number;

declare const XK_ISO_Fast_Cursor_Right: number;

declare const XK_ISO_Fast_Cursor_Up: number;

declare const XK_ISO_First_Group: number;

declare const XK_ISO_First_Group_Lock: number;

declare const XK_ISO_Group_Latch: number;

declare const XK_ISO_Group_Lock: number;

declare const XK_ISO_Group_Shift: number;

declare const XK_ISO_Last_Group: number;

declare const XK_ISO_Last_Group_Lock: number;

declare const XK_ISO_Left_Tab: number;

declare const XK_ISO_Level2_Latch: number;

declare const XK_ISO_Level3_Latch: number;

declare const XK_ISO_Level3_Lock: number;

declare const XK_ISO_Level3_Shift: number;

declare const XK_ISO_Level5_Latch: number;

declare const XK_ISO_Level5_Lock: number;

declare const XK_ISO_Level5_Shift: number;

declare const XK_ISO_Lock: number;

declare const XK_ISO_Move_Line_Down: number;

declare const XK_ISO_Move_Line_Up: number;

declare const XK_ISO_Next_Group: number;

declare const XK_ISO_Next_Group_Lock: number;

declare const XK_ISO_Partial_Line_Down: number;

declare const XK_ISO_Partial_Line_Up: number;

declare const XK_ISO_Partial_Space_Left: number;

declare const XK_ISO_Partial_Space_Right: number;

declare const XK_ISO_Prev_Group: number;

declare const XK_ISO_Prev_Group_Lock: number;

declare const XK_ISO_Release_Both_Margins: number;

declare const XK_ISO_Release_Margin_Left: number;

declare const XK_ISO_Release_Margin_Right: number;

declare const XK_ISO_Set_Margin_Left: number;

declare const XK_ISO_Set_Margin_Right: number;

declare const XK_Iabovedot: number;

declare const XK_Iacute: number;

declare const XK_Ibelowdot: number;

declare const XK_Ibreve: number;

declare const XK_Icircumflex: number;

declare const XK_Idiaeresis: number;

declare const XK_Igrave: number;

declare const XK_Ihook: number;

declare const XK_Imacron: number;

declare const XK_Insert: number;

declare const XK_Iogonek: number;

declare const XK_Itilde: number;

declare const XK_J: number;

declare const XK_Jcircumflex: number;

declare const XK_K: number;

declare const XK_KP_0: number;

declare const XK_KP_1: number;

declare const XK_KP_2: number;

declare const XK_KP_3: number;

declare const XK_KP_4: number;

declare const XK_KP_5: number;

declare const XK_KP_6: number;

declare const XK_KP_7: number;

declare const XK_KP_8: number;

declare const XK_KP_9: number;

declare const XK_KP_Add: number;

declare const XK_KP_Begin: number;

declare const XK_KP_Decimal: number;

declare const XK_KP_Delete: number;

declare const XK_KP_Divide: number;

declare const XK_KP_Down: number;

declare const XK_KP_End: number;

declare const XK_KP_Enter: number;

declare const XK_KP_Equal: number;

declare const XK_KP_F1: number;

declare const XK_KP_F2: number;

declare const XK_KP_F3: number;

declare const XK_KP_F4: number;

declare const XK_KP_Home: number;

declare const XK_KP_Insert: number;

declare const XK_KP_Left: number;

declare const XK_KP_Multiply: number;

declare const XK_KP_Next: number;

declare const XK_KP_Page_Down: number;

declare const XK_KP_Page_Up: number;

declare const XK_KP_Prior: number;

declare const XK_KP_Right: number;

declare const XK_KP_Separator: number;

declare const XK_KP_Space: number;

declare const XK_KP_Subtract: number;

declare const XK_KP_Tab: number;

declare const XK_KP_Up: number;

declare const XK_Kana_Lock: number;

declare const XK_Kana_Shift: number;

declare const XK_Kanji: number;

declare const XK_Kanji_Bangou: number;

declare const XK_Katakana: number;

declare const XK_Kcedilla: number;

declare const XK_Korean_Won: number;

declare const XK_L: number;

declare const XK_L1: number;

declare const XK_L10: number;

declare const XK_L2: number;

declare const XK_L3: number;

declare const XK_L4: number;

declare const XK_L5: number;

declare const XK_L6: number;

declare const XK_L7: number;

declare const XK_L8: number;

declare const XK_L9: number;

declare const XK_Lacute: number;

declare const XK_Last_Virtual_Screen: number;

declare const XK_Lbelowdot: number;

declare const XK_Lcaron: number;

declare const XK_Lcedilla: number;

declare const XK_Left: number;

declare const XK_Linefeed: number;

declare const XK_LiraSign: number;

declare const XK_Lstroke: number;

declare const XK_M: number;

declare const XK_Mabovedot: number;

declare const XK_Macedonia_DSE: number;

declare const XK_Macedonia_GJE: number;

declare const XK_Macedonia_KJE: number;

declare const XK_Macedonia_dse: number;

declare const XK_Macedonia_gje: number;

declare const XK_Macedonia_kje: number;

declare const XK_Mae_Koho: number;

declare const XK_Massyo: number;

declare const XK_Menu: number;

declare const XK_Meta_L: number;

declare const XK_Meta_R: number;

declare const XK_MillSign: number;

declare const XK_Mode_switch: number;

declare const XK_MouseKeys_Accel_Enable: number;

declare const XK_MouseKeys_Enable: number;

declare const XK_Muhenkan: number;

declare const XK_Multi_key: number;

declare const XK_MultipleCandidate: number;

declare const XK_N: number;

declare const XK_Nacute: number;

declare const XK_NairaSign: number;

declare const XK_Ncaron: number;

declare const XK_Ncedilla: number;

declare const XK_NewSheqelSign: number;

declare const XK_Next: number;

declare const XK_Next_Virtual_Screen: number;

declare const XK_Ntilde: number;

declare const XK_Num_Lock: number;

declare const XK_O: number;

declare const XK_OE: number;

declare const XK_Oacute: number;

declare const XK_Obarred: number;

declare const XK_Obelowdot: number;

declare const XK_Ocaron: number;

declare const XK_Ocircumflex: number;

declare const XK_Ocircumflexacute: number;

declare const XK_Ocircumflexbelowdot: number;

declare const XK_Ocircumflexgrave: number;

declare const XK_Ocircumflexhook: number;

declare const XK_Ocircumflextilde: number;

declare const XK_Odiaeresis: number;

declare const XK_Odoubleacute: number;

declare const XK_Ograve: number;

declare const XK_Ohook: number;

declare const XK_Ohorn: number;

declare const XK_Ohornacute: number;

declare const XK_Ohornbelowdot: number;

declare const XK_Ohorngrave: number;

declare const XK_Ohornhook: number;

declare const XK_Ohorntilde: number;

declare const XK_Omacron: number;

declare const XK_Ooblique: number;

declare const XK_Oslash: number;

declare const XK_Otilde: number;

declare const XK_Overlay1_Enable: number;

declare const XK_Overlay2_Enable: number;

declare const XK_P: number;

declare const XK_Pabovedot: number;

declare const XK_Page_Down: number;

declare const XK_Page_Up: number;

declare const XK_Pause: number;

declare const XK_PesetaSign: number;

declare const XK_Pointer_Accelerate: number;

declare const XK_Pointer_Button1: number;

declare const XK_Pointer_Button2: number;

declare const XK_Pointer_Button3: number;

declare const XK_Pointer_Button4: number;

declare const XK_Pointer_Button5: number;

declare const XK_Pointer_Button_Dflt: number;

declare const XK_Pointer_DblClick1: number;

declare const XK_Pointer_DblClick2: number;

declare const XK_Pointer_DblClick3: number;

declare const XK_Pointer_DblClick4: number;

declare const XK_Pointer_DblClick5: number;

declare const XK_Pointer_DblClick_Dflt: number;

declare const XK_Pointer_DfltBtnNext: number;

declare const XK_Pointer_DfltBtnPrev: number;

declare const XK_Pointer_Down: number;

declare const XK_Pointer_DownLeft: number;

declare const XK_Pointer_DownRight: number;

declare const XK_Pointer_Drag1: number;

declare const XK_Pointer_Drag2: number;

declare const XK_Pointer_Drag3: number;

declare const XK_Pointer_Drag4: number;

declare const XK_Pointer_Drag5: number;

declare const XK_Pointer_Drag_Dflt: number;

declare const XK_Pointer_EnableKeys: number;

declare const XK_Pointer_Left: number;

declare const XK_Pointer_Right: number;

declare const XK_Pointer_Up: number;

declare const XK_Pointer_UpLeft: number;

declare const XK_Pointer_UpRight: number;

declare const XK_Prev_Virtual_Screen: number;

declare const XK_PreviousCandidate: number;

declare const XK_Print: number;

declare const XK_Prior: number;

declare const XK_Q: number;

declare const XK_R: number;

declare const XK_R1: number;

declare const XK_R10: number;

declare const XK_R11: number;

declare const XK_R12: number;

declare const XK_R13: number;

declare const XK_R14: number;

declare const XK_R15: number;

declare const XK_R2: number;

declare const XK_R3: number;

declare const XK_R4: number;

declare const XK_R5: number;

declare const XK_R6: number;

declare const XK_R7: number;

declare const XK_R8: number;

declare const XK_R9: number;

declare const XK_Racute: number;

declare const XK_Rcaron: number;

declare const XK_Rcedilla: number;

declare const XK_Redo: number;

declare const XK_RepeatKeys_Enable: number;

declare const XK_Return: number;

declare const XK_Right: number;

declare const XK_Romaji: number;

declare const XK_RupeeSign: number;

declare const XK_S: number;

declare const XK_SCHWA: number;

declare const XK_Sabovedot: number;

declare const XK_Sacute: number;

declare const XK_Scaron: number;

declare const XK_Scedilla: number;

declare const XK_Scircumflex: number;

declare const XK_Scroll_Lock: number;

declare const XK_Select: number;

declare const XK_Serbian_DJE: number;

declare const XK_Serbian_DZE: number;

declare const XK_Serbian_JE: number;

declare const XK_Serbian_LJE: number;

declare const XK_Serbian_NJE: number;

declare const XK_Serbian_TSHE: number;

declare const XK_Serbian_dje: number;

declare const XK_Serbian_dze: number;

declare const XK_Serbian_je: number;

declare const XK_Serbian_lje: number;

declare const XK_Serbian_nje: number;

declare const XK_Serbian_tshe: number;

declare const XK_Shift_L: number;

declare const XK_Shift_Lock: number;

declare const XK_Shift_R: number;

declare const XK_SingleCandidate: number;

declare const XK_Sinh_a: number;

declare const XK_Sinh_aa: number;

declare const XK_Sinh_aa2: number;

declare const XK_Sinh_ae: number;

declare const XK_Sinh_ae2: number;

declare const XK_Sinh_aee: number;

declare const XK_Sinh_aee2: number;

declare const XK_Sinh_ai: number;

declare const XK_Sinh_ai2: number;

declare const XK_Sinh_al: number;

declare const XK_Sinh_au: number;

declare const XK_Sinh_au2: number;

declare const XK_Sinh_ba: number;

declare const XK_Sinh_bha: number;

declare const XK_Sinh_ca: number;

declare const XK_Sinh_cha: number;

declare const XK_Sinh_dda: number;

declare const XK_Sinh_ddha: number;

declare const XK_Sinh_dha: number;

declare const XK_Sinh_dhha: number;

declare const XK_Sinh_e: number;

declare const XK_Sinh_e2: number;

declare const XK_Sinh_ee: number;

declare const XK_Sinh_ee2: number;

declare const XK_Sinh_fa: number;

declare const XK_Sinh_ga: number;

declare const XK_Sinh_gha: number;

declare const XK_Sinh_h2: number;

declare const XK_Sinh_ha: number;

declare const XK_Sinh_i: number;

declare const XK_Sinh_i2: number;

declare const XK_Sinh_ii: number;

declare const XK_Sinh_ii2: number;

declare const XK_Sinh_ja: number;

declare const XK_Sinh_jha: number;

declare const XK_Sinh_jnya: number;

declare const XK_Sinh_ka: number;

declare const XK_Sinh_kha: number;

declare const XK_Sinh_kunddaliya: number;

declare const XK_Sinh_la: number;

declare const XK_Sinh_lla: number;

declare const XK_Sinh_lu: number;

declare const XK_Sinh_lu2: number;

declare const XK_Sinh_luu: number;

declare const XK_Sinh_luu2: number;

declare const XK_Sinh_ma: number;

declare const XK_Sinh_mba: number;

declare const XK_Sinh_na: number;

declare const XK_Sinh_ndda: number;

declare const XK_Sinh_ndha: number;

declare const XK_Sinh_ng: number;

declare const XK_Sinh_ng2: number;

declare const XK_Sinh_nga: number;

declare const XK_Sinh_nja: number;

declare const XK_Sinh_nna: number;

declare const XK_Sinh_nya: number;

declare const XK_Sinh_o: number;

declare const XK_Sinh_o2: number;

declare const XK_Sinh_oo: number;

declare const XK_Sinh_oo2: number;

declare const XK_Sinh_pa: number;

declare const XK_Sinh_pha: number;

declare const XK_Sinh_ra: number;

declare const XK_Sinh_ri: number;

declare const XK_Sinh_rii: number;

declare const XK_Sinh_ru2: number;

declare const XK_Sinh_ruu2: number;

declare const XK_Sinh_sa: number;

declare const XK_Sinh_sha: number;

declare const XK_Sinh_ssha: number;

declare const XK_Sinh_tha: number;

declare const XK_Sinh_thha: number;

declare const XK_Sinh_tta: number;

declare const XK_Sinh_ttha: number;

declare const XK_Sinh_u: number;

declare const XK_Sinh_u2: number;

declare const XK_Sinh_uu: number;

declare const XK_Sinh_uu2: number;

declare const XK_Sinh_va: number;

declare const XK_Sinh_ya: number;

declare const XK_SlowKeys_Enable: number;

declare const XK_StickyKeys_Enable: number;

declare const XK_Super_L: number;

declare const XK_Super_R: number;

declare const XK_Sys_Req: number;

declare const XK_T: number;

declare const XK_THORN: number;

declare const XK_Tab: number;

declare const XK_Tabovedot: number;

declare const XK_Tcaron: number;

declare const XK_Tcedilla: number;

declare const XK_Terminate_Server: number;

declare const XK_Thai_baht: number;

declare const XK_Thai_bobaimai: number;

declare const XK_Thai_chochan: number;

declare const XK_Thai_chochang: number;

declare const XK_Thai_choching: number;

declare const XK_Thai_chochoe: number;

declare const XK_Thai_dochada: number;

declare const XK_Thai_dodek: number;

declare const XK_Thai_fofa: number;

declare const XK_Thai_fofan: number;

declare const XK_Thai_hohip: number;

declare const XK_Thai_honokhuk: number;

declare const XK_Thai_khokhai: number;

declare const XK_Thai_khokhon: number;

declare const XK_Thai_khokhuat: number;

declare const XK_Thai_khokhwai: number;

declare const XK_Thai_khorakhang: number;

declare const XK_Thai_kokai: number;

declare const XK_Thai_lakkhangyao: number;

declare const XK_Thai_lekchet: number;

declare const XK_Thai_lekha: number;

declare const XK_Thai_lekhok: number;

declare const XK_Thai_lekkao: number;

declare const XK_Thai_leknung: number;

declare const XK_Thai_lekpaet: number;

declare const XK_Thai_leksam: number;

declare const XK_Thai_leksi: number;

declare const XK_Thai_leksong: number;

declare const XK_Thai_leksun: number;

declare const XK_Thai_lochula: number;

declare const XK_Thai_loling: number;

declare const XK_Thai_lu: number;

declare const XK_Thai_maichattawa: number;

declare const XK_Thai_maiek: number;

declare const XK_Thai_maihanakat: number;

declare const XK_Thai_maihanakat_maitho: number;

declare const XK_Thai_maitaikhu: number;

declare const XK_Thai_maitho: number;

declare const XK_Thai_maitri: number;

declare const XK_Thai_maiyamok: number;

declare const XK_Thai_moma: number;

declare const XK_Thai_ngongu: number;

declare const XK_Thai_nikhahit: number;

declare const XK_Thai_nonen: number;

declare const XK_Thai_nonu: number;

declare const XK_Thai_oang: number;

declare const XK_Thai_paiyannoi: number;

declare const XK_Thai_phinthu: number;

declare const XK_Thai_phophan: number;

declare const XK_Thai_phophung: number;

declare const XK_Thai_phosamphao: number;

declare const XK_Thai_popla: number;

declare const XK_Thai_rorua: number;

declare const XK_Thai_ru: number;

declare const XK_Thai_saraa: number;

declare const XK_Thai_saraaa: number;

declare const XK_Thai_saraae: number;

declare const XK_Thai_saraaimaimalai: number;

declare const XK_Thai_saraaimaimuan: number;

declare const XK_Thai_saraam: number;

declare const XK_Thai_sarae: number;

declare const XK_Thai_sarai: number;

declare const XK_Thai_saraii: number;

declare const XK_Thai_sarao: number;

declare const XK_Thai_sarau: number;

declare const XK_Thai_saraue: number;

declare const XK_Thai_sarauee: number;

declare const XK_Thai_sarauu: number;

declare const XK_Thai_sorusi: number;

declare const XK_Thai_sosala: number;

declare const XK_Thai_soso: number;

declare const XK_Thai_sosua: number;

declare const XK_Thai_thanthakhat: number;

declare const XK_Thai_thonangmontho: number;

declare const XK_Thai_thophuthao: number;

declare const XK_Thai_thothahan: number;

declare const XK_Thai_thothan: number;

declare const XK_Thai_thothong: number;

declare const XK_Thai_thothung: number;

declare const XK_Thai_topatak: number;

declare const XK_Thai_totao: number;

declare const XK_Thai_wowaen: number;

declare const XK_Thai_yoyak: number;

declare const XK_Thai_yoying: number;

declare const XK_Thorn: number;

declare const XK_Touroku: number;

declare const XK_Tslash: number;

declare const XK_U: number;

declare const XK_Uacute: number;

declare const XK_Ubelowdot: number;

declare const XK_Ubreve: number;

declare const XK_Ucircumflex: number;

declare const XK_Udiaeresis: number;

declare const XK_Udoubleacute: number;

declare const XK_Ugrave: number;

declare const XK_Uhook: number;

declare const XK_Uhorn: number;

declare const XK_Uhornacute: number;

declare const XK_Uhornbelowdot: number;

declare const XK_Uhorngrave: number;

declare const XK_Uhornhook: number;

declare const XK_Uhorntilde: number;

declare const XK_Ukrainian_GHE_WITH_UPTURN: number;

declare const XK_Ukrainian_I: number;

declare const XK_Ukrainian_IE: number;

declare const XK_Ukrainian_YI: number;

declare const XK_Ukrainian_ghe_with_upturn: number;

declare const XK_Ukrainian_i: number;

declare const XK_Ukrainian_ie: number;

declare const XK_Ukrainian_yi: number;

declare const XK_Ukranian_I: number;

declare const XK_Ukranian_JE: number;

declare const XK_Ukranian_YI: number;

declare const XK_Ukranian_i: number;

declare const XK_Ukranian_je: number;

declare const XK_Ukranian_yi: number;

declare const XK_Umacron: number;

declare const XK_Undo: number;

declare const XK_Uogonek: number;

declare const XK_Up: number;

declare const XK_Uring: number;

declare const XK_Utilde: number;

declare const XK_V: number;

declare const XK_VoidSymbol: number;

declare const XK_W: number;

declare const XK_Wacute: number;

declare const XK_Wcircumflex: number;

declare const XK_Wdiaeresis: number;

declare const XK_Wgrave: number;

declare const XK_WonSign: number;

declare const XK_X: number;

declare const XK_Xabovedot: number;

declare const XK_Y: number;

declare const XK_Yacute: number;

declare const XK_Ybelowdot: number;

declare const XK_Ycircumflex: number;

declare const XK_Ydiaeresis: number;

declare const XK_Ygrave: number;

declare const XK_Yhook: number;

declare const XK_Ytilde: number;

declare const XK_Z: number;

declare const XK_Zabovedot: number;

declare const XK_Zacute: number;

declare const XK_Zcaron: number;

declare const XK_Zen_Koho: number;

declare const XK_Zenkaku: number;

declare const XK_Zenkaku_Hankaku: number;

declare const XK_Zstroke: number;

declare const XK_a: number;

declare const XK_aacute: number;

declare const XK_abelowdot: number;

declare const XK_abovedot: number;

declare const XK_abreve: number;

declare const XK_abreveacute: number;

declare const XK_abrevebelowdot: number;

declare const XK_abrevegrave: number;

declare const XK_abrevehook: number;

declare const XK_abrevetilde: number;

declare const XK_acircumflex: number;

declare const XK_acircumflexacute: number;

declare const XK_acircumflexbelowdot: number;

declare const XK_acircumflexgrave: number;

declare const XK_acircumflexhook: number;

declare const XK_acircumflextilde: number;

declare const XK_acute: number;

declare const XK_adiaeresis: number;

declare const XK_ae: number;

declare const XK_agrave: number;

declare const XK_ahook: number;

declare const XK_amacron: number;

declare const XK_ampersand: number;

declare const XK_aogonek: number;

declare const XK_apostrophe: number;

declare const XK_approxeq: number;

declare const XK_aring: number;

declare const XK_asciicircum: number;

declare const XK_asciitilde: number;

declare const XK_asterisk: number;

declare const XK_at: number;

declare const XK_atilde: number;

declare const XK_b: number;

declare const XK_babovedot: number;

declare const XK_backslash: number;

declare const XK_bar: number;

declare const XK_because: number;

declare const XK_braceleft: number;

declare const XK_braceright: number;

declare const XK_bracketleft: number;

declare const XK_bracketright: number;

declare const XK_braille_blank: number;

declare const XK_braille_dot_1: number;

declare const XK_braille_dot_10: number;

declare const XK_braille_dot_2: number;

declare const XK_braille_dot_3: number;

declare const XK_braille_dot_4: number;

declare const XK_braille_dot_5: number;

declare const XK_braille_dot_6: number;

declare const XK_braille_dot_7: number;

declare const XK_braille_dot_8: number;

declare const XK_braille_dot_9: number;

declare const XK_braille_dots_1: number;

declare const XK_braille_dots_12: number;

declare const XK_braille_dots_123: number;

declare const XK_braille_dots_1234: number;

declare const XK_braille_dots_12345: number;

declare const XK_braille_dots_123456: number;

declare const XK_braille_dots_1234567: number;

declare const XK_braille_dots_12345678: number;

declare const XK_braille_dots_1234568: number;

declare const XK_braille_dots_123457: number;

declare const XK_braille_dots_1234578: number;

declare const XK_braille_dots_123458: number;

declare const XK_braille_dots_12346: number;

declare const XK_braille_dots_123467: number;

declare const XK_braille_dots_1234678: number;

declare const XK_braille_dots_123468: number;

declare const XK_braille_dots_12347: number;

declare const XK_braille_dots_123478: number;

declare const XK_braille_dots_12348: number;

declare const XK_braille_dots_1235: number;

declare const XK_braille_dots_12356: number;

declare const XK_braille_dots_123567: number;

declare const XK_braille_dots_1235678: number;

declare const XK_braille_dots_123568: number;

declare const XK_braille_dots_12357: number;

declare const XK_braille_dots_123578: number;

declare const XK_braille_dots_12358: number;

declare const XK_braille_dots_1236: number;

declare const XK_braille_dots_12367: number;

declare const XK_braille_dots_123678: number;

declare const XK_braille_dots_12368: number;

declare const XK_braille_dots_1237: number;

declare const XK_braille_dots_12378: number;

declare const XK_braille_dots_1238: number;

declare const XK_braille_dots_124: number;

declare const XK_braille_dots_1245: number;

declare const XK_braille_dots_12456: number;

declare const XK_braille_dots_124567: number;

declare const XK_braille_dots_1245678: number;

declare const XK_braille_dots_124568: number;

declare const XK_braille_dots_12457: number;

declare const XK_braille_dots_124578: number;

declare const XK_braille_dots_12458: number;

declare const XK_braille_dots_1246: number;

declare const XK_braille_dots_12467: number;

declare const XK_braille_dots_124678: number;

declare const XK_braille_dots_12468: number;

declare const XK_braille_dots_1247: number;

declare const XK_braille_dots_12478: number;

declare const XK_braille_dots_1248: number;

declare const XK_braille_dots_125: number;

declare const XK_braille_dots_1256: number;

declare const XK_braille_dots_12567: number;

declare const XK_braille_dots_125678: number;

declare const XK_braille_dots_12568: number;

declare const XK_braille_dots_1257: number;

declare const XK_braille_dots_12578: number;

declare const XK_braille_dots_1258: number;

declare const XK_braille_dots_126: number;

declare const XK_braille_dots_1267: number;

declare const XK_braille_dots_12678: number;

declare const XK_braille_dots_1268: number;

declare const XK_braille_dots_127: number;

declare const XK_braille_dots_1278: number;

declare const XK_braille_dots_128: number;

declare const XK_braille_dots_13: number;

declare const XK_braille_dots_134: number;

declare const XK_braille_dots_1345: number;

declare const XK_braille_dots_13456: number;

declare const XK_braille_dots_134567: number;

declare const XK_braille_dots_1345678: number;

declare const XK_braille_dots_134568: number;

declare const XK_braille_dots_13457: number;

declare const XK_braille_dots_134578: number;

declare const XK_braille_dots_13458: number;

declare const XK_braille_dots_1346: number;

declare const XK_braille_dots_13467: number;

declare const XK_braille_dots_134678: number;

declare const XK_braille_dots_13468: number;

declare const XK_braille_dots_1347: number;

declare const XK_braille_dots_13478: number;

declare const XK_braille_dots_1348: number;

declare const XK_braille_dots_135: number;

declare const XK_braille_dots_1356: number;

declare const XK_braille_dots_13567: number;

declare const XK_braille_dots_135678: number;

declare const XK_braille_dots_13568: number;

declare const XK_braille_dots_1357: number;

declare const XK_braille_dots_13578: number;

declare const XK_braille_dots_1358: number;

declare const XK_braille_dots_136: number;

declare const XK_braille_dots_1367: number;

declare const XK_braille_dots_13678: number;

declare const XK_braille_dots_1368: number;

declare const XK_braille_dots_137: number;

declare const XK_braille_dots_1378: number;

declare const XK_braille_dots_138: number;

declare const XK_braille_dots_14: number;

declare const XK_braille_dots_145: number;

declare const XK_braille_dots_1456: number;

declare const XK_braille_dots_14567: number;

declare const XK_braille_dots_145678: number;

declare const XK_braille_dots_14568: number;

declare const XK_braille_dots_1457: number;

declare const XK_braille_dots_14578: number;

declare const XK_braille_dots_1458: number;

declare const XK_braille_dots_146: number;

declare const XK_braille_dots_1467: number;

declare const XK_braille_dots_14678: number;

declare const XK_braille_dots_1468: number;

declare const XK_braille_dots_147: number;

declare const XK_braille_dots_1478: number;

declare const XK_braille_dots_148: number;

declare const XK_braille_dots_15: number;

declare const XK_braille_dots_156: number;

declare const XK_braille_dots_1567: number;

declare const XK_braille_dots_15678: number;

declare const XK_braille_dots_1568: number;

declare const XK_braille_dots_157: number;

declare const XK_braille_dots_1578: number;

declare const XK_braille_dots_158: number;

declare const XK_braille_dots_16: number;

declare const XK_braille_dots_167: number;

declare const XK_braille_dots_1678: number;

declare const XK_braille_dots_168: number;

declare const XK_braille_dots_17: number;

declare const XK_braille_dots_178: number;

declare const XK_braille_dots_18: number;

declare const XK_braille_dots_2: number;

declare const XK_braille_dots_23: number;

declare const XK_braille_dots_234: number;

declare const XK_braille_dots_2345: number;

declare const XK_braille_dots_23456: number;

declare const XK_braille_dots_234567: number;

declare const XK_braille_dots_2345678: number;

declare const XK_braille_dots_234568: number;

declare const XK_braille_dots_23457: number;

declare const XK_braille_dots_234578: number;

declare const XK_braille_dots_23458: number;

declare const XK_braille_dots_2346: number;

declare const XK_braille_dots_23467: number;

declare const XK_braille_dots_234678: number;

declare const XK_braille_dots_23468: number;

declare const XK_braille_dots_2347: number;

declare const XK_braille_dots_23478: number;

declare const XK_braille_dots_2348: number;

declare const XK_braille_dots_235: number;

declare const XK_braille_dots_2356: number;

declare const XK_braille_dots_23567: number;

declare const XK_braille_dots_235678: number;

declare const XK_braille_dots_23568: number;

declare const XK_braille_dots_2357: number;

declare const XK_braille_dots_23578: number;

declare const XK_braille_dots_2358: number;

declare const XK_braille_dots_236: number;

declare const XK_braille_dots_2367: number;

declare const XK_braille_dots_23678: number;

declare const XK_braille_dots_2368: number;

declare const XK_braille_dots_237: number;

declare const XK_braille_dots_2378: number;

declare const XK_braille_dots_238: number;

declare const XK_braille_dots_24: number;

declare const XK_braille_dots_245: number;

declare const XK_braille_dots_2456: number;

declare const XK_braille_dots_24567: number;

declare const XK_braille_dots_245678: number;

declare const XK_braille_dots_24568: number;

declare const XK_braille_dots_2457: number;

declare const XK_braille_dots_24578: number;

declare const XK_braille_dots_2458: number;

declare const XK_braille_dots_246: number;

declare const XK_braille_dots_2467: number;

declare const XK_braille_dots_24678: number;

declare const XK_braille_dots_2468: number;

declare const XK_braille_dots_247: number;

declare const XK_braille_dots_2478: number;

declare const XK_braille_dots_248: number;

declare const XK_braille_dots_25: number;

declare const XK_braille_dots_256: number;

declare const XK_braille_dots_2567: number;

declare const XK_braille_dots_25678: number;

declare const XK_braille_dots_2568: number;

declare const XK_braille_dots_257: number;

declare const XK_braille_dots_2578: number;

declare const XK_braille_dots_258: number;

declare const XK_braille_dots_26: number;

declare const XK_braille_dots_267: number;

declare const XK_braille_dots_2678: number;

declare const XK_braille_dots_268: number;

declare const XK_braille_dots_27: number;

declare const XK_braille_dots_278: number;

declare const XK_braille_dots_28: number;

declare const XK_braille_dots_3: number;

declare const XK_braille_dots_34: number;

declare const XK_braille_dots_345: number;

declare const XK_braille_dots_3456: number;

declare const XK_braille_dots_34567: number;

declare const XK_braille_dots_345678: number;

declare const XK_braille_dots_34568: number;

declare const XK_braille_dots_3457: number;

declare const XK_braille_dots_34578: number;

declare const XK_braille_dots_3458: number;

declare const XK_braille_dots_346: number;

declare const XK_braille_dots_3467: number;

declare const XK_braille_dots_34678: number;

declare const XK_braille_dots_3468: number;

declare const XK_braille_dots_347: number;

declare const XK_braille_dots_3478: number;

declare const XK_braille_dots_348: number;

declare const XK_braille_dots_35: number;

declare const XK_braille_dots_356: number;

declare const XK_braille_dots_3567: number;

declare const XK_braille_dots_35678: number;

declare const XK_braille_dots_3568: number;

declare const XK_braille_dots_357: number;

declare const XK_braille_dots_3578: number;

declare const XK_braille_dots_358: number;

declare const XK_braille_dots_36: number;

declare const XK_braille_dots_367: number;

declare const XK_braille_dots_3678: number;

declare const XK_braille_dots_368: number;

declare const XK_braille_dots_37: number;

declare const XK_braille_dots_378: number;

declare const XK_braille_dots_38: number;

declare const XK_braille_dots_4: number;

declare const XK_braille_dots_45: number;

declare const XK_braille_dots_456: number;

declare const XK_braille_dots_4567: number;

declare const XK_braille_dots_45678: number;

declare const XK_braille_dots_4568: number;

declare const XK_braille_dots_457: number;

declare const XK_braille_dots_4578: number;

declare const XK_braille_dots_458: number;

declare const XK_braille_dots_46: number;

declare const XK_braille_dots_467: number;

declare const XK_braille_dots_4678: number;

declare const XK_braille_dots_468: number;

declare const XK_braille_dots_47: number;

declare const XK_braille_dots_478: number;

declare const XK_braille_dots_48: number;

declare const XK_braille_dots_5: number;

declare const XK_braille_dots_56: number;

declare const XK_braille_dots_567: number;

declare const XK_braille_dots_5678: number;

declare const XK_braille_dots_568: number;

declare const XK_braille_dots_57: number;

declare const XK_braille_dots_578: number;

declare const XK_braille_dots_58: number;

declare const XK_braille_dots_6: number;

declare const XK_braille_dots_67: number;

declare const XK_braille_dots_678: number;

declare const XK_braille_dots_68: number;

declare const XK_braille_dots_7: number;

declare const XK_braille_dots_78: number;

declare const XK_braille_dots_8: number;

declare const XK_breve: number;

declare const XK_brokenbar: number;

declare const XK_c: number;

declare const XK_c_h: number;

declare const XK_cabovedot: number;

declare const XK_cacute: number;

declare const XK_caron: number;

declare const XK_ccaron: number;

declare const XK_ccedilla: number;

declare const XK_ccircumflex: number;

declare const XK_cedilla: number;

declare const XK_cent: number;

declare const XK_ch: number;

declare const XK_colon: number;

declare const XK_combining_acute: number;

declare const XK_combining_belowdot: number;

declare const XK_combining_grave: number;

declare const XK_combining_hook: number;

declare const XK_combining_tilde: number;

declare const XK_comma: number;

declare const XK_containsas: number;

declare const XK_copyright: number;

declare const XK_cuberoot: number;

declare const XK_currency: number;

declare const XK_d: number;

declare const XK_dabovedot: number;

declare const XK_dcaron: number;

declare const XK_dead_A: number;

declare const XK_dead_E: number;

declare const XK_dead_I: number;

declare const XK_dead_O: number;

declare const XK_dead_SCHWA: number;

declare const XK_dead_U: number;

declare const XK_dead_a: number;

declare const XK_dead_abovecomma: number;

declare const XK_dead_abovedot: number;

declare const XK_dead_abovereversedcomma: number;

declare const XK_dead_abovering: number;

declare const XK_dead_acute: number;

declare const XK_dead_belowbreve: number;

declare const XK_dead_belowcircumflex: number;

declare const XK_dead_belowcomma: number;

declare const XK_dead_belowdiaeresis: number;

declare const XK_dead_belowdot: number;

declare const XK_dead_belowmacron: number;

declare const XK_dead_belowring: number;

declare const XK_dead_belowtilde: number;

declare const XK_dead_breve: number;

declare const XK_dead_capital_schwa: number;

declare const XK_dead_caron: number;

declare const XK_dead_cedilla: number;

declare const XK_dead_circumflex: number;

declare const XK_dead_currency: number;

declare const XK_dead_dasia: number;

declare const XK_dead_diaeresis: number;

declare const XK_dead_doubleacute: number;

declare const XK_dead_doublegrave: number;

declare const XK_dead_e: number;

declare const XK_dead_grave: number;

declare const XK_dead_greek: number;

declare const XK_dead_hook: number;

declare const XK_dead_horn: number;

declare const XK_dead_i: number;

declare const XK_dead_invertedbreve: number;

declare const XK_dead_iota: number;

declare const XK_dead_macron: number;

declare const XK_dead_o: number;

declare const XK_dead_ogonek: number;

declare const XK_dead_perispomeni: number;

declare const XK_dead_psili: number;

declare const XK_dead_schwa: number;

declare const XK_dead_semivoiced_sound: number;

declare const XK_dead_small_schwa: number;

declare const XK_dead_stroke: number;

declare const XK_dead_tilde: number;

declare const XK_dead_u: number;

declare const XK_dead_voiced_sound: number;

declare const XK_degree: number;

declare const XK_diaeresis: number;

declare const XK_dintegral: number;

declare const XK_division: number;

declare const XK_dollar: number;

declare const XK_doubleacute: number;

declare const XK_dstroke: number;

declare const XK_e: number;

declare const XK_eabovedot: number;

declare const XK_eacute: number;

declare const XK_ebelowdot: number;

declare const XK_ecaron: number;

declare const XK_ecircumflex: number;

declare const XK_ecircumflexacute: number;

declare const XK_ecircumflexbelowdot: number;

declare const XK_ecircumflexgrave: number;

declare const XK_ecircumflexhook: number;

declare const XK_ecircumflextilde: number;

declare const XK_ediaeresis: number;

declare const XK_egrave: number;

declare const XK_ehook: number;

declare const XK_eightsubscript: number;

declare const XK_eightsuperior: number;

declare const XK_elementof: number;

declare const XK_emacron: number;

declare const XK_emptyset: number;

declare const XK_eng: number;

declare const XK_eogonek: number;

declare const XK_equal: number;

declare const XK_eth: number;

declare const XK_etilde: number;

declare const XK_exclam: number;

declare const XK_exclamdown: number;

declare const XK_ezh: number;

declare const XK_f: number;

declare const XK_fabovedot: number;

declare const XK_fivesubscript: number;

declare const XK_fivesuperior: number;

declare const XK_foursubscript: number;

declare const XK_foursuperior: number;

declare const XK_fourthroot: number;

declare const XK_g: number;

declare const XK_gabovedot: number;

declare const XK_gbreve: number;

declare const XK_gcaron: number;

declare const XK_gcedilla: number;

declare const XK_gcircumflex: number;

declare const XK_grave: number;

declare const XK_greater: number;

declare const XK_guillemetleft: number;

declare const XK_guillemetright: number;

declare const XK_guillemotleft: number;

declare const XK_guillemotright: number;

declare const XK_h: number;

declare const XK_hcircumflex: number;

declare const XK_hebrew_aleph: number;

declare const XK_hebrew_ayin: number;

declare const XK_hebrew_bet: number;

declare const XK_hebrew_beth: number;

declare const XK_hebrew_chet: number;

declare const XK_hebrew_dalet: number;

declare const XK_hebrew_daleth: number;

declare const XK_hebrew_doublelowline: number;

declare const XK_hebrew_finalkaph: number;

declare const XK_hebrew_finalmem: number;

declare const XK_hebrew_finalnun: number;

declare const XK_hebrew_finalpe: number;

declare const XK_hebrew_finalzade: number;

declare const XK_hebrew_finalzadi: number;

declare const XK_hebrew_gimel: number;

declare const XK_hebrew_gimmel: number;

declare const XK_hebrew_he: number;

declare const XK_hebrew_het: number;

declare const XK_hebrew_kaph: number;

declare const XK_hebrew_kuf: number;

declare const XK_hebrew_lamed: number;

declare const XK_hebrew_mem: number;

declare const XK_hebrew_nun: number;

declare const XK_hebrew_pe: number;

declare const XK_hebrew_qoph: number;

declare const XK_hebrew_resh: number;

declare const XK_hebrew_samech: number;

declare const XK_hebrew_samekh: number;

declare const XK_hebrew_shin: number;

declare const XK_hebrew_taf: number;

declare const XK_hebrew_taw: number;

declare const XK_hebrew_tet: number;

declare const XK_hebrew_teth: number;

declare const XK_hebrew_waw: number;

declare const XK_hebrew_yod: number;

declare const XK_hebrew_zade: number;

declare const XK_hebrew_zadi: number;

declare const XK_hebrew_zain: number;

declare const XK_hebrew_zayin: number;

declare const XK_hstroke: number;

declare const XK_hyphen: number;

declare const XK_i: number;

declare const XK_iacute: number;

declare const XK_ibelowdot: number;

declare const XK_ibreve: number;

declare const XK_icircumflex: number;

declare const XK_idiaeresis: number;

declare const XK_idotless: number;

declare const XK_igrave: number;

declare const XK_ihook: number;

declare const XK_imacron: number;

declare const XK_iogonek: number;

declare const XK_itilde: number;

declare const XK_j: number;

declare const XK_jcircumflex: number;

declare const XK_k: number;

declare const XK_kana_A: number;

declare const XK_kana_CHI: number;

declare const XK_kana_E: number;

declare const XK_kana_FU: number;

declare const XK_kana_HA: number;

declare const XK_kana_HE: number;

declare const XK_kana_HI: number;

declare const XK_kana_HO: number;

declare const XK_kana_HU: number;

declare const XK_kana_I: number;

declare const XK_kana_KA: number;

declare const XK_kana_KE: number;

declare const XK_kana_KI: number;

declare const XK_kana_KO: number;

declare const XK_kana_KU: number;

declare const XK_kana_MA: number;

declare const XK_kana_ME: number;

declare const XK_kana_MI: number;

declare const XK_kana_MO: number;

declare const XK_kana_MU: number;

declare const XK_kana_N: number;

declare const XK_kana_NA: number;

declare const XK_kana_NE: number;

declare const XK_kana_NI: number;

declare const XK_kana_NO: number;

declare const XK_kana_NU: number;

declare const XK_kana_O: number;

declare const XK_kana_RA: number;

declare const XK_kana_RE: number;

declare const XK_kana_RI: number;

declare const XK_kana_RO: number;

declare const XK_kana_RU: number;

declare const XK_kana_SA: number;

declare const XK_kana_SE: number;

declare const XK_kana_SHI: number;

declare const XK_kana_SO: number;

declare const XK_kana_SU: number;

declare const XK_kana_TA: number;

declare const XK_kana_TE: number;

declare const XK_kana_TI: number;

declare const XK_kana_TO: number;

declare const XK_kana_TSU: number;

declare const XK_kana_TU: number;

declare const XK_kana_U: number;

declare const XK_kana_WA: number;

declare const XK_kana_WO: number;

declare const XK_kana_YA: number;

declare const XK_kana_YO: number;

declare const XK_kana_YU: number;

declare const XK_kana_a: number;

declare const XK_kana_closingbracket: number;

declare const XK_kana_comma: number;

declare const XK_kana_conjunctive: number;

declare const XK_kana_e: number;

declare const XK_kana_fullstop: number;

declare const XK_kana_i: number;

declare const XK_kana_middledot: number;

declare const XK_kana_o: number;

declare const XK_kana_openingbracket: number;

declare const XK_kana_switch: number;

declare const XK_kana_tsu: number;

declare const XK_kana_tu: number;

declare const XK_kana_u: number;

declare const XK_kana_ya: number;

declare const XK_kana_yo: number;

declare const XK_kana_yu: number;

declare const XK_kappa: number;

declare const XK_kcedilla: number;

declare const XK_kra: number;

declare const XK_l: number;

declare const XK_lacute: number;

declare const XK_lbelowdot: number;

declare const XK_lcaron: number;

declare const XK_lcedilla: number;

declare const XK_less: number;

declare const XK_lstroke: number;

declare const XK_m: number;

declare const XK_mabovedot: number;

declare const XK_macron: number;

declare const XK_masculine: number;

declare const XK_minus: number;

declare const XK_mu: number;

declare const XK_multiply: number;

declare const XK_n: number;

declare const XK_nacute: number;

declare const XK_ncaron: number;

declare const XK_ncedilla: number;

declare const XK_ninesubscript: number;

declare const XK_ninesuperior: number;

declare const XK_nobreakspace: number;

declare const XK_notapproxeq: number;

declare const XK_notelementof: number;

declare const XK_notidentical: number;

declare const XK_notsign: number;

declare const XK_ntilde: number;

declare const XK_numbersign: number;

declare const XK_numerosign: number;

declare const XK_o: number;

declare const XK_oacute: number;

declare const XK_obarred: number;

declare const XK_obelowdot: number;

declare const XK_ocaron: number;

declare const XK_ocircumflex: number;

declare const XK_ocircumflexacute: number;

declare const XK_ocircumflexbelowdot: number;

declare const XK_ocircumflexgrave: number;

declare const XK_ocircumflexhook: number;

declare const XK_ocircumflextilde: number;

declare const XK_odiaeresis: number;

declare const XK_odoubleacute: number;

declare const XK_oe: number;

declare const XK_ogonek: number;

declare const XK_ograve: number;

declare const XK_ohook: number;

declare const XK_ohorn: number;

declare const XK_ohornacute: number;

declare const XK_ohornbelowdot: number;

declare const XK_ohorngrave: number;

declare const XK_ohornhook: number;

declare const XK_ohorntilde: number;

declare const XK_omacron: number;

declare const XK_onehalf: number;

declare const XK_onequarter: number;

declare const XK_onesubscript: number;

declare const XK_onesuperior: number;

declare const XK_ooblique: number;

declare const XK_ordfeminine: number;

declare const XK_ordmasculine: number;

declare const XK_oslash: number;

declare const XK_otilde: number;

declare const XK_overline: number;

declare const XK_p: number;

declare const XK_pabovedot: number;

declare const XK_paragraph: number;

declare const XK_parenleft: number;

declare const XK_parenright: number;

declare const XK_partdifferential: number;

declare const XK_percent: number;

declare const XK_period: number;

declare const XK_periodcentered: number;

declare const XK_plus: number;

declare const XK_plusminus: number;

declare const XK_prolongedsound: number;

declare const XK_q: number;

declare const XK_question: number;

declare const XK_questiondown: number;

declare const XK_quotedbl: number;

declare const XK_quoteleft: number;

declare const XK_quoteright: number;

declare const XK_r: number;

declare const XK_racute: number;

declare const XK_rcaron: number;

declare const XK_rcedilla: number;

declare const XK_registered: number;

declare const XK_s: number;

declare const XK_sabovedot: number;

declare const XK_sacute: number;

declare const XK_scaron: number;

declare const XK_scedilla: number;

declare const XK_schwa: number;

declare const XK_scircumflex: number;

declare const XK_script_switch: number;

declare const XK_section: number;

declare const XK_semicolon: number;

declare const XK_semivoicedsound: number;

declare const XK_sevensubscript: number;

declare const XK_sevensuperior: number;

declare const XK_sixsubscript: number;

declare const XK_sixsuperior: number;

declare const XK_slash: number;

declare const XK_space: number;

declare const XK_squareroot: number;

declare const XK_ssharp: number;

declare const XK_sterling: number;

declare const XK_stricteq: number;

declare const XK_t: number;

declare const XK_tabovedot: number;

declare const XK_tcaron: number;

declare const XK_tcedilla: number;

declare const XK_thorn: number;

declare const XK_threequarters: number;

declare const XK_threesubscript: number;

declare const XK_threesuperior: number;

declare const XK_tintegral: number;

declare const XK_tslash: number;

declare const XK_twosubscript: number;

declare const XK_twosuperior: number;

declare const XK_u: number;

declare const XK_uacute: number;

declare const XK_ubelowdot: number;

declare const XK_ubreve: number;

declare const XK_ucircumflex: number;

declare const XK_udiaeresis: number;

declare const XK_udoubleacute: number;

declare const XK_ugrave: number;

declare const XK_uhook: number;

declare const XK_uhorn: number;

declare const XK_uhornacute: number;

declare const XK_uhornbelowdot: number;

declare const XK_uhorngrave: number;

declare const XK_uhornhook: number;

declare const XK_uhorntilde: number;

declare const XK_umacron: number;

declare const XK_underscore: number;

declare const XK_uogonek: number;

declare const XK_uring: number;

declare const XK_utilde: number;

declare const XK_v: number;

declare const XK_voicedsound: number;

declare const XK_w: number;

declare const XK_wacute: number;

declare const XK_wcircumflex: number;

declare const XK_wdiaeresis: number;

declare const XK_wgrave: number;

declare const XK_x: number;

declare const XK_xabovedot: number;

declare const XK_y: number;

declare const XK_yacute: number;

declare const XK_ybelowdot: number;

declare const XK_ycircumflex: number;

declare const XK_ydiaeresis: number;

declare const XK_yen: number;

declare const XK_ygrave: number;

declare const XK_yhook: number;

declare const XK_ytilde: number;

declare const XK_z: number;

declare const XK_zabovedot: number;

declare const XK_zacute: number;

declare const XK_zcaron: number;

declare const XK_zerosubscript: number;

declare const XK_zerosuperior: number;

declare const XK_zstroke: number;

interface XKeyEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
	root: number;
	subwindow: number;
	time: number;
	x: number;
	y: number;
	x_root: number;
	y_root: number;
	state: number;
	keycode: number;
	same_screen: number;
}
declare var XKeyEvent: interop.StructType<XKeyEvent>;

interface XKeyboardControl {
	key_click_percent: number;
	bell_percent: number;
	bell_pitch: number;
	bell_duration: number;
	led: number;
	led_mode: number;
	key: number;
	auto_repeat_mode: number;
}
declare var XKeyboardControl: interop.StructType<XKeyboardControl>;

interface XKeyboardState {
	key_click_percent: number;
	bell_percent: number;
	bell_pitch: number;
	bell_duration: number;
	led_mask: number;
	global_auto_repeat: number;
	auto_repeats: interop.Reference<number>;
}
declare var XKeyboardState: interop.StructType<XKeyboardState>;

declare function XKeycodeToKeysym(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

interface XKeymapEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
	key_vector: interop.Reference<number>;
}
declare var XKeymapEvent: interop.StructType<XKeymapEvent>;

declare function XKeysymToKeycode(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XKeysymToString(p1: number): interop.Pointer | interop.Reference<any> | null;

declare function XKillClient(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XLastKnownRequestProcessed(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XListDepths(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function XListExtensions(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;

declare function XListFonts(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;

declare function XListFontsWithInfo(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<XFontStruct> | null> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;

declare function XListHosts(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<XHostAddress> | null;

declare function XListInstalledColormaps(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function XListPixmapFormats(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<XPixmapFormatValues> | null;

declare function XListProperties(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function XLoadFont(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XLoadQueryFont(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<XFontStruct> | null;

declare const XLocaleNotSupported: number;

declare function XLocaleOfFontSet(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function XLocaleOfIM(p1: interop.Pointer | interop.Reference<_XIM> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function XLocaleOfOM(p1: interop.Pointer | interop.Reference<_XOM> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function XLockDisplay(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): void;

declare const XLookupBoth: number;

declare const XLookupChars: number;

declare function XLookupColor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null): number;

declare const XLookupKeySym: number;

declare function XLookupKeysym(p1: interop.Pointer | interop.Reference<XKeyEvent> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare const XLookupNone: number;

declare function XLookupString(p1: interop.Pointer | interop.Reference<XKeyEvent> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<XComposeStatus> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XLowerWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

interface XMapEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	event: number;
	window: number;
	override_redirect: number;
}
declare var XMapEvent: interop.StructType<XMapEvent>;

declare function XMapRaised(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

interface XMapRequestEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	parent: number;
	window: number;
}
declare var XMapRequestEvent: interop.StructType<XMapRequestEvent>;

declare function XMapSubwindows(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XMapWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

interface XMappingEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
	request: number;
	first_keycode: number;
	count: number;
}
declare var XMappingEvent: interop.StructType<XMappingEvent>;

declare function XMaskEvent(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XEvent> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XMatchVisualInfo(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: interop.Pointer | interop.Reference<XVisualInfo> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XMaxCmapsOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XMaxRequestSize(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XMinCmapsOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

interface XModifierKeymap {
	max_keypermod: number;
	modifiermap: interop.Pointer | interop.Reference<any> | null;
}
declare var XModifierKeymap: interop.StructType<XModifierKeymap>;

interface XMotionEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
	root: number;
	subwindow: number;
	time: number;
	x: number;
	y: number;
	x_root: number;
	y_root: number;
	state: number;
	is_hint: number;
	same_screen: number;
}
declare var XMotionEvent: interop.StructType<XMotionEvent>;

declare function XMoveResizeWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number): number;

declare function XMoveWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number): number;

declare const XNArea: string;

declare const XNAreaNeeded: string;

declare const XNBackground: string;

declare const XNBackgroundPixmap: string;

declare const XNBaseFontName: string;

declare const XNClientWindow: string;

declare const XNColormap: string;

declare const XNContextualDrawing: string;

declare const XNCursor: string;

declare const XNDefaultString: string;

declare const XNDestroyCallback: string;

declare const XNDirectionalDependentDrawing: string;

declare const XNFilterEvents: string;

declare const XNFocusWindow: string;

declare const XNFontInfo: string;

declare const XNFontSet: string;

declare const XNForeground: string;

declare const XNGeometryCallback: string;

declare const XNHotKey: string;

declare const XNHotKeyState: string;

declare const XNInputStyle: string;

declare const XNLineSpace: string;

declare const XNMissingCharSet: string;

declare const XNOMAutomatic: string;

declare const XNOrientation: string;

declare const XNPreeditAttributes: string;

declare const XNPreeditCaretCallback: string;

declare const XNPreeditDoneCallback: string;

declare const XNPreeditDrawCallback: string;

declare const XNPreeditStartCallback: string;

declare const XNPreeditState: string;

declare const XNPreeditStateNotifyCallback: string;

declare const XNQueryICValuesList: string;

declare const XNQueryIMValuesList: string;

declare const XNQueryInputStyle: string;

declare const XNQueryOrientation: string;

declare const XNR6PreeditCallback: string;

declare const XNRequiredCharSet: string;

declare const XNResetState: string;

declare const XNResourceClass: string;

declare const XNResourceName: string;

declare const XNSeparatorofNestedList: string;

declare const XNSpotLocation: string;

declare const XNStatusAttributes: string;

declare const XNStatusDoneCallback: string;

declare const XNStatusDrawCallback: string;

declare const XNStatusStartCallback: string;

declare const XNStdColormap: string;

declare const XNStringConversion: string;

declare const XNStringConversionCallback: string;

declare const XNVaNestedList: string;

declare const XNVisiblePosition: string;

declare const XNegative: number;

declare function XNewModifiermap(p1: number): interop.Pointer | interop.Reference<XModifierKeymap> | null;

declare function XNextEvent(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XEvent> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XNextRequest(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

interface XNoExposeEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	drawable: number;
	major_code: number;
	minor_code: number;
}
declare var XNoExposeEvent: interop.StructType<XNoExposeEvent>;

declare const XNoMemory: number;

declare function XNoOp(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

interface XOMCharSetList {
	charset_count: number;
	charset_list: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;
}
declare var XOMCharSetList: interop.StructType<XOMCharSetList>;

interface XOMFontInfo {
	num_font: number;
	font_struct_list: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<XFontStruct> | null> | null;
	font_name_list: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null;
}
declare var XOMFontInfo: interop.StructType<XOMFontInfo>;

declare function XOMOfOC(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<_XOM> | null;

interface XOMOrientation {
	num_orientation: number;
	orientation: interop.Pointer | interop.Reference<XOrientation> | null;
}
declare var XOMOrientation: interop.StructType<XOMOrientation>;

declare function XOffsetRegion(p1: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XOpenDisplay(p1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<Display> | null;

declare function XOpenIM(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XrmHashBucketRec> | ArrayBufferLike | ArrayBufferView | null, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<_XIM> | null;

declare function XOpenOM(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XrmHashBucketRec> | ArrayBufferLike | ArrayBufferView | null, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<_XOM> | null;

declare const enum XOrientation {

	LTR_TTB = 0,

	RTL_TTB = 1,

	TTB_LTR = 2,

	TTB_RTL = 3,

	Context = 4
}

declare function XParseColor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XParseGeometry(p1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XPeekEvent(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XEvent> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XPeekIfEvent(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XEvent> | ArrayBufferLike | ArrayBufferView | null, p3: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null, p2: interop.Pointer | interop.Reference<XEvent> | null, p3: interop.Pointer | interop.Reference<any> | null) => number>, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XPending(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

interface XPixmapFormatValues {
	depth: number;
	bits_per_pixel: number;
	scanline_pad: number;
}
declare var XPixmapFormatValues: interop.StructType<XPixmapFormatValues>;

declare function XPlanesOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

interface XPoint {
	x: number;
	y: number;
}
declare var XPoint: interop.StructType<XPoint>;

declare function XPointInRegion(p1: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XPolygonRegion(p1: interop.Pointer | interop.Reference<XPoint> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): interop.Pointer | interop.Reference<_XRegion> | null;

declare function XProcessInternalConnection(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): void;

interface XPropertyEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
	atom: number;
	time: number;
	state: number;
}
declare var XPropertyEvent: interop.StructType<XPropertyEvent>;

declare function XProtocolRevision(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XProtocolVersion(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XPutBackEvent(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XEvent> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XPutImage(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<XImage> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: number, p7: number, p8: number, p9: number, p10: number): number;

declare function XQLength(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XQueryBestCursor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XQueryBestSize(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p7: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XQueryBestStipple(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XQueryBestTile(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XQueryColor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XQueryColors(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null, p4: number): number;

declare function XQueryExtension(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XQueryFont(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): interop.Pointer | interop.Reference<XFontStruct> | null;

declare function XQueryKeymap(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Reference<number>): number;

declare function XQueryPointer(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p7: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p8: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p9: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XQueryTextExtents(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p7: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p8: interop.Pointer | interop.Reference<XCharStruct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XQueryTextExtents16(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XChar2b> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p7: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p8: interop.Pointer | interop.Reference<XCharStruct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XQueryTree(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XRaiseWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XReadBitmapFile(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p7: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p8: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XReadBitmapFileData(p1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XRebindKeysym(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p6: number): number;

declare function XRecolorCursor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XReconfigureWMWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: interop.Pointer | interop.Reference<XWindowChanges> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XRectInRegion(p1: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number): number;

interface XRectangle {
	x: number;
	y: number;
	width: number;
	height: number;
}
declare var XRectangle: interop.StructType<XRectangle>;

declare function XRefreshKeyboardMapping(p1: interop.Pointer | interop.Reference<XMappingEvent> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XRegisterIMInstantiateCallback(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XrmHashBucketRec> | ArrayBufferLike | ArrayBufferView | null, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p5: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: interop.Pointer | interop.Reference<any> | null) => void>, p6: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XRemoveConnectionWatch(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: number, p4: number, p5: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null) => void>, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XRemoveFromSaveSet(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XRemoveHost(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XHostAddress> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XRemoveHosts(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XHostAddress> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

interface XReparentEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	event: number;
	window: number;
	parent: number;
	x: number;
	y: number;
	override_redirect: number;
}
declare var XReparentEvent: interop.StructType<XReparentEvent>;

declare function XReparentWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number): number;

declare function XResetScreenSaver(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

interface XResizeRequestEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
	width: number;
	height: number;
}
declare var XResizeRequestEvent: interop.StructType<XResizeRequestEvent>;

declare function XResizeWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number): number;

declare function XResourceManagerString(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function XRestackWindows(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XRootWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XRootWindowOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XRotateBuffers(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XRotateWindowProperties(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number): number;

declare function XSaveContext(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XScreenCount(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XScreenNumberOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XScreenOfDisplay(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): interop.Pointer | interop.Reference<Screen> | null;

declare function XScreenResourceString(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

interface XSegment {
	x1: number;
	y1: number;
	x2: number;
	y2: number;
}
declare var XSegment: interop.StructType<XSegment>;

declare function XSelectInput(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

interface XSelectionClearEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
	selection: number;
	time: number;
}
declare var XSelectionClearEvent: interop.StructType<XSelectionClearEvent>;

interface XSelectionEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	requestor: number;
	selection: number;
	target: number;
	property: number;
	time: number;
}
declare var XSelectionEvent: interop.StructType<XSelectionEvent>;

interface XSelectionRequestEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	owner: number;
	requestor: number;
	selection: number;
	target: number;
	property: number;
	time: number;
}
declare var XSelectionRequestEvent: interop.StructType<XSelectionRequestEvent>;

declare function XSendEvent(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: interop.Pointer | interop.Reference<XEvent> | ArrayBufferLike | ArrayBufferView | null): number;

interface XServerInterpretedAddress {
	typelength: number;
	valuelength: number;
	type: interop.Pointer | interop.Reference<any> | null;
	value: interop.Pointer | interop.Reference<any> | null;
}
declare var XServerInterpretedAddress: interop.StructType<XServerInterpretedAddress>;

declare function XServerVendor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function XSetAccessControl(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XSetAfterFunction(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null) => number>): interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null) => number>;

declare function XSetArcMode(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetAuthorization(p1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: number): void;

declare function XSetBackground(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetClassHint(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XClassHint> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XSetClipMask(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetClipOrigin(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: number): number;

declare function XSetClipRectangles(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: number, p5: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p6: number, p7: number): number;

declare function XSetCloseDownMode(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XSetCommand(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, p4: number): number;

declare function XSetDashes(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p5: number): number;

declare function XSetErrorHandler(p1: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null, p2: interop.Pointer | interop.Reference<XErrorEvent> | null) => number>): interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null, p2: interop.Pointer | interop.Reference<XErrorEvent> | null) => number>;

declare function XSetFillRule(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetFillStyle(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetFont(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetFontPath(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetForeground(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetFunction(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetGraphicsExposures(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetICFocus(p1: interop.Pointer | interop.Reference<_XIC> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XSetICValues(p1: interop.Pointer | interop.Reference<_XIC> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): interop.Pointer | interop.Reference<any> | null;

declare function XSetIMValues(p1: interop.Pointer | interop.Reference<_XIM> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): interop.Pointer | interop.Reference<any> | null;

declare function XSetIOErrorExitHandler(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null, p2: interop.Pointer | interop.Reference<any> | null) => void>, p3: interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XSetIOErrorHandler(p1: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null) => number>): interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null) => number>;

declare function XSetIconName(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XSetIconSizes(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XIconSize> | ArrayBufferLike | ArrayBufferView | null, p4: number): number;

declare function XSetInputFocus(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number): number;

declare function XSetLineAttributes(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: number, p5: number, p6: number): number;

declare function XSetLocaleModifiers(p1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function XSetModifierMapping(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XModifierKeymap> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XSetNormalHints(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XSetOCValues(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): interop.Pointer | interop.Reference<any> | null;

declare function XSetOMValues(p1: interop.Pointer | interop.Reference<_XOM> | ArrayBufferLike | ArrayBufferView | null, ...args: any[]): interop.Pointer | interop.Reference<any> | null;

declare function XSetPlaneMask(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetPointerMapping(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetRGBColormaps(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XStandardColormap> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number): void;

declare function XSetRegion(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XSetScreenSaver(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number): number;

declare function XSetSelectionOwner(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number): number;

declare function XSetSizeHints(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null, p4: number): number;

declare function XSetStandardColormap(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XStandardColormap> | ArrayBufferLike | ArrayBufferView | null, p4: number): void;

declare function XSetStandardProperties(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, p7: number, p8: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XSetState(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: number, p5: number, p6: number): number;

declare function XSetStipple(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetSubwindowMode(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetTSOrigin(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: number): number;

declare function XSetTextProperty(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null, p4: number): void;

declare function XSetTile(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XSetTransientForHint(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XSetWMClientMachine(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XSetWMColormapWindows(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p4: number): number;

declare function XSetWMHints(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XWMHints> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XSetWMIconName(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XSetWMName(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XSetWMNormalHints(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XSetWMProperties(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, p6: number, p7: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null, p8: interop.Pointer | interop.Reference<XWMHints> | ArrayBufferLike | ArrayBufferView | null, p9: interop.Pointer | interop.Reference<XClassHint> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XSetWMProtocols(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p4: number): number;

declare function XSetWMSizeHints(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null, p4: number): void;

interface XSetWindowAttributes {
	background_pixmap: number;
	background_pixel: number;
	border_pixmap: number;
	border_pixel: number;
	bit_gravity: number;
	win_gravity: number;
	backing_store: number;
	backing_planes: number;
	backing_pixel: number;
	save_under: number;
	event_mask: number;
	do_not_propagate_mask: number;
	override_redirect: number;
	colormap: number;
	cursor: number;
}
declare var XSetWindowAttributes: interop.StructType<XSetWindowAttributes>;

declare function XSetWindowBackground(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XSetWindowBackgroundPixmap(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XSetWindowBorder(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XSetWindowBorderPixmap(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XSetWindowBorderWidth(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XSetWindowColormap(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XSetZoomHints(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XShrinkRegion(p1: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

interface XSizeHints {
	flags: number;
	x: number;
	y: number;
	width: number;
	height: number;
	min_width: number;
	min_height: number;
	max_width: number;
	max_height: number;
	width_inc: number;
	height_inc: number;
	min_aspect: { x: number; y: number; };
	max_aspect: { x: number; y: number; };
	base_width: number;
	base_height: number;
	win_gravity: number;
}
declare var XSizeHints: interop.StructType<XSizeHints>;

interface XStandardColormap {
	colormap: number;
	red_max: number;
	red_mult: number;
	green_max: number;
	green_mult: number;
	blue_max: number;
	blue_mult: number;
	base_pixel: number;
	visualid: number;
	killid: number;
}
declare var XStandardColormap: interop.StructType<XStandardColormap>;

declare function XStoreBuffer(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: number): number;

declare function XStoreBytes(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XStoreColor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XStoreColors(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XColor> | ArrayBufferLike | ArrayBufferView | null, p4: number): number;

declare function XStoreName(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XStoreNamedColor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number): number;

declare function XStringListToTextProperty(p1: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XStringToKeysym(p1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XSubtractRegion(p1: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XSupportsLocale(): number;

declare function XSync(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XSynchronize(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null) => number>;

declare function XTextExtents(p1: interop.Pointer | interop.Reference<XFontStruct> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p7: interop.Pointer | interop.Reference<XCharStruct> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XTextExtents16(p1: interop.Pointer | interop.Reference<XFontStruct> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XChar2b> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p7: interop.Pointer | interop.Reference<XCharStruct> | ArrayBufferLike | ArrayBufferView | null): number;

interface XTextItem {
	chars: interop.Pointer | interop.Reference<any> | null;
	nchars: number;
	delta: number;
	font: number;
}
declare var XTextItem: interop.StructType<XTextItem>;

interface XTextItem16 {
	chars: interop.Pointer | interop.Reference<XChar2b> | null;
	nchars: number;
	delta: number;
	font: number;
}
declare var XTextItem16: interop.StructType<XTextItem16>;

interface XTextProperty {
	value: interop.Pointer | interop.Reference<any> | null;
	encoding: number;
	format: number;
	nitems: number;
}
declare var XTextProperty: interop.StructType<XTextProperty>;

declare function XTextPropertyToStringList(p1: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XTextWidth(p1: interop.Pointer | interop.Reference<XFontStruct> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XTextWidth16(p1: interop.Pointer | interop.Reference<XFontStruct> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XChar2b> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

interface XTimeCoord {
	time: number;
	x: number;
	y: number;
}
declare var XTimeCoord: interop.StructType<XTimeCoord>;

declare function XTranslateCoordinates(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p7: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p8: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XUndefineCursor(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XUngrabButton(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number): number;

declare function XUngrabKey(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number): number;

declare function XUngrabKeyboard(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XUngrabPointer(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XUngrabServer(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XUninstallColormap(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XUnionRectWithRegion(p1: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XUnionRegion(p1: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XUnloadFont(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XUnlockDisplay(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): void;

interface XUnmapEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	event: number;
	window: number;
	from_configure: number;
}
declare var XUnmapEvent: interop.StructType<XUnmapEvent>;

declare function XUnmapSubwindows(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XUnmapWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XUnregisterIMInstantiateCallback(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XrmHashBucketRec> | ArrayBufferLike | ArrayBufferView | null, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p5: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null, p2: interop.Pointer | interop.Reference<any> | null, p3: interop.Pointer | interop.Reference<any> | null) => void>, p6: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XUnsetICFocus(p1: interop.Pointer | interop.Reference<_XIC> | ArrayBufferLike | ArrayBufferView | null): void;

declare const XUrgencyHint: number;

declare function XVaCreateNestedList(p1: number, ...args: any[]): interop.Pointer | interop.Reference<any> | null;

declare const XValue: number;

declare function XVendorRelease(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null): number;

interface XVisibilityEvent {
	type: number;
	serial: number;
	send_event: number;
	display: interop.Pointer | interop.Reference<Display> | null;
	window: number;
	state: number;
}
declare var XVisibilityEvent: interop.StructType<XVisibilityEvent>;

declare function XVisualIDFromVisual(p1: interop.Pointer | interop.Reference<Visual> | ArrayBufferLike | ArrayBufferView | null): number;

interface XVisualInfo {
	visual: interop.Pointer | interop.Reference<Visual> | null;
	visualid: number;
	screen: number;
	depth: number;
	class: number;
	red_mask: number;
	green_mask: number;
	blue_mask: number;
	colormap_size: number;
	bits_per_rgb: number;
}
declare var XVisualInfo: interop.StructType<XVisualInfo>;

declare function XWMGeometry(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null, p7: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p8: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p9: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p10: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p11: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

interface XWMHints {
	flags: number;
	input: number;
	initial_state: number;
	icon_pixmap: number;
	icon_window: number;
	icon_x: number;
	icon_y: number;
	icon_mask: number;
	window_group: number;
}
declare var XWMHints: interop.StructType<XWMHints>;

declare function XWarpPointer(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: number, p5: number, p6: number, p7: number, p8: number, p9: number): number;

declare function XWhitePixel(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

declare function XWhitePixelOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XWidthMMOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XWidthOfScreen(p1: interop.Pointer | interop.Reference<Screen> | ArrayBufferLike | ArrayBufferView | null): number;

interface XWindowAttributes {
	x: number;
	y: number;
	width: number;
	height: number;
	border_width: number;
	depth: number;
	visual: interop.Pointer | interop.Reference<Visual> | null;
	root: number;
	class: number;
	bit_gravity: number;
	win_gravity: number;
	backing_store: number;
	backing_planes: number;
	backing_pixel: number;
	save_under: number;
	colormap: number;
	map_installed: number;
	map_state: number;
	all_event_masks: number;
	your_event_mask: number;
	do_not_propagate_mask: number;
	override_redirect: number;
	screen: interop.Pointer | interop.Reference<Screen> | null;
}
declare var XWindowAttributes: interop.StructType<XWindowAttributes>;

interface XWindowChanges {
	x: number;
	y: number;
	width: number;
	height: number;
	border_width: number;
	sibling: number;
	stack_mode: number;
}
declare var XWindowChanges: interop.StructType<XWindowChanges>;

declare function XWindowEvent(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number, p4: interop.Pointer | interop.Reference<XEvent> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XWithdrawWindow(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: number): number;

declare function XWriteBitmapFile(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: number, p5: number, p6: number, p7: number): number;

declare function XXorRegion(p1: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<_XRegion> | ArrayBufferLike | ArrayBufferView | null): number;

declare const XYBitmap: number;

declare const XYPixmap: number;

declare const X_HAVE_UTF8_STRING: number;

declare const X_PROTOCOL: number;

declare const X_PROTOCOL_REVISION: number;

declare const XlibSpecificationRelease: number;

declare function XmbDrawImageString(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: number, p7: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p8: number): void;

declare function XmbDrawString(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: number, p7: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p8: number): void;

declare function XmbDrawText(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: interop.Pointer | interop.Reference<XmbTextItem> | ArrayBufferLike | ArrayBufferView | null, p7: number): void;

declare function XmbLookupString(p1: interop.Pointer | interop.Reference<_XIC> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XKeyEvent> | ArrayBufferLike | ArrayBufferView | null, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XmbResetIC(p1: interop.Pointer | interop.Reference<_XIC> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function XmbSetWMProperties(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, p6: number, p7: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null, p8: interop.Pointer | interop.Reference<XWMHints> | ArrayBufferLike | ArrayBufferView | null, p9: interop.Pointer | interop.Reference<XClassHint> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XmbTextEscapement(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XmbTextExtents(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null): number;

interface XmbTextItem {
	chars: interop.Pointer | interop.Reference<any> | null;
	nchars: number;
	delta: number;
	font_set: interop.Pointer | interop.Reference<_XOC> | null;
}
declare var XmbTextItem: interop.StructType<XmbTextItem>;

declare function XmbTextListToTextProperty(display: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, list: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, count: number, style: XICCEncodingStyle, text_prop_return: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XmbTextPerCharExtents(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p6: number, p7: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p8: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p9: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XmbTextPropertyToTextList(display: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, text_prop: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null, list_return: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null> | ArrayBufferLike | ArrayBufferView | null, count_return: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XrmInitialize(): void;

declare function Xutf8DrawImageString(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: number, p7: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p8: number): void;

declare function Xutf8DrawString(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: number, p7: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p8: number): void;

declare function Xutf8DrawText(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: interop.Pointer | interop.Reference<XmbTextItem> | ArrayBufferLike | ArrayBufferView | null, p7: number): void;

declare function Xutf8LookupString(p1: interop.Pointer | interop.Reference<_XIC> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XKeyEvent> | ArrayBufferLike | ArrayBufferView | null, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function Xutf8ResetIC(p1: interop.Pointer | interop.Reference<_XIC> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<any> | null;

declare function Xutf8SetWMProperties(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p4: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, p6: number, p7: interop.Pointer | interop.Reference<XSizeHints> | ArrayBufferLike | ArrayBufferView | null, p8: interop.Pointer | interop.Reference<XWMHints> | ArrayBufferLike | ArrayBufferView | null, p9: interop.Pointer | interop.Reference<XClassHint> | ArrayBufferLike | ArrayBufferView | null): void;

declare function Xutf8TextEscapement(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function Xutf8TextExtents(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null): number;

declare function Xutf8TextListToTextProperty(display: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, list: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | ArrayBufferLike | ArrayBufferView | null, count: number, style: XICCEncodingStyle, text_prop_return: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null): number;

declare function Xutf8TextPerCharExtents(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p6: number, p7: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p8: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p9: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null): number;

declare function Xutf8TextPropertyToTextList(display: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, text_prop: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null, list_return: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<any> | null> | null> | ArrayBufferLike | ArrayBufferView | null, count_return: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XwcDrawImageString(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: number, p7: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p8: number): void;

declare function XwcDrawString(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p4: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p5: number, p6: number, p7: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p8: number): void;

declare function XwcDrawText(p1: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, p2: number, p3: interop.Pointer | interop.Reference<_XGC> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: number, p6: interop.Pointer | interop.Reference<XwcTextItem> | ArrayBufferLike | ArrayBufferView | null, p7: number): void;

declare function XwcFreeStringList(list: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null): void;

declare function XwcLookupString(p1: interop.Pointer | interop.Reference<_XIC> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<XKeyEvent> | ArrayBufferLike | ArrayBufferView | null, p3: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p4: number, p5: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p6: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XwcResetIC(p1: interop.Pointer | interop.Reference<_XIC> | ArrayBufferLike | ArrayBufferView | null): interop.Pointer | interop.Reference<number> | null;

declare function XwcTextEscapement(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

declare function XwcTextExtents(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null): number;

interface XwcTextItem {
	chars: interop.Pointer | interop.Reference<number> | null;
	nchars: number;
	delta: number;
	font_set: interop.Pointer | interop.Reference<_XOC> | null;
}
declare var XwcTextItem: interop.StructType<XwcTextItem>;

declare function XwcTextListToTextProperty(display: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, list: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | ArrayBufferLike | ArrayBufferView | null, count: number, style: XICCEncodingStyle, text_prop_return: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XwcTextPerCharExtents(p1: interop.Pointer | interop.Reference<_XOC> | ArrayBufferLike | ArrayBufferView | null, p2: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p3: number, p4: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p5: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p6: number, p7: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p8: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null, p9: interop.Pointer | interop.Reference<XRectangle> | ArrayBufferLike | ArrayBufferView | null): number;

declare function XwcTextPropertyToTextList(display: interop.Pointer | interop.Reference<Display> | ArrayBufferLike | ArrayBufferView | null, text_prop: interop.Pointer | interop.Reference<XTextProperty> | ArrayBufferLike | ArrayBufferView | null, list_return: interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<interop.Pointer | interop.Reference<number> | null> | null> | ArrayBufferLike | ArrayBufferView | null, count_return: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null): number;

declare const YNegative: number;

declare const YSorted: number;

declare const YValue: number;

declare const YXBanded: number;

declare const YXSorted: number;

declare const ZPixmap: number;

declare const ZoomState: number;

interface _XGC {
}
declare var _XGC: interop.StructType<_XGC>;

interface _XIC {
}
declare var _XIC: interop.StructType<_XIC>;

interface _XIM {
}
declare var _XIM: interop.StructType<_XIM>;

interface _XOC {
}
declare var _XOC: interop.StructType<_XOC>;

interface _XOM {
}
declare var _XOM: interop.StructType<_XOM>;

interface _XPrivate {
}
declare var _XPrivate: interop.StructType<_XPrivate>;

interface _XRegion {
}
declare var _XRegion: interop.StructType<_XRegion>;

declare var _Xdebug: number;

declare function _Xmblen(str: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, len: number): number;

declare function _Xmbtowc(p1: interop.Pointer | interop.Reference<number> | ArrayBufferLike | ArrayBufferView | null, p2: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p3: number): number;

interface _XrmHashBucketRec {
}
declare var _XrmHashBucketRec: interop.StructType<_XrmHashBucketRec>;

declare function _Xwctomb(p1: string | interop.Pointer | interop.Reference<any> | ArrayBufferLike | ArrayBufferView | null, p2: number): number;

interface funcs {
	create_image: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<Display> | null, p2: interop.Pointer | interop.Reference<Visual> | null, p3: number, p4: number, p5: number, p6: interop.Pointer | interop.Reference<any> | null, p7: number, p8: number, p9: number, p10: number) => interop.Pointer | interop.Reference<XImage> | null>;
	destroy_image: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<XImage> | null) => number>;
	get_pixel: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<XImage> | null, p2: number, p3: number) => number>;
	put_pixel: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<XImage> | null, p2: number, p3: number, p4: number) => number>;
	sub_image: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<XImage> | null, p2: number, p3: number, p4: number, p5: number) => interop.Pointer | interop.Reference<XImage> | null>;
	add_pixel: interop.FunctionReference<(p1: interop.Pointer | interop.Reference<XImage> | null, p2: number) => number>;
}
declare var funcs: interop.StructType<funcs>;
